// GuiN 安卓版 1.1.4 新功能端到端验证（WebView CDP 驱动真实 APK）
// 前置：pm clear com.guina.app.debug && pm grant POST_NOTIFICATIONS/CAMERA && am start ...
import { execSync } from 'node:child_process'
import fs from 'node:fs'
import { check as baseCheck, ev, bodyText, shot, waitFor, waitText, sheetOpen, sheetText, summary, sleep } from './mobile-e2e.mjs'

// 每条断言即时打印，失败时可定位到具体步骤
const check = function (name, ok, detail) {
  console.log((ok ? 'PASS ' : 'FAIL ') + name + (ok || !detail ? '' : ' :: ' + detail))
  baseCheck(name, ok, detail)
}

const ADB = process.env.ADB || 'F:/Android/sdk/platform-tools/adb.exe'
const OUT = process.env.SHOT_DIR || '.tmp-shots/android'
fs.mkdirSync(OUT, { recursive: true })

const c = await (await import('./cdp.mjs')).connect(Number(process.env.CDP_PORT || 9333), 'app.local')
await c.send('Page.enable')
await c.send('Runtime.enable')
await c.send('Input.enable').catch(function () {})

async function ev2(expr) {
  return c.evaluate(expr)
}

/** 元素中心坐标；找不到返回 null */
async function center(sel, text) {
  const raw = await ev2(`(() => {
    const scope = document;
    const list = [...scope.querySelectorAll(${JSON.stringify(sel)})];
    const el = ${text ? `list.find((e) => ((e.innerText || e.textContent || '') + '').replace(/\\s+/g, ' ').trim().includes(` + JSON.stringify(text) + `))` : 'list[0]'}
    if (!el) return 'null';
    el.scrollIntoView({ block: 'center', inline: 'center' });
    const r = el.getBoundingClientRect();
    return JSON.stringify({ x: r.left + r.width / 2, y: r.top + r.height / 2, w: r.width, h: r.height, text: (el.innerText || '').slice(0, 20) });
  })()`)
  if (!raw || raw === 'null') return null
  return JSON.parse(raw)
}

async function mouse(type, x, y) {
  await c.send('Input.dispatchMouseEvent', { type, x, y, button: 'left', clickCount: 1 })
}
async function tap(sel, text) {
  const p = await center(sel, text)
  if (!p) return false
  await mouse('mouseMoved', p.x, p.y)
  await mouse('mousePressed', p.x, p.y)
  await sleep(60)
  await mouse('mouseReleased', p.x, p.y)
  await sleep(260)
  return true
}
async function longPress(sel, text, hold) {
  const p = await center(sel, text)
  if (!p) return false
  await mouse('mouseMoved', p.x, p.y)
  await mouse('mousePressed', p.x, p.y)
  await sleep(hold || 700)
  await mouse('mouseReleased', p.x, p.y)
  await sleep(300)
  return true
}
async function drag(fromSel, fromText, toSel, toText) {
  const a = await center(fromSel, fromText)
  const b = await center(toSel, toText)
  if (!a || !b) return null
  await mouse('mouseMoved', a.x, a.y)
  await mouse('mousePressed', a.x, a.y)
  await sleep(750)
  for (let i = 1; i <= 6; i++) {
    const x = a.x + ((b.x - a.x) * i) / 6
    const y = a.y + ((b.y - a.y) * i) / 6
    await c.send('Input.dispatchMouseEvent', { type: 'mouseMoved', x, y, button: 'left' })
    await sleep(80)
  }
  await mouse('mouseReleased', b.x, b.y)
  await sleep(400)
  return true
}
async function tapText(text, sel) {
  return tap(sel || 'button,.btn,.tab,.chip,.row,.about-link', text)
}
async function readState() {
  const raw = await ev2('window.GuinaNative.loadData()')
  return JSON.parse(raw)
}
async function readSyncConfig() {
  const raw = await ev2('window.GuinaNative.loadSyncConfig()')
  if (!raw || !String(raw).trim()) return null
  return JSON.parse(raw)
}
/** 点某一行右侧的按钮（设置页 row 本身不可点） */
async function tapRowButton(title) {
  const raw = await ev2(`(() => {
    const rows = [...document.querySelectorAll('.row')];
    const row = rows.find((r) => ((r.querySelector('.row-title') || {}).textContent || '').includes(${JSON.stringify(title)}));
    if (!row) return 'null';
    const b = row.querySelector('button');
    if (!b) return 'null';
    b.scrollIntoView({ block: 'center' });
    const r = b.getBoundingClientRect();
    return JSON.stringify({ x: r.left + r.width / 2, y: r.top + r.height / 2 });
  })()`)
  if (!raw || raw === 'null') return false
  const p = JSON.parse(raw)
  await mouse('mouseMoved', p.x, p.y)
  await mouse('mousePressed', p.x, p.y)
  await mouse('mouseReleased', p.x, p.y)
  await sleep(350)
  return true
}
async function closeSheetIfOpen() {
  if (await sheetOpen()) {
    const p = await center('.sheet-head button')
    if (p) { await mouse('mouseMoved', p.x, p.y); await mouse('mousePressed', p.x, p.y); await mouse('mouseReleased', p.x, p.y); await sleep(300) }
  }
}
function adb(shell) {
  try { return execSync('"' + ADB + '" ' + shell, { encoding: 'utf8', timeout: 20000 }) } catch (e) { return String((e && e.stdout) || '') }
}
function orderOf(state, names) {
  const list = state.categories.slice().sort(function (a, b) {
    const sa = a.pinned || a.builtin ? 0 : 1
    const sb = b.pinned || b.builtin ? 0 : 1
    if (sa !== sb) return sa - sb
    return (a.order || 0) - (b.order || 0)
  })
  return list.map(function (c) { return c.name })
}

// ---------- 准备：跳过引导 ----------
if ((await bodyText()).includes('跳过')) {
  await tapText('跳过')
  await sleep(1200)
}
await waitFor(async function () { return (await ev2('!!document.querySelector(".tabbar")')) }, 8000)

async function goHome() {
  await tap('.tab', '首页')
  await sleep(700)
}
async function openSettings() {
  await tap('.tab', '设置')
  await sleep(700)
}

// ---------- A. 便签：长按删除 + 长按 + 多选删除 ----------
await goHome()
const beforeState = await readState()
check('A0 测试前便签为空', beforeState.stickies.length === 0, 'stickies=' + beforeState.stickies.length)

async function createSticky(kind, content, title) {
  const add = await tap('.sticky-col[data-kind="' + kind + '"] .sticky-col-add')
  if (!add) return false
  await waitFor(async function () { return await sheetOpen() }, 5000)
  // 空内容保存 → 内容必填（只测便签列一次）
  await setFieldText('内容', content)
  if (title) await setFieldText('标题', title)
  await tapText('保存')
  await sleep(700)
  return !(await sheetOpen())
}
async function setFieldText(label, value) {
  return ev2(`(() => {
    const fields = [...document.querySelectorAll('.field')];
    const f = fields.find((x) => { const l = (x.querySelector('.field-label') || {}).textContent || ''; return l.trim().split('*')[0].trim() === ${JSON.stringify(label)}; });
    if (!f) return 'NO_FIELD';
    const el = f.querySelector('input,textarea,select');
    if (!el) return 'NO_INPUT';
    const proto = el.tagName === 'TEXTAREA' ? window.HTMLTextAreaElement.prototype : window.HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, 'value').set;
    setter.call(el, ${JSON.stringify(value)});
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    return 'OK';
  })()`)
}

// 新建便签一：先验证内容必填
await tap('.sticky-col[data-kind="note"] .sticky-col-add')
await waitFor(async function () { return await sheetOpen() }, 5000)
await tapText('保存')
await sleep(400)
check('A1 便签内容为空时提示必填', (await sheetText()).includes('写点什么吧，内容不能为空'))
await setFieldText('内容', '测试便签一')
await tapText('保存')
await sleep(800)
check('A2 便签创建成功', !(await sheetOpen()) && (await bodyText()).includes('测试便签一'))
check('A3 创建便签 toast 正确', await waitText('便签已创建', 3000))

// 新建便签二
await tap('.sticky-col[data-kind="note"] .sticky-col-add')
await waitFor(async function () { return await sheetOpen() }, 5000)
await setFieldText('内容', '测试便签二')
await tapText('保存')
await waitFor(async function () { return (await bodyText()).includes('测试便签二') }, 6000)

// 长按卡片 → 删除按钮
const cards = await ev2('document.querySelectorAll(".sticky-col[data-kind=note] .sticky-card-wrap").length')
check('A4 便签列有两张卡片', cards === 2, 'cards=' + cards)
await longPress('.sticky-col[data-kind="note"] .sticky-card', '测试便签一', 700)
check('A5 长按便签卡片出现删除按钮', await waitFor(async function () { return await ev2('!!document.querySelector(".sticky-card-actions .sticky-card-delete")') }, 3000))
await tap('.sticky-card-delete')
await sleep(400)
check('A6 删除卡片弹出确认框', await waitFor(async function () { return await ev2('!!document.querySelector(".confirm-card")') }, 3000))
check('A7 确认框标题正确', (await ev2('(document.querySelector(".confirm-title")||{}).textContent || ""')).includes('删除这条便签'))
await tap('.confirm-actions .btn', '删除')
await sleep(1000)
const afterDel = await readState()
check('A8 长按删除后便签只剩一条', afterDel.stickies.filter(function (s) { return s.kind === 'note' }).length === 1, JSON.stringify(afterDel.stickies.map(function (s) { return s.content })))
check('A9 长按删除 toast 正确', await waitText('已删除', 3000))
await shot('114-A-sticky-longpress-delete')

// 长按 + 进入多选管理，全选删除
await longPress('.sticky-col[data-kind="note"] .sticky-col-add', null, 800)
check('A10 长按 + 进入多选管理', await waitFor(async function () { return await ev2('!!document.querySelector(".sticky-manage-bar")') }, 4000))
check('A11 管理态 + 按钮 aria-label 变化', (await ev2('(document.querySelector(".sticky-col[data-kind=note] .sticky-col-add")||{}).getAttribute("aria-label")')) === '完成管理便签')
await tap('.sticky-col[data-kind="note"] .sticky-card')
await sleep(300)
check('A12 选中一张便签后显示已选 1 条', (await ev2('(document.querySelector(".sticky-manage-bar")||{}).innerText || ""')).includes('已选 1 条'))
await tap('.sticky-manage-bar .link-btn', '全选')
await sleep(300)
check('A13 全选后仍为 1 条', (await ev2('(document.querySelector(".sticky-manage-bar")||{}).innerText || ""')).includes('已选 1 条'))
await tap('.sticky-manage-bar .link-btn', '删除所选')
await waitFor(async function () { return await ev2('!!document.querySelector(".confirm-card")') }, 4000)
await tap('.confirm-actions .btn', '删除')
await sleep(1000)
const afterMulti = await readState()
check('A14 多选删除后便签清空', afterMulti.stickies.filter(function (s) { return s.kind === 'note' }).length === 0)
check('A15 多选删除 toast 正确', await waitText('已删除 1 个便签', 3000))

// 提醒便签列同样支持长按 + 多选删除
await createSticky('reminder', '提醒内容一', '提醒一')
await sleep(400)
await createSticky('reminder', '提醒内容二', '提醒二')
await sleep(600)
const remCount = (await readState()).stickies.filter(function (s) { return s.kind === 'reminder' }).length
check('A16 提醒便签创建两条', remCount === 2, 'reminders=' + remCount)
await longPress('.sticky-col[data-kind="reminder"] .sticky-col-add', null, 800)
await waitFor(async function () { return await ev2('!!document.querySelector(".sticky-manage-bar")') }, 4000)
await tap('.sticky-manage-bar .link-btn', '全选')
await sleep(300)
await tap('.sticky-manage-bar .link-btn', '删除所选')
await waitFor(async function () { return await ev2('!!document.querySelector(".confirm-card")') }, 4000)
await tap('.confirm-actions .btn', '删除')
await sleep(1000)
check('A17 提醒便签多选删除 toast 正确', await waitText('已删除 2 个提醒便签', 4000))
check('A18 提醒便签已全部删除', (await readState()).stickies.filter(function (s) { return s.kind === 'reminder' }).length === 0)

// ---------- B. 我的分类管理：多选删除 ----------
async function createCategory(name) {
  await tapText('+ 新建分类')
  await waitFor(async function () { return await sheetOpen() }, 5000)
  await setFieldText('分类名称', name)
  await tapText('保存')
  await sleep(800)
  return !(await sheetOpen())
}
await goHome()
await createCategory('测试分类甲')
await sleep(300)
await createCategory('测试分类乙')
await sleep(600)
check('B1 新建两个分类成功', (await readState()).categories.filter(function (c) { return c.name.indexOf('测试分类') === 0 }).length === 2)
await tap('[data-testid="category-manage"]')
await sleep(400)
check('B2 进入分类管理态', await waitFor(async function () { return await ev2('!!document.querySelector(".cat-manage-bar")') }, 3000))
await tap('.cat-card', '测试分类甲')
await sleep(300)
check('B3 选中一个分类显示已选 1 个', (await ev2('(document.querySelector(".cat-manage-bar")||{}).innerText || ""')).includes('已选 1 个'))
await tap('.cat-manage-bar .link-btn', '全选')
await sleep(300)
check('B4 全选只选中非内置分类', (await ev2('(document.querySelector(".cat-manage-bar")||{}).innerText || ""')).includes('已选 2 个'), await ev2('(document.querySelector(".cat-manage-bar")||{}).innerText || ""'))
await tap('.cat-manage-bar .link-btn', '删除所选')
check('B5 分类多选删除有确认框', await waitFor(async function () { return await ev2('!!document.querySelector(".confirm-card")') }, 4000))
await tap('.confirm-actions .btn', '删除')
await sleep(1200)
check('B6 分类多选删除 toast 正确', await waitText('已删除 2 个分类', 4000))
const catsAfter = await readState()
check('B7 两个测试分类已删除', catsAfter.categories.filter(function (c) { return c.name.indexOf('测试分类') === 0 }).length === 0)
check('B8 内置四个分类仍在', catsAfter.categories.filter(function (c) { return c.builtin }).length === 4)
// 只有内置分类时全选无法删除（B6 删除成功后管理态已自动退出，需重新进入）
await tap('[data-testid="category-manage"]')
await waitFor(async function () { return await ev2('!!document.querySelector(".cat-manage-bar")') }, 3000)
await tap('.cat-manage-bar .link-btn', '全选')
await sleep(300)
await tap('.cat-manage-bar .link-btn', '删除所选')
await sleep(500)
check('B9 无普通分类时提示先选择分类', await waitText('先选择要删除的分类', 4000))
await tap('.section-head .link-btn', '完成')
await sleep(400)
check('B10 退出分类管理态', !(await ev2('!!document.querySelector(".cat-manage-bar")')))
await shot('114-B-category-manage')

// ---------- C. 分类长按拖拽排序 ----------
await createCategory('拖拽分类甲')
await sleep(300)
await createCategory('拖拽分类乙')
await sleep(600)
let cats = await readState()
const names0 = orderOf(cats, [])
check('C1 新建分类排在普通区末尾', names0.indexOf('拖拽分类甲') > names0.indexOf('食品') && names0.indexOf('拖拽分类乙') === names0.length - 1, names0.join('|'))
await drag('.cat-card', '拖拽分类甲', '.cat-card', '拖拽分类乙')
check('C2 同组拖拽提示顺序已调整', await waitText('分类顺序已调整', 4000))
cats = await readState()
const names1 = orderOf(cats, [])
check('C3 同组拖拽后位置互换', names1.indexOf('拖拽分类乙') < names1.indexOf('拖拽分类甲'), names1.join('|'))
check('C4 内置分类位置不受影响', names1.slice(0, 4).join('|') === '图书|物品|食品|药品', names1.join('|'))
const ordersBefore = {}
cats.categories.forEach(function (c) { ordersBefore[c.id] = c.order })
await drag('.cat-card', '拖拽分类甲', '.cat-card', '图书')
await sleep(600)
check('C5 普通分类拖到内置分类提示跨组', await waitText('普通分类只能和普通分类换位置', 4000))
cats = await readState()
let sameOrder = true
cats.categories.forEach(function (c) { if (ordersBefore[c.id] !== c.order) sameOrder = false })
check('C6 跨组拖拽不改变顺序', sameOrder, JSON.stringify(cats.categories.map(function (c) { return c.name + ':' + c.order })))
await drag('.cat-card', '药品', '.cat-card', '图书')
check('C7 内置分类之间可拖拽', await waitText('分类顺序已调整', 4000))
cats = await readState()
const namesSpecial = orderOf(cats, [])
check('C8 内置分类顺序调整生效', namesSpecial[0] === '药品' && namesSpecial[1] === '图书', namesSpecial.join('|'))
await shot('114-C-category-drag')

// ---------- D. 提醒便签：标题必填 + 一键导入系统闹钟 ----------
await goHome()
await tap('.sticky-col[data-kind="reminder"] .sticky-col-add')
await waitFor(async function () { return await sheetOpen() }, 5000)
check('D1 新建提醒便签弹窗标题正确', (await sheetText()).includes('新建提醒便签'))
await tapText('保存')
await sleep(400)
check('D2 提醒内容为空提示必填', (await sheetText()).includes('写点什么吧，内容不能为空'))
await setFieldText('内容', '现在喝一杯水吧')
await tapText('保存')
await sleep(400)
check('D3 提醒标题为空提示必填', (await sheetText()).includes('提醒便签需要填标题'))
await setFieldText('标题', '喝水提醒')
await sleep(300)
check('D4 提醒方式出现保存并导入闹钟按钮', (await ev2(`[...document.querySelectorAll('.sheet-foot button,.sheet-panel button')].some((b) => (b.innerText || '').includes('保存并导入闹钟'))`)))
adb('logcat -c')
await tapText('保存并导入闹钟')
await sleep(1500)
check('D5 导入闹钟后弹窗关闭', !(await sheetOpen()))
check('D6 导入闹钟 toast 正确', await waitText('已保存，并导入到系统闹钟', 5000))
const alarmState = await readState()
const alarmSticky = alarmState.stickies.filter(function (s) { return s.title === '喝水提醒' })[0]
check('D7 提醒便签已保存且带提醒时间', Boolean(alarmSticky && alarmSticky.kind === 'reminder' && alarmSticky.remindAt), JSON.stringify(alarmSticky && { title: alarmSticky.title, kind: alarmSticky.kind, remindAt: alarmSticky.remindAt }))
// 系统时钟的 HandleSetApiCalls 在 SKIP_UI 下创建任务后立即 finish，前台不会停留；用 logcat 里它被启动的记录作为系统已收到导入请求的证据
let clockLog = ''
for (let i = 0; i < 12 && clockLog.indexOf('HandleSetApiCalls') < 0; i++) {
  await sleep(500)
  clockLog = adb('logcat -d -t 800')
}
const clockHit = (clockLog.match(/[^\n]*HandleSetApiCalls[^\n]*/g) || [])[0] || ''
check('D8 系统时钟已收到导入请求', clockHit.indexOf('HandleSetApiCalls') >= 0, clockHit.slice(0, 180))
// 回到 GuiN
adb('shell am start -n com.guina.app.debug/com.guina.app.MainActivity')
await sleep(2500)
await waitFor(async function () { return (await bodyText()).length > 0 }, 8000)

// ---------- E. 数据同步：备注 + 在线检测 ----------
const syncCfgRaw = await ev2('window.GuinaNative.loadSyncConfig()')
const syncCfg = syncCfgRaw && String(syncCfgRaw).trim() ? JSON.parse(syncCfgRaw) : null
check('E1 同步配置已初始化', Boolean(syncCfg && syncCfg.identity), syncCfgRaw ? String(syncCfgRaw).slice(0, 80) : 'empty')
const injected = syncCfg || { version: 1, identity: { deviceId: 'dev-114', peerId: 'guina-114-peer', name: '测试手机', machineCode: 'AAAA-114', kind: 'android', platform: 'Android 15', appVersion: '1.1.4' }, bindings: [] }
injected.bindings = [{
  deviceId: 'peer-114-desktop',
  peerId: 'guina-114-desktop-peer',
  name: '旧设备名',
  alias: '书房的电脑',
  machineCode: 'TEST-114-DESK',
  kind: 'desktop',
  platform: 'Windows 11',
  appVersion: '1.1.3',
  syncKey: 'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=',
  boundAt: new Date().toISOString(),
  lastSyncAt: null,
  lastMode: null,
  lastSeenAt: null
}]
await ev2('window.GuinaNative.saveSyncConfig(' + JSON.stringify(JSON.stringify(injected)) + ')')
await ev2('location.reload()')
await sleep(2500)
await waitFor(async function () { return (await ev2('!!document.querySelector(".tabbar")')) }, 15000)
await openSettings()
check('E2a 设置页可打开数据同步', await tapRowButton('数据同步'))
await waitFor(async function () { return await sheetOpen() }, 8000)
await sleep(1200)
const syncText = await sheetText()
check('E2 已绑定设备卡片出现', await waitFor(async function () { return await ev2('!!document.querySelector("[data-testid=sync-binding]")') }, 8000))
check('E3 备注优先显示为设备名', (await ev2('(document.querySelector("[data-testid=sync-binding-name]")||{}).textContent || ""')).includes('书房的电脑'))
check('E4 显示备注标签', (await ev2('!!document.querySelector(".sync-alias-chip")')))
check('E5 未检测时徽标为未检测', (await ev2('(document.querySelector("[data-testid=sync-online-badge]")||{}).textContent || ""')).includes('未检测'))
check('E6 卡片显示机器码与最后在线', (await ev2('(document.querySelector("[data-testid=sync-binding-meta]")||{}).textContent || ""')).includes('TEST-114-DESK'))
await shot('114-E-sync-binding')
// 编辑备注
await tap('[data-testid="sync-alias-edit"]')
await sleep(400)
check('E7 备注输入框带出当前备注', (await ev2('(document.querySelector("[data-testid=sync-alias-input]")||{}).value || ""')) === '书房的电脑')
await ev2(`(() => { const el = document.querySelector('[data-testid="sync-alias-input"]'); const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set; setter.call(el, '书房的笔记本'); el.dispatchEvent(new Event('input', { bubbles: true })); return 'OK'; })()`)
await tap('[data-testid="sync-alias-save"]')
await sleep(900)
check('E8 保存备注 toast 正确', await waitText('备注已保存为「书房的笔记本」', 5000))
const cfgAfterAlias = await readSyncConfig()
check('E9 备注已持久化', Boolean(cfgAfterAlias && cfgAfterAlias.bindings && cfgAfterAlias.bindings[0] && cfgAfterAlias.bindings[0].alias === '书房的笔记本'), JSON.stringify(cfgAfterAlias && cfgAfterAlias.bindings && cfgAfterAlias.bindings.map(function (b) { return b.alias })))
// 清除备注
await tap('[data-testid="sync-alias-edit"]')
await sleep(300)
await ev2(`(() => { const el = document.querySelector('[data-testid="sync-alias-input"]'); const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set; setter.call(el, ''); el.dispatchEvent(new Event('input', { bubbles: true })); return 'OK'; })()`)
await tap('[data-testid="sync-alias-save"]')
await sleep(900)
check('E10 清除备注 toast 正确', await waitText('已清除备注，恢复显示对方设备名', 5000))
check('E11 清除后备注标签消失且显示原名', !(await ev2('!!document.querySelector(".sync-alias-chip")')) && (await ev2('(document.querySelector("[data-testid=sync-binding-name]")||{}).textContent || ""')).includes('旧设备名'))
// 检测在线（对方不存在 → 离线）
await tap('[data-testid="sync-check-online"]')
check('E12 检测在线后徽标变离线', await waitFor(async function () {
  const t = (await ev2('(document.querySelector("[data-testid=sync-online-badge]")||{}).textContent || ""'))
  return t.includes('离线')
}, 30000))
check('E13 离线 toast 提示设备不在线', await waitText('设备不在线', 5000))

// ---------- F. 扫码绑定：默认后置主摄、画面等比不裁剪 ----------
await closeSheetIfOpen()
await sleep(400)
// 拦截 getUserMedia，记录约束并让摄像头失败（模拟器无相机）
await ev2(`(() => {
  window.__cams = [];
  const md = navigator.mediaDevices;
  md.getUserMedia = function (constraints) { window.__cams.push(constraints); return Promise.reject(new Error('test-camera-unavailable')); };
  return 'OK';
})()`)
await tapRowButton('数据同步')
await waitFor(async function () { return await sheetOpen() }, 8000)
await tapText('扫码绑定')
await sleep(1200)
const cams = await ev2('window.__cams || []')
check('F1 扫码请求后置主摄', Boolean(cams.length >= 1 && cams[0].video && cams[0].video.facingMode && cams[0].video.facingMode.exact === 'environment'), JSON.stringify(cams[0] || null))
check('F2 扫码请求相机分辨率理想值 1920x1080', Boolean(cams.length >= 1 && cams[0].video.width && cams[0].video.width.ideal === 1920 && cams[0].video.height && cams[0].video.height.ideal === 1080), JSON.stringify(cams[0] && cams[0].video))
const scanCss = await ev2(`(() => {
  let found = '';
  for (const sheet of [...document.styleSheets]) {
    let rules = [];
    try { rules = [...sheet.cssRules] } catch (e) { continue }
    for (const r of rules) { if (r.selectorText && r.selectorText.indexOf('scan-video') >= 0) found += r.cssText + ' ' }
  }
  return found;
})()`)
check('F3 扫码预览填满取景框（object-fit: cover）', scanCss.indexOf('object-fit: cover') >= 0 || scanCss.indexOf('object-fit:cover') >= 0, scanCss.slice(0, 160))
const scanPanelCss = await ev2(`(() => {
  let found = '';
  for (const sheet of [...document.styleSheets]) {
    let rules = [];
    try { rules = [...sheet.cssRules] } catch (e) { continue }
    for (const r of rules) { if (r.selectorText && r.selectorText.indexOf('scan-panel') >= 0) found += r.cssText + ' ' }
  }
  return found;
})()`)
check('F4 扫码改为卡片浮层（scan-panel 圆角面板）', scanPanelCss.indexOf('border-radius') >= 0 && scanPanelCss.indexOf('max-width') >= 0, scanPanelCss.slice(0, 200))

async function done() {
  await shot('114-final')
  summary()
}
await done()