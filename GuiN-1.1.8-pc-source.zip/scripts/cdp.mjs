// 极简 CDP 客户端：用于在真实运行的 Electron 应用上做端到端验证
export async function listTargets(port) {
  const res = await fetch('http://127.0.0.1:' + port + '/json/list')
  return res.json()
}

export async function connect(port, urlFilter) {
  const targets = await listTargets(port)
  const page = targets.find(function (t) {
    if (t.type !== 'page') return false
    return urlFilter ? t.url.indexOf(urlFilter) >= 0 : true
  })
  if (!page) throw new Error('no page target: ' + JSON.stringify(targets.map(function (t) { return t.url })))
  const ws = new WebSocket(page.webSocketDebuggerUrl)
  let id = 0
  const pending = new Map()
  const events = []
  await new Promise(function (resolve, reject) {
    ws.addEventListener('open', resolve, { once: true })
    ws.addEventListener('error', function (e) { reject(new Error('ws error')) }, { once: true })
  })
  ws.addEventListener('message', function (ev) {
    const msg = JSON.parse(String(ev.data))
    if (msg.id && pending.has(msg.id)) {
      const p = pending.get(msg.id)
      pending.delete(msg.id)
      if (msg.error) p.reject(new Error(msg.error.message))
      else p.resolve(msg.result)
    } else if (msg.method) {
      events.push(msg)
    }
  })
  function send(method, params) {
    return new Promise(function (resolve, reject) {
      const mid = ++id
      pending.set(mid, { resolve: resolve, reject: reject })
      ws.send(JSON.stringify({ id: mid, method: method, params: params || {} }))
    })
  }
  async function evaluate(expression, awaitPromise) {
    const res = await send('Runtime.evaluate', {
      expression: expression,
      awaitPromise: awaitPromise !== false,
      returnByValue: true,
      userGesture: true
    })
    if (res.exceptionDetails) {
      throw new Error('eval: ' + (res.exceptionDetails.exception && res.exceptionDetails.exception.description || res.exceptionDetails.text))
    }
    return res.result && res.result.value
  }
  const fs = await import('node:fs')
  async function shot(file) {
    const res = await send('Page.captureScreenshot', { format: 'png' })
    fs.mkdirSync('.tmp-shots', { recursive: true })
    fs.writeFileSync(file, Buffer.from(res.data, 'base64'))
    return file
  }
  function drain() { return events.splice(0) }
  return { page: page, send: send, evaluate: evaluate, shot: shot, drain: drain, close: function () { ws.close() } }
}

export async function waitFor(client, expression, timeoutMs, label) {
  const deadline = Date.now() + (timeoutMs || 8000)
  while (Date.now() < deadline) {
    try {
      const v = await client.evaluate(expression)
      if (v) return v
    } catch (e) { /* 页面可能正在刷新 */ }
    await new Promise(function (r) { setTimeout(r, 200) })
  }
  throw new Error('waitFor timeout: ' + (label || expression))
}

export const DOM_HELPERS = {
  byTest: function (id) { return document.querySelector('[data-testid="' + id + '"]') },
  clickTest: function (id) {
    const el = document.querySelector('[data-testid="' + id + '"]')
    if (!el) throw new Error('missing testid ' + id)
    el.click()
    return true
  },
  setValue: function (el, value) {
    const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : el instanceof HTMLSelectElement ? HTMLSelectElement.prototype : HTMLInputElement.prototype
    const desc = Object.getOwnPropertyDescriptor(proto, 'value')
    desc.set.call(el, value)
    el.dispatchEvent(new Event('input', { bubbles: true }))
    el.dispatchEvent(new Event('change', { bubbles: true }))
  },
  fillTest: function (id, value) {
    const el = document.querySelector('[data-testid="' + id + '"]')
    if (!el) throw new Error('missing testid ' + id)
    DOM_HELPERS.setValue(el, value)
    return true
  },
}