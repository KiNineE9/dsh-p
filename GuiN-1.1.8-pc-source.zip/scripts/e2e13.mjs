// 1.1.8 桌面端 E2E：通知只有手动点「标为已读」才不再提醒；未读/手动标为未读仍会提醒；一次性提醒只弹一次
import fs from 'node:fs'
import { listTargets, connect, waitFor } from './cdp.mjs'

const results = []
function check(name, ok, detail) {
  results.push({ name: name, ok: !!ok, detail: detail === undefined ? '' : String(detail) })
  console.log((ok ? 'PASS' : 'FAIL') + ' | ' + name + (detail === undefined || detail === '' ? '' : ' | ' + detail))
}
function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms) }) }

async function waitPort(port, ms, filter) {
  const end = Date.now() + ms
  while (Date.now() < end) {
    try {
      const t = await listTargets(port)
      if (t && t.length) {
        const found = t.filter(function (x) { return x.type === 'page' && x.url.indexOf(filter) >= 0 })
        if (found.length) return found
      }
    } catch (e) {}
    await sleep(250)
  }
  return null
}

const targets = await waitPort(9222, 25000, 'index.html')
if (!targets) { console.log('NO_CDP'); process.exit(2) }
const client = await connect(9222, 'index.html')
const ev = function (expr) { return client.evaluate(expr) }
const send = function (method, params) { return client.send(method, params) }
fs.mkdirSync('.tmp-shots', { recursive: true })
const shot = function (name) { return Promise.race([client.shot('.tmp-shots/' + name + '.png').catch(function () { return null }), sleep(9000)]) }

const INSTALL = [
  'window.__t = {',
  '  all: function (id) { return Array.prototype.filter.call(document.querySelectorAll("[data-testid]"), function (e) { return e.getAttribute("data-testid") === id }) },',
  '  q: function (id, i) { return window.__t.all(id)[i || 0] || null },',
  '  count: function (id) { return window.__t.all(id).length },',
  '  has: function (id) { return !!window.__t.q(id) },',
  '  text: function (id, i) { var e = window.__t.q(id, i); return e ? e.innerText : "" },',
  '  click: function (id, i) { var el = window.__t.q(id, i); if (!el) throw new Error("missing " + id); el.click(); return true },',
  '  clickText: function (id, needle) { var list = window.__t.all(id); for (var k = 0; k < list.length; k++) { if (list[k].innerText.indexOf(needle) >= 0) { list[k].click(); return true } } throw new Error("no " + id + " with " + needle) },',
  '  fill: function (id, value, i) { var el = window.__t.q(id, i); if (!el) throw new Error("missing " + id); var proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : el instanceof HTMLSelectElement ? HTMLSelectElement.prototype : HTMLInputElement.prototype; Object.getOwnPropertyDescriptor(proto, "value").set.call(el, value); el.dispatchEvent(new Event("input", { bubbles: true })); el.dispatchEvent(new Event("change", { bubbles: true })); return true },',
  '  back: function () { var bs = Array.prototype.slice.call(document.querySelectorAll("button")); for (var i = 0; i < bs.length; i++) { if (bs[i].innerText.indexOf("返回") >= 0) { bs[i].click(); return true } } return false },',
  '  unreadCount: function () { return document.querySelectorAll(".notif-item:not(.read)").length },',
  '  readCount: function () { return document.querySelectorAll(".notif-item.read").length },',
  '  badge: function () { return window.__t.has("bell-badge") ? window.__t.text("bell-badge") : "" },',
  '  readIdx: function (name) { var items = window.__t.all("notif-item"); for (var k = 0; k < items.length; k++) { if (items[k].innerText.indexOf(name) >= 0) return k } return -1 },',
  '  body: function () { return document.body.innerText }',
  '}',
  'true'
].join(String.fromCharCode(10))

async function boot() {
  await waitFor(client, '!!document.body', 20000, 'body')
  await client.evaluate(INSTALL)
  await sleep(600)
  if (await ev("__t.has('onboarding')")) {
    await ev("__t.click('onboarding-skip')")
    await waitFor(client, "!__t.has('onboarding')", 8000, 'onboarding closes')
  }
  await sleep(400)
}
await boot()

const info = await ev('window.guina.getDataInfo()')
const DIR = info.dir
function readDisk() {
  try { return JSON.parse(fs.readFileSync(DIR + '/data.json', 'utf8')) } catch (e) { return null }
}
function breadNotif() {
  const d = readDisk()
  return d ? d.notifications.filter(function (n) { return !n.deleted && n.kind === 'food' }) : []
}

// ---------- A 到期提醒：只有手动点「标为已读」才停止提醒 ----------
const exp = await ev("(function(){ var d = new Date(); d.setDate(d.getDate() + 20); var m = d.getMonth() + 1; var day = d.getDate(); return d.getFullYear() + '-' + (m < 10 ? '0' + m : m) + '-' + (day < 10 ? '0' + day : day) })()")
await ev("__t.clickText('category-card', '食品')")
await waitFor(client, "!!document.querySelector('[data-testid=add-item]')", 8000, 'food category')
await ev("__t.click('add-item')")
await waitFor(client, "!!document.querySelector('[data-testid=form-name]')", 8000, 'item form')
await ev("__t.fill('form-name', '测试面包')")
await ev("__t.click('form-location-place')")
await ev("__t.fill('form-location-name', '橱柜')")
await ev("__t.fill('form-field-foodType', '固体')")
await ev("__t.click('form-field-opened-no')")
await ev("__t.fill('form-field-expiresAt', '" + exp + "')")
await sleep(300)
await ev("__t.click('form-submit')")
await sleep(800)
const formErr = await ev("__t.has('form-error') ? __t.text('form-error') : ''")
if (formErr) console.log('FORM_ERROR | ' + formErr)
await waitFor(client, "(function(){ return Array.prototype.some.call(document.querySelectorAll('[data-testid=item-row]'), function(e){ return e.innerText.indexOf('测试面包') >= 0 }) })()", 10000, 'food row')
await ev("__t.back()")
await waitFor(client, "!!document.querySelector('[data-testid=bell]')", 8000, 'home bell')
await sleep(2600)

const discord = await ev('__t.badge()')
check('A1 新生成的到期提醒有未读角标', discord.indexOf('!') >= 0 && Number(String(discord).replace(/[^0-9]/g, '')) >= 1, discord)
await ev("__t.click('bell')")
await waitFor(client, "!!document.querySelector('[data-testid=notification-panel]')", 8000, 'panel')
const unreadBefore = await ev("__t.unreadCount()")
check('A2 打开面板时条目是未读样式', unreadBefore >= 1, String(unreadBefore))
await shot('118-01-panel-unread')
// 只看不点，直接关闭：未读状态必须保持不变
await ev("__t.click('notif-close')")
await sleep(900)
check('A3 关闭面板不会自动已读（角标仍在）', (await ev('__t.badge()')).indexOf('!') >= 0, await ev('__t.badge()'))
check('A4 关闭后 data.json 里仍是未读', breadNotif().length >= 1 && breadNotif().every(function (n) { return n.read === false }), JSON.stringify(breadNotif().map(function (n) { return n.read })))

// 重开软件：未读提醒应该继续出现
await send('Page.reload')
await sleep(600)
await boot()
check('A5 重开软件后未读角标仍在（未读会继续提醒）', (await ev('__t.badge()')).indexOf('!') >= 0, await ev('__t.badge()'))

// 手动点「标为已读」
await ev("__t.click('bell')")
await waitFor(client, "!!document.querySelector('[data-testid=notification-panel]')", 8000, 'panel manual read')
const idxRead = await ev("__t.readIdx('测试面包')")
if (idxRead >= 0) await ev("__t.click('notif-read', " + String(idxRead) + ")")
await sleep(1200)
check('A6 手动标为已读后角标消失', (await ev('__t.badge()')) === '', await ev('__t.badge()'))
check('A7 手动已读写入 data.json（read=true）', breadNotif().length >= 1 && breadNotif().every(function (n) { return n.read === true }), JSON.stringify(breadNotif().map(function (n) { return n.read })))
await shot('118-02-panel-read')
await ev("__t.click('notif-close')")
await sleep(600)

// 重开软件：手动已读的不再提示
await send('Page.reload')
await sleep(600)
await boot()
check('A8 重开软件后已读提醒不再提示（无角标）', (await ev('__t.badge()')) === '', await ev('__t.badge()'))
await ev("__t.click('bell')")
await waitFor(client, "!!document.querySelector('[data-testid=notification-panel]')", 8000, 'panel after reload')
const unreadAfterReload = await ev("__t.unreadCount()")
const readAfterReload = await ev("__t.readCount()")
check('A9 重开后条目显示为已读', unreadAfterReload === 0 && readAfterReload >= 1, 'unread=' + String(unreadAfterReload) + ' read=' + String(readAfterReload))

// 手动标为未读：应该重新提醒，且重开软件后还在
const idxUnread = await ev("__t.readIdx('测试面包')")
if (idxUnread >= 0) await ev("__t.click('notif-read', " + String(idxUnread) + ")")
await sleep(1000)
check('A10 手动标为未读后角标重新出现', (await ev('__t.badge()')).indexOf('!') >= 0, await ev('__t.badge()'))
await ev("__t.click('notif-close')")
await sleep(600)
await send('Page.reload')
await sleep(600)
await boot()
check('A11 重开软件后手动标未读的仍会提醒', (await ev('__t.badge()')).indexOf('!') >= 0, await ev('__t.badge()'))

// ---------- B 一次性提醒：只弹一次，重启后不再弹 ----------
const past = await ev("new Date(Date.now() - 120000).toISOString()")
const created = await ev("window.guina.createSticky({ kind: 'reminder', content: '测试一次性提醒', remindAt: " + JSON.stringify(past) + " })")
const stickyId = created && created.ok ? (created.value && created.value.id) : ''
check('B1 造出一条已过时间的一次性提醒', !!stickyId, stickyId)
let reminderTargets = await waitPort(9222, 12000, 'reminder.html')
check('B2 到点后弹出提醒小窗', !!reminderTargets, reminderTargets ? String(reminderTargets.length) : 'none')
await shot('118-03-desktop-reminder-popup')
if (reminderTargets) {
  const rc = await connect(9222, 'reminder.html')
  const rv = function (expr) { return rc.evaluate(expr) }
  await waitFor(rc, "!!document.querySelector('[data-testid=reminder-ok]')", 8000, 'reminder ok btn')
  const popupText = await rv('document.body.innerText')
  check('B3 提醒小窗展示提醒内容', popupText.indexOf('测试一次性提醒') >= 0, popupText.replace(/\n/g, ' | ').slice(0, 120))
  await Promise.race([rc.shot('.tmp-shots/118-03-desktop-reminder-popup.png').catch(function () { return null }), sleep(8000)])
  await rv("document.querySelector('[data-testid=reminder-ok]').click()")
  rc.close()
  await sleep(1500)
  const disk2 = readDisk()
  const st2 = disk2 ? disk2.stickies.filter(function (s) { return s.id === stickyId })[0] : null
  check('B4 点「知道了」后提醒记为已提醒', !!st2 && st2.notified === true, st2 ? String(st2.notified) : 'missing')
}
await sleep(1200)
await send('Page.reload')
await sleep(600)
await boot()
reminderTargets = await waitPort(9222, 5000, 'reminder.html')
check('B5 重新打开软件后不再弹同一条提醒', !reminderTargets, reminderTargets ? String(reminderTargets.length) : 'none')
const disk3 = readDisk()
const st3 = disk3 ? disk3.stickies.filter(function (s) { return s.id === stickyId })[0] : null
check('B6 重启后提醒仍是已提醒状态', !!st3 && st3.notified === true, st3 ? String(st3.notified) : 'missing')

const passed = results.filter(function (r) { return r.ok }).length
console.log('===== RESULT ' + passed + '/' + results.length + ' =====')
const failed = results.filter(function (r) { return !r.ok }).map(function (r) { return r.name })
if (failed.length) console.log('FAILED:', failed.join(' ; '))
await client.close()
process.exit(0)
