// 手机 ↔ 电脑真实同步联调：桌面实例作为被绑定方，模拟器 APK 作为绑定方
import { connect } from './cdp.mjs'
import fs from 'node:fs'

const OUT = '.tmp-shots/android'
fs.mkdirSync(OUT, { recursive: true })
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))
let pass = 0, fail = 0
const failures = []
function check(name, ok, detail) {
  if (ok) { pass++; console.log('PASS ' + name) }
  else { fail++; failures.push(name + (detail ? ' :: ' + String(detail).slice(0, 300) : '')); console.log('FAIL ' + name + (detail ? ' :: ' + String(detail).slice(0, 300) : '')) }
}

const desktop = await connect(9222, 'index.html')
const mobile = await connect(9333, 'app.local')
for (const c of [desktop, mobile]) { await c.send('Page.enable'); await c.send('Runtime.enable') }
async function ev(cl, expr) { const r = await cl.evaluate(expr); if (r && typeof r === 'object' && 'value' in r) return r.value; return r }
async function body(cl) { return (await ev(cl, 'document.body.innerText')) || '' }
async function waitFor(cl, expr, ms, label) {
  const t0 = Date.now()
  while (Date.now() - t0 < ms) {
    if (await ev(cl, expr)) return true
    await sleep(250)
  }
  console.log('[timeout] ' + label + ' after ' + ms + 'ms')
  return false
}
async function shot(cl, name) { const s = await cl.send('Page.captureScreenshot', { format: 'png' }); fs.writeFileSync(OUT + '/' + name + '.png', Buffer.from(s.data, 'base64')) }
async function clickSel(cl, sel) { return ev(cl, "(() => { const el = document.querySelector(" + JSON.stringify(sel) + "); if (!el) return 'NO_EL'; el.click(); return 'OK' })()") }
async function clickText(cl, text, scopeSel) {
  return ev(cl, "(() => { const sc = " + (scopeSel ? "document.querySelector(" + JSON.stringify(scopeSel) + ")" : "document") + "; if (!sc) return 'NO_SCOPE'; const list = [...sc.querySelectorAll('button,[role=button],.row,.tab,.item-card,.sticky-card')]; const el = list.find(e => ((e.innerText||'')+'').trim().includes(" + JSON.stringify(text) + ")); if (!el) return 'NOTFOUND'; el.click(); return 'OK' })()")
}
async function setInput(cl, sel, value) {
  return ev(cl, "(() => { const el = document.querySelector(" + JSON.stringify(sel) + "); if (!el) return 'NO_EL'; const proto = el.tagName === 'TEXTAREA' ? window.HTMLTextAreaElement.prototype : window.HTMLInputElement.prototype; const s = Object.getOwnPropertyDescriptor(proto, 'value').set; s.call(el, " + JSON.stringify(value) + "); el.dispatchEvent(new Event('input', { bubbles: true })); el.dispatchEvent(new Event('change', { bubbles: true })); return 'OK' })()")
}

// ---------- 桌面准备 ----------
await waitFor(desktop, "document.readyState === 'complete'", 30000, 'desktop ready')
if (await ev(desktop, "!!document.querySelector('[data-testid=onboarding-skip]')")) {
  await clickSel(desktop, '[data-testid=onboarding-skip]')
  await sleep(800)
}
await waitFor(desktop, "!!document.querySelector('[data-testid=settings-btn]')", 20000, 'desktop home')
check('桌面端有设置入口', !!(await ev(desktop, "!!document.querySelector('[data-testid=settings-btn]')")))

// 桌面端先确保有一件独有数据（用于验证手机合并后收到）
const seed = await ev(desktop, "window.guina.createItem('cat-item', { name: '电脑端物品', locationType: 'place', locationLabel: '书房', locationName: '抽屉', fields: {} }).then(r => r.ok ? 'OK' : r.error)")
check('桌面端写入测试物品', seed === 'OK', seed)
await shot(desktop, 'cross-01-desktop-home')

await clickSel(desktop, '[data-testid=settings-btn]')
await waitFor(desktop, "!!document.querySelector('[data-testid=sync-bind-new]')", 15000, 'desktop sync card')
const rename = await setInput(desktop, '[data-testid=sync-device-name]', '电脑主机')
await clickSel(desktop, '[data-testid=sync-save-name]')
await sleep(600)
check('桌面端设备名保存', rename === 'OK' && (await body(desktop)).includes('电脑主机'))

await clickSel(desktop, '[data-testid=sync-bind-new]')
const gotCode = await waitFor(desktop, "(() => { const el = document.querySelector('[data-testid=sync-pair-code]'); return !!el && /^\\d{6}$/.test((el.innerText||'').trim()) })()", 40000, 'desktop pairing code')
const code = gotCode ? (await ev(desktop, "(document.querySelector('[data-testid=sync-pair-code]')||{}).innerText.trim()")) : ''
const invite = gotCode ? (await ev(desktop, "(document.querySelector('[data-testid=sync-invite-text]')||{}).value")) : ''
check('桌面端生成六位数字', gotCode, code)
check('桌面端生成邀请文本', !!invite && invite.startsWith('GUINPAIR1:'), (invite || '').slice(0, 30))
await shot(desktop, 'cross-02-desktop-pairing')
if (!gotCode) { console.log('[abort] pairing code missing'); summaryAndExit() }

// ---------- 手机加入配对 ----------
for (let i = 0; i < 8; i++) {
  if (await ev(mobile, "!!document.querySelector('.tabbar')")) break
  if ((await body(mobile)).includes('跳过')) { await clickText(mobile, '跳过') }
  await sleep(800)
}
check('手机端进入主界面', await waitFor(mobile, "!!document.querySelector('.tabbar')", 20000, 'mobile tabbar'), (await body(mobile)).slice(0, 120))
const tabRes = await clickText(mobile, '设置', '.tabbar')
await sleep(800)
const openSync = await ev(mobile, "(() => { const row = [...document.querySelectorAll('.row')].find(r => ((r.querySelector('.row-title')||{}).innerText||'').includes('数据同步')); if (!row) return 'NO_ROW'; const b = row.querySelector('button'); if (!b) return 'NO_BTN'; b.click(); return 'OK' })()")
check('手机端打开数据同步面板', tabRes === 'OK' && openSync === 'OK', tabRes + '/' + openSync)
await waitFor(mobile, "(document.querySelector('.sheet-title')||{}).innerText === '数据同步'", 10000, 'mobile sync sheet')
const machineCode = await ev(mobile, "(document.querySelector('.mono, .sync-code, .sheet-panel')||{}).innerText || ''")
check('手机端显示机器码', /[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{4}/.test(machineCode), machineCode.slice(0, 80))
await shot(mobile, 'cross-03-mobile-sync-sheet')

await clickText(mobile, '输入邀请码绑定', '.sheet-panel')
await sleep(500)
const setText = await setInput(mobile, '.sheet-panel textarea', invite)
const setCode = await setInput(mobile, '.sheet-panel input[inputmode=numeric]', code)
check('手机端填写邀请码与数字', setText === 'OK' && setCode === 'OK', setText + '/' + setCode)
await clickText(mobile, '确认绑定', '.sheet-panel')
const bound = await waitFor(mobile, "(() => { const sc = document.querySelector('.sheet-panel'); return !!sc && (sc.innerText||'').includes('已绑定设备') })()", 60000, 'mobile binding')
check('手机端绑定电脑成功', bound, (await ev(mobile, "(document.querySelector('.sheet-panel')||{}).innerText || ''")).slice(-260))
const boundReady = await waitFor(
  mobile,
  "(() => { const sc = document.querySelector('.sheet-panel'); if (!sc) return false; const t = sc.innerText || ''; return t.includes('已绑定设备') && t.includes('不同步便签') && [...sc.querySelectorAll('button')].some(b => (b.innerText||'').includes('合并数据')) })()",
  20000,
  'mobile bound view ready'
)
check('手机端提示不同步便签', boundReady, (await ev(mobile, "(document.querySelector('.sheet-panel')||{}).innerText || ''")).slice(-260))
await shot(mobile, 'cross-04-mobile-bound')
check('桌面端出现已绑定手机', await waitFor(desktop, "(document.body.innerText).includes('手机') || (document.body.innerText).includes('安卓') || document.querySelectorAll('[data-testid=sync-binding]').length > 0", 30000, 'desktop binding row'))
await shot(desktop, 'cross-05-desktop-bound')

// 手机端新建独有物品，作为合并是否真的生效的证据
async function setFieldM(label, value) {
  return ev(mobile, "(() => { const fields = [...document.querySelectorAll('.field')]; const want = " + JSON.stringify(label) + "; const f = fields.find(x => { const l = (x.querySelector('.field-label') || {}).textContent || ''; return l.trim().split('*')[0].trim() === want }); if (!f) return 'NO_FIELD'; const el = f.querySelector('input,textarea,select'); if (!el) return 'NO_INPUT'; const proto = el.tagName === 'TEXTAREA' ? window.HTMLTextAreaElement.prototype : window.HTMLInputElement.prototype; const s = Object.getOwnPropertyDescriptor(proto, 'value').set; s.call(el, " + JSON.stringify(value) + "); el.dispatchEvent(new Event('input', { bubbles: true })); el.dispatchEvent(new Event('change', { bubbles: true })); return 'OK' })()")
}
await clickSel(mobile, '.sheet-head button[aria-label=关闭]')
await sleep(700)
await clickText(mobile, '首页', '.tabbar')
await sleep(800)
const fabOpen = await clickSel(mobile, '.fab')
await sleep(600)
const fabPick = await clickText(mobile, '新增条目', '.fab-menu')
await sleep(900)
const catPick = await ev(mobile, "(() => { const rows = [...document.querySelectorAll('.sheet-panel button.row')]; const b = rows.find(r => ((r.querySelector('.row-title')||{}).innerText||'').trim() === '物品') || rows[0]; if (!b) return 'NO'; b.click(); return 'OK' })()")
await sleep(1000)
const nameSet = await setFieldM('物品名称', '手机端物品')
const locSet = (await setFieldM('详细位置', '手机客厅')) + '/' + (await setFieldM('地点名称', '手机客厅'))
await sleep(400)
const saved = await clickText(mobile, '保存', '.sheet-panel')
const itemAdded = await waitFor(mobile, "(document.body.innerText).includes('已添加') || (document.body.innerText).includes('手机端物品')", 12000, 'mobile item saved')
check('手机端新建独有物品', fabOpen === 'OK' && fabPick === 'OK' && catPick === 'OK' && nameSet === 'OK' && locSet === 'OK/OK' && itemAdded, [fabOpen, fabPick, catPick, nameSet, locSet, saved, itemAdded].join('|'))
await shot(mobile, 'cross-04b-mobile-item')

// 重新打开数据同步面板
const openSync2 = await ev(mobile, "(() => { const t = [...document.querySelectorAll('.tab')].find(x => (x.innerText||'').includes('设置')); if (t) t.click(); return 'OK' })()")
await sleep(900)
const openSync3 = await ev(mobile, "(() => { const row = [...document.querySelectorAll('.row')].find(r => ((r.querySelector('.row-title')||{}).innerText||'').includes('数据同步')); if (!row) return 'NO_ROW'; const b = row.querySelector('button'); if (!b) return 'NO_BTN'; b.click(); return 'OK' })()")
const sheetAgain = await waitFor(mobile, "(document.querySelector('.sheet-title')||{}).innerText === '数据同步'", 10000, 'mobile sync sheet again')
const mergeReady = await waitFor(mobile, "(() => { const sc = document.querySelector('.sheet-panel'); if (!sc) return false; const b = [...sc.querySelectorAll('button')].find(x => (x.innerText||'').includes('合并数据')); return !!b && !b.disabled })()", 20000, 'mobile merge button')
check('手机端可点合并数据', openSync2 === 'OK' && openSync3 === 'OK' && sheetAgain && mergeReady, [openSync2, openSync3, sheetAgain, mergeReady].join('|'))

// ---------- 手机 -> 电脑 合并 ----------
const mergeClick = await ev(mobile, "(() => { const b = [...document.querySelectorAll('.sheet-panel button')].find(x => (x.innerText||'').includes('合并数据')); if (!b) return 'NO'; b.click(); return 'OK' })()")
const confirmShown = await waitFor(mobile, "!!document.querySelector('.confirm-card')", 15000, 'mobile merge confirm')
const confirmBody = await ev(mobile, "(document.querySelector('.confirm-body')||{}).innerText || ''")
check('手机端合并确认含自动备份提示', mergeClick === 'OK' && confirmShown && (confirmBody.includes('自动备份') || confirmBody.includes('回滚')), mergeClick + '|' + confirmShown + '|' + confirmBody.slice(0, 160))
await shot(mobile, 'cross-06-mobile-merge-confirm')
await ev(mobile, "(() => { const b = document.querySelector('.confirm-card .btn.primary'); if (!b) return 'NO'; b.click(); return 'OK' })()")
check('桌面端弹出同步请求', await waitFor(desktop, "!!document.querySelector('[data-testid=modal-confirm]')", 90000, 'desktop incoming'))
await sleep(500)
const modalText = await ev(desktop, "(document.querySelector('[data-testid=modal]')||document.body).innerText || ''")
check('桌面端请求弹窗内容', modalText.includes('有设备请求同步') || modalText.includes('接受同步'), modalText.slice(-260))
await shot(desktop, 'cross-07-desktop-incoming')
await clickSel(desktop, '[data-testid=modal-confirm]')
const mergedA = await waitFor(mobile, "(document.body.innerText).includes('合并完成') || (document.body.innerText).includes('同步完成')", 120000, 'mobile merge done')
check('手机端合并完成', mergedA, (await body(mobile)).slice(-260))
const desktopState = await ev(desktop, "window.guina.getState().then(s => JSON.stringify({ items: s.items.map(i => i.name), categories: s.categories.length }))")
check('桌面端合并后收到手机独有物品', desktopState.includes('手机端物品'), desktopState.slice(0, 260))
check('桌面端保留自己的物品', desktopState.includes('电脑端物品'), desktopState.slice(0, 200))
await shot(mobile, 'cross-08-mobile-merged')
await shot(desktop, 'cross-09-desktop-merged')

// ---------- 电脑 -> 手机 推送 ----------
await ev(desktop, "window.guina.createItem('cat-item', { name: '电脑推送物品', locationType: 'place', locationLabel: '阳台', locationName: '柜子', fields: {} })")
await sleep(500)
await clickSel(desktop, '[data-testid=sync-push]')
await waitFor(desktop, "!!document.querySelector('[data-testid=sync-confirm]')", 8000, 'desktop push confirm')
await clickSel(desktop, '[data-testid=sync-confirm-run]')
const mobileIncoming = await waitFor(mobile, "!!document.querySelector('.confirm-card')", 90000, 'mobile incoming')
check('手机端弹出同步请求', mobileIncoming, '')
if (mobileIncoming) {
  const incText = await ev(mobile, "(document.querySelector('.confirm-card')||{}).innerText || ''")
  check('手机端请求弹窗内容', incText.includes('有设备请求同步') || incText.includes('接受同步'), incText.slice(0, 200))
  await shot(mobile, 'cross-09-mobile-incoming')
  await ev(mobile, "(() => { const b = document.querySelector('.confirm-card .btn.primary'); if (!b) return 'NO'; b.click(); return 'OK' })()")
  check('桌面端推送完成', await waitFor(desktop, "(document.body.innerText).includes('同步完成')", 120000, 'desktop push done'), (await body(desktop)).slice(-200))
}
await sleep(1000)
// 手机端确认收到推送物品
await clickText(mobile, '关闭', '.sheet-panel')
await ev(mobile, "(() => { const b = document.querySelector('.sheet-mask .icon-btn, .sheet-mask button'); if (b) b.click(); return 'OK' })()")
await sleep(500)
await clickText(mobile, '搜索', '.tabbar')
await sleep(600)
await ev(mobile, "(() => { const el = [...document.querySelectorAll('input')].find(i => (i.placeholder||'').includes('搜索物品')); if (!el) return 'NO'; const s = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set; s.call(el, '电脑推送物品'); el.dispatchEvent(new Event('input', { bubbles: true })); return 'OK' })()")
check('手机端搜索到桌面推送的物品', await waitFor(mobile, "(document.body.innerText).includes('电脑推送物品')", 15000, 'mobile pushed item'), (await body(mobile)).slice(-200))
await shot(mobile, 'cross-10-mobile-pushed')

function summaryAndExit() {
  console.log('\n===== CROSS SYNC ' + pass + '/' + (pass + fail) + ' =====')
  if (failures.length) { console.log('FAILURES:'); failures.forEach(f => console.log(' - ' + f)) }
  setTimeout(function () { process.exit(fail ? 1 : 0) }, 300).unref()
  if (fail) process.exitCode = 1
}
summaryAndExit()
