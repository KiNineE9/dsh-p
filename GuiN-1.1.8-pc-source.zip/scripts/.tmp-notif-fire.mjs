import { ev, sleep } from './mobile-e2e.mjs'
const r = await ev("(() => { try { window.GuinaNative.notifyExpiry(3, 2); return 'OK' } catch (e) { return 'ERR ' + e } })()")
console.log('notifyExpiry=' + r)
await sleep(2500)
process.exit(0)
