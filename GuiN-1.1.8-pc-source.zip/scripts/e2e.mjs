import { listTargets, connect, waitFor } from './cdp.mjs'

const results = []
function check(name, ok, detail) {
  results.push({ name: name, ok: !!ok, detail: detail === undefined ? '' : String(detail) })
  console.log((ok ? 'PASS' : 'FAIL') + ' | ' + name + (detail === undefined || detail === '' ? '' : ' | ' + detail))
}
function fail(name, detail) {
  check(name, false, detail)
}

async function waitPort(port, ms) {
  const end = Date.now() + ms
  while (Date.now() < end) {
    try {
      const t = await listTargets(port)
      if (t && t.length) return t
    } catch (e) {}
    await new Promise(function (r) { setTimeout(r, 250) })
  }
  return null
}

const targets = await waitPort(9222, 25000)
if (!targets) {
  console.log('NO_CDP')
  process.exit(2)
}
const client = await connect(9222, 'index.html')
const ev = function (expr) { return client.evaluate(expr) }
const sleep = function (ms) { return new Promise(function (r) { setTimeout(r, ms) }) }
const shot = function (name) { return client.shot('.tmp-shots/' + name + '.png') }

const INSTALL = [
  'window.__t = {',
  '  all: function (id) {',
  '    return Array.prototype.filter.call(document.querySelectorAll("[data-testid]"), function (e) {',
  '      return e.getAttribute("data-testid") === id',
  '    })',
  '  },',
  '  q: function (id, i) { return window.__t.all(id)[i || 0] || null },',
  '  count: function (id) { return window.__t.all(id).length },',
  '  texts: function (id) { return window.__t.all(id).map(function (e) { return e.innerText }) },',
  '  has: function (id) { return !!window.__t.q(id) },',
  '  text: function (id, i) { var e = window.__t.q(id, i); return e ? e.innerText : "" },',
  '  click: function (id, i) {',
  '    var el = window.__t.q(id, i)',
  '    if (!el) throw new Error("missing " + id)',
  '    el.click()',
  '    return true',
  '  },',
  '  clickText: function (id, needle) {',
  '    var list = window.__t.all(id)',
  '    for (var k = 0; k < list.length; k++) {',
  '      if (list[k].innerText.indexOf(needle) >= 0) { list[k].click(); return true }',
  '    }',
  '    throw new Error("no " + id + " with " + needle)',
  '  },',
  '  setValue: function (el, v) {',
  '    var proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype',
  '      : el instanceof HTMLSelectElement ? HTMLSelectElement.prototype',
  '      : HTMLInputElement.prototype',
  '    Object.getOwnPropertyDescriptor(proto, "value").set.call(el, v)',
  '    el.dispatchEvent(new Event("input", { bubbles: true }))',
  '    el.dispatchEvent(new Event("change", { bubbles: true }))',
  '    return true',
  '  },',
  '  set: function (id, v) {',
  '    var el = window.__t.q(id)',
  '    if (!el) throw new Error("missing " + id)',
  '    return window.__t.setValue(el, v)',
  '  },',
  '  setIn: function (id, i, selector, v) {',
  '    var root = window.__t.q(id, i)',
  '    if (!root) throw new Error("missing " + id)',
  '    var el = root.querySelector(selector)',
  '    if (!el) throw new Error("missing " + selector + " in " + id)',
  '    return window.__t.setValue(el, v)',
  '  },',
  '  clickIn: function (id, i, label) {',
  '    var root = window.__t.q(id, i)',
  '    if (!root) throw new Error("missing " + id)',
  '    var list = Array.prototype.slice.call(root.querySelectorAll("button"))',
  '    for (var k = 0; k < list.length; k++) {',
  '      if (list[k].innerText.trim() === label) { list[k].click(); return true }',
  '    }',
  '    throw new Error("no button " + label + " in " + id)',
  '  },',
  '  hasClass: function (id, cls, i) {',
  '    var el = window.__t.q(id, i)',
  '    return !!el && String(el.className).split(" ").indexOf(cls) >= 0',
  '  },',
  '  state: function () { return window.guina.getState() },',
  '  body: function () { return document.body.innerText },',
  '}',
  'true'
].join(String.fromCharCode(10))

await waitFor(client, '!!document.body', 20000, 'body')
await client.evaluate(INSTALL)
await sleep(800)

// ---- 引导 ----
if (await ev("__t.has('onboarding')")) {
  await shot('01-onboarding')
  await ev("__t.click('onboarding-skip')")
  await waitFor(client, "!__t.has('onboarding')", 8000, 'onboarding closes')
  check('首次启动 3 步图文引导出现且可跳过', true)
} else {
  check('首次启动 3 步图文引导出现且可跳过', false, 'onboarding not shown')
}
await sleep(400)
await shot('02-home-empty')

// ---- 新建「香水」到物品分类 ----
async function openCategory(name) {
  await ev("window.__t.clickText('category-card', '" + name + "')")
  await waitFor(client, "!!document.querySelector('[data-testid=category-title]')", 8000, 'category page')
}

async function addItem(opts) {
  await ev("__t.click('add-item')")
  await waitFor(client, "!!document.querySelector('[data-testid=form-name]')", 8000, 'item form')
  await ev("__t.set('form-name', '" + opts.name + "')")
  if (opts.locationType === 'container') {
    await ev("__t.click('form-location-container')")
  } else {
    await ev("__t.click('form-location-place')")
  }
  await ev("__t.set('form-location-name', '" + opts.location + "')")
  if (opts.fields) {
    for (const key of Object.keys(opts.fields)) {
      const value = opts.fields[key]
      if (value === true) {
        await ev("__t.click('form-field-" + key + "')")
      } else if (value === false) {
        await ev("__t.click('form-field-" + key + "-no')")
      } else {
        await ev("__t.set('form-field-" + key + "', '" + value + "')")
      }
    }
  }
  await ev("__t.click('form-submit')")
}

await openCategory('物品')
await waitFor(client, "!!document.querySelector('[data-testid=add-item]')", 8000, 'add-item button')
await addItem({ name: '香水', locationType: 'place', location: '卧室第二层抽屉' })
await waitFor(client, "__t.texts('item-row').join('|').indexOf('香水') >= 0", 10000, 'perfume row')
check('新建条目「香水」保存成功', true, (await ev("__t.texts('item-row')")).join(' / '))
await shot('03-item-created')

// 编辑位置
await ev("__t.click('item-more')")
await sleep(200)
await ev("__t.click('item-edit')")
await waitFor(client, "!!document.querySelector('[data-testid=form-location-name]')", 8000, 'edit form')
await ev("__t.set('form-location-name', '客厅柜子')")
await ev("__t.click('form-submit')")
await waitFor(client, "__t.texts('item-row').join('|').indexOf('客厅柜子') >= 0", 10000, 'location updated')
check('编辑条目位置为「客厅柜子」生效', true)
await shot('04-item-edited')

// ---- 图书 + 食品 + 字段校验 ----
await ev("window.guina.getState().then(function(){return true})")
await ev("document.querySelector('[data-testid=category-title]') && window.history.length")
// 返回首页
await ev("(function(){ var btns = Array.prototype.slice.call(document.querySelectorAll('button')); for (var i = 0; i < btns.length; i++) { if (btns[i].innerText.indexOf('返回') >= 0) { btns[i].click(); return true } } return false })()")
await waitFor(client, "!!document.querySelector('[data-testid=add-category]')", 8000, 'home again')

await openCategory('图书')
await ev("__t.click('add-item')")
await waitFor(client, "!!document.querySelector('[data-testid=form-name]')", 8000, 'book form')
await ev("__t.click('form-submit')")
await sleep(400)
const err1 = await ev("__t.text('form-error')")
check('图书表单必填校验生效', !!err1, err1)
check('图书表单包含存放时间字段', await ev("__t.has('form-field-storedAt')"))
await ev("__t.set('form-field-storedAt', '2025-03-08')")
await ev("__t.set('form-name', '三体')")
await ev("__t.set('form-location-name', '书架 A 层')")
await ev("__t.click('form-submit')")
await waitFor(client, "__t.texts('item-row').join('|').indexOf('三体') >= 0", 10000, 'book row')
const bookRow = (await ev("__t.texts('item-row')")).join(' / ')
check('图书条目含书名/位置/存放时间', bookRow.indexOf('三体') >= 0 && bookRow.indexOf('书架 A 层') >= 0 && bookRow.indexOf('2025-03-08') >= 0, bookRow)
await shot('05-book-category')

// 食品
await ev("(function(){ var btns = Array.prototype.slice.call(document.querySelectorAll('button')); for (var i = 0; i < btns.length; i++) { if (btns[i].innerText.indexOf('返回') >= 0) { btns[i].click(); return true } } return false })()")
await waitFor(client, "!!document.querySelector('[data-testid=add-category]')", 8000, 'home again 2')
await openCategory('食品')
const today = new Date()
function plusDays(n) {
  const d = new Date(today.getTime() + n * 86400000)
  const m = String(d.getMonth() + 1).padStart(2, '0')
  const day = String(d.getDate()).padStart(2, '0')
  return d.getFullYear() + '-' + m + '-' + day
}
await addItem({ name: '娃哈哈纯净水', locationType: 'place', location: '冰箱', fields: { foodType: '液体', opened: true, expiresAt: plusDays(12) } })
await waitFor(client, "__t.texts('item-row').join('|').indexOf('娃哈哈纯净水') >= 0", 10000, 'water row')
check('食品条目含类型/拆封/位置/过期时间', true, (await ev("__t.texts('item-row')")).join(' / '))
await shot('06-food-category')

await addItem({ name: '酸奶', locationType: 'place', location: '冰箱', fields: { foodType: '固体', opened: false, expiresAt: plusDays(5) } })
await waitFor(client, "__t.texts('item-row').join('|').indexOf('酸奶') >= 0", 10000, 'yogurt row')
await addItem({ name: '苹果', locationType: 'place', location: '客厅果篮', fields: { foodType: '固体', opened: true, expiresAt: plusDays(2) } })
await waitFor(client, "__t.texts('item-row').join('|').indexOf('苹果') >= 0", 10000, 'apple row')
await shot('07-food-three')

const foodRow = (await ev("__t.texts('item-row')")).join(' / ')
check('食品行显示还剩天数', foodRow.indexOf('还剩') >= 0, foodRow.split(' / ')[0])
await ev("__t.click('add-item')")
await waitFor(client, "!!document.querySelector('[data-testid=form-name]')", 8000, 'food form 2')
await ev("__t.set('form-name', '')")
await ev("__t.click('form-submit')")
await sleep(400)
const foodErr = await ev("__t.has('form-error') ? __t.text('form-error') : ''")
check('食品表单必填校验生效', foodErr.indexOf('食品名称') >= 0, foodErr)
await ev("__t.click('modal-cancel')")
await sleep(300)

// ---- 分类内搜索 ----
await ev("__t.set('cat-search', '冰')")
await sleep(500)
const inFood = await ev("__t.texts('item-row')")
check('分类内搜索「冰」只返回食品分类中的冰箱物品', inFood.length === 2, inFood.join(' / '))
await ev("__t.set('cat-search', '香水')")
await sleep(500)
const inFood2 = await ev("__t.texts('item-row')")
check('分类内搜索不越界（食品里搜「香水」为空）', inFood2.length === 0, inFood2.join(' / '))
await ev("__t.set('cat-search', '')")
await sleep(400)

// 食品排序：点一次升序，再点一次倒序
const sortLabels = await ev("Array.prototype.map.call(document.querySelectorAll('[data-testid=sort-group] button'), function (b) { return b.innerText.replace(/[\\s↑↓]/g, '') })")
check('食品排序提供「按过期时间」按钮', Array.isArray(sortLabels) && sortLabels.indexOf('按过期时间') >= 0, JSON.stringify(sortLabels))
await ev("__t.click('sort-expiresAt')")
await sleep(500)
const byExpiry = await ev("__t.texts('item-row')")
const expiryDir = await ev("__t.q('sort-expiresAt').getAttribute('data-direction')")
check('食品按过期时间排序（第一次升序，早过期在前）', expiryDir === 'asc' && byExpiry[0].indexOf('苹果') >= 0, expiryDir + ' | ' + byExpiry.map(function (t) { return t.split(String.fromCharCode(10))[0] }).join(' > '))
await ev("__t.click('sort-expiresAt')")
await sleep(500)
const byExpiryDesc = await ev("__t.texts('item-row')")
const expiryDir2 = await ev("__t.q('sort-expiresAt').getAttribute('data-direction')")
check('再点一次按过期时间倒序', expiryDir2 === 'desc' && JSON.stringify(byExpiryDesc) === JSON.stringify(byExpiry.slice().reverse()), expiryDir2 + ' | ' + byExpiryDesc.map(function (t) { return t.split(String.fromCharCode(10))[0] }).join(' > '))

// 名称拼音排序
await ev("__t.click('sort-name')")
await sleep(500)
const byName = await ev("__t.texts('item-row')")
check('名称按拼音排序（苹果 p > 酸奶 s > 娃哈哈 w）', byName[0].indexOf('苹果') >= 0 && byName[1].indexOf('酸奶') >= 0 && byName[2].indexOf('娃哈哈') >= 0, byName.map(function (t) { return t.split(String.fromCharCode(10))[0] }).join(' > '))
await ev("__t.click('sort-name')")
await sleep(500)
const byNameDesc = await ev("__t.texts('item-row')")
const nameDir = await ev("__t.q('sort-name').getAttribute('data-direction')")
check('再点一次按名称倒序', nameDir === 'desc' && JSON.stringify(byNameDesc) === JSON.stringify(byName.slice().reverse()), nameDir + ' | ' + byNameDesc.map(function (t) { return t.split(String.fromCharCode(10))[0] }).join(' > '))
await shot('08-food-sorted')

// ---- 全局搜索 ----
await ev("(function(){ var btns = Array.prototype.slice.call(document.querySelectorAll('button')); for (var i = 0; i < btns.length; i++) { if (btns[i].innerText.indexOf('返回') >= 0) { btns[i].click(); return true } } return false })()")
await waitFor(client, "!!document.querySelector('[data-testid=search-input]')", 8000, 'topbar')
await ev("__t.set('search-input', '净')")
await sleep(600)
const hits1 = await ev("__t.texts('search-hit')")
check('全局搜索「净」命中「娃哈哈纯净水」', hits1.join('|').indexOf('娃哈哈纯净水') >= 0, hits1.join(' / '))
await shot('09-search-jing')
await ev("__t.set('search-input', '冰箱')")
await sleep(600)
const hits2 = await ev("__t.texts('search-hit')")
check('全局搜索「冰箱」列出冰箱里的所有东西', hits2.length >= 2, hits2.join(' / '))
await ev("__t.set('search-input', '')")
await sleep(300)

// ---- 备注 ----
await openCategory('物品')
await ev("__t.click('item-more')")
await sleep(200)
await ev("__t.click('item-notes')")
await waitFor(client, "!!document.querySelector('[data-testid=note-input]')", 8000, 'notes modal')
await ev("__t.set('note-input', '第一层左边')")
await ev("__t.click('note-add')")
await sleep(400)
await ev("__t.set('note-input', '喷头有点松，小心')")
await ev("__t.click('note-add')")
await sleep(400)
check('一个条目可添加多条备注', (await ev("__t.count('note-item')")) === 2, await ev("__t.count('note-item')"))
await shot('10-notes')
await ev("__t.click('note-edit', 0)")
await sleep(300)
await ev("__t.setIn('note-item', 0, 'textarea', '第一层左边（已确认）')")
await ev("__t.clickIn('note-item', 0, '保存')")
await sleep(500)
check('备注可修改', (await ev("__t.texts('note-item')")).join('|').indexOf('已确认') >= 0)
await ev("__t.click('note-delete', 1)")
await sleep(300)
await ev("__t.click('modal-confirm')")
await sleep(500)
check('备注可单条删除', (await ev("__t.count('note-item')")) === 1, await ev("__t.count('note-item')"))
await ev("__t.clickIn('modal', 0, '关闭')")
await sleep(300)
check('备注数量标记显示在条目行', (await ev("__t.count('item-notes-count')")) >= 1)

// ---- 状态盘点 ----
const snap = await ev("__t.state().then(function (s) { return { items: s.items.length, notes: s.notes.length, stickies: s.stickies.length, notifs: s.notifications.length, categories: s.categories.length } })")
check('数据已写入（条目/备注落盘）', snap.items === 5 && snap.notes === 1, JSON.stringify(snap))

console.log('RESULT_JSON ' + JSON.stringify(results))
process.exit(0)
