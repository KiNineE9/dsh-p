import { connect } from './cdp.mjs'
import fs from 'node:fs'
const c = await connect(Number(process.env.CDP_PORT || 9333), 'app.local')
await c.send('Page.enable')
const sleep = (ms) => new Promise(r => setTimeout(r, ms))
async function ev(expr) { const r = await c.evaluate(expr); return r && r.value !== undefined ? r.value : r }
async function shot(name) {
  const s = await c.send('Page.captureScreenshot', { format: 'png' })
  fs.writeFileSync('.tmp-shots/' + name + '.png', Buffer.from(s.data, 'base64'))
}
async function tap(text, sel) {
  return ev(`(() => { const list=[...document.querySelectorAll(${JSON.stringify(sel || 'button,[role=button],a,.cat-card,.tab')})]; const el=list.find(e=>(e.innerText||'').trim().includes(${JSON.stringify(text)})); if(!el) return 'NOTFOUND:'+list.map(e=>(e.innerText||'').trim().slice(0,15)).join('|'); el.click(); return 'OK'; })()`)
}
console.log('tap cat:', await tap('药品'))
await sleep(500)
console.log('--- category screen text ---')
console.log(await ev('document.body.innerText.slice(0,800)'))
fs.writeFileSync('.tmp-shots/cat.html', await ev('document.body.innerHTML'))
await shot('phone-03-category')
// 找到新增条目按钮
console.log('buttons:', await ev(`[...document.querySelectorAll('button')].map(b=>(b.innerText||'').trim()).filter(Boolean).slice(0,20).join(' / ')`))
c.close()
