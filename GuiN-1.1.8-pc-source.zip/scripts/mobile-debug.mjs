import { connect } from './cdp.mjs'
const c = await connect(9333, 'app.local')
const ev = async (e) => { const r = await c.evaluate(e); return (r && typeof r === 'object' && 'value' in r) ? r.value : r }
const sleep = (ms) => new Promise(r => setTimeout(r, ms))
console.log('tab active=' + await ev("(document.querySelector('.tab.active')||{}).innerText"))
console.log('btns=' + await ev("JSON.stringify([...document.querySelectorAll('button')].map(b => (b.innerText||'').trim()).filter(Boolean))"))
console.log('click=' + await ev("(() => { const b = [...document.querySelectorAll('button')].find(x => (x.innerText||'').trim() === '管理'); if (!b) return 'NO'; b.click(); return 'OK'; })()"))
await sleep(500)
console.log('sheets=' + await ev("document.querySelectorAll('.sheet-panel').length") + ' title=' + await ev("(document.querySelector('.sheet-title')||{}).innerText"))
console.log('sheetText=' + ((await ev("(document.querySelector('.sheet-panel')||{}).innerText")) || '').slice(0, 300).replace(/\n/g, ' / '))
c.close()
