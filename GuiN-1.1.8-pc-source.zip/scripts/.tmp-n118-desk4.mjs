import { spawn, execSync } from 'node:child_process'
import fs from 'node:fs'
import path from 'node:path'
import { connect } from './cdp.mjs'
const ROOT = 'F:/DSH/GC/GuiNa'
const PROFILE = path.join(ROOT, '.tmp-n118b-profile')
const PORT = 9222
const ELECTRON = path.join(ROOT, 'node_modules/electron/dist/electron.exe')
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))
function killElectron() { try { execSync('taskkill /F /IM electron.exe /T', { stdio: 'ignore' }) } catch {} }
async function launch() {
  const env = { ...process.env }; delete env.ELECTRON_RUN_AS_NODE
  spawn(ELECTRON, [ROOT, '--remote-debugging-port=' + PORT, '--no-sandbox', '--user-data-dir=' + PROFILE], { env, stdio: 'ignore' })
  for (let i = 0; i < 120; i++) {
    try { const list = await (await fetch('http://127.0.0.1:' + PORT + '/json/list')).json(); if (list.find((t) => String(t.url).includes('index.html'))) break } catch {}
    await sleep(250)
  }
  await sleep(2600)
}
const readDisk = () => {
  try { const j = JSON.parse(fs.readFileSync(path.join(PROFILE, 'data.json'), 'utf8')); return { notifs: (j.notifications || []).map((n) => ({ id: n.id, read: n.read, del: n.deleted })), stickies: (j.stickies || []).map((s) => ({ id: s.id, notified: s.notified, at: s.remindAt, status: s.status })) } } catch (e) { return 'ERR ' + e.message }
}
fs.rmSync(PROFILE, { recursive: true, force: true })
fs.mkdirSync(PROFILE, { recursive: true })
const now = new Date()
const exp = new Date(now.getTime() + 5 * 86400000).toISOString().slice(0, 10)
const state = {
  version: 4, categories: [], items: [{ id: 'it-1', categoryId: 'cat-food', name: '测试牛奶', locationType: 'place', locationLabel: '冰箱', locationName: '', fields: { name: '测试牛奶', placeName: '冰箱', foodType: '固体', opened: '否', storedAt: now.toISOString().slice(0, 10), expiresAt: exp }, createdAt: now.toISOString(), updatedAt: now.toISOString() }],
  notes: [], stickies: [{ id: 'st-1', title: '一次性提醒', content: '测试一次性提醒内容', kind: 'reminder', pinned: false, remindAt: new Date(now.getTime() - 60000).toISOString(), repeat: null, status: 'pending', createdAt: now.toISOString(), updatedAt: now.toISOString(), notified: false }],
  notifications: [], tombstones: [], settings: { theme: 'system', autoLaunch: false, closeToTray: true, reminderPopup: true, reminderSound: false, stickySearchHistory: true, itemSearchHistory: true, expiryTiers: { 30: true, 15: true, 7: true, 1: true } }, savedNames: { place: [], container: [] }, searchHistory: { item: [], sticky: [] }, onboardingDone: true, createdAt: now.toISOString()
}
fs.writeFileSync(path.join(PROFILE, 'data.json'), JSON.stringify(state))
killElectron(); await sleep(500)
await launch()
const p = await connect(PORT)
const ev = (e) => p.evaluate(e)
console.log('L1_BADGE ' + await ev('(function(){var b=document.querySelector("[data-testid=bell-badge]");return b?b.textContent:"none"})()'))
console.log('L1_REMIND ' + await ev('(function(){var w=document.querySelectorAll("body *");return "n/a"})()'))
console.log('L1_DISK ' + JSON.stringify(readDisk()))
await ev('(function(){document.querySelector("[data-testid=bell]").click();return 1})()')
await sleep(800)
const rectS = await ev('(function(){var bs=[].slice.call(document.querySelectorAll("[data-testid=notification-panel] button"));var b=bs.find(function(x){return x.textContent.trim()==="全部标为已读"});if(!b)return "none";var r=b.getBoundingClientRect();return JSON.stringify({x:r.x+r.width/2,y:r.y+r.height/2})})()')
console.log('L1_BTN ' + rectS)
if (rectS !== 'none') { const r = JSON.parse(rectS); await p.send('Input.dispatchMouseEvent', { type: 'mousePressed', x: r.x, y: r.y, button: 'left', clickCount: 1 }); await p.send('Input.dispatchMouseEvent', { type: 'mouseReleased', x: r.x, y: r.y, button: 'left', clickCount: 1 }) }
await sleep(1500)
console.log('L1_AFTER_BADGE ' + await ev('(function(){var b=document.querySelector("[data-testid=bell-badge]");return b?b.textContent:"none"})()'))
console.log('L1_AFTER_DISK ' + JSON.stringify(readDisk()))
await p.close(); killElectron(); await sleep(1200)
await launch()
const p2 = await connect(PORT)
const ev2 = (e) => p2.evaluate(e)
console.log('L2_BADGE ' + await ev2('(function(){var b=document.querySelector("[data-testid=bell-badge]");return b?b.textContent:"none"})()'))
console.log('L2_DISK ' + JSON.stringify(readDisk()))
console.log('L2_STICKY ' + await ev2('(function(){var els=[].slice.call(document.querySelectorAll(".sticky-card"));return JSON.stringify(els.map(function(e){return e.innerText.replace(/\n/g," | ").slice(0,60)}))})()'))
await p2.close(); killElectron()
