// 1.1.2 新增功能 E2E：关于页链接、模板图标自动选中、分类置顶、两处搜索历史、提示音改 wav
import fs from 'node:fs'
import { listTargets, connect, waitFor } from './cdp.mjs'

const results = []
function check(name, ok, detail) {
  results.push({ name: name, ok: !!ok, detail: detail === undefined ? '' : String(detail) })
  console.log((ok ? 'PASS' : 'FAIL') + ' | ' + name + (detail === undefined || detail === '' ? '' : ' | ' + detail))
}
function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms) }) }

async function waitPort(port, ms, filter) {
  const end = Date.now() + ms
  while (Date.now() < end) {
    try {
      const t = await listTargets(port)
      if (t && t.length) {
        if (!filter) return t
        const found = t.filter(function (x) { return x.url.indexOf(filter) >= 0 })
        if (found.length) return found
      }
    } catch (e) {}
    await sleep(250)
  }
  return null
}

const targets = await waitPort(9222, 25000, 'index.html')
if (!targets) { console.log('NO_CDP'); process.exit(2) }
const client = await connect(9222, 'index.html')
const ev = function (expr) { return client.evaluate(expr) }
const shot = function (name) { return Promise.race([client.shot('.tmp-shots/' + name + '.png').catch(function () { return null }), sleep(9000)]) }

const INSTALL = [
  'window.__t = {',
  '  all: function (id) { return Array.prototype.filter.call(document.querySelectorAll("[data-testid]"), function (e) { return e.getAttribute("data-testid") === id }) },',
  '  q: function (id, i) { return window.__t.all(id)[i || 0] || null },',
  '  count: function (id) { return window.__t.all(id).length },',
  '  texts: function (id) { return window.__t.all(id).map(function (e) { return e.innerText }) },',
  '  has: function (id) { return !!window.__t.q(id) },',
  '  text: function (id, i) { var e = window.__t.q(id, i); return e ? e.innerText : "" },',
  '  click: function (id, i) { var el = window.__t.q(id, i); if (!el) throw new Error("missing " + id); el.click(); return true },',
  '  fill: function (id, value) {',
  '    var el = window.__t.q(id); if (!el) throw new Error("missing " + id)',
  '    var proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype',
  '    var desc = Object.getOwnPropertyDescriptor(proto, "value")',
  '    desc.set.call(el, value)',
  '    el.dispatchEvent(new Event("input", { bubbles: true }))',
  '    el.dispatchEvent(new Event("change", { bubbles: true }))',
  '    return true',
  '  },',
  '  focusEmpty: function (id) { var el = window.__t.q(id); if (document.activeElement && document.activeElement.blur) document.activeElement.blur(); window.__t.fill(id, ""); el.focus(); return true },',
  '  blur: function () { document.body.dispatchEvent(new MouseEvent("mousedown", { bubbles: true })); return true },',
  '  home: function () { var b = document.querySelector(".brand"); if (!b) return false; b.click(); return true },',
  '  enter: function (id) { var el = window.__t.q(id); el.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", bubbles: true })); return true },',
  '  icons: function () { return Array.prototype.slice.call(document.querySelectorAll(".icon-choice")).map(function (e) { return e.innerText }) },',
  '  activeIcon: function () { var a = document.querySelector(".icon-choice.active"); return a ? a.innerText : "" },',
  '  iconClick: function (text) {',
  '    var arr = Array.prototype.slice.call(document.querySelectorAll(".icon-choice"))',
  '    for (var i = 0; i < arr.length; i++) { if (arr[i].innerText === text) { arr[i].click(); return true } }',
  '    throw new Error("no icon " + text)',
  '  },',
  '  historyDelete: function (text) {',
  '    var rows = Array.prototype.slice.call(document.querySelectorAll(".search-history-row"))',
  '    for (var i = 0; i < rows.length; i++) {',
  '      if (rows[i].innerText.indexOf(text) >= 0) {',
  '        var d = rows[i].querySelector(".search-history-del")',
  '        if (d) { d.click(); return true }',
  '      }',
  '    }',
  '    return false',
  '  },',
  '  cardNames: function () { return Array.prototype.slice.call(document.querySelectorAll("[data-testid=category-card] .cat-name")).map(function (e) { return e.innerText.trim() }) },',
  '  state: function () { return window.guina.getState() },',
  '}',
  'true'
].join(String.fromCharCode(10))

await waitFor(client, '!!document.body', 20000, 'body')
await client.evaluate(INSTALL)
await sleep(1200)
if (await ev("__t.has('onboarding-skip')")) {
  await ev("__t.click('onboarding-skip')")
  await sleep(800)
}

// 预置一条物品与一条便签，供搜索与历史验证
const seeded = await ev("(async function () { var a = await window.guina.createItem('cat-item', { name: '螺丝刀', locationType: 'container', locationLabel: '工具箱', locationName: '上层', fields: {} }); var b = await window.guina.createSticky({ content: '喝水提醒测试', kind: 'note' }); return { item: !!(a && a.ok), sticky: !!(b && b.ok) } })()")
check('预置条目与便签成功', seeded.item && seeded.sticky, JSON.stringify(seeded))
await sleep(600)

// ---- 1. 新建分类：选模板自动选中图标，模板图标排最后 ----
await ev("__t.click('add-category')")
await waitFor(client, "!!__t.has('template-book')", 6000, 'modal')
const tplOrder = await ev("__t.texts('template-book').length ? Array.prototype.slice.call(document.querySelectorAll('.template-row .template-btn')).map(function (e) { return e.getAttribute('data-testid') }) : []")
check('模板顺序为 图书 / 物品 / 食品 / 药品', JSON.stringify(tplOrder) === JSON.stringify(['template-book', 'template-item', 'template-food', 'template-medicine']), JSON.stringify(tplOrder))
const iconState = await ev("({ icons: __t.icons(), active: __t.activeIcon() })")
check('图标共 14 个且模板图标排在最后（📚📦🍎💊）', iconState.icons.length === 14 && iconState.icons.slice(-4).join('') === '📚📦🍎💊', JSON.stringify(iconState.icons))
check('新建分类默认选中图书图标 📚', iconState.active === '📚', iconState.active)
await ev("__t.click('template-food')")
await sleep(300)
check('选「食品」模板后自动选中 🍎', (await ev("__t.activeIcon()")) === '🍎', await ev("__t.activeIcon()"))
await ev("__t.click('template-medicine')")
await sleep(300)
check('选「药品」模板后自动选中 💊', (await ev("__t.activeIcon()")) === '💊', await ev("__t.activeIcon()"))
await ev("__t.iconClick('🧸')")
await sleep(250)
const manual = await ev("({ active: __t.activeIcon(), tpl: !!document.querySelector('[data-testid=template-medicine].active') })")
check('选模板后仍可手动改图标（自动选中不是固定死）', manual.active === '🧸' && manual.tpl === true, JSON.stringify(manual))
await ev("__t.click('template-medicine')")
await sleep(250)
await ev("__t.fill('category-name', '测试分类112')")
await ev("__t.click('modal-confirm')")
await waitFor(client, "(async function () { var s = await window.guina.getState(); return s.categories.some(function (c) { return c.name === '测试分类112' }) })()", 6000, 'new category')
const newCat = await ev("(async function () { var s = await window.guina.getState(); var c = s.categories.filter(function (x) { return x.name === '测试分类112' })[0]; return c ? { icon: c.icon, baseTemplate: c.baseTemplate } : null })()")
check('新建分类保存模板图标 💊 / 药品模板', newCat && newCat.icon === '💊' && newCat.baseTemplate === 'medicine', JSON.stringify(newCat))
await sleep(500)
await shot('e2e9-category-template')

// ---- 2. 分类置顶 / 取消置顶 ----
const names0 = await ev("__t.cardNames()")
check('初始分类按内置顺序排列', names0.length === 5 && names0[0].indexOf('图书') === 0 && names0[4].indexOf('测试分类112') === 0, JSON.stringify(names0))
check('所有分类（含内置）都有「更多」菜单', (await ev("__t.count('category-more')")) === 5, await ev("__t.count('category-more')"))

async function pinCategory(name) {
  const names = await ev("__t.cardNames()")
  const idx = names.findIndex(function (n) { return n.indexOf(name) >= 0 })
  if (idx < 0) throw new Error('category not found: ' + name)
  await ev('__t.click("category-more", ' + idx + ')')
  await sleep(250)
  await ev("__t.click('category-pin')")
  await sleep(800)
}

await pinCategory('食品')
const afterPin = await ev("(async function () { var s = await window.guina.getState(); var f = s.categories.filter(function (c) { return c.name === '食品' })[0]; return { names: __t.cardNames(), pinned: !!(f && f.pinned), toast: __t.text('toast') } })()")
check('置顶「食品」后排到第一并显示 📌', afterPin.names[0].indexOf('食品') === 0 && afterPin.names[0].indexOf('📌') >= 0, JSON.stringify(afterPin.names))
check('置顶状态写入数据（pinned=true）', afterPin.pinned === true)
check('置顶后提示「分类已置顶」', afterPin.toast.indexOf('分类已置顶') >= 0, afterPin.toast)

await pinCategory('测试分类112')
const afterPin2 = await ev("__t.cardNames()")
check('两个置顶分类中后置顶的排第一（按置顶时间倒序）', afterPin2[0].indexOf('测试分类112') === 0 && afterPin2[1].indexOf('食品') === 0, JSON.stringify(afterPin2))

async function unpinCategory(name) {
  const names = await ev("__t.cardNames()")
  const idx = names.findIndex(function (n) { return n.indexOf(name) >= 0 })
  if (idx < 0) throw new Error('category not found: ' + name)
  await ev('__t.click("category-more", ' + idx + ')')
  await sleep(250)
  const label = await ev("__t.text('category-pin')")
  await ev("__t.click('category-pin')")
  await sleep(800)
  return label
}

const unpinLabel = await unpinCategory('食品')
const afterUnpin = await ev("(async function () { var s = await window.guina.getState(); var f = s.categories.filter(function (c) { return c.name === '食品' })[0]; return { names: __t.cardNames(), pinned: !!(f && f.pinned), toast: __t.text('toast') } })()")
check('置顶后菜单项变为「取消置顶」', unpinLabel === '取消置顶', unpinLabel)
check('取消置顶后 📌 消失且不再是第一', afterUnpin.names[0].indexOf('食品') !== 0 && afterUnpin.names.filter(function (n) { return n.indexOf('📌') >= 0 }).length === 1, JSON.stringify(afterUnpin.names))
check('取消置顶提示「已取消置顶」', afterUnpin.toast.indexOf('已取消置顶') >= 0, afterUnpin.toast)
await unpinCategory('测试分类112')
const namesBack = await ev("__t.cardNames()")
check('全部取消后恢复原来的内置顺序', namesBack[0].indexOf('图书') === 0 && namesBack[4].indexOf('测试分类112') === 0, JSON.stringify(namesBack))
await shot('e2e9-category-pin')

// ---- 3. 物品搜索历史 ----
await ev("__t.focusEmpty('search-input')")
await ev("__t.fill('search-input', '螺丝刀')")
await waitFor(client, "!!document.querySelector('[data-testid=search-hit]')", 6000, 'item hit')
await ev("__t.click('search-hit')")
await sleep(800)
const h1 = await ev("(async function () { var s = await window.guina.getState(); return s.searchHistory.item.map(function (e) { return e.text }) })()")
check('搜索物品后写入物品搜索历史', h1[0] === '螺丝刀', JSON.stringify(h1))
await ev("__t.home()")
await sleep(600)
await ev("__t.focusEmpty('search-input')")
await sleep(350)
check('搜索框空焦点时显示「最近搜索」', (await ev("__t.has('search-history')")) === true)
check('最近搜索里是刚搜过的词', (await ev("__t.texts('search-history-item')"))[0] === '螺丝刀', JSON.stringify(await ev("__t.texts('search-history-item')")))

await ev("__t.fill('search-input', '工具箱')")
await waitFor(client, "!!document.querySelector('[data-testid=search-hit]')", 6000, 'item hit 2')
await ev("__t.enter('search-input')")
await sleep(800)
const h2 = await ev("(async function () { var s = await window.guina.getState(); return s.searchHistory.item.map(function (e) { return e.text }) })()")
check('新搜索的词排在最前', h2[0] === '工具箱' && h2[1] === '螺丝刀', JSON.stringify(h2))

await ev("__t.home()")
await sleep(500)
await ev("__t.blur()")
await sleep(200)
await ev("__t.focusEmpty('search-input')")
await sleep(350)
const rowTexts = await ev("__t.texts('search-history-item')")
const olderIdx = rowTexts.indexOf('螺丝刀')
await ev('__t.click("search-history-item", ' + olderIdx + ')')
await sleep(700)
const h3 = await ev("(async function () { var s = await window.guina.getState(); return s.searchHistory.item.map(function (e) { return e.text }) })()")
check('点击历史条目自动置顶回第一个', h3[0] === '螺丝刀', JSON.stringify(h3))
check('点击历史条目回填搜索框', (await ev("__t.q('search-input').value")) === '螺丝刀')

await ev("__t.fill('search-input', '')")
await ev("__t.blur()")
await sleep(250)
await ev("__t.focusEmpty('search-input')")
await sleep(300)
await ev("__t.historyDelete('工具箱')")
await sleep(700)
const h4 = await ev("(async function () { var s = await window.guina.getState(); return { texts: s.searchHistory.item.map(function (e) { return e.text }), dom: __t.texts('search-history-item') } })()")
check('删除单条搜索历史生效', h4.texts.indexOf('工具箱') < 0 && h4.dom.indexOf('工具箱') < 0, JSON.stringify(h4))

await ev("(async function () { for (var i = 1; i <= 8; i++) { await window.guina.addSearchHistory('item', '历史词' + i) } return true })()")
await sleep(500)
await ev("__t.blur()")
await sleep(150)
await ev("__t.focusEmpty('search-input')")
await sleep(350)
const shown = await ev("__t.texts('search-history-item')")
check('最近搜索最多显示 5 条', shown.length === 5, JSON.stringify(shown))
check('显示最近的 5 条且新的在前', shown[0] === '历史词8' && shown[4] === '历史词4', JSON.stringify(shown))
await ev("(async function () { for (var i = 1; i <= 55; i++) { await window.guina.addSearchHistory('item', '批量' + i) } return true })()")
await sleep(900)
const cap = await ev("(async function () { var s = await window.guina.getState(); return s.searchHistory.item.length })()")
check('搜索历史最多保留 50 条', cap === 50, cap)
await shot('e2e9-search-history')

// ---- 4. 便签搜索历史 ----
await ev("__t.blur()")
await sleep(200)
await ev("__t.fill('sticky-search', '喝水')")
await sleep(300)
await ev("__t.enter('sticky-search')")
await sleep(700)
const s1 = await ev("(async function () { var s = await window.guina.getState(); return s.searchHistory.sticky.map(function (e) { return e.text }) })()")
check('搜索便签后写入便签搜索历史', s1[0] === '喝水', JSON.stringify(s1))
await ev("__t.fill('sticky-search', '')")
await ev("__t.blur()")
await sleep(250)
await ev("__t.focusEmpty('sticky-search')")
await sleep(350)
check('便签搜索框空焦点时显示最近搜索', (await ev("__t.has('sticky-search-history')")) === true)
await ev("__t.click('sticky-search-history-item')")
await sleep(600)
check('点击便签历史条目回填搜索框', (await ev("__t.q('sticky-search').value")) === '喝水', await ev("__t.q('sticky-search').value"))
await ev("__t.fill('sticky-search', '')")
await ev("__t.blur()")
await sleep(250)
await ev("__t.focusEmpty('sticky-search')")
await sleep(300)
await ev("__t.click('sticky-search-history-delete')")
await sleep(700)
const s2 = await ev("(async function () { var s = await window.guina.getState(); return { len: s.searchHistory.sticky.length, dom: __t.has('sticky-search-history') } })()")
check('删除便签搜索历史生效', s2.len === 0 && s2.dom === false, JSON.stringify(s2))

// ---- 5. 关于页（文案 / 链接可点 / 版本） ----
await ev("__t.blur()")
await ev("__t.click('settings-btn')")
await waitFor(client, "!!__t.has('about-card')", 8000, 'about card')
const about = await ev("(function () { var info = function (id) { var e = __t.q(id); return e ? { tag: e.tagName, text: e.innerText.trim() } : null }; return { gh: info('about-github'), bl: info('about-bilibili'), em: info('about-email'), lic: __t.text('about-license'), ver: __t.text('about-version'), card: __t.text('about-card') } })()")
const PKG_VERSION = JSON.parse(fs.readFileSync(new URL('../package.json', import.meta.url), 'utf8')).version
check('关于页 GitHub 是可点击按钮 @KiNineE9', about.gh && about.gh.tag === 'BUTTON' && about.gh.text === '@KiNineE9', JSON.stringify(about.gh))
check('关于页 Bilibili 是可点击按钮 @梦境薇凉i', about.bl && about.bl.tag === 'BUTTON' && about.bl.text === '@梦境薇凉i', JSON.stringify(about.bl))
check('关于页邮箱是可点击按钮 1332004191@qq.com', about.em && about.em.tag === 'BUTTON' && about.em.text === '1332004191@qq.com', JSON.stringify(about.em))
check('关于页写明仅限个人使用', about.lic === '仅限个人使用', about.lic)
check('关于页显示版本 ' + PKG_VERSION, about.ver.indexOf(PKG_VERSION) >= 0, about.ver)
const hrefBefore = await ev('location.href')
await ev("__t.click('about-github')")
await sleep(1800)
check('点击外部链接不破坏应用（页面仍是设置页）', (await ev('location.href')) === hrefBefore && (await ev("!!__t.has('about-card')")) === true, await ev('location.href'))
await shot('e2e9-about')

// ---- 6. 搜索历史开关 ----
await ev("__t.click('toggle-search-history-item')")
await sleep(700)
const off1 = await ev("(async function () { var s = await window.guina.getState(); return { item: s.settings.itemSearchHistory, sticky: s.settings.stickySearchHistory } })()")
check('设置可单独关闭物品搜索历史（便签历史不受影响）', off1.item === false && off1.sticky === true, JSON.stringify(off1))
const addOff = await ev("(async function () { var r = await window.guina.addSearchHistory('item', '关闭后不该记录'); return { ok: r.ok, error: r.error || '' } })()")
check('关闭后不再记录物品搜索历史', addOff.ok === false, JSON.stringify(addOff))
await ev("__t.click('toggle-search-history-sticky')")
await sleep(700)
const off2 = await ev("(async function () { var s = await window.guina.getState(); return { item: s.settings.itemSearchHistory, sticky: s.settings.stickySearchHistory } })()")
check('设置可关闭便签搜索历史', off2.item === false && off2.sticky === false, JSON.stringify(off2))
const addOff2 = await ev("(async function () { var r = await window.guina.addSearchHistory('sticky', '关闭后不该记录'); return { ok: r.ok } })()")
check('关闭后不再记录便签搜索历史', addOff2.ok === false, JSON.stringify(addOff2))
await ev("__t.click('toggle-search-history-item')")
await sleep(400)
await ev("__t.click('toggle-search-history-sticky')")
await sleep(600)
const onAgain = await ev("(async function () { var s = await window.guina.getState(); return { item: s.settings.itemSearchHistory, sticky: s.settings.stickySearchHistory } })()")
check('两个开关可以重新打开', onAgain.item === true && onAgain.sticky === true, JSON.stringify(onAgain))

// ---- 7. 测试提示音改为 08_03.wav 播放 ----
await ev("(function () { window.__aud = { decode: 0, start: 0, osc: 0, dur: 0 }; var A = window.AudioContext || window.webkitAudioContext; var op = A.prototype.decodeAudioData; A.prototype.decodeAudioData = function () { window.__aud.decode++; return op.apply(this, arguments) }; var SB = window.AudioBufferSourceNode.prototype; var os = SB.start; SB.start = function () { try { if (this.buffer && this.buffer.duration > 0.3) { window.__aud.start++; window.__aud.dur = this.buffer.duration } } catch (e) {} return os.apply(this, arguments) }; var OB = window.OscillatorNode.prototype; var oo = OB.start; OB.start = function () { window.__aud.osc++; return oo.apply(this, arguments) }; return true })()")
await ev("__t.click('btn-test-sound')")
await sleep(500)
const toastText = await ev("__t.text('toast')")
check('测试提示音给出提示文案', toastText.indexOf('已播放测试提示音') >= 0, toastText)
await sleep(2000)
const aud = await ev('window.__aud')
check('提示音解码并播放打包的 wav（时长约 1.23 秒，未走振荡器兜底）', aud.decode >= 1 && aud.start >= 1 && aud.osc === 0 && aud.dur > 1.0 && aud.dur < 1.6, JSON.stringify(aud))
await shot('e2e9-test-sound')

const failed = results.filter(function (r) { return !r.ok })
console.log(JSON.stringify({ total: results.length, passed: results.length - failed.length, failed: failed }))
if (failed.length) process.exitCode = 1