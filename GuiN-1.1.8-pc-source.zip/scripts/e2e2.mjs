import { listTargets, connect, waitFor } from './cdp.mjs'

const results = []
function check(name, ok, detail) {
  results.push({ name: name, ok: !!ok, detail: detail === undefined ? '' : String(detail) })
  console.log((ok ? 'PASS' : 'FAIL') + ' | ' + name + (detail === undefined || detail === '' ? '' : ' | ' + detail))
}
function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms) }) }

async function waitPort(port, ms, filter) {
  const end = Date.now() + ms
  while (Date.now() < end) {
    try {
      const t = await listTargets(port)
      if (t && t.length) {
        if (!filter) return t
        const found = t.filter(function (x) { return x.url.indexOf(filter) >= 0 })
        if (found.length) return found
      }
    } catch (e) {}
    await sleep(250)
  }
  return null
}

const targets = await waitPort(9222, 25000, 'index.html')
if (!targets) { console.log('NO_CDP'); process.exit(2) }
const client = await connect(9222, 'index.html')
const ev = function (expr) { return client.evaluate(expr) }
const shot = function (name) { return Promise.race([client.shot('.tmp-shots/' + name + '.png').catch(function () { return null }), sleep(9000)]) }

const INSTALL = [
  'window.__t = {',
  '  all: function (id) { return Array.prototype.filter.call(document.querySelectorAll("[data-testid]"), function (e) { return e.getAttribute("data-testid") === id }) },',
  '  q: function (id, i) { return window.__t.all(id)[i || 0] || null },',
  '  count: function (id) { return window.__t.all(id).length },',
  '  texts: function (id) { return window.__t.all(id).map(function (e) { return e.innerText }) },',
  '  has: function (id) { return !!window.__t.q(id) },',
  '  text: function (id, i) { var e = window.__t.q(id, i); return e ? e.innerText : "" },',
  '  click: function (id, i) { var el = window.__t.q(id, i); if (!el) throw new Error("missing " + id); el.click(); return true },',
  '  clickText: function (id, needle) { var list = window.__t.all(id); for (var k = 0; k < list.length; k++) { if (list[k].innerText.indexOf(needle) >= 0) { list[k].click(); return true } } throw new Error("no " + id + " with " + needle) },',
  '  set: function (id, v) {',
  '    var el = window.__t.q(id)',
  '    if (!el) throw new Error("missing " + id)',
  '    var proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : el instanceof HTMLSelectElement ? HTMLSelectElement.prototype : HTMLInputElement.prototype',
  '    Object.getOwnPropertyDescriptor(proto, "value").set.call(el, v)',
  '    el.dispatchEvent(new Event("input", { bubbles: true }))',
  '    el.dispatchEvent(new Event("change", { bubbles: true }))',
  '    return true',
  '  },',
  '  hasClass: function (id, cls, i) { var el = window.__t.q(id, i); return !!el && String(el.className).split(" ").indexOf(cls) >= 0 },',
  '  back: function () { var btns = Array.prototype.slice.call(document.querySelectorAll("button")); for (var k = 0; k < btns.length; k++) { if (btns[k].innerText.indexOf("返回") >= 0) { btns[k].click(); return true } } return false },',
  '  state: function () { return window.guina.getState() },',
  '}',
  'true'
].join(String.fromCharCode(10))

await waitFor(client, '!!document.body', 20000, 'body')
await client.evaluate(INSTALL)
await sleep(1200)

// ---- 重启后数据仍在 ----
const snap1 = await ev("__t.state().then(function (s) { return { items: s.items.length, notes: s.notes.length, notifs: s.notifications.length, unread: s.notifications.filter(function (n) { return !n.read && !n.deleted }).length } })")
check('重启软件后数据仍在', snap1.items === 5 && snap1.notes === 1, JSON.stringify(snap1))
check('重启后同一档位不重复生成通知', snap1.notifs === 3, JSON.stringify(snap1))
await shot('11-restart-home')

// ---- 主题 ----
await ev("__t.click('settings-btn')")
await waitFor(client, "!!document.querySelector('[data-testid=settings-page]')", 8000, 'settings page')
await ev("__t.click('theme-light')")
await sleep(900)
const lightDark = await ev("window.matchMedia('(prefers-color-scheme: dark)').matches")
const lightBg = await ev("getComputedStyle(document.body).backgroundColor")
check('切换浅色主题即时生效', lightDark === false, lightBg)
await shot('12-theme-light')
await ev("__t.click('theme-dark')")
await sleep(900)
const darkDark = await ev("window.matchMedia('(prefers-color-scheme: dark)').matches")
check('切换深色主题即时生效', darkDark === true, await ev("getComputedStyle(document.body).backgroundColor"))
await shot('13-theme-dark')
await ev("__t.click('theme-system')")
await sleep(600)
const sysTheme = await ev("__t.state().then(function (s) { return s.settings.theme })")
check('跟随系统主题可设置', sysTheme === 'system', sysTheme)

// ---- 开机自启开关 ----
const autoBefore = await ev("__t.state().then(function (s) { return s.settings.autoLaunch })")
await ev("__t.click('toggle-auto-launch')")
await sleep(700)
const autoAfter = await ev("__t.state().then(function (s) { return s.settings.autoLaunch })")
check('开机自启开关可关闭并生效', autoBefore === true && autoAfter === false, String(autoBefore) + ' -> ' + String(autoAfter))
await ev("__t.click('toggle-auto-launch')")
await sleep(700)
check('开机自启可重新打开', (await ev("__t.state().then(function (s) { return s.settings.autoLaunch })")) === true)

// ---- 通知中心：新建一条 20 天后到期的食品来驱动 ----
await ev("__t.back()")
await waitFor(client, "!!document.querySelector('[data-testid=bell]')", 8000, 'home topbar')
await ev("window.__t.clickText('category-card', '食品')")
await waitFor(client, "!!document.querySelector('[data-testid=add-item]')", 8000, 'food category for notif')
const expIn20 = await ev("(function(){ var d = new Date(); d.setDate(d.getDate() + 20); var m = d.getMonth() + 1; var day = d.getDate(); return d.getFullYear() + '-' + (m < 10 ? '0' + m : m) + '-' + (day < 10 ? '0' + day : day) })()")
await ev("__t.click('add-item')")
await waitFor(client, "!!document.querySelector('[data-testid=form-name]')", 8000, 'notif item form')
await ev("__t.set('form-name', '测试牛奶')")
await ev("__t.click('form-location-place')")
await ev("__t.set('form-location-name', '冰箱')")
await ev("__t.set('form-field-foodType', '液体')")
await ev("__t.click('form-field-opened')")
await ev("__t.set('form-field-expiresAt', '" + expIn20 + "')")
await ev("__t.click('form-submit')")
await waitFor(client, "__t.texts('item-row').join('|').indexOf('测试牛奶') >= 0", 10000, 'new food row')
await ev("__t.back()")
await waitFor(client, "!!document.querySelector('[data-testid=bell]')", 8000, 'home for bell')
await sleep(2500)
const milkInfo = await ev("__t.state().then(function (s) { var it = s.items.filter(function (i) { return i.name === '测试牛奶' })[0] || {}; var mine = s.notifications.filter(function (n) { return !n.deleted && n.itemId === it.id }); return { itemId: it.id, mine: mine.length, unread: s.notifications.filter(function (n) { return !n.read && !n.deleted }).length, tiers: mine.map(function (n) { return n.tier }) } })")
check('临期食品自动生成提醒（未读通知）', milkInfo.mine === 1 && milkInfo.unread >= 1, JSON.stringify(milkInfo))
const badge = await ev("__t.has('bell-badge') ? __t.text('bell-badge') : ''")
check('铃铛显示感叹号与未读数量角标', badge.indexOf('!') >= 0 && badge.replace(/[^0-9]/g, '') === String(milkInfo.unread), badge)
await shot('14-bell-badge')
await ev("__t.click('bell')")
await waitFor(client, "!!document.querySelector('[data-testid=notification-panel]')", 8000, 'notif panel')
const notifText = await ev("__t.texts('notif-item').join(' || ')")
check('通知面板显示食品名称/剩余天数/位置', notifText.indexOf('测试牛奶') >= 0 && notifText.indexOf('还剩') >= 0 && notifText.indexOf('冰箱') >= 0, notifText.slice(0, 160))
await shot('15-notification-panel')

// 同一档位不重复
const notifCountBefore = await ev("__t.count('notif-item')")
await ev("window.guina.updateSettings({ expiryTiers: { 30: false, 15: true, 7: true, 1: true } })")
await sleep(900)
await ev("window.guina.updateSettings({ expiryTiers: { 30: true, 15: true, 7: true, 1: true } })")
await sleep(1200)
const milkCountAfter = await ev("__t.state().then(function (s) { var it = s.items.filter(function (i) { return i.name === '测试牛奶' })[0] || {}; return s.notifications.filter(function (n) { return !n.deleted && n.itemId === it.id }).length })")
const notifCountAfter = await ev("__t.count('notif-item')")
check('同一档位不重复提醒（通知不堆叠）', milkCountAfter === 1 && notifCountBefore === notifCountAfter, 'milk=' + String(milkCountAfter) + ' panel ' + String(notifCountBefore) + '->' + String(notifCountAfter))

// 单条已读：手动点「标为已读」角标应减少，再点回来恢复未读（后面还要用这条测定位）
const clickMilkRead = "(function(){ var items = __t.all('notif-item'); for (var k = 0; k < items.length; k++) { if (items[k].innerText.indexOf('测试牛奶') >= 0) { var btn = items[k].querySelector('[data-testid=notif-read]'); if (!btn) throw new Error('no read btn'); btn.click(); return true } } throw new Error('no milk row') })()"
const unreadBeforeManual = Number(String(await ev("__t.has('bell-badge') ? __t.text('bell-badge') : '0'")).replace(/[^0-9]/g, '') || '0')
await ev(clickMilkRead)
await sleep(900)
const unreadAfterManual = Number(String(await ev("__t.has('bell-badge') ? __t.text('bell-badge') : '0'")).replace(/[^0-9]/g, '') || '0')
check('单条标记已读后角标数量减少', unreadAfterManual === unreadBeforeManual - 1, String(unreadBeforeManual) + ' -> ' + String(unreadAfterManual))
await ev(clickMilkRead)
await sleep(900)
const unreadRestored = Number(String(await ev("__t.has('bell-badge') ? __t.text('bell-badge') : '0'")).replace(/[^0-9]/g, '') || '0')
check('单条标为未读后角标恢复', unreadRestored === unreadBeforeManual, String(unreadBeforeManual) + ' -> ' + String(unreadRestored))

// 定位跳转 + 高亮
await ev("(function(){ var items = __t.all('notif-item'); var btns = __t.all('notif-locate'); for (var k = 0; k < items.length; k++) { if (items[k].innerText.indexOf('测试牛奶') >= 0) { btns[k].click(); return true } } throw new Error('no notif row for milk') })()")
await waitFor(client, "!!document.querySelector('[data-testid=item-row]') && !!document.querySelector('[data-testid=category-title]')", 8000, 'located category page')
await sleep(250)
const catTitle = await ev("__t.has('category-title') ? __t.text('category-title') : ''")
const hlNow = await ev("Array.prototype.some.call(document.querySelectorAll('[data-testid=item-row]'), function (e) { return String(e.className).indexOf('hl-item') >= 0 })")
check('通知「定位」跳转到对应分类', catTitle.indexOf('食品') >= 0, catTitle.replace(/\n/g, ' '))
check('定位后条目高亮', hlNow === true)
await shot('16-locate-highlight')
await sleep(2300)
const hlLater = await ev("Array.prototype.some.call(document.querySelectorAll('[data-testid=item-row]'), function (e) { return String(e.className).indexOf('hl-item') >= 0 })")
check('高亮约 2 秒后自动消失', hlLater === false)

// 打开 / 关闭面板不算已读（1.1.8 起只有手动点「标为已读」才不再提醒）
await ev("__t.click('bell')")
await waitFor(client, "!!document.querySelector('[data-testid=notification-panel]')", 8000, 'panel again')
const stillUnreadCount = await ev("document.querySelectorAll('.notif-item:not(.read)').length")
const readCountNow = await ev("document.querySelectorAll('.notif-item.read').length")
check('关闭面板不会自动标为已读', stillUnreadCount >= 1 && readCountNow === 0, 'unread=' + String(stillUnreadCount) + ' read=' + String(readCountNow))
const delIdx = await ev("(function(){ var items = __t.all('notif-item'); for (var k = 0; k < items.length; k++) { if (items[k].innerText.indexOf('测试牛奶') >= 0) return k } return -1 })()")
await ev("__t.click('notif-delete', " + String(delIdx) + ")")
await sleep(400)
if (await ev("__t.has('modal-confirm')")) { await ev("__t.click('modal-confirm')"); await sleep(600) }
const milkGone = await ev("__t.state().then(function (s) { var it = s.items.filter(function (i) { return i.name === '测试牛奶' })[0] || {}; return s.notifications.filter(function (n) { return !n.deleted && n.itemId === it.id }).length })")
check('单条通知可删除', milkGone === 0, String(milkGone))

// 一键已读
await ev("__t.click('notif-read-all')")
await sleep(400)
if (await ev("__t.has('modal-confirm')")) { await ev("__t.click('modal-confirm')"); await sleep(800) }
const unreadGone = await ev("__t.state().then(function (s) { return s.notifications.filter(function (n) { return !n.read && !n.deleted }).length })")
const badgeGone = await ev("__t.has('bell-badge') ? __t.text('bell-badge') : '0'")
check('一键已读生效（角标消失）', unreadGone === 0 && !(await ev("__t.has('bell-badge')")), String(unreadGone) + ' badge=' + badgeGone)

// 一键删除已读
await ev("__t.click('notif-delete-read')")
await sleep(400)
if (await ev("__t.has('modal-confirm')")) { await ev("__t.click('modal-confirm')"); await sleep(700) }
const notifLeft = await ev("__t.count('notif-item')")
check('一键删除已读生效', notifLeft === 0, String(notifLeft))
await shot('17-notifications-cleared')
await ev("__t.click('notif-close')")
await sleep(300)
await ev("__t.back()")
await waitFor(client, "!!document.querySelector('[data-testid=sticky-add-note]')", 8000, 'home before sticky')

// ---- 便利贴提醒：弹窗 + 提示音开启 ----
await ev("__t.click('sticky-add-reminder')")
await waitFor(client, "!!document.querySelector('[data-testid=sticky-content]')", 8000, 'sticky form')
await ev("__t.set('sticky-content', '记得喝水')")
await ev("__t.set('sticky-remind', '2026-11-01T09:00')")
await ev("__t.click('modal-confirm')")
await sleep(600)
check('便利贴创建成功', (await ev("__t.count('sticky-card')")) === 1)
await shot('18-sticky-card')

let reminderTargets = await waitPort(9222, 25000, 'reminder.html')
const gotReminder = !!reminderTargets
check('便利贴到点后弹出提醒窗口', gotReminder)
if (gotReminder) {
  const rc = await connect(9222, 'reminder.html')
  await sleep(800)
  const rtext = await rc.evaluate("document.body.innerText")
  await rc.shot('.tmp-shots/19-reminder-window.png')
  check('提醒窗口显示提醒内容', rtext.indexOf('记得喝水') >= 0, rtext.replace(/\n/g, ' ').slice(0, 120))
  await rc.evaluate("(function(){var b=document.querySelector('[data-testid=reminder-ok]');if(b)b.click();return true})()")
  rc.close()
  await sleep(1500)
  const stillOpen = await waitPort(9222, 3000, 'reminder.html')
  check('提醒窗口「知道了」可关闭', !stillOpen)
}
const notified = await ev("__t.state().then(function (s) { return s.stickies.filter(function (x) { return x.notified }).length })")
check('提醒已标记为已提醒（同一次不重复弹）', notified >= 1, String(notified))

// ---- 关闭弹窗与提示音后仅托盘闪烁 ----
await ev("window.guina.updateSettings({ reminderPopup: false, reminderSound: false })")
await sleep(500)
await ev("__t.click('sticky-add-reminder')")
await waitFor(client, "!!document.querySelector('[data-testid=sticky-content]')", 8000, 'sticky form 2')
await ev("__t.set('sticky-content', '静默提醒测试')")
await ev("__t.set('sticky-remind', '2026-11-01T10:00')")
await ev("__t.click('modal-confirm')")
await sleep(23000)
const silentReminder = await waitPort(9222, 2000, 'reminder.html')
const silentNotified = await ev("__t.state().then(function (s) { return s.stickies.filter(function (x) { return x.notified }).length })")
check('关闭弹窗后到点不再弹窗（仅托盘提醒）', !silentReminder && silentNotified >= 2, 'notified=' + String(silentNotified))
await ev("window.guina.updateSettings({ reminderPopup: true, reminderSound: true })")
await sleep(300)

// ---- 关闭窗口驻留托盘 ----
await ev("window.close()")
await sleep(1500)
let alive = false
try { alive = (await ev("1 === 1")) === true } catch (e) { alive = false }
check('点关闭后程序仍在运行（驻留托盘）', alive)
const hiddenAlive = await ev("!!document.querySelector('[data-testid=search-input]')")
check('关闭窗口只是隐藏，界面仍在（下次唤出无需重建）', hiddenAlive === true)
await ev("window.guina.showMainWindow()")
await sleep(1200)
await shot('21-window-restored')

// ---- 单实例：重复启动唤出已有窗口 ----
const cp = await import('node:child_process')
const exe = 'node_modules/electron/dist/electron.exe'
const ud = process.env.GUINA_UD || '.tmp-userdata'
const second = cp.spawn(exe, ['.', '--no-sandbox', '--disable-gpu', '--user-data-dir=F:/DSH/GC/GuiNa/' + ud], { stdio: 'ignore' })
const secondExit = await new Promise(function (resolve) {
  const timer = setTimeout(function () { try { second.kill() } catch (e) {} resolve('timeout') }, 15000)
  second.on('exit', function (code) { clearTimeout(timer); resolve(String(code)) })
})
check('重复启动不新开进程（单实例锁）', secondExit !== 'timeout', 'second exit=' + secondExit)
await sleep(800)
const pageCount = (await listTargets(9222)).filter(function (t) { return t.type === 'page' }).length
check('重复启动后仍只有一个主窗口', pageCount >= 1, 'pages=' + String(pageCount))

console.log('RESULT_JSON ' + JSON.stringify(results))
await ev("window.guina.quitApp()").catch(function () { return true })
await sleep(1500)
process.exit(0)