import { connect } from './cdp.mjs'
import { execFileSync } from 'node:child_process'

const ADB = 'F:/Android/sdk/platform-tools/adb.exe'
function adb(...args) {
  try { return execFileSync(ADB, args, { encoding: 'utf8' }).trim() } catch (e) { return 'ERR ' + e.message }
}
function sleep(ms) { return new Promise((r) => setTimeout(r, ms)) }

const page = await connect(9333)
const ev = (expr) => page.evaluate(expr)

const raw = await ev('window.GuinaNative.loadData()')
const state = JSON.parse(raw)
const now = Date.now()
state.stickies = (state.stickies || []).filter((s) => !String(s.id).startsWith('probe-'))
state.stickies.push({
  id: 'probe-past-once',
  title: '探针一次性提醒',
  content: '这条应该只提示一次',
  kind: 'reminder',
  pinned: false,
  remindAt: new Date(now - 3 * 60 * 1000).toISOString(),
  repeat: null,
  status: 'pending',
  notified: false,
  createdAt: new Date(now - 5 * 60 * 1000).toISOString(),
  updatedAt: new Date(now - 5 * 60 * 1000).toISOString()
})
state.stickies.push({
  id: 'probe-past-repeat',
  title: '探针循环提醒',
  content: '每天循环，过去的时间',
  kind: 'reminder',
  pinned: false,
  remindAt: new Date(now - 2 * 60 * 1000).toISOString(),
  repeat: { kind: 'daily', time: '07:00' },
  status: 'pending',
  notified: false,
  createdAt: new Date(now - 5 * 60 * 1000).toISOString(),
  updatedAt: new Date(now - 5 * 60 * 1000).toISOString()
})
await ev('window.GuinaNative.saveData(' + JSON.stringify(JSON.stringify(state)) + ')')
await sleep(500)

// 重启应用，模拟「下次打开」
adb('shell', 'am', 'force-stop', 'com.guina.app.debug')
await sleep(800)
adb('shell', 'am', 'start', '-n', 'com.guina.app.debug/com.guina.app.MainActivity')
await sleep(6000)
const pid = adb('shell', 'pidof', 'com.guina.app.debug')
adb('forward', '--remove-all')
adb('forward', 'tcp:9333', 'localabstract:webview_devtools_remote_' + pid.split('\n')[0].trim())
const page2 = await connect(9333)
await sleep(3000)
const raw2 = await page2.evaluate('window.GuinaNative.loadData()')
const st2 = JSON.parse(raw2)
const mine = st2.stickies.filter((s) => String(s.id).startsWith('probe-'))
console.log('AFTER_LAUNCH_STICKIES ' + JSON.stringify(mine.map((s) => ({ id: s.id, notified: s.notified, status: s.status, remindAt: s.remindAt }))))
console.log('NOTIF_DUMP ' + adb('shell', 'dumpsys', 'notification', '--noredact').split('\n').filter((l) => l.includes('com.guina.app')).slice(0, 6).join(' | '))
console.log('LOGCAT ' + adb('shell', 'logcat', '-d', '-t', '300').split('\n').filter((l) => l.includes('GuiN')).slice(-10).join(' | '))
await page.close(); await page2.close()
