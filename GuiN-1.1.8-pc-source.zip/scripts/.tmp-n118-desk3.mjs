import { spawn, execSync } from 'node:child_process'
import fs from 'node:fs'
import path from 'node:path'
import { connect } from './cdp.mjs'
const ROOT = 'F:/DSH/GC/GuiNa'
const PROFILE = path.join(ROOT, '.tmp-n118-profile')
const PORT = 9222
const ELECTRON = path.join(ROOT, 'node_modules/electron/dist/electron.exe')
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))
function killElectron() { try { execSync('taskkill /F /IM electron.exe /T', { stdio: 'ignore' }) } catch {} }
async function start() {
  const env = { ...process.env }; delete env.ELECTRON_RUN_AS_NODE
  spawn(ELECTRON, [ROOT, '--remote-debugging-port=' + PORT, '--no-sandbox', '--user-data-dir=' + PROFILE], { env, stdio: 'ignore' })
  for (let i = 0; i < 120; i++) {
    try { const list = await (await fetch('http://127.0.0.1:' + PORT + '/json/list')).json(); if (list.find((t) => String(t.url).includes('index.html'))) break } catch {}
    await sleep(250)
  }
  await sleep(2500)
}
const readDisk = () => {
  try { const j = JSON.parse(fs.readFileSync(path.join(PROFILE, 'data.json'), 'utf8')); return (j.notifications || []).map((n) => ({ id: n.id, read: n.read, del: n.deleted })) } catch (e) { return 'ERR ' + e.message }
}
killElectron(); await sleep(600)
await start()
const p = await connect(PORT)
const ev = (e) => p.evaluate(e)
console.log('DISK_BEFORE ' + JSON.stringify(readDisk()))
await ev('(function(){document.querySelector("[data-testid=bell]").click();return 1})()')
await sleep(800)
const rect = await ev('(function(){var bs=[].slice.call(document.querySelectorAll("[data-testid=notification-panel] button"));var b=bs.find(function(x){return x.textContent.trim()==="全部标为已读"});if(!b)return null;var r=b.getBoundingClientRect();return JSON.stringify({x:r.x+r.width/2,y:r.y+r.height/2,w:r.width,h:r.height})})()')
console.log('BTN_RECT ' + rect)
const r = JSON.parse(rect || '{}')
if (r.x) {
  await p.send('Input.dispatchMouseEvent', { type: 'mousePressed', x: r.x, y: r.y, button: 'left', clickCount: 1 })
  await p.send('Input.dispatchMouseEvent', { type: 'mouseReleased', x: r.x, y: r.y, button: 'left', clickCount: 1 })
}
await sleep(1200)
console.log('STATE_AFTER_CLICK ' + await ev('(async function(){var s=await window.guina.getState();return JSON.stringify((s.notifications||[]).map(function(n){return {id:n.id,read:n.read,del:n.deleted}}))})()'))
console.log('DISK_AFTER_CLICK ' + JSON.stringify(readDisk()))
console.log('BADGE_AFTER_CLICK ' + await ev('(function(){var b=document.querySelector("[data-testid=bell-badge]");return b?b.textContent:"none"})()'))
console.log('PANEL_AFTER ' + await ev('(function(){var p=document.querySelector("[data-testid=notification-panel]");return p?p.innerText.slice(0,120):"closed"})()'))
// direct api
console.log('DIRECT ' + await ev('(async function(){return JSON.stringify(await window.guina.markAllNotificationsRead())})()'))
await sleep(1200)
console.log('DISK_AFTER_DIRECT ' + JSON.stringify(readDisk()))
await sleep(500)
console.log('DISK_LATER ' + JSON.stringify(readDisk()))
await p.close(); killElectron()
