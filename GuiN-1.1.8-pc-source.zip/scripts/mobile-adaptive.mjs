// GuiN 安卓版自适应检查：手机 / 平板 / 折叠屏 / 横屏 布局断言与截图
import { connect } from './cdp.mjs'
import fs from 'node:fs'

const PORT = Number(process.env.CDP_PORT || 9333)
const LABEL = process.env.ADAPTIVE_LABEL || 'phone'
const OUT = process.env.SHOT_DIR || '.tmp-shots/android'
fs.mkdirSync(OUT, { recursive: true })
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

let pass = 0, fail = 0
const failures = []
function check(name, ok, detail) {
  if (ok) { pass++; console.log('PASS ' + name) }
  else { fail++; failures.push(name + (detail ? ' :: ' + detail : '')); console.log('FAIL ' + name + (detail ? ' :: ' + detail : '')) }
}

const c = await connect(PORT, 'app.local')
await c.send('Page.enable'); await c.send('Runtime.enable')
async function ev(expr) { const r = await c.evaluate(expr); if (r && typeof r === 'object' && 'value' in r) return r.value; return r }
async function bodyText() { return (await ev('document.body.innerText')) || '' }
async function shot(name) { const s = await c.send('Page.captureScreenshot', { format: 'png' }); fs.writeFileSync(OUT + '/' + name + '.png', Buffer.from(s.data, 'base64')) }
async function waitFor(pred, timeout = 8000) { const t0 = Date.now(); while (Date.now() - t0 < timeout) { if (await pred()) return true; await sleep(150) } return false }
async function clickText(text, scope) {
  return ev(`(() => { const sc = ${scope ? 'document.querySelector(' + JSON.stringify(scope) + ')' : 'document'}; if (!sc) return 'NO_SCOPE'; const list = [...sc.querySelectorAll('button,[role=button],.tab,.cat-card,.chip,.row,.item-card,.sticky-card,.fab')]; const el = list.find(e => ((e.innerText||'')+'').trim().includes(${JSON.stringify(text)})); if (!el) return 'NOTFOUND'; el.click(); return 'OK' })()`)
}

async function setField(label, value) {
  return ev(`(() => { const fields = [...document.querySelectorAll('.field')]; const want = ${JSON.stringify(label)}; const f = fields.find(x => { const l = (x.querySelector('.field-label') || {}).textContent || ''; return l.trim().split('*')[0].trim() === want }); if (!f) return 'NO_FIELD'; const el = f.querySelector('input,textarea,select'); if (!el) return 'NO_INPUT'; const proto = el.tagName === 'TEXTAREA' ? window.HTMLTextAreaElement.prototype : window.HTMLInputElement.prototype; const s = Object.getOwnPropertyDescriptor(proto, 'value').set; s.call(el, ${JSON.stringify(value)}); el.dispatchEvent(new Event('input', { bubbles: true })); el.dispatchEvent(new Event('change', { bubbles: true })); return 'OK' })()`)
}

if ((await bodyText()).includes('跳过')) { await clickText('跳过'); await sleep(600) }
await waitFor(async () => (await bodyText()).includes('我的分类'))

// 回到首页
await ev("(() => { const t = [...document.querySelectorAll('.tab')].find(x => (x.innerText||'').includes('首页')); if (t) t.click(); return 'OK' })()")
await sleep(800)

const m = await ev(`(() => {
  const de = document.documentElement
  const tabbar = document.querySelector('.tabbar')
  const fab = document.querySelector('.fab')
  const screen = document.querySelector('.screen')
  const catGrid = document.querySelector('.cat-grid')
  const cols = (el) => el ? getComputedStyle(el).gridTemplateColumns.split(' ').filter(Boolean).length : 0
  const r = (el) => el ? el.getBoundingClientRect() : null
  const tb = r(tabbar), fb = r(fab), sn = r(screen)
  return {
    w: innerWidth, h: innerHeight, dpr: devicePixelRatio,
    scrollW: de.scrollWidth, bodyScrollW: document.body.scrollWidth,
    catCols: cols(catGrid),
    tabs: tabbar ? [...tabbar.querySelectorAll('.tab')].length : 0,
    tabRects: tabbar ? [...tabbar.querySelectorAll('.tab')].map(function (el) { const q = el.getBoundingClientRect(); return { left: q.left, right: q.right, width: q.width } }) : [],
    tabbar: tb ? { left: tb.left, right: tb.right, top: tb.top, bottom: tb.bottom, width: tb.width } : null,
    fab: fb ? { left: fb.left, right: fb.right, bottom: fb.bottom } : null,
    screen: sn ? { left: sn.left, right: sn.right, width: sn.width } : null
  }
})()`)
console.log('[metrics] ' + JSON.stringify(m))

const w = m.w
const expCat = w < 600 ? 2 : (w < 840 ? 3 : 4)
check(LABEL + ' 视口宽度记录', w > 200, String(w) + 'x' + m.h + ' dpr=' + m.dpr)
check(LABEL + ' 无横向溢出', m.scrollW <= w + 1 && m.bodyScrollW <= w + 1, 'scrollW=' + m.scrollW + ' body=' + m.bodyScrollW + ' w=' + w)
check(LABEL + ' 分类网格列数 ' + expCat, m.catCols === expCat, 'actual=' + m.catCols)
check(LABEL + ' 底部导航 3 项', m.tabs === 3, 'tabs=' + m.tabs)
  const tr = m.tabRects || []
  const tabWidthGap = tr.length === 3 ? Math.max.apply(null, tr.map(function (x) { return x.width })) - Math.min.apply(null, tr.map(function (x) { return x.width })) : 99
  const tabGapA = tr.length === 3 ? tr[1].left - tr[0].right : 0
  const tabGapB = tr.length === 3 ? tr[2].left - tr[1].right : 0
  const tabEdgeL = tr.length === 3 ? tr[0].left : 0
  const tabEdgeR = tr.length === 3 ? m.w - tr[2].right : 0
  check(LABEL + ' 三个按钮等宽', tr.length === 3 && tabWidthGap < 1, 'widths=' + tr.map(function (x) { return x.width }).join(','))
  check(LABEL + ' 左右按钮间距一致', tr.length === 3 && Math.abs(tabGapA - tabGapB) < 1, 'gaps=' + tabGapA.toFixed(1) + ',' + tabGapB.toFixed(1))
  check(LABEL + ' 两侧留白对称', tr.length === 3 && Math.abs(tabEdgeL - tabEdgeR) < 1, 'edges=' + tabEdgeL.toFixed(1) + ',' + tabEdgeR.toFixed(1))
check(LABEL + ' 底部导航贴底', !!m.tabbar && Math.abs(m.tabbar.bottom - m.h) <= 2 && m.tabbar.left >= 0 && m.tabbar.right <= w + 1, JSON.stringify(m.tabbar))
check(LABEL + ' FAB 在导航之上', !!m.fab && m.fab.bottom <= (m.tabbar ? m.tabbar.top + 1 : m.h), JSON.stringify(m.fab))
check(LABEL + ' 内容不超出屏幕', !!m.screen && m.screen.left >= -1 && m.screen.right <= w + 1, JSON.stringify(m.screen))
await shot('adaptive-' + LABEL + '-home')

// ===== 进入分类看条目网格（带返回与空数据兜底） =====
async function clickBack() {
  return ev("(() => { const b = document.querySelector('.topbar .icon-btn[aria-label=\"返回\"]'); if (!b) return 'NO'; b.click(); return 'OK' })()")
}
async function goHome() {
  for (let i = 0; i < 5; i++) {
    if (await ev("!!document.querySelector('.cat-card')")) return true
    if (await ev("!!document.querySelector('.sheet-panel')")) {
      await ev("(() => { const b = document.querySelector('.sheet-head .icon-btn'); if (b) b.click(); return 'OK' })()")
      await sleep(400)
      continue
    }
    if ((await clickBack()) !== 'OK') return false
    await sleep(500)
  }
  return await ev("!!document.querySelector('.cat-card')")
}
async function detectItemGrid() {
  const count = await ev("document.querySelectorAll('.cat-card').length")
  for (let i = 0; i < count; i++) {
    const name = await ev(`(() => { const list = document.querySelectorAll('.cat-card'); const el = list[${i}]; if (!el) return ''; el.click(); return (el.innerText||'').split('\\n')[0] })()`)
    await sleep(750)
    if (await ev("!!document.querySelector('.item-grid')")) {
      const cols = await ev("getComputedStyle(document.querySelector('.item-grid')).gridTemplateColumns.split(' ').filter(Boolean).length")
      return { cols: cols, name: name }
    }
    await clickBack()
    await sleep(450)
  }
  return null
}

let found = await detectItemGrid()
if (!found) {
  console.log('[seed] 所有分类为空，新建一个测试条目')
  await goHome()
  await ev("(() => { const f = document.querySelector('.fab'); if (f) f.click(); return 'OK' })()")
  await sleep(700)
  await ev("(() => { const b = [...document.querySelectorAll('.fab-action')].find(x => (x.innerText||'').includes('新增条目')); if (!b) return 'NO'; b.click(); return 'OK' })()")
  await sleep(800)
  const pickTitle = await ev("document.querySelector('.sheet-title') ? document.querySelector('.sheet-title').innerText : ''")
  if (pickTitle.includes('分类')) {
    await ev("(() => { const rows = [...document.querySelectorAll('.sheet-panel button.row')]; const b = rows.find(r => ((r.querySelector('.row-title')||{}).innerText||'') === '物品') || rows[0]; if (!b) return 'NO'; b.click(); return 'OK' })()")
    await sleep(800)
  }
  let labelOk = ''
  for (const label of ['书名', '物品名称', '食品名称', '药品名称', '名称']) {
    if ((await setField(label, '自适应测试物品')) === 'OK') { labelOk = label; break }
  }
  const locOk = await setField('详细位置', '客厅') + '/' + await setField('地点名称', '客厅')
  console.log('[seed] pick=' + pickTitle + ' nameLabel=' + labelOk + ' loc=' + locOk)
  await clickText('保存', '.sheet-panel')
  await sleep(1200)
  console.log('[seed] sheetOpen=' + await ev("!!document.querySelector('.sheet-panel')") + ' title=' + await ev("document.querySelector('.sheet-title') ? document.querySelector('.sheet-title').innerText : ''") + ' errors=' + await ev("JSON.stringify([...document.querySelectorAll('.field-error')].map(e => e.innerText))") + ' toast=' + await ev("(document.querySelector('.toast')||{}).innerText || ''") + ' cats=' + await ev("document.querySelectorAll('.cat-card').length"))
  found = await detectItemGrid()
}
const itemCols = found ? found.cols : 0
const itemText = found ? found.name : ''

const expItem = w < 600 ? 2 : (w < 840 ? 2 : 3)
if (itemCols) {
  check(LABEL + ' 分类「' + itemText + '」条目列数 ' + expItem, itemCols === expItem, 'actual=' + itemCols)
  const itemOverflow = await ev("document.documentElement.scrollWidth <= innerWidth + 1")
  check(LABEL + ' 条目页无横向溢出', itemOverflow)
  await shot('adaptive-' + LABEL + '-items')
} else {
  check(LABEL + ' 找到含条目的分类', false, '所有分类均为空且兜底新建失败')
}

// 底部弹层尺寸（FAB 打开）
await ev("(() => { const f = document.querySelector('.fab'); if (f) f.click(); return 'OK' })()")
await sleep(700)
let sheet = await ev("(() => { const p = document.querySelector('.sheet-panel'); if (!p) return null; const r = p.getBoundingClientRect(); return { top: r.top, bottom: r.bottom, left: r.left, right: r.right, width: r.width, maxW: getComputedStyle(p).maxWidth } })()")
if (!sheet) { await ev("(() => { const c = document.querySelector('.cat-card'); if (c) c.click(); return 'OK' })()"); await sleep(600) }
check(LABEL + ' 弹层在屏内且不超 660', !sheet || (sheet.width <= 660 && sheet.left >= -1 && sheet.right <= w + 1), JSON.stringify(sheet))
await shot('adaptive-' + LABEL + '-sheet')
// 关闭弹层
await ev("(() => { const b = document.querySelector('.sheet-mask'); if (b) b.click(); return 'OK' })()")
await sleep(400)

console.log('\n===== ADAPTIVE ' + LABEL + ' ' + pass + '/' + (pass + fail) + ' =====')
if (failures.length) { console.log('FAILURES:'); failures.forEach(f => console.log(' - ' + f)) }
setTimeout(function () { console.log('[watchdog] force exit'); process.exit(fail ? 1 : 0) }, 500).unref()
if (fail) process.exitCode = 1
