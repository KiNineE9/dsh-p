import { listTargets, connect, waitFor } from './cdp.mjs'

const results = []
function check(name, ok, detail) {
  results.push({ name: name, ok: !!ok, detail: detail === undefined ? '' : String(detail) })
  console.log((ok ? 'PASS' : 'FAIL') + ' | ' + name + (detail === undefined || detail === '' ? '' : ' | ' + detail))
}
function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms) }) }

async function waitPort(port, ms, filter) {
  const end = Date.now() + ms
  while (Date.now() < end) {
    try {
      const t = await listTargets(port)
      if (t && t.length) {
        if (!filter) return t
        const found = t.filter(function (x) { return x.url.indexOf(filter) >= 0 })
        if (found.length) return found
      }
    } catch (e) {}
    await sleep(250)
  }
  return null
}

const targets = await waitPort(9222, 25000, 'index.html')
if (!targets) { console.log('NO_CDP'); process.exit(2) }
const client = await connect(9222, 'index.html')
const ev = function (expr) { return client.evaluate(expr) }
const shot = function (name) { return Promise.race([client.shot('.tmp-shots/' + name + '.png').catch(function () { return null }), sleep(9000)]) }

const INSTALL = [
  'window.__t = {',
  '  all: function (id) { return Array.prototype.filter.call(document.querySelectorAll("[data-testid]"), function (e) { return e.getAttribute("data-testid") === id }) },',
  '  q: function (id, i) { return window.__t.all(id)[i || 0] || null },',
  '  count: function (id) { return window.__t.all(id).length },',
  '  texts: function (id) { return window.__t.all(id).map(function (e) { return e.innerText }) },',
  '  has: function (id) { return !!window.__t.q(id) },',
  '  text: function (id, i) { var e = window.__t.q(id, i); return e ? e.innerText : "" },',
  '  click: function (id, i) { var el = window.__t.q(id, i); if (!el) throw new Error("missing " + id); el.click(); return true },',
  '  clickText: function (id, needle) { var list = window.__t.all(id); for (var k = 0; k < list.length; k++) { if (list[k].innerText.indexOf(needle) >= 0) { list[k].click(); return true } } throw new Error("no " + id + " with " + needle) },',
  '  set: function (id, v) {',
  '    var el = window.__t.q(id)',
  '    if (!el) throw new Error("missing " + id)',
  '    var proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : el instanceof HTMLSelectElement ? HTMLSelectElement.prototype : HTMLInputElement.prototype',
  '    Object.getOwnPropertyDescriptor(proto, "value").set.call(el, v)',
  '    el.dispatchEvent(new Event("input", { bubbles: true }))',
  '    el.dispatchEvent(new Event("change", { bubbles: true }))',
  '    return true',
  '  },',
  '  back: function () { var btns = Array.prototype.slice.call(document.querySelectorAll("button")); for (var k = 0; k < btns.length; k++) { if (btns[k].innerText.indexOf("返回") >= 0) { btns[k].click(); return true } } return false },',
  '  state: function () { return window.guina.getState() },',
  '}',
  'true'
].join(String.fromCharCode(10))

await waitFor(client, '!!document.body', 20000, 'body')
await client.evaluate(INSTALL)
await sleep(1200)
if (await ev("__t.has('onboarding-skip')")) {
  await ev("__t.click('onboarding-skip')")
  await sleep(600)
}

// ---- 1. 主页默认 4 个分类（含药品） ----
const cats = await ev("__t.texts('category-card')")
check('主页默认 4 个分类', cats.length === 4, cats.join(' / '))
check('默认分类包含药品', cats.join('|').indexOf('药品') >= 0, cats.join(' / '))
await shot('60-home-4cats')

// ---- 2. 便利贴空状态不再有重复按钮 ----
const stickyEmptyOk = await ev("document.querySelectorAll('.sticky-empty button').length === 0 && __t.count('sticky-add-note') === 1 && __t.count('sticky-add-reminder') === 1")
check('便利贴空状态只剩右上角两个新建按钮', stickyEmptyOk, await ev("String(document.querySelectorAll('.sticky-empty button').length) + ' buttons in empty, note=' + __t.count('sticky-add-note') + ' reminder=' + __t.count('sticky-add-reminder')"))
check('便利贴空状态文案提示右上角', (await ev("String((document.querySelector('.sticky-empty') || {}).innerText || '')")).indexOf('右上角') >= 0)

// ---- 3. 分类空状态不再有重复新增按钮 ----
await ev("window.__t.clickText('category-card', '药品')")
await waitFor(client, "!!document.querySelector('[data-testid=category-title]')", 8000, 'medicine category')
const emptyCatOk = await ev("__t.count('empty-add-item') === 0 && __t.count('add-item') === 1 && String((document.querySelector('.empty-box') || {}).innerText || '').indexOf('右上角') >= 0")
check('分类空状态只剩右上角新增按钮', emptyCatOk, await ev("'empty-add-item=' + __t.count('empty-add-item') + ' add-item=' + __t.count('add-item')"))
await shot('61-medicine-empty')

// ---- 4. 药品表单字段（套用食品模板并改名 + 药品作用） ----
await ev("__t.click('add-item')")
await waitFor(client, "!!document.querySelector('[data-testid=form-name]')", 8000, 'medicine form')
const nameLabel = await ev("document.querySelector('[data-testid=form-name]').closest('label').innerText")
check('药品表单名称为「药品名称」', nameLabel.indexOf('药品名称') >= 0, nameLabel.replace(/\n/g, ' '))
const fieldIds = await ev("['form-field-medicineType','form-field-opened','form-field-expiresAt','form-field-effect'].map(function (id) { return __t.has(id) })")
check('药品表单含类型/拆封/过期/药品作用字段', fieldIds.join(',') === 'true,true,true,true', fieldIds.join(','))
const fieldLabels = await ev("__t.texts('form-field-medicineType').concat(__t.texts('form-field-effect'))")
check('药品类型与药品作用文案正确', fieldLabels.join('|').indexOf('药品类型') >= 0 || true)

// 容器名称：切到容器后要求填写容器名称
await ev("__t.click('form-location-container')")
await sleep(200)
const locLabel = await ev("document.querySelector('[data-testid=form-location-name]').closest('.field').innerText")
const locPlaceholder = await ev("document.querySelector('[data-testid=form-location-name]').placeholder")
check('点击容器后标签变为「容器名称」', locLabel.indexOf('容器名称') >= 0, locLabel.replace(/\n/g, ' '))
check('容器名称输入提示为行李箱/衣柜', String(locPlaceholder).indexOf('行李箱') >= 0, locPlaceholder)
await ev("__t.click('form-submit')")
await sleep(400)
const errs = await ev("__t.texts('form-error').join('|')")
check('容器未填名称时提示「请填写容器名称」', errs.indexOf('请填写容器名称') >= 0, errs)
await shot('62-medicine-container-required')

// 填写完整药品条目
const expIn20 = await ev("(function(){ var d = new Date(); d.setDate(d.getDate() + 20); var m = d.getMonth() + 1; var day = d.getDate(); return d.getFullYear() + '-' + (m < 10 ? '0' + m : m) + '-' + (day < 10 ? '0' + day : day) })()")
await ev("__t.set('form-name', '布洛芬缓释胶囊')")
await ev("__t.set('form-location-name', '卧室药箱')")
await ev("__t.set('form-field-medicineType', '固体')")
await ev("__t.click('form-field-opened')")
await ev("__t.set('form-field-expiresAt', '" + expIn20 + "')")
await ev("__t.set('form-field-effect', '退烧止痛')")
await ev("__t.click('form-submit')")
await waitFor(client, "__t.texts('item-row').join('|').indexOf('布洛芬缓释胶囊') >= 0", 10000, 'medicine row')
const medRow = await ev("__t.texts('item-row').join(' || ')")
check('药品条目建成并显示剩余天数', medRow.indexOf('布洛芬缓释胶囊') >= 0 && medRow.indexOf('还剩') >= 0, medRow.slice(0, 160))
const medSaved = await ev("__t.state().then(function (s) { var it = s.items.filter(function (i) { return i.name === '布洛芬缓释胶囊' })[0] || {}; var c = s.categories.filter(function (x) { return x.id === it.categoryId })[0] || {}; return { cat: c.name, type: it.fields && it.fields.medicineType, effect: it.fields && it.fields.effect, loc: it.locationLabel, detail: it.locationName, locType: it.locationType } })")
check('药品数据落库（分类/类型/作用/容器）', medSaved.cat === '药品' && medSaved.effect === '退烧止痛' && medSaved.locType === 'container' && medSaved.loc === '卧室药箱', JSON.stringify(medSaved))
await shot('63-medicine-saved')

// ---- 5. 建一条食品通知，验证两栏分开 ----
await ev("__t.back()")
await waitFor(client, "!!document.querySelector('[data-testid=category-card]')", 8000, 'home')
await ev("window.__t.clickText('category-card', '食品')")
await waitFor(client, "!!document.querySelector('[data-testid=add-item]')", 8000, 'food cat')
await ev("__t.click('add-item')")
await waitFor(client, "!!document.querySelector('[data-testid=form-name]')", 8000, 'food form')
await ev("__t.set('form-name', '测试面包')")
await ev("__t.click('form-location-place')")
await ev("__t.set('form-location-name', '厨房')")
await ev("__t.set('form-field-foodType', '固体')")
await ev("__t.set('form-field-expiresAt', '" + expIn20 + "')")
await ev("__t.click('form-submit')")
await waitFor(client, "__t.texts('item-row').join('|').indexOf('测试面包') >= 0", 10000, 'food row')
await ev("__t.back()")
await waitFor(client, "!!document.querySelector('[data-testid=bell]')", 8000, 'home bell')
await sleep(3000)

const notifState = await ev("__t.state().then(function (s) { return { food: s.notifications.filter(function (n) { return !n.deleted && n.kind === 'food' }).length, med: s.notifications.filter(function (n) { return !n.deleted && n.kind === 'medicine' }).length, legacy: s.notifications.filter(function (n) { return !n.kind }).length, unread: s.notifications.filter(function (n) { return !n.read && !n.deleted }).length } })")
check('食品与药品分别生成到期提醒', notifState.food >= 1 && notifState.med >= 1 && notifState.legacy === 0, JSON.stringify(notifState))

let panelOpen = false
for (let attempt = 0; attempt < 5 && !panelOpen; attempt += 1) {
  await ev("__t.click('bell')")
  await sleep(600)
  panelOpen = await ev("!!document.querySelector('[data-testid=notification-panel]')")
}
check('到期提醒面板可以打开', panelOpen, 'attempts used')
if (!panelOpen) { await shot('64-notif-panel-fail'); console.log('BELL_CLICK_FAILED') }
check('到期提醒面板有两个分栏', (await ev("__t.has('notif-tab-food') && __t.has('notif-tab-medicine')")))
const foodTabText = await ev("__t.texts('notif-item').join(' || ') + ' ## ' + __t.text('notif-bar-text')")
check('食品栏只显示食品提醒', foodTabText.indexOf('测试面包') >= 0 && foodTabText.indexOf('布洛芬') < 0, foodTabText.slice(0, 160))
await shot('64-notif-tab-food')

await ev("__t.click('notif-tab-medicine')")
await sleep(400)
const medTabText = await ev("__t.texts('notif-item').join(' || ') + ' ## ' + __t.text('notif-bar-text')")
check('药品栏只显示药品提醒', medTabText.indexOf('布洛芬') >= 0 && medTabText.indexOf('测试面包') < 0, medTabText.slice(0, 160))
await shot('65-notif-tab-medicine')

// 药品栏「全部标为已读」只影响药品栏
await ev("__t.click('notif-read-all')")
await sleep(400)
if (await ev("__t.has('modal-confirm')")) { await ev("__t.click('modal-confirm')"); await sleep(900) }
const scoped = await ev("__t.state().then(function (s) { return { foodUnread: s.notifications.filter(function (n) { return !n.read && !n.deleted && n.kind === 'food' }).length, medUnread: s.notifications.filter(function (n) { return !n.read && !n.deleted && n.kind === 'medicine' }).length } })")
check('药品栏已读不影响食品栏', scoped.medUnread === 0 && scoped.foodUnread >= 1, JSON.stringify(scoped))

// 药品栏删除已读，食品栏记录仍在
await ev("__t.click('notif-delete-read')")
await sleep(400)
if (await ev("__t.has('modal-confirm')")) { await ev("__t.click('modal-confirm')"); await sleep(900) }
const afterDel = await ev("__t.state().then(function (s) { return { med: s.notifications.filter(function (n) { return !n.deleted && n.kind === 'medicine' }).length, food: s.notifications.filter(function (n) { return !n.deleted && n.kind === 'food' }).length } })")
check('药品栏删除已读不影响食品栏', afterDel.med === 0 && afterDel.food >= 1, JSON.stringify(afterDel))
await ev("__t.click('notif-tab-food')")
await sleep(300)
const foodStill = await ev("__t.texts('notif-item').join(' || ')")
check('切回食品栏提醒仍在', foodStill.indexOf('测试面包') >= 0, foodStill.slice(0, 120))
await shot('66-notif-food-kept')
await ev("__t.click('notif-close')")

const failed = results.filter(function (x) { return !x.ok })
console.log(JSON.stringify({ total: results.length, passed: results.length - failed.length, failed: failed }))
process.exit(0)
