import { spawn, execSync } from 'node:child_process'
import fs from 'node:fs'
import path from 'node:path'
import { connect } from './cdp.mjs'
const ROOT = 'F:/DSH/GC/GuiNa'
const PROFILE = path.join(ROOT, '.tmp-n118-profile')
const PORT = 9222
const ELECTRON = path.join(ROOT, 'node_modules/electron/dist/electron.exe')
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))
function killElectron() { try { execSync('taskkill /F /IM electron.exe /T', { stdio: 'ignore' }) } catch {} }
async function start() {
  const env = { ...process.env }; delete env.ELECTRON_RUN_AS_NODE
  spawn(ELECTRON, [ROOT, '--remote-debugging-port=' + PORT, '--no-sandbox', '--user-data-dir=' + PROFILE], { env, stdio: 'ignore' })
  for (let i = 0; i < 120; i++) {
    try { const list = await (await fetch('http://127.0.0.1:' + PORT + '/json/list')).json(); if (list.find((t) => String(t.url).includes('index.html'))) break } catch {}
    await sleep(250)
  }
  await sleep(2500)
}
killElectron(); await sleep(600)
await start()
const p = await connect(PORT)
const ev = (e) => p.evaluate(e)
await ev('(function(){document.querySelector("[data-testid=bell]").click();return 1})()')
await sleep(700)
console.log('BUTTONS ' + await ev('(function(){return JSON.stringify([].slice.call(document.querySelectorAll("[data-testid=notification-panel] button")).map(function(b){return b.textContent.trim().slice(0,20)}))})()'))
console.log('API ' + await ev('(function(){return typeof window.guina.markAllNotificationsRead})()'))
console.log('CALL ' + await ev('(async function(){var r=await window.guina.markAllNotificationsRead();return JSON.stringify(r)})()'))
await sleep(1000)
console.log('AFTER_API ' + await ev('(async function(){var s=await window.guina.state.get();var n=(s.notifications||[]);return JSON.stringify(n.map(function(x){return {id:x.id,read:x.read}}))})()'))
const disk = JSON.parse(fs.readFileSync(path.join(PROFILE, 'data.json'), 'utf8'))
console.log('DISK ' + JSON.stringify((disk.notifications || []).map((n) => ({ read: n.read }))))
console.log('BADGE ' + await ev('(function(){var b=document.querySelector("[data-testid=bell-badge]");return b?b.textContent:"none"})()'))
await p.close(); killElectron()
