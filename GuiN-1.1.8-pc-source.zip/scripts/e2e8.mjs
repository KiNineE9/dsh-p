import { listTargets, connect, waitFor } from './cdp.mjs'

const results = []
function check(name, ok, detail) {
  results.push({ name: name, ok: !!ok, detail: detail === undefined ? '' : String(detail) })
  console.log((ok ? 'PASS' : 'FAIL') + ' | ' + name + (detail === undefined || detail === '' ? '' : ' | ' + detail))
}
function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms) }) }
async function waitPort(port, ms, filter) {
  const end = Date.now() + ms
  while (Date.now() < end) {
    try {
      const t = await listTargets(port)
      if (t && t.length) {
        if (!filter) return t
        const found = t.filter(function (x) { return x.url.indexOf(filter) >= 0 })
        if (found.length) return found
      }
    } catch (e) {}
    await sleep(250)
  }
  return null
}

const targets = await waitPort(9222, 25000, 'index.html')
if (!targets) { console.log('NO_CDP'); process.exit(2) }
const client = await connect(9222, 'index.html')
const ev = function (expr) { return client.evaluate(expr) }
const shot = function (name) { return Promise.race([client.shot('.tmp-shots/' + name + '.png').catch(function () { return null }), sleep(9000)]) }

const INSTALL = [
  'window.__t = {',
  '  all: function (id) { return Array.prototype.filter.call(document.querySelectorAll("[data-testid]"), function (e) { return e.getAttribute("data-testid") === id }) },',
  '  q: function (id, i) { return window.__t.all(id)[i || 0] || null },',
  '  count: function (id) { return window.__t.all(id).length },',
  '  texts: function (id) { return window.__t.all(id).map(function (e) { return e.innerText }) },',
  '  has: function (id) { return !!window.__t.q(id) },',
  '  text: function (id, i) { var e = window.__t.q(id, i); return e ? e.innerText : "" },',
  '  click: function (id, i) { var el = window.__t.q(id, i); if (!el) throw new Error("missing " + id); el.click(); return true },',
  '  clickText: function (id, needle) { var list = window.__t.all(id); for (var k = 0; k < list.length; k++) { if (list[k].innerText.indexOf(needle) >= 0) { list[k].click(); return true } } throw new Error("no " + id + " with " + needle) },',
  '  set: function (id, v) {',
  '    var el = window.__t.q(id)',
  '    if (!el) throw new Error("missing " + id)',
  '    var proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : el instanceof HTMLSelectElement ? HTMLSelectElement.prototype : HTMLInputElement.prototype',
  '    Object.getOwnPropertyDescriptor(proto, "value").set.call(el, v)',
  '    el.dispatchEvent(new Event("input", { bubbles: true }))',
  '    el.dispatchEvent(new Event("change", { bubbles: true }))',
  '    return true',
  '  },',
  '  back: function () { var btns = Array.prototype.slice.call(document.querySelectorAll("button")); for (var k = 0; k < btns.length; k++) { if (btns[k].innerText.indexOf("返回") >= 0) { btns[k].click(); return true } } return false },',
  '  state: function () { return window.guina.getState() },',
  '}',
  'true'
].join(String.fromCharCode(10))

await waitFor(client, '!!document.body', 20000, 'body')
await client.evaluate(INSTALL)
await sleep(1200)
if (await ev("__t.has('onboarding-skip')")) {
  await ev("__t.click('onboarding-skip')")
  await sleep(700)
}

// ---- 1. 便签/提醒便签之间的竖线分隔 ----
const divider = await ev("(function(){ var a=document.querySelector('[data-testid=sticky-col-note]'); var b=document.querySelector('[data-testid=sticky-col-reminder]'); if(!a||!b) return {missing:true}; var ca=getComputedStyle(a), cb=getComputedStyle(b); return { noteBorder: ca.borderLeftWidth, remBorder: cb.borderLeftWidth, remColor: cb.borderLeftColor, gap: parseFloat(getComputedStyle(document.querySelector('.sticky-columns')).columnGap) } })()")
check('便签与提醒便签之间有竖线分隔', divider.remBorder === '1px' && divider.noteBorder === '0px' && divider.remColor !== 'rgba(0, 0, 0, 0)', JSON.stringify(divider))

// ---- 2. 便签区独立搜索栏 ----
const stickySetup = await ev("(async function(){ var a=await window.guina.createSticky({ content: '明天吃饭记得订位', kind: 'note', title: '聚餐安排' }); var b=await window.guina.createSticky({ content: '买牛奶', kind: 'note' }); var c=await window.guina.createSticky({ content: '喝水提醒正文', kind: 'reminder', title: '喝水', repeat: { kind: 'daily', time: '09:00' } }); return [a.ok,b.ok,c.ok].filter(Boolean).length })()")
check('准备两张便签 + 一张提醒便签', stickySetup === 3, stickySetup)
await sleep(1200)
check('便签板块有独立搜索栏', await ev("__t.has('sticky-search')"))
check('搜索栏提示文案说明搜索便签', (await ev("__t.q('sticky-search').placeholder")).indexOf('便签') >= 0)
await ev("__t.set('sticky-search', '吃')")
await sleep(700)
const searchOne = await ev("(function(){ var cards=[].map.call(document.querySelectorAll('[data-testid=sticky-card]'), function(e){ return e.innerText }); var rem=document.querySelector('[data-testid=sticky-col-reminder] .sticky-empty'); return { cards: cards, remEmpty: rem ? rem.innerText : '' } })()")
check('搜内容里的“吃”只命中对应便签', searchOne.cards.length === 1 && searchOne.cards[0].indexOf('聚餐安排') >= 0, JSON.stringify(searchOne.cards))
check('无匹配的一栏给出提示', searchOne.remEmpty.indexOf('没有匹配') >= 0, searchOne.remEmpty)
await shot('105-sticky-search')
await ev("__t.set('sticky-search', '喝水')")
await sleep(700)
const searchTitle = await ev("[].map.call(document.querySelectorAll('[data-testid=sticky-card]'), function(e){ return e.innerText })")
check('搜标题“喝水”命中提醒便签', searchTitle.length === 1 && searchTitle[0].indexOf('喝水') >= 0, JSON.stringify(searchTitle))
await ev("__t.click('sticky-search-clear')")
await sleep(700)
check('清除搜索后恢复全部与提醒便签', (await ev("__t.count('sticky-card')")) === 3)

// ---- 3. 顶部全局搜索不搜便签 ----
await ev("__t.set('search-input', '吃')")
await sleep(800)
const topSearch = await ev("(function(){ var box=document.querySelector('[data-testid=search-results]'); return { hits: document.querySelectorAll('[data-testid=search-hit]').length, empty: box ? box.innerText : '', open: !!box } })()")
check('顶部搜索不返回便签结果', topSearch.open === true && topSearch.hits === 0 && topSearch.empty.indexOf('没找到') >= 0, JSON.stringify(topSearch))
await ev("__t.set('search-input', '')")
await sleep(500)

// ---- 4. 分类条目双列布局 ----
const itemSetup = await ev("(async function(){ var s=await window.guina.getState(); var c=s.categories.filter(function(x){return x.name==='物品'})[0]; var names=[['卧室里的钥匙','卧室'],['抽屉柜里的钥匙','抽屉柜'],['客厅遥控器','客厅'],['厨房剪刀','厨房']]; var n=0; for (var i=0;i<names.length;i++){ var r=await window.guina.createItem(c.id, { name: names[i][0], locationType: 'place', locationLabel: names[i][1], locationName: '', fields: {} }); if(r.ok) n++; } return n })()")
check('准备 4 个物品条目', itemSetup === 4, itemSetup)
await sleep(1200)
await ev("__t.clickText('category-card', '物品')")
await waitFor(client, "document.querySelectorAll('[data-testid=item-row]').length >= 4", 10000, 'item rows')
const layout = await ev("(function(){ var list=document.querySelector('.item-list'); var cs=list?getComputedStyle(list):null; var rows=[].map.call(document.querySelectorAll('[data-testid=item-row]'), function(e){ return e.getBoundingClientRect() }); return { display: cs?cs.display:'', tracks: cs?cs.gridTemplateColumns.split(' ').length:0, rows: rows.length, firstRowTwo: rows.length>=2 ? Math.abs(rows[0].top-rows[1].top)<2 : false, thirdNextRow: rows.length>=3 ? Math.abs(rows[0].top-rows[2].top)>3 : false, firstWidth: rows.length?Math.round(rows[0].width):0, listWidth: list?Math.round(list.getBoundingClientRect().width):0 } })()")
check('条目列表为双列网格', layout.display === 'grid' && layout.tracks === 2, JSON.stringify(layout))
check('同一行显示两个条目', layout.firstRowTwo === true, JSON.stringify(layout))
check('第 3 个条目换到下一行', layout.thirdNextRow === true)
check('条目卡片宽度约为列表一半', layout.firstWidth > layout.listWidth * 0.42 && layout.firstWidth < layout.listWidth * 0.58, layout.firstWidth + '/' + layout.listWidth)
await shot('106-category-two-columns')

// ---- 5. 全局搜索定位到双列中的条目 ----
await ev("__t.back()")
await waitFor(client, "!!document.querySelector('[data-testid=search-input]')", 8000, 'topbar')
await ev("__t.set('search-input', '钥匙')")
await sleep(800)
const hitCount = await ev("__t.count('search-hit')")
check('顶部搜索能搜到物品', hitCount >= 2, hitCount)
await ev("__t.click('search-hit')")
await waitFor(client, "!!document.querySelector('[data-testid=category-title]')", 10000, 'located category')
await sleep(800)
const locate = await ev("(function(){ var hl=document.querySelectorAll('[data-testid=item-row].hl-item').length; var title=document.querySelector('[data-testid=category-title]'); var cats=document.querySelector('[data-testid=category-title]'); var scrolled=Array.prototype.some.call(document.querySelectorAll('[data-testid=item-row].hl-item'), function(e){ var r=e.getBoundingClientRect(); return r.top>=0 && r.bottom<=window.innerHeight }); return { hl: hl, title: title?title.innerText:'', inView: scrolled } })()")
check('搜索定位进入分类页并高亮条目', locate.hl === 1 && locate.title.indexOf('物品') >= 0, JSON.stringify(locate))
check('高亮条目在可视区域内（自动滚动）', locate.inView === true, JSON.stringify(locate))
await shot('107-locate-highlight')

const failed = results.filter(function (r) { return !r.ok })
console.log(JSON.stringify({ total: results.length, passed: results.length - failed.length, failed: failed }))
if (failed.length) process.exitCode = 1
