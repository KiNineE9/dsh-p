// 1.1.6 桌面端 E2E：分类页搜索与排序同时可用、搜索框输入光标不跳、同存放日期升序/降序都有变化、便签详情时间不用 ISO
import fs from 'node:fs'
import { listTargets, connect, waitFor } from './cdp.mjs'

const results = []
function check(name, ok, detail) {
  results.push({ name: name, ok: !!ok, detail: detail === undefined ? '' : String(detail) })
  console.log((ok ? 'PASS' : 'FAIL') + ' | ' + name + (detail === undefined || detail === '' ? '' : ' | ' + detail))
}
function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms) }) }

async function waitPort(port, ms, filter) {
  const end = Date.now() + ms
  while (Date.now() < end) {
    try {
      const t = await listTargets(port)
      if (t && t.length) {
        if (!filter) return t
        const found = t.filter(function (x) { return x.url.indexOf(filter) >= 0 })
        if (found.length) return found
      }
    } catch (e) {}
    await sleep(250)
  }
  return null
}

const targets = await waitPort(9222, 25000, 'index.html')
if (!targets) { console.log('NO_CDP'); process.exit(2) }
const client = await connect(9222, 'index.html')
const ev = function (expr) { return client.evaluate(expr) }
const send = function (method, params) { return client.send(method, params) }
fs.mkdirSync('.tmp-shots', { recursive: true })
const shot = function (name) { return Promise.race([client.shot('.tmp-shots/' + name + '.png').catch(function () { return null }), sleep(9000)]) }

const INSTALL = [
  'window.__t = {',
  '  all: function (id) { return Array.prototype.filter.call(document.querySelectorAll("[data-testid]"), function (e) { return e.getAttribute("data-testid") === id }) },',
  '  q: function (id, i) { return window.__t.all(id)[i || 0] || null },',
  '  count: function (id) { return window.__t.all(id).length },',
  '  texts: function (id) { return window.__t.all(id).map(function (e) { return e.innerText }) },',
  '  has: function (id) { return !!window.__t.q(id) },',
  '  text: function (id, i) { var e = window.__t.q(id, i); return e ? e.innerText : "" },',
  '  click: function (id, i) { var el = window.__t.q(id, i); if (!el) throw new Error("missing " + id); el.click(); return true },',
  '  clickText: function (id, needle) { var list = window.__t.all(id); for (var k = 0; k < list.length; k++) { if (list[k].innerText.indexOf(needle) >= 0) { list[k].click(); return true } } throw new Error("no " + id + " with " + needle) },',
  '  fill: function (id, value, i) {',
  '    var el = window.__t.q(id, i); if (!el) throw new Error("missing " + id)',
  '    var proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype',
  '      : el instanceof HTMLSelectElement ? HTMLSelectElement.prototype',
  '      : HTMLInputElement.prototype',
  '    Object.getOwnPropertyDescriptor(proto, "value").set.call(el, value)',
  '    el.dispatchEvent(new Event("input", { bubbles: true }))',
  '    el.dispatchEvent(new Event("change", { bubbles: true }))',
  '    return true',
  '  },',
  '  dir: function (id) { var el = window.__t.q(id); return el ? el.getAttribute("data-direction") : "" },',
  '  active: function (id) { var el = window.__t.q(id); return !!el && String(el.className).split(" ").indexOf("active") >= 0 },',
  '  rowNames: function () { return Array.prototype.map.call(document.querySelectorAll("[data-testid=item-row] .item-name"), function (e) { return e.innerText.trim() }) },',
  '  searchInfo: function () { var el = window.__t.q("cat-search"); return el ? { value: el.value, caret: el.selectionStart, sorts: window.__t.count("sort-group") ? window.__t.all("sort-group")[0].querySelectorAll("button").length : 0 } : null },',
  '  body: function () { return document.body.innerText }',
  '}',
  'true'
].join(String.fromCharCode(10))

await waitFor(client, '!!document.body', 20000, 'body')
await client.evaluate(INSTALL)
await sleep(800)

if (await ev("__t.has('onboarding')")) {
  await ev("__t.click('onboarding-skip')")
  await waitFor(client, "!__t.has('onboarding')", 8000, 'onboarding closes')
}
await sleep(500)

async function backHome() {
  await ev("(function(){ var bs = Array.prototype.slice.call(document.querySelectorAll('button')); for (var i = 0; i < bs.length; i++) { if (bs[i].innerText.indexOf('返回') >= 0) { bs[i].click(); return true } } return false })()")
  await waitFor(client, "!!document.querySelector('[data-testid=add-category]')", 8000, 'home')
}
async function openCategory(name) {
  await ev("window.__t.clickText('category-card', '" + name + "')")
  await waitFor(client, "!!document.querySelector('[data-testid=category-title]')", 8000, 'category ' + name)
}
async function addItem(opts) {
  await ev("__t.click('add-item')")
  await waitFor(client, "!!document.querySelector('[data-testid=form-name]')", 8000, 'item form')
  await ev("__t.fill('form-name', " + JSON.stringify(opts.name) + ")")
  await ev("__t.click('form-location-place')")
  await ev("__t.fill('form-location-name', " + JSON.stringify(opts.location) + ")")
  if (opts.fields) {
    for (const key of Object.keys(opts.fields)) {
      const value = opts.fields[key]
      if (value === true) await ev("__t.click('form-field-" + key + "')")
      else if (value === false) await ev("__t.click('form-field-" + key + "-no')")
      else await ev("__t.fill('form-field-" + key + "', " + JSON.stringify(value) + ")")
    }
  }
  await ev("__t.click('form-submit')")
}

// ---------- A 食品：搜索与排序同屏可用 ----------
await openCategory('食品')
await waitFor(client, "!!document.querySelector('[data-testid=sort-group]')", 8000, 'sort group')
check('A1 搜索框与排序按钮同时存在', (await ev("__t.has('cat-search')")) && (await ev("__t.all('sort-group')[0].querySelectorAll('button').length")) === 3)
await addItem({ name: '苹果', location: '冰箱', fields: { storedAt: '2025-01-10' } })
await waitFor(client, "__t.rowNames().indexOf('苹果') >= 0", 8000, 'apple')
await addItem({ name: '香蕉', location: '冰箱', fields: { storedAt: '2025-01-10' } })
await waitFor(client, "__t.rowNames().indexOf('香蕉') >= 0", 8000, 'banana')
await addItem({ name: '橙子', location: '果篮', fields: { storedAt: '2025-02-01' } })
await waitFor(client, "__t.rowNames().indexOf('橙子') >= 0", 8000, 'orange')
await shot('116-01-desktop-search-sort')

// 搜索框里用真实输入事件打字，光标要停在末尾
await ev("document.querySelector('[data-testid=cat-search]').focus()")
await send('Input.insertText', { text: '苹' })
await sleep(500)
const si1 = await ev("JSON.stringify(__t.searchInfo())")
check('A2 搜索框输入后光标在末尾', JSON.parse(si1).value === '苹' && JSON.parse(si1).caret === 1, si1)
await send('Input.insertText', { text: '果' })
await sleep(500)
const si2 = await ev("JSON.stringify(__t.searchInfo())")
check('A3 继续输入不会插到前面', JSON.parse(si2).value === '苹果' && JSON.parse(si2).caret === 2, si2)
check('A4 输入时排序按钮仍在（不会随输入卸载）', JSON.parse(si2).sorts === 3, si2)
const filtered = await ev("__t.rowNames()")
check('A5 搜索只留匹配项', JSON.stringify(filtered) === JSON.stringify(['苹果']), JSON.stringify(filtered))
await ev("__t.click('sort-name')")
await sleep(450)
check('A6 搜索时仍能切换排序方向', (await ev("__t.dir('sort-name')")) === 'desc' && JSON.stringify(await ev("__t.rowNames()")) === JSON.stringify(['苹果']), await ev("__t.dir('sort-name')"))
await ev("__t.fill('cat-search', '')")
await sleep(450)
check('A7 清空搜索后恢复全部条目', (await ev("__t.rowNames()")).length === 3, JSON.stringify(await ev("__t.rowNames()")))

// ---------- B 同存放日期：升/降序都能看到变化 ----------
await ev("__t.click('sort-storedAt')")
await sleep(450)
const storedAsc = await ev("__t.rowNames()")
check('B1 按存放时间升序（同日期按名称）', (await ev("__t.dir('sort-storedAt')")) === 'asc' && storedAsc[0] === '苹果' && storedAsc[1] === '香蕉', JSON.stringify(storedAsc))
await ev("__t.click('sort-storedAt')")
await sleep(450)
const storedDesc = await ev("__t.rowNames()")
check('B2 再点降序，同日期顺序也翻转（切方向看得出来）', (await ev("__t.dir('sort-storedAt')")) === 'desc' && JSON.stringify(storedDesc) === JSON.stringify(storedAsc.slice().reverse()), JSON.stringify(storedDesc))
await shot('116-02-desktop-stored-desc')
await backHome()

// ---------- C 便签详情时间格式 ----------
await ev("__t.click('sticky-add-reminder')")
await waitFor(client, "!!document.querySelector('[data-testid=sticky-kind-reminder]')", 8000, 'sticky form')
await ev("__t.fill('sticky-title', '喝水')")
await ev("__t.fill('sticky-content', '十分钟后喝一杯水')")
await ev("__t.click('sticky-kind-reminder')")
await sleep(250)
await ev("__t.click('quick-10m')")
await ev("__t.click('modal-confirm')")
await waitFor(client, "__t.texts('sticky-card').join('|').indexOf('喝水') >= 0", 8000, 'reminder card')
await ev("(function(){ var cards = __t.all('sticky-card'); for (var i = 0; i < cards.length; i++) { if (cards[i].innerText.indexOf('十分钟后喝一杯水') >= 0) { cards[i].click(); return true } } return false })()")
await waitFor(client, "!!document.querySelector('[data-testid=sticky-detail]')", 8000, 'detail')
const detailTime = await ev("Array.prototype.map.call(document.querySelectorAll('[data-testid=sticky-detail] .sticky-detail-time'), function (e) { return e.innerText.trim() }).join(' | ')")
check('C1 便签详情的时间用本地日期时间', /^\d{4}-\d{2}-\d{2} \d{2}:\d{2}$/.test(detailTime) || detailTime === '已到时间', detailTime)
check('C2 便签详情不出现 ISO 时间串', detailTime.indexOf('T') < 0 && detailTime.indexOf('.000Z') < 0, detailTime)
await shot('116-03-desktop-sticky-detail')
await ev("__t.click('modal-cancel')")

await sleep(300)
console.log('===== RESULT ' + results.filter(function (r) { return r.ok }).length + '/' + results.length + ' =====')
process.exit(0)