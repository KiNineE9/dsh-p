// 1.1.6 安卓新功能端到端：按存放时间排序（旧条目兜底）、搜索框与排序条共存且光标不乱跳、扫码默认后置主摄、系统闹钟识别、提醒详情时间格式
import { execSync } from 'node:child_process'
import fs from 'node:fs'
const ADB = 'F:/Android/sdk/platform-tools/adb.exe'
const SHOT_DIR = process.env.SHOT_DIR || '.tmp-shots/116'
fs.mkdirSync(SHOT_DIR, { recursive: true })
const { connect } = await import('./cdp.mjs')
const c = await connect(9333, 'app.local')
await c.send('Page.enable'); await c.send('Runtime.enable')
const sleep = function (ms) { return new Promise(function (r) { setTimeout(r, ms) }) }
const ev = function (e) { return c.evaluate(e) }
const results = []
function check(name, ok, detail) {
  results.push({ name: name, ok: !!ok })
  console.log((ok ? 'PASS' : 'FAIL') + ' | ' + name + (detail === undefined || detail === '' ? '' : ' | ' + detail))
}
function adb(shell) { try { return execSync('"' + ADB + '" ' + shell, { encoding: 'utf8', timeout: 30000 }) } catch (e) { return String((e && e.stdout) || '') } }
async function shot(name) {
  try {
    const buf = execSync('"' + ADB + '" exec-out screencap -p', { maxBuffer: 40 * 1024 * 1024 })
    fs.writeFileSync(SHOT_DIR + '/' + name + '.png', buf)
  } catch (e) {}
}
async function center(sel, text) {
  return await ev('(() => { const list = [...document.querySelectorAll(' + JSON.stringify(sel) + ')]; const el = ' + (text ? 'list.find((e) => ((e.innerText || e.textContent || "") + "").trim().includes(' + JSON.stringify(text) + '))' : 'list[0]') + '; if (!el) return null; el.scrollIntoView({ block: "center" }); const r = el.getBoundingClientRect(); return { x: r.left + r.width / 2, y: r.top + r.height / 2 }; })()')
}
async function tapPoint(p) {
  if (!p) return false
  await c.send('Input.dispatchMouseEvent', { type: 'mouseMoved', x: p.x, y: p.y })
  await c.send('Input.dispatchMouseEvent', { type: 'mousePressed', x: p.x, y: p.y, button: 'left', clickCount: 1 })
  await sleep(70)
  await c.send('Input.dispatchMouseEvent', { type: 'mouseReleased', x: p.x, y: p.y, button: 'left', clickCount: 1 })
  await sleep(360)
  return true
}
async function tap(sel, text) { return tapPoint(await center(sel, text)) }
async function tapExact(sel, text) {
  const p = await ev('(() => { const list = [...document.querySelectorAll(' + JSON.stringify(sel) + ')]; const el = list.find((e) => ((e.innerText || "") + "").trim() === ' + JSON.stringify(text) + '); if (!el) return null; el.scrollIntoView({ block: "center" }); const r = el.getBoundingClientRect(); return { x: r.left + r.width / 2, y: r.top + r.height / 2 }; })()')
  return tapPoint(p)
}
const bodyText = async function () { return (await ev('document.body.innerText')) || '' }
async function waitText(text, ms) {
  const end = Date.now() + (ms || 8000)
  while (Date.now() < end) {
    if ((await bodyText()).includes(text)) return true
    await sleep(250)
  }
  return false
}
async function jsTap(sel, text) {
  const ok = await ev('(() => { const list = [...document.querySelectorAll(' + JSON.stringify(sel) + ')]; const el = ' + (text ? 'list.find((e) => ((e.innerText || "").trim()).indexOf(' + JSON.stringify(text) + ') >= 0)' : 'list[0]') + '; if (!el) return false; el.click(); return true; })()')
  await sleep(600)
  return ok
}
async function goHome() { await jsTap('.tabbar .tab', '首页'); await sleep(400) }
async function openCategory(name) { await tap('.cat-card', name); await sleep(800) }
async function names() { return await ev('JSON.stringify([...document.querySelectorAll(".item-card")].map((e) => { const n = e.querySelector(".item-name"); return ((n ? n.innerText : e.innerText) || "").trim().split("\\n")[0]; }))') }
async function reload() { await c.send('Page.reload'); await sleep(2600); if ((await bodyText()).includes('跳过')) { await tap('button', '跳过'); await sleep(1400) } }

// ---------- A 按存放时间排序：旧条目退到创建日期，同日期按名称且随方向翻转 ----------
const st = JSON.parse(await ev('window.GuinaNative.loadData()'))
let baseItem = st.items.filter(function (i) { return i.categoryId === 'cat-food' })[0]
if (!baseItem) {
  baseItem = { id: 'base-116', categoryId: 'cat-food', name: '基准', locationType: 'place', locationLabel: '冰箱', locationName: '', fields: {}, createdAt: '2026-01-01T00:00:00.000Z', updatedAt: '2026-01-01T00:00:00.000Z' }
}
const mk = function (name, created, storedAt) {
  const it = JSON.parse(JSON.stringify(baseItem))
  it.id = 'it-116-' + name
  it.name = name
  it.createdAt = created
  it.updatedAt = created
  it.fields.name = name
  if (storedAt) it.fields.storedAt = storedAt
  else delete it.fields.storedAt
  return it
}
st.items = [
  mk('C食品', '2026-01-01T08:00:00.000Z'),
  mk('A食品', '2026-02-01T08:00:00.000Z'),
  mk('B食品', '2026-03-01T08:00:00.000Z')
]
await ev('window.GuinaNative.saveData(' + JSON.stringify(JSON.stringify(st)) + ')')
await reload()
await goHome()
await openCategory('食品')
check('A1 默认按名称升序', JSON.stringify(JSON.parse(await names())) === JSON.stringify(['A食品', 'B食品', 'C食品']), await names())
await tap('.sort-chips .chip', '按存放时间'); await sleep(600)
check('A2 旧条目按创建日期升序（不再与名称排序一模一样）', JSON.stringify(JSON.parse(await names())) === JSON.stringify(['C食品', 'A食品', 'B食品']), await names())
await tap('.sort-chips .chip', '按存放时间'); await sleep(600)
check('A3 再点变降序，顺序真的反过来', JSON.stringify(JSON.parse(await names())) === JSON.stringify(['B食品', 'A食品', 'C食品']), await names())
await shot('116-a1-sort-stored-desc')
await tap('.sort-chips .chip', '按名称'); await sleep(600)
check('A4 切回按名称恢复升序', JSON.stringify(JSON.parse(await names())) === JSON.stringify(['A食品', 'B食品', 'C食品']), await names())

// 同一天存放的两条：升/降序必须能看出区别
const st2 = JSON.parse(await ev('window.GuinaNative.loadData()'))
st2.items = [mk('甲食品', '2026-01-01T08:00:00.000Z', '2025-06-06'), mk('乙食品', '2026-01-02T08:00:00.000Z', '2025-06-06')]
await ev('window.GuinaNative.saveData(' + JSON.stringify(JSON.stringify(st2)) + ')')
await reload()
await goHome()
await openCategory('食品')
await tap('.sort-chips .chip', '按存放时间'); await sleep(600)
check('A5 同存放日期按名称升序', JSON.stringify(JSON.parse(await names())) === JSON.stringify(['甲食品', '乙食品']), await names())
await tap('.sort-chips .chip', '按存放时间'); await sleep(600)
check('A6 同存放日期降序翻转', JSON.stringify(JSON.parse(await names())) === JSON.stringify(['乙食品', '甲食品']), await names())

// ---------- B 搜索框与排序条共存、光标不乱跳 ----------
const searchInfo = '(() => { const el = document.querySelector(".toolbar-search input, .search-wrap input, input[type=search]"); const chips = document.querySelectorAll(".sort-chips .chip"); return el ? JSON.stringify({ value: el.value, caret: el.selectionStart, chips: chips.length }) : "NO_INPUT"; })()'
const sp = await center('.toolbar-search input, .search-wrap input, input[type=search]')
check('B1 搜索框与排序条同时可见', !!sp && (await ev('document.querySelectorAll(".sort-chips .chip").length')) === 3)
await tapPoint(sp)
await c.send('Input.insertText', { text: '甲' }); await sleep(500)
const b1 = JSON.parse(await ev(searchInfo))
check('B2 输入后光标在末尾', b1.value === '甲' && b1.caret === 1, JSON.stringify(b1))
await c.send('Input.insertText', { text: '食' }); await sleep(450)
const b2 = JSON.parse(await ev(searchInfo))
check('B3 继续输入不会插到前面', b2.value === '甲食' && b2.caret === 2, JSON.stringify(b2))
check('B4 输入过程中排序条仍常驻', b2.chips === 3, JSON.stringify(b2))
await shot('116-b-search-caret')
const clearP = await center('.search-clear')
await tapPoint(clearP)
check('B5 清空按钮清掉关键字', (JSON.parse(await ev(searchInfo))).value === '', await ev(searchInfo))

// ---------- C 扫码默认后置主摄（模拟默认落在长焦，看是否切回主摄） ----------
await ev('(() => { const cvs = document.createElement("canvas"); cvs.width = 1280; cvs.height = 720; const ctx = cvs.getContext("2d"); ctx.fillStyle = "#666"; ctx.fillRect(0, 0, 1280, 720); window.__cons = []; window.__applied = []; navigator.mediaDevices.enumerateDevices = async function () { return [ { kind: "videoinput", deviceId: "cam-wide", label: "camera2 0, facing back (wide)" }, { kind: "videoinput", deviceId: "cam-tele", label: "camera2 2, facing back (telephoto)" }, { kind: "videoinput", deviceId: "cam-front", label: "camera2 1, facing front" } ]; }; navigator.mediaDevices.getUserMedia = async function (cons) { window.__cons.push(cons); const stream = cvs.captureStream(6); const track = stream.getVideoTracks()[0]; const isSwitch = cons && cons.video && cons.video.deviceId; track.getSettings = function () { return { deviceId: isSwitch ? "cam-wide" : "cam-tele", facingMode: "environment" }; }; track.getCapabilities = function () { return { zoom: { min: 0.5, max: 8, step: 0.1 }, torch: true }; }; track.applyConstraints = async function (x) { window.__applied.push(x); return true; }; return stream; }; })()')
await goHome()
await tap('.tabbar .tab', '设置'); await sleep(900)
const rowBtn = await ev('(() => { const row = [...document.querySelectorAll(".row")].find((r) => ((r.innerText || "")).includes("数据同步")); if (!row) return null; const b = row.querySelector("button"); if (!b) return null; b.scrollIntoView({ block: "center" }); const r = b.getBoundingClientRect(); return { x: r.left + r.width / 2, y: r.top + r.height / 2 }; })()')
await tapPoint(rowBtn)
await waitText('绑定新设备', 6000)
await tap('button', '扫码绑定')
await sleep(2200)
const cons = JSON.parse(await ev('JSON.stringify(window.__cons || [])'))
const applied = JSON.parse(await ev('JSON.stringify(window.__applied || [])'))
const scanDom = JSON.parse(await ev('(() => { const panel = document.querySelector(".scan-panel"); const v = document.querySelector(".scan-video"); return JSON.stringify({ panel: !!panel, video: !!v, fit: v ? getComputedStyle(v).objectFit : null, torch: !![...document.querySelectorAll("button")].find((b) => (b.innerText || "").includes("手电筒")) }); })()'))
check('C1 第一次用后置摄像头打开', cons.length > 0 && cons[0].video && cons[0].video.facingMode && cons[0].video.facingMode.exact === 'environment', JSON.stringify(cons[0] || null))
check('C2 请求 1920x1080', cons.length > 0 && cons[0].video.width.ideal === 1920 && cons[0].video.height.ideal === 1080, JSON.stringify(cons[0] || null))
check('C3 默认落在长焦时切回主摄（wide）', cons.length > 1 && cons[1].video && cons[1].video.deviceId && cons[1].video.deviceId.exact === 'cam-wide', JSON.stringify(cons[1] || null))
check('C4 变焦拉回 1x', applied.length > 0 && applied[0].advanced && applied[0].advanced[0] && applied[0].advanced[0].zoom === 1, JSON.stringify(applied))
check('C5 取景面板为等比铺满卡片', scanDom.panel && scanDom.video && scanDom.fit === 'cover', JSON.stringify(scanDom))
check('C6 支持手电筒时显示按钮', scanDom.torch === true, JSON.stringify(scanDom))
await shot('116-c-scan-panel')
await tap('button', '取消扫码'); await sleep(600)

// ---------- D 系统闹钟识别与导入方式 ----------
const alarmInfo = JSON.parse(await ev('window.GuinaNative.getAlarmInfo()'))
check('D1 能识别系统时钟应用', alarmInfo.resolved === true && String(alarmInfo.clockPackage || '').length > 0, JSON.stringify(alarmInfo))
check('D2 有循环时自动模式会判断要不要打开确认', alarmInfo.effective === 'silent' || alarmInfo.effective === 'guided', JSON.stringify(alarmInfo))
const sub = await ev('(() => { const row = [...document.querySelectorAll(".row")].find((r) => ((r.innerText || "").includes("系统闹钟导入方式"))); return row ? row.innerText.replace(/\\n/g, " | ") : ""; })()')
check('D3 设置页显示检测到的时钟应用', sub.indexOf('检测到时钟应用') >= 0, sub)
check('D4 有自动/不打开时钟/打开确认三种模式', (await ev('!!document.querySelector("[data-testid=alarm-mode-auto]") && !!document.querySelector("[data-testid=alarm-mode-silent]") && !!document.querySelector("[data-testid=alarm-mode-guided]")')) === true)
await jsTap('[data-testid=alarm-mode-guided]'); await sleep(500)
const infoGuided = JSON.parse(await ev('window.GuinaNative.getAlarmInfo()'))
check('D5 选「打开确认」后模式生效', infoGuided.mode === 'guided', JSON.stringify(infoGuided))
await jsTap('[data-testid=alarm-mode-auto]'); await sleep(500)
const infoAuto = JSON.parse(await ev('window.GuinaNative.getAlarmInfo()'))
check('D6 切回自动识别后模式生效', infoAuto.mode === 'auto', JSON.stringify(infoAuto))

// ---------- E 提醒详情时间格式 ----------
await goHome()
await jsTap('.sticky-col[data-kind=reminder] .sticky-col-add'); await sleep(900)
const setFieldText = async function (label, value) {
  const ok = await ev('(() => { const label = [...document.querySelectorAll(".field-label")].find((e) => ((e.innerText || "")).indexOf(' + JSON.stringify(label) + ') >= 0); if (!label) return false; const field = label.parentElement; const el = field.querySelector("input:not([type=time]):not([type=date]):not([type=datetime-local]), textarea"); if (!el) return false; const proto = el.tagName === "TEXTAREA" ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype; Object.getOwnPropertyDescriptor(proto, "value").set.call(el, ' + JSON.stringify(value) + '); el.dispatchEvent(new Event("input", { bubbles: true })); el.dispatchEvent(new Event("change", { bubbles: true })); return true; })()')
  return ok
}
await setFieldText('标题', '喝水提醒')
await setFieldText('内容', '十分钟后喝一杯水')
await jsTap('.sheet-panel .chip', '10 分钟后')
await jsTap('.sheet-foot .btn', '保存')
await sleep(900)
await jsTap('.sticky-card', '喝水提醒')
await sleep(900)
const detailText = (await ev('(() => { const s = document.querySelector(".sheet-panel"); return s ? s.innerText : document.body.innerText; })()')) || ''
check('E1 提醒详情不显示 ISO 时间串', !/[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}\.[0-9]{3}Z/.test(detailText), detailText.replace(/\n/g, ' | ').slice(0, 120))
check('E2 提醒详情显示本地时间或已到时间', detailText.indexOf('提醒 今天') >= 0 || detailText.indexOf('提醒 ') >= 0 || detailText.indexOf('已到时间') >= 0, detailText.slice(0, 120))
await shot('116-e-reminder-detail')

console.log('===== RESULT ' + results.filter(function (r) { return r.ok }).length + '/' + results.length + ' =====')
process.exit(0)