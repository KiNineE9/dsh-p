import { check, ev, bodyText, shot, waitFor, clickText, sheetText, sleep, goTab, summary } from './mobile-e2e.mjs'

if ((await bodyText()).includes('跳过')) {
  await clickText('跳过')
  await sleep(1500)
}
await goTab('设置')
await sleep(800)
const opened = await ev(`(() => {
  const rows = [...document.querySelectorAll('.row')];
  const row = rows.find((x) => (x.innerText || '').includes('数据同步'));
  if (!row) return 'NO_ROW';
  row.scrollIntoView({ block: 'center' });
  const b = row.querySelector('button');
  if (!b) return 'NO_BTN';
  b.click();
  return 'OK';
})()`)
check('点击数据同步入口', opened === 'OK', opened)
await waitFor(async () => (await sheetText()).includes('本机设备名'), 8000)
const st0 = await sheetText()
check('同步面板已打开', st0.includes('本机设备名'), st0.slice(0, 200))
check('显示机器码', /[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{4}/.test(st0), st0.slice(0, 300))
check('显示未绑定提示', st0.includes('还没有绑定设备'))
await shot('sync-01-sheet')
await clickText('绑定新设备', '.sheet-panel')
const okCode = await waitFor(async () => /\b\d{6}\b/.test(await sheetText()), 20000)
const st1 = await sheetText()
check('生成六位数字', okCode, st1.slice(0, 500))
check('显示邀请码与二维码', st1.includes('复制邀请码') && st1.includes('把这六位数字告诉对方'))
await shot('sync-02-pairing')
summary()
