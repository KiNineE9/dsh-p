import { execSync } from 'node:child_process'
import { connect } from './cdp.mjs'
const ADB = 'F:/Android/sdk/platform-tools/adb.exe'
const PKG = 'com.guina.app.debug'
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))
function adb(args) { return execSync('"' + ADB + '" ' + args, { encoding: 'utf8' }).trim() }
function stop() { try { adb('shell am force-stop ' + PKG) } catch {} }
async function start(port) {
  adb('shell am start -n ' + PKG + '/com.guina.app.MainActivity')
  await sleep(10000)
  const pid = adb('shell pidof ' + PKG).trim()
  adb('forward --remove-all')
  adb('forward tcp:' + port + ' localabstract:webview_devtools_remote_' + pid)
  await sleep(1500)
}
async function evalOk(expr, tag) {
  for (let i = 0; i < 10; i++) {
    try {
      const p = await connect(9333)
      const t = await p.evaluate('typeof window.GuinaNative')
      if (t !== 'object') { await p.close(); await sleep(600); continue }
      const v = await p.evaluate(expr)
      await p.close()
      return v
    } catch (e) { await sleep(600) }
  }
  throw new Error('eval failed ' + tag)
}
const disk = () => { try { const out = adb('shell run-as ' + PKG + ' cat files/data.json'); const j = JSON.parse(out); return { notifs: (j.notifications || []).map((n) => ({ id: n.id, read: n.read, del: n.deleted })), stickies: (j.stickies || []).map((s) => ({ id: s.id, notified: s.notified, at: s.remindAt, repeat: s.repeat && s.repeat.kind })) } } catch (e) { return 'ERR ' + e.message } }
const countNotif = () => adb('shell dumpsys notification --noredact').split(String.fromCharCode(10)).filter((l) => l.indexOf('pkg=com.guina') >= 0).length
const info = async (tag) => console.log(tag + '_INFO ' + await evalOk('JSON.stringify({native: typeof window.GuinaNative, body: document.body.innerText.slice(0,60), badge: (document.querySelector(".badge")||{}).textContent || null})', tag))
stop(); await sleep(800)
await start(9333)
await evalOk('window.__s = JSON.parse(window.GuinaNative.loadData()); "ok"', 'load')
const built = await evalOk('(function(){var now=new Date();var food=(window.__s.categories||[]).find(function(c){return c.baseTemplate==="food"});var exp=new Date(now.getTime()+5*86400000).toISOString().slice(0,10);window.__s.items=(window.__s.items||[]).filter(function(i){return i.id!=="it-probe"});window.__s.items.push({id:"it-probe",categoryId:food.id,name:"探针牛奶",locationType:"place",locationLabel:"冰箱",locationName:"",fields:{name:"探针牛奶",placeName:"冰箱",foodType:"固体",opened:"否",storedAt:now.toISOString().slice(0,10),expiresAt:exp},createdAt:now.toISOString(),updatedAt:now.toISOString()});window.__s.notifications=[{id:"notif-probe-1",type:"foodExpiring",kind:"food",itemId:"it-probe",tier:7,expiryDate:exp,read:true,deleted:false,createdAt:now.toISOString()}];window.__s.stickies=(window.__s.stickies||[]).filter(function(s){return s.id.indexOf("st-probe")!==0});window.__s.stickies.push({id:"st-probe",title:"探针提醒",content:"探针提醒内容",kind:"reminder",pinned:false,remindAt:new Date(now.getTime()-300000).toISOString(),repeat:null,status:"pending",createdAt:now.toISOString(),updatedAt:now.toISOString(),notified:false});window.__s.onboardingDone=true;return "built"})()', 'build')
console.log('BUILD ' + built)
console.log('SAVE ' + await evalOk('window.GuinaNative.saveData(JSON.stringify(window.__s)); "saved"', 'save'))
await sleep(600)
console.log('SEEDED_DISK ' + JSON.stringify(disk()))
stop(); await sleep(1500)
await start(9333); await info('L1')
console.log('L1_DISK ' + JSON.stringify(disk()))
console.log('L1_NOTIFCOUNT ' + countNotif())
stop(); await sleep(1500)
await start(9333); await info('L2')
console.log('L2_DISK ' + JSON.stringify(disk()))
console.log('L2_NOTIFCOUNT ' + countNotif())
stop()
