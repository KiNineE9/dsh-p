import { connect, waitFor } from './cdp.mjs'
const port = Number(process.env.CDP_PORT || 9453)
const value = process.env.VALUE === 'false' ? false : true
const sleep = function (ms) { return new Promise(function (r) { setTimeout(r, ms) }) }
async function waitPort (p, ms) {
  const end = Date.now() + ms
  while (Date.now() < end) {
    try { const res = await fetch('http://127.0.0.1:' + p + '/json/list'); const list = await res.json(); if (list && list.length) return list } catch (e) {}
    await sleep(300)
  }
  return null
}
const out = { ok: false, value: value }
const targets = await waitPort(port, 40000)
if (!targets) { out.reason = 'NO_CDP'; console.log(JSON.stringify(out)); process.exit(2) }
const client = await connect(port, 'index.html')
const ev = function (e) { return client.evaluate(e) }
await waitFor(client, '!!document.body', 25000, 'body')
await sleep(1200)
out.api = await ev('typeof window.guina.updateSettings')
await ev('window.guina.updateSettings({ autoLaunch: ' + (value ? 'true' : 'false') + ' })')
await sleep(2000)
out.settings = await ev('window.guina.getState().then(function (s) { return { autoLaunch: s.settings.autoLaunch } })')
out.ok = out.settings && out.settings.autoLaunch === value
console.log(JSON.stringify(out))
client.close()
await sleep(300)
process.exit(out.ok ? 0 : 1)
