import { connect } from './cdp.mjs'
import fs from 'node:fs'
const c = await connect(Number(process.env.CDP_PORT || 9333), 'app.local')
await c.send('Page.enable')
const sleep = (ms) => new Promise(r => setTimeout(r, ms))
async function ev(expr) { const r = await c.evaluate(expr); return r && r.value !== undefined ? r.value : r }
async function shot(name) {
  const s = await c.send('Page.captureScreenshot', { format: 'png' })
  fs.writeFileSync('.tmp-shots/' + name + '.png', Buffer.from(s.data, 'base64'))
}
async function tap(text) {
  return ev(`(() => { const list=[...document.querySelectorAll('button,[role=button],.sheet-head button,.chip,.seg-item')]; const el=list.find(e=>(e.innerText||'').trim().includes(${JSON.stringify(text)})); if(!el) return 'NOTFOUND:'+list.map(e=>(e.innerText||'').trim().slice(0,12)).join('|'); el.click(); return 'OK'; })()`)
}
console.log('add item:', await tap('+ 条目'))
await sleep(700)
console.log('--- form text ---')
console.log(await ev('document.body.innerText.slice(0,2000)'))
fs.writeFileSync('.tmp-shots/item-form.html', await ev('document.querySelector(".sheet-panel") ? document.querySelector(".sheet-panel").outerHTML : document.body.innerHTML'))
const fields = await ev(`[...document.querySelectorAll('.field')].map(f=>{ const l=(f.querySelector('.field-label')||{}).innerText||''; const i=f.querySelector('input,textarea,select'); return l.trim()+' :: '+(i?i.tagName+':'+(i.type||'')+' name='+(i.name||i.id||'')+'' :'?') }).join('\\n')`)
console.log('--- fields ---\n' + fields)
await shot('phone-04-item-form')
c.close()
