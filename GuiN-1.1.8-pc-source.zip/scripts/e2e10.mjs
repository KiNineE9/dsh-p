// 1.1.4 桌面端数据同步：已绑定设备备注、备注持久化、在线检测（离线分支）
import fs from 'node:fs'
import path from 'node:path'
import { connect, waitFor } from './cdp.mjs'

const results = []
function check(name, ok, detail) {
  results.push({ name: name, ok: !!ok, detail: detail === undefined ? '' : String(detail) })
  console.log((ok ? 'PASS' : 'FAIL') + ' | ' + name + (detail === undefined || detail === '' ? '' : ' | ' + detail))
}
function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms) }) }

const client = await connect(9222, 'index.html')
const ev = function (expr) { return client.evaluate(expr) }
async function shot(name) {
  try { await client.shot('.tmp-shots/' + name + '.png') } catch (e) { console.log('shot fail', e.message) }
}

const INSTALL = [
  'window.__t = {',
  '  all: function (id) { return Array.prototype.filter.call(document.querySelectorAll("[data-testid]"), function (e) { return e.getAttribute("data-testid") === id }) },',
  '  q: function (id, i) { return window.__t.all(id)[i || 0] || null },',
  '  has: function (id) { return !!window.__t.q(id) },',
  '  text: function (id, i) { var e = window.__t.q(id, i); return e ? e.innerText : "" },',
  '  click: function (id, i) { var el = window.__t.q(id, i); if (!el) throw new Error("missing " + id); el.click(); return true },',
  '  fill: function (id, value) {',
  '    var el = window.__t.q(id); if (!el) throw new Error("missing " + id)',
  '    var proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype',
  '    var desc = Object.getOwnPropertyDescriptor(proto, "value")',
  '    desc.set.call(el, value)',
  '    el.dispatchEvent(new Event("input", { bubbles: true }))',
  '    el.dispatchEvent(new Event("change", { bubbles: true }))',
  '    return true',
  '  },',
  '}',
  'true'
].join(String.fromCharCode(10))

function installHelpers() { return client.evaluate(INSTALL) }

async function enterApp() {
  await waitFor(client, '!!document.body', 25000, 'body')
  await installHelpers()
  await sleep(800)
  if (await ev("__t.has('onboarding-skip')")) {
    await ev("__t.click('onboarding-skip')")
    await sleep(900)
  }
}

await enterApp()

// 1. 预写同步配置：一条带备注的绑定 + 一条无备注的绑定
const dir = await ev('(async function () { var i = await window.guina.getDataInfo(); return i.dir })()')
check('E2E10-0 取得数据目录', typeof dir === 'string' && dir.length > 0, String(dir))
const now = new Date().toISOString()
const syncCfg = {
  version: 1,
  identity: {
    deviceId: 'dev-e2e10',
    peerId: 'guina-e2e10-peer',
    name: '测试电脑',
    machineCode: 'E2E10-PC',
    kind: 'desktop',
    platform: 'win32 x64',
    appVersion: '1.1.4'
  },
  bindings: [
    {
      deviceId: 'peer-114-phone',
      peerId: 'guina-114-phone-peer',
      name: '旧手机名',
      alias: '书房的手机',
      machineCode: 'TEST-114-PHONE',
      kind: 'android',
      platform: 'Android 15',
      appVersion: '1.1.3',
      syncKey: 'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=',
      boundAt: now,
      lastSyncAt: null,
      lastMode: null,
      lastSeenAt: null
    },
    {
      deviceId: 'peer-114-desk2',
      peerId: 'guina-114-desk2-peer',
      name: '办公室电脑',
      machineCode: 'TEST-114-DESK2',
      kind: 'desktop',
      platform: 'win32 x64',
      appVersion: '1.1.3',
      syncKey: 'BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB=',
      boundAt: now,
      lastSyncAt: null,
      lastMode: null,
      lastSeenAt: null
    }
  ]
}
const cfgFile = path.join(dir, 'sync-device.json')
fs.writeFileSync(cfgFile, JSON.stringify(syncCfg, null, 2), 'utf8')
check('E2E10-1 同步配置已写入 userData', fs.existsSync(cfgFile), cfgFile)

// 2. 重新加载后打开设置 → 数据同步
await client.send('Page.reload')
await enterApp()
await ev("__t.click('settings-btn')")
await waitFor(client, "!!__t.has('sync-card')", 12000, 'sync-card')
await sleep(1200)

const names = await ev("Array.prototype.map.call(document.querySelectorAll('[data-testid=sync-binding-name]'), function (e) { return e.innerText.trim() })")
check('E2E10-2 设备名优先显示备注', names[0] === '书房的手机', JSON.stringify(names))
check('E2E10-3 第二台按原名显示', names[1] === '办公室电脑', JSON.stringify(names))
const firstCard = await ev("(function () { var c = __t.q('sync-binding'); return c ? c.innerText : '' })()")
check('E2E10-4 显示备注标签与机器码', firstCard.includes('备注') && firstCard.includes('TEST-114-PHONE'), firstCard.replace(/\s+/g, ' ').slice(0, 160))
check('E2E10-5 未检测时徽标为未检测', (await ev("__t.text('sync-online-badge')")) === '未检测', await ev("__t.text('sync-online-badge')"))
const machineCode = await ev("__t.text('sync-machine-code')")
check('E2E10-6 本机身份来自预写配置', machineCode === 'E2E10-PC', machineCode)

// 3. 编辑备注
await ev("__t.click('sync-alias-edit')")
await sleep(400)
const prefilled = await ev("(function () { var el = __t.q('sync-alias-input'); return el ? el.value : 'NO_INPUT' })()")
check('E2E10-7 备注输入框带出当前备注', prefilled === '书房的手机', prefilled)
await ev("__t.fill('sync-alias-input', '书房的手机-改')")
await ev("__t.click('sync-alias-save')")
await waitFor(client, "(function () { var t = document.querySelector('[data-testid=toast]'); return t ? t.innerText.includes('备注已保存为') : false })()", 6000, 'alias toast')
check('E2E10-8 保存备注 toast 正确', (await ev("__t.text('toast')")).includes('备注已保存为「书房的手机-改」'), await ev("__t.text('toast')"))
await sleep(600)
const savedCfg = await ev('(async function () { return await window.guina.getSyncConfig() })()')
check('E2E10-9 备注已通过 IPC 持久化', Boolean(savedCfg && savedCfg.bindings[0] && savedCfg.bindings[0].alias === '书房的手机-改'), JSON.stringify(savedCfg && savedCfg.bindings[0] && savedCfg.bindings[0].alias))
const onDisk = JSON.parse(fs.readFileSync(cfgFile, 'utf8'))
check('E2E10-10 备注已写入 sync-device.json', onDisk.bindings[0].alias === '书房的手机-改', onDisk.bindings[0].alias)
const renamed = await ev("__t.text('sync-binding-name')")
check('E2E10-11 卡片显示新备注', renamed === '书房的手机-改', renamed)

// 4. 清除备注恢复原名
await ev("__t.click('sync-alias-edit')")
await sleep(300)
await ev("__t.fill('sync-alias-input', '')")
await ev("__t.click('sync-alias-save')")
await waitFor(client, "(function () { var t = document.querySelector('[data-testid=toast]'); return t ? t.innerText.includes('已清除备注') : false })()", 6000, 'clear alias toast')
check('E2E10-12 清除备注 toast 正确', (await ev("__t.text('toast')")).includes('已清除备注，恢复显示对方设备名'), await ev("__t.text('toast')"))
await sleep(500)
check('E2E10-13 清除后备注标签消失且显示原名', (await ev("__t.text('sync-binding-name')")) === '旧手机名' && !(await ev("(function () { var c = __t.q('sync-binding'); return c ? c.querySelector('.sync-device-alias-note') !== null : true })()")), await ev("__t.text('sync-binding-name')"))

// 5. 检测在线：对端不存在 → 徽标变离线
await ev("__t.click('sync-check-online')")
const badge = await waitFor(client, "(function () { var el = document.querySelector('[data-testid=sync-online-badge]'); return el && el.innerText.trim() === '离线' ? '离线' : false })()", 45000, 'offline badge')
check('E2E10-14 检测在线后徽标变离线', badge === '离线')
await sleep(400)
const toastText = await ev("__t.text('toast')")
check('E2E10-15 离线 toast 提示设备不在线', toastText.includes('设备不在线'), toastText)
const seenMeta = await ev("(function () { var el = __t.q('sync-binding-meta'); return el ? el.innerText : '' })()")
check('E2E10-16 离线检测不写入上次在线时间', !seenMeta.includes('上次在线') && Boolean(savedCfg) && savedCfg.bindings[0].lastSeenAt === null, seenMeta.replace(/\s+/g, ' ').slice(0, 160))
await shot('desktop-sync-114')

const pass = results.filter(function (r) { return r.ok }).length
console.log('\n===== RESULT ' + pass + '/' + results.length + ' =====')
const failed = results.filter(function (r) { return !r.ok })
if (failed.length) {
  console.log('FAILURES:')
  failed.forEach(function (f) { console.log(' - ' + f.name + (f.detail ? ' :: ' + f.detail : '')) })
}
client.close()
process.exit(failed.length ? 1 : 0)
