import fs from 'node:fs';
const ver = process.argv[2];
const out = process.argv[3];
const url = 'https://npmmirror.com/mirrors/electron/' + ver + '/electron-v' + ver + '-win32-x64.zip';
console.log('GET', url);
const res = await fetch(url, { redirect: 'follow' });
if (!res.ok) { console.log('HTTP', res.status); process.exit(2); }
const buf = Buffer.from(await res.arrayBuffer());
fs.writeFileSync(out, buf);
console.log('OK bytes=' + buf.length);
