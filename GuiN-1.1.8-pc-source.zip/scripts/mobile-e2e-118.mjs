// 1.1.8 安卓端 E2E：通知只有手动点「标为已读」才不再提醒；未读/标为未读仍会提醒；一次性提醒只弹一次
import { execSync } from 'node:child_process'
import fs from 'node:fs'
const ADB = 'F:/Android/sdk/platform-tools/adb.exe'
const PKG = 'com.guina.app.debug'
const SHOT_DIR = process.env.SHOT_DIR || '.tmp-shots/118'
fs.mkdirSync(SHOT_DIR, { recursive: true })
const { connect } = await import('./cdp.mjs')
const sleep = function (ms) { return new Promise(function (r) { setTimeout(r, ms) }) }
const results = []
function check(name, ok, detail) {
  results.push({ name: name, ok: !!ok })
  console.log((ok ? 'PASS' : 'FAIL') + ' | ' + name + (detail === undefined || detail === '' ? '' : ' | ' + detail))
}
function adb(shell) { try { return execSync('"' + ADB + '" ' + shell, { encoding: 'utf8', timeout: 40000 }) } catch (e) { return String((e && e.stdout) || '') } }
async function shot(name) {
  try { const buf = execSync('"' + ADB + '" exec-out screencap -p', { maxBuffer: 40 * 1024 * 1024 }); fs.writeFileSync(SHOT_DIR + '/' + name + '.png', buf) } catch (e) {}
}
let c = null
async function attach() {
  c = await connect(9333, 'app.local')
  await c.send('Page.enable'); await c.send('Runtime.enable')
}
const ev = function (e) { return c.evaluate(e) }
const bodyText = async function () { return (await ev('document.body.innerText')) || '' }
async function waitText(text, ms) {
  const end = Date.now() + (ms || 8000)
  while (Date.now() < end) { if ((await bodyText()).includes(text)) return true; await sleep(250) }
  return false
}
async function waitSel(sel, ms) {
  const end = Date.now() + (ms || 8000)
  while (Date.now() < end) { if (await ev('!!document.querySelector(' + JSON.stringify(sel) + ')')) return true; await sleep(250) }
  return false
}
async function jsTap(sel, text) {
  const ok = await ev('(() => { const list = [...document.querySelectorAll(' + JSON.stringify(sel) + ')]; const el = ' + (text ? 'list.find((e) => ((e.innerText || "").trim()).indexOf(' + JSON.stringify(text) + ') >= 0)' : 'list[0]') + '; if (!el) return false; el.click(); return true; })()')
  await sleep(600)
  return ok
}
async function closeSheet() { await jsTap('button[aria-label="关闭"]'); await sleep(600) }
async function reload() { await c.send('Page.reload'); await sleep(3000); if ((await bodyText()).includes('跳过')) { await jsTap('button', '跳过'); await sleep(1500) } }
function forward() {
  const pid = String(adb('shell pidof ' + PKG)).trim()
  adb('forward --remove-all')
  adb('forward tcp:9333 localabstract:webview_devtools_remote_' + pid)
  return pid
}
async function restartApp() {
  adb('shell am force-stop ' + PKG)
  await sleep(1200)
  adb('shell am start -n ' + PKG + '/com.guina.app.MainActivity')
  await sleep(9000)
  const pid = forward()
  await attach()
  await sleep(1200)
  if ((await bodyText()).includes('跳过')) { await jsTap('button', '跳过'); await sleep(1200) }
  return pid
}
function readDisk() {
  try { return JSON.parse(adb('shell run-as ' + PKG + ' cat files/data.json')) } catch (e) { return null }
}
// 通知栏里当前还挂着的、属于 GuiN 的通知条数（只看 Notification List 里的活动记录）
function guinNotifCount() {
  try {
    const out = adb('shell dumpsys notification --noredact')
    return out.split(String.fromCharCode(10)).filter(function (line) {
      return line.indexOf('NotificationRecord(') >= 0 && line.indexOf('pkg=com.guina.app.debug') >= 0
    }).length
  } catch (e) { return -1 }
}

await attach()
await sleep(1500)
if ((await bodyText()).includes('跳过')) { await jsTap('button', '跳过'); await sleep(1200) }

// ---------- 造数据：一条 20 天后到期的食品 + 一条未读到期提醒 ----------
const now = Date.now()
function iso(ms) { return new Date(ms).toISOString() }
function day(offset) {
  const d = new Date(now + offset * 86400000)
  const m = d.getMonth() + 1; const dd = d.getDate()
  return d.getFullYear() + '-' + (m < 10 ? '0' + m : m) + '-' + (dd < 10 ? '0' + dd : dd)
}
const st = JSON.parse(await ev('window.GuinaNative.loadData()'))
const foodCat = st.categories.filter(function (x) { return x.baseTemplate === 'food' })[0]
if (!foodCat) { console.log('NO_FOOD_CATEGORY'); process.exit(1) }
const exp = day(20)
const today = day(0)
st.items = [{
  id: 'it-118', categoryId: foodCat.id, name: '测试面包', locationType: 'place', locationLabel: '橱柜', locationName: '',
  fields: { name: '测试面包', foodType: '固体', opened: 'no', expiresAt: exp, storedAt: today },
  createdAt: iso(now - 3600000), updatedAt: iso(now - 3600000)
}]
st.notifications = [{
  id: 'notif-118-1', type: 'expiry', kind: 'food', itemId: 'it-118', tier: 30, expiryDate: exp,
  read: false, deleted: false, createdAt: iso(now - 3600000)
}]
st.stickies = []
st.onboardingDone = true
st.settings.reminderSound = false
await ev('window.GuinaNative.saveData(' + JSON.stringify(JSON.stringify(st)) + ')')
await reload()

// ---------- A 到期提醒：只有手动点「标为已读」才停止提醒 ----------
const badgeText = async function () { return await ev('(() => { const b = document.querySelector(\'button[aria-label="通知"] .badge\'); return b ? (b.innerText || "") : "" })()') }
check('A1 首页铃铛显示未读角标', Number(await badgeText()) >= 1, String(await badgeText()))
await jsTap('button[aria-label="通知"]')
await waitSel('.sheet-panel', 6000)
const unreadStyles = await ev('document.querySelectorAll(".notice.unread").length')
check('A2 通知面板里条目是未读样式', Number(unreadStyles) >= 1, String(unreadStyles))
check('A3 面板里能看到提醒对应的条目名称', (await bodyText()).includes('测试面包'), '')
await shot('118-a-notif-unread')
await closeSheet()
await sleep(1000)
check('A4 关闭面板不会自动已读（角标仍在）', Number(await badgeText()) >= 1, String(await badgeText()))
const diskA1 = readDisk()
const nA1 = diskA1 ? (diskA1.notifications || []).filter(function (n) { return n.id === 'notif-118-1' })[0] : null
check('A5 关闭后 data.json 里仍是未读', !!nA1 && nA1.read === false, nA1 ? String(nA1.read) : 'missing')

await restartApp()
await sleep(1500)
check('A6 重开 App 后未读角标仍在（未读会继续提醒）', Number(await badgeText()) >= 1, String(await badgeText()))

// 手动点「标为已读」
await jsTap('button[aria-label="通知"]')
await waitSel('.sheet-panel', 6000)
await jsTap('.notice .mini-btn', '标为已读')
await sleep(1000)
check('A7 手动标为已读后角标消失', (await badgeText()) === '', String(await badgeText()))
const diskA2 = readDisk()
const nA2 = diskA2 ? (diskA2.notifications || []).filter(function (n) { return n.id === 'notif-118-1' })[0] : null
check('A8 手动已读写入 data.json（read=true）', !!nA2 && nA2.read === true, nA2 ? String(nA2.read) : 'missing')
const shade1 = guinNotifCount()
check('A9 已读后通知栏没有残留的到期提醒通知', shade1 === 0, String(shade1))
await shot('118-b-notif-read')
await closeSheet()

await restartApp()
await sleep(1500)
check('A10 重开 App 后已读提醒不再提示（无角标）', (await badgeText()) === '', String(await badgeText()))

// ---------- D 手动标为未读：应该重新提醒，且重开 App 后还在 ----------
await jsTap('button[aria-label="通知"]')
await waitSel('.sheet-panel', 6000)
const readCountAfter = await ev('document.querySelectorAll(".notice").length')
check('D0 重开后面板里仍能看到这条已读记录', Number(readCountAfter) >= 1, String(readCountAfter))
await jsTap('.notice .mini-btn', '标为未读')
await sleep(1000)
check('D1 手动标为未读后角标重新出现', Number(await badgeText()) >= 1, String(await badgeText()))
await closeSheet()
await sleep(800)
check('D2 关闭面板后不会又被自动已读', Number(await badgeText()) >= 1, String(await badgeText()))
await restartApp()
await sleep(1500)
check('D3 重开 App 后手动标未读的仍会提醒', Number(await badgeText()) >= 1, String(await badgeText()))


// ---------- B 一次性提醒：只弹一次，重启后不再弹 ----------
const st2 = JSON.parse(await ev('window.GuinaNative.loadData()'))
st2.stickies = [{
  id: 'st-118-once', title: '一次性提醒', content: '测试一次性提醒', kind: 'reminder', pinned: false,
  remindAt: iso(now - 120000), repeat: null, status: 'pending', createdAt: iso(now - 300000), updatedAt: iso(now - 300000), notified: false
}]
await ev('window.GuinaNative.saveData(' + JSON.stringify(JSON.stringify(st2)) + ')')
await reload()
const popupShown = await waitSel('.reminder-card', 8000)
check('B1 到点的一次性提醒弹出应用内提醒', popupShown === true, '')
const popupText = await ev('(() => { const e = document.querySelector(".reminder-card"); return e ? e.innerText : "" })()')
check('B2 提醒弹窗里是这条提醒的内容', String(popupText).indexOf('测试一次性提醒') >= 0, String(popupText).replace(/\n/g, ' | ').slice(0, 120))
await shot('118-c-reminder-popup')
await jsTap('.reminder-actions button', '知道了')
await sleep(1200)
check('B3 点知道了后弹窗关闭', (await ev('document.querySelectorAll(".reminder-card").length')) === 0, '')
const disk2 = readDisk()
const s2 = disk2 ? (disk2.stickies || []).filter(function (s) { return s.id === 'st-118-once' })[0] : null
check('B4 一次性提醒记为已提醒并写入 data.json', !!s2 && s2.notified === true, s2 ? String(s2.notified) : 'missing')

await restartApp()
await sleep(4000)
const popupAfterRestart = await ev('document.querySelectorAll(".reminder-card").length')
check('B5 重新打开 App 不再弹这条一次性提醒', Number(popupAfterRestart) === 0, String(popupAfterRestart))
const shadeReminder = guinNotifCount()
check('B6 通知栏没有留下重复的提醒通知', shadeReminder === 0, String(shadeReminder))
const disk3 = readDisk()
const s3 = disk3 ? (disk3.stickies || []).filter(function (s) { return s.id === 'st-118-once' })[0] : null
check('B7 重启后提醒仍是已提醒状态', !!s3 && s3.notified === true, s3 ? String(s3.notified) : 'missing')

// ---------- C 桥接与版本 ----------
const hasClear = await ev('typeof (window.GuinaNative && window.GuinaNative.clearExpiryNotifications) === "function"')
check('C1 原生桥接提供 clearExpiryNotifications', hasClear === true, String(hasClear))
const clearOk = await ev('(() => { try { window.GuinaNative.clearExpiryNotifications(); return true } catch (e) { return String(e) } })()')
check('C2 调用 clearExpiryNotifications 不报错', clearOk === true, String(clearOk))
const shadeFinal = guinNotifCount()
check('C3 通知栏没有残留到期提醒通知', shadeFinal === 0, String(shadeFinal))

await jsTap('.tabbar .tab', '设置'); await sleep(1200)
await ev('window.scrollTo(0, document.body.scrollHeight)'); await sleep(900)
const aboutOk = await waitText('版本 1.1.8', 6000)
check('C4 关于页显示版本 1.1.8', aboutOk === true, String(await ev('(() => { const e = document.querySelector(".about-version"); return e ? e.innerText : "" })()')))

const passed = results.filter(function (r) { return r.ok }).length
console.log('===== RESULT ' + passed + '/' + results.length + ' =====')
const failed = results.filter(function (r) { return !r.ok }).map(function (r) { return r.name })
if (failed.length) console.log('FAILED:', failed.join(' ; '))
await c.close()
process.exit(0)