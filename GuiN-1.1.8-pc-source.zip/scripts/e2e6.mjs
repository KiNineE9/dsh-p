import fs from 'node:fs'
import { listTargets, connect, waitFor } from './cdp.mjs'

const results = []
function check(name, ok, detail) {
  results.push({ name: name, ok: !!ok, detail: detail === undefined ? '' : String(detail) })
  console.log((ok ? 'PASS' : 'FAIL') + ' | ' + name + (detail === undefined || detail === '' ? '' : ' | ' + detail))
}
function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms) }) }

async function waitPort(port, ms, filter) {
  const end = Date.now() + ms
  while (Date.now() < end) {
    try {
      const t = await listTargets(port)
      if (t && t.length) {
        if (!filter) return t
        const found = t.filter(function (x) { return x.url.indexOf(filter) >= 0 })
        if (found.length) return found
      }
    } catch (e) {}
    await sleep(250)
  }
  return null
}

const targets = await waitPort(9222, 25000, 'index.html')
if (!targets) { console.log('NO_CDP'); process.exit(2) }
const client = await connect(9222, 'index.html')
const ev = function (expr) { return client.evaluate(expr) }
const shot = function (name) { return Promise.race([client.shot('.tmp-shots/' + name + '.png').catch(function () { return null }), sleep(9000)]) }

const INSTALL = [
  'window.__t = {',
  '  all: function (id) { return Array.prototype.filter.call(document.querySelectorAll("[data-testid]"), function (e) { return e.getAttribute("data-testid") === id }) },',
  '  q: function (id, i) { return window.__t.all(id)[i || 0] || null },',
  '  count: function (id) { return window.__t.all(id).length },',
  '  texts: function (id) { return window.__t.all(id).map(function (e) { return e.innerText }) },',
  '  has: function (id) { return !!window.__t.q(id) },',
  '  text: function (id, i) { var e = window.__t.q(id, i); return e ? e.innerText : "" },',
  '  click: function (id, i) { var el = window.__t.q(id, i); if (!el) throw new Error("missing " + id); el.click(); return true },',
  '  back: function () { var btns = Array.prototype.slice.call(document.querySelectorAll("button")); for (var k = 0; k < btns.length; k++) { if (btns[k].innerText.indexOf("返回") >= 0) { btns[k].click(); return true } } return false },',
  '  state: function () { return window.guina.getState() },',
  '}',
  'true'
].join(String.fromCharCode(10))

const MEASURE = function (kind) {
  return '(' + function (k) {
    const col = document.querySelector('[data-testid="sticky-col-' + k + '"]')
    const board = col ? col.querySelector('.sticky-board') : null
    if (!board) return { missing: true }
    const bs = getComputedStyle(board)
    const br = board.getBoundingClientRect()
    const cards = Array.prototype.slice.call(board.querySelectorAll('[data-testid="sticky-card"]'))
    const rects = cards.map(function (c) { return c.getBoundingClientRect() })
    const tops = rects.map(function (r) { return Math.round(r.top) })
    const uniqueTops = tops.filter(function (t, i) { return tops.indexOf(t) === i })
    const visibleRows = uniqueTops.filter(function (t) { return t >= br.top - 1 && t + 40 <= br.bottom }).length
    return {
      display: bs.display,
      tracks: bs.gridTemplateColumns.split(' ').length,
      cards: cards.length,
      scrollHeight: board.scrollHeight,
      clientHeight: board.clientHeight,
      scrollWidth: board.scrollWidth,
      clientWidth: board.clientWidth,
      firstRowSameTop: rects.length >= 2 ? Math.abs(rects[0].top - rects[1].top) < 2 : false,
      thirdCardNextRow: rects.length >= 3 ? Math.abs(rects[0].top - rects[2].top) > 40 : false,
      fourthCardNextRow: rects.length >= 4 ? Math.abs(rects[0].top - rects[3].top) > 5 : false,
      visibleRows: visibleRows,
      cardWidth: rects.length ? Math.round(rects[0].width) : 0
    }
  }.toString() + ')(' + JSON.stringify(kind) + ')'
}

await waitFor(client, '!!document.body', 20000, 'body')
await client.evaluate(INSTALL)
await sleep(1200)
if (await ev("__t.has('onboarding-skip')")) {
  await ev("__t.click('onboarding-skip')")
  await sleep(700)
}

// ---- 1. 软件名改为 GuiN ----
check('窗口/文档标题为 GuiN', (await ev('document.title')) === 'GuiN', await ev('document.title'))
const brandName = await ev("(document.querySelector('.brand-name') || {}).innerText || ''")
check('顶栏品牌名为 GuiN', brandName === 'GuiN', brandName)
const brandTip = await ev("(document.querySelector('.brand-tip') || {}).innerText || ''")
check('顶栏副标题改为个人生活记忆库', brandTip.indexOf('个人生活记忆库') >= 0, brandTip)
check('界面里不再出现旧名字', (await ev("document.body.innerText.indexOf('物品归纳') === -1")), 'screenshot 90-guin-brand')
await shot('90-guin-home')

// ---- 2. 关于页 ----
await ev("__t.click('settings-btn')")
await waitFor(client, "!!document.querySelector('[data-testid=about-card]')", 8000, 'about card')
check('设置页有关于卡片', await ev("__t.has('about-card')"))
check('关于卡片标题为 GuiN', (await ev("__t.text('about-name')")) === 'GuiN', await ev("__t.text('about-name')"))
const aboutText = await ev("__t.text('about-card')")
check('关于简介含 DSH / 个人生活记忆库 / 开源', aboutText.indexOf('DSH') >= 0 && aboutText.indexOf('个人生活记忆库') >= 0 && aboutText.indexOf('开源') >= 0)
check('关于页有 GitHub 链接 @KiNineE9', (await ev("__t.text('about-github')")) === '@KiNineE9', await ev("__t.text('about-github')"))
check('关于页有 Bilibili 链接 @梦境薇凉i', (await ev("__t.text('about-bilibili')")) === '@梦境薇凉i', await ev("__t.text('about-bilibili')"))
check('关于页有邮箱 1332004191@qq.com', (await ev("__t.text('about-email')")) === '1332004191@qq.com', await ev("__t.text('about-email')"))
check('关于页写明仅限个人使用', (await ev("__t.text('about-license')")) === '仅限个人使用')
const PKG_VERSION = JSON.parse(fs.readFileSync(new URL('../package.json', import.meta.url), 'utf8')).version
check('关于页显示版本 ' + PKG_VERSION, (await ev("__t.text('about-version')")).indexOf(PKG_VERSION) >= 0, await ev("__t.text('about-version')"))
const extGuard = await ev("window.guina.openExternal('file:///C:/Windows/System32/calc.exe').then(function () { return 'guarded' }).catch(function () { return 'threw' })")
check('外部链接只放行 https/mailto（file 被忽略且不报错）', extGuard === 'guarded', extGuard)
await shot('91-guin-about')
await ev("__t.back()")
await sleep(700)

// ---- 3. 便签区：3 列 × 最多 3 行，高度约为界面 1/3，超出纵向滚动 ----
const created = await ev("(async function(){ var out=[]; for (var i=1;i<=12;i++){ out.push(await window.guina.createSticky({ content: '布局便签' + i, kind: 'note' })); } for (var j=1;j<=12;j++){ out.push(await window.guina.createSticky({ content: '布局提醒' + j, kind: 'reminder', repeat: { kind: 'daily', time: '09:00' } })); } return out.filter(function(r){return r && r.ok}).length })()")
check('成功创建 12 条便签 + 12 条提醒便签', created === 24, created)
await sleep(2000)
check('便签栏共 12 张卡片', (await ev("document.querySelectorAll('[data-testid=sticky-col-note] [data-testid=sticky-card]').length")) === 12)
const noteM = await ev(MEASURE('note'))
const remM = await ev(MEASURE('reminder'))
check('便签栏为 3 列网格', noteM.display === 'grid' && noteM.tracks === 3, JSON.stringify(noteM))
check('便签栏同一行放 3 张卡片', noteM.firstRowSameTop === true)
check('便签栏第 4 张卡片换到下一行', noteM.fourthCardNextRow === true, JSON.stringify(noteM))
check('便签栏默认可见 3 行（3×3）', noteM.visibleRows === 3, JSON.stringify(noteM))
check('便签栏超出后纵向滚动', noteM.scrollHeight > noteM.clientHeight + 1, noteM.scrollHeight + ' > ' + noteM.clientHeight)
check('便签栏没有横向滚动', noteM.scrollWidth <= noteM.clientWidth + 1, noteM.scrollWidth + ' <= ' + noteM.clientWidth)
check('提醒便签栏同样 3 列 3 行可见', remM.display === 'grid' && remM.tracks === 3 && remM.visibleRows === 3 && remM.firstRowSameTop === true, JSON.stringify(remM))
check('提醒便签栏超出后纵向滚动', remM.scrollHeight > remM.clientHeight + 1, remM.scrollHeight + ' > ' + remM.clientHeight)
check('提醒便签栏没有横向滚动', remM.scrollWidth <= remM.clientWidth + 1)
check('卡片宽度约为栏宽三分之一（3 列铺满）', noteM.cardWidth > noteM.clientWidth / 4 && noteM.cardWidth < noteM.clientWidth / 2.5, noteM.cardWidth + '/' + noteM.clientWidth)
const secM = await ev("(function(){ var r=document.querySelector('[data-testid=sticky-section]').getBoundingClientRect(); return { h: Math.round(r.height), win: window.innerHeight, ratio: Math.round(r.height / window.innerHeight * 1000) / 1000 } })()")
check('便签区高度约为界面 1/3', secM.ratio >= 0.28 && secM.ratio <= 0.40, JSON.stringify(secM))
await shot('92-sticky-grid3x3')

// 滚动后能看到第 4 行卡片，且未出现横向滚动
const scrolled = await ev("(function(){ var b = document.querySelector('[data-testid=sticky-col-note] .sticky-board'); b.scrollTop = b.scrollHeight; return b.scrollTop > 0 })()")
check('便签栏可以向下滚动看到更多', scrolled === true)
await shot('93-sticky-vertical-scroll')
const failed = results.filter(function (r) { return !r.ok })
console.log(JSON.stringify({ total: results.length, passed: results.length - failed.length, failed: failed }))
if (failed.length) process.exitCode = 1
