// GuiN 安卓版端到端测试：通过 WebView CDP 驱动真实 APK（debug 构建）
import { connect } from './cdp.mjs'
import fs from 'node:fs'

const PORT = Number(process.env.CDP_PORT || 9333)
const OUT = process.env.SHOT_DIR || '.tmp-shots/android'
fs.mkdirSync(OUT, { recursive: true })

const sleep = (ms) => new Promise((r) => setTimeout(r, ms))
let pass = 0
let fail = 0
const failures = []
const results = []

function check(name, ok, detail) {
  if (ok) { pass++; results.push('PASS ' + name) }
  else { fail++; failures.push(name + (detail ? ' :: ' + detail : '')); results.push('FAIL ' + name + (detail ? ' :: ' + detail : '')) }
}

const c = await connect(PORT, 'app.local')
await c.send('Page.enable')
await c.send('Runtime.enable')

async function ev(expr) {
  const r = await c.evaluate(expr)
  if (r && typeof r === 'object' && 'value' in r) return r.value
  return r
}
async function bodyText() { return (await ev('document.body.innerText')) || '' }
async function shot(name) {
  const s = await c.send('Page.captureScreenshot', { format: 'png' })
  fs.writeFileSync(OUT + '/' + name + '.png', Buffer.from(s.data, 'base64'))
}
async function waitFor(pred, timeout = 6000) {
  const start = Date.now()
  while (Date.now() - start < timeout) {
    if (await pred()) return true
    await sleep(150)
  }
  return false
}
async function waitText(text, timeout = 6000) {
  return waitFor(async () => (await bodyText()).includes(text), timeout)
}
async function clickText(text, scope) {
  return ev(`(() => {
    const scope = ${scope ? 'document.querySelector(' + JSON.stringify(scope) + ')' : 'document'};
    if (!scope) return 'NO_SCOPE';
    const sels = 'button,[role=button],a,.tab,.cat-card,.chip,.seg-item,.item-card,.sticky-card,.row,.tab-pill,.link-btn,.icon-btn,.fab-action,.sheet-head button';
    const list = [...scope.querySelectorAll(sels)];
    const el = list.find((e) => ((e.innerText || e.textContent || '') + '').trim().includes(${JSON.stringify(text)}));
    if (!el) return 'NOTFOUND: ' + list.map((e) => ((e.innerText || '') + '').trim().slice(0, 14)).filter(Boolean).slice(0, 24).join(' | ');
    el.click();
    return 'OK';
  })()`)
}
async function clickExact(text) {
  return ev(`(() => {
    const sels = 'button,[role=button],.tab,.chip,.seg-item,.tab-pill';
    const list = [...document.querySelectorAll(sels)];
    const el = list.find((e) => ((e.innerText || '') + '').trim() === ${JSON.stringify(text)});
    if (!el) return 'NOTFOUND';
    el.click();
    return 'OK';
  })()`)
}
async function setInput(elExpr, value) {
  return ev(`(() => {
    const el = ${elExpr};
    if (!el) return 'NO_EL';
    const proto = el.tagName === 'TEXTAREA' ? window.HTMLTextAreaElement.prototype : window.HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, 'value').set;
    setter.call(el, ${JSON.stringify(value)});
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    return 'OK';
  })()`)
}
async function setField(label, value) {
  return ev(`(() => {
    const fields = [...document.querySelectorAll('.field')];
    const want = ${JSON.stringify(label)};
    const f = fields.find((x) => { const l = (x.querySelector('.field-label') || {}).textContent || ''; return l.trim().split('*')[0].trim() === want; });
    if (!f) return 'NO_FIELD';
    const el = f.querySelector('input,textarea,select');
    if (!el) return 'NO_INPUT';
    const proto = el.tagName === 'TEXTAREA' ? window.HTMLTextAreaElement.prototype : window.HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, 'value').set;
    setter.call(el, ${JSON.stringify(value)});
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    return 'OK';
  })()`)
}
async function sheetOpen() { return ev('!!document.querySelector(".sheet-panel")') }
async function sheetText() { return ev('(document.querySelector(".sheet-panel")||{}).innerText || ""') }
async function closeSheet() { return ev(`(() => { const b = [...document.querySelectorAll('.sheet-head button')].find(x => (x.textContent||'').trim() === '✕'); if (!b) return 'NO_CLOSE'; b.click(); return 'OK'; })()`) }
async function goTab(name) {
  return ev(`(() => {
    const t = [...document.querySelectorAll('.tab')].find(x => (x.innerText||'').includes(${JSON.stringify(name)}));
    if (!t) return 'NO_TAB'; t.click(); return 'OK';
  })()`)
}

// 重置应用数据后重新加载
async function resetData() {
  const r = await ev('window.GuinaNative ? window.GuinaNative.getInfo() : "no-native"')
  return r
}

function summary() {
  console.log('\n===== RESULT ' + pass + '/' + (pass + fail) + ' =====')
  results.forEach((r) => console.log(r))
  if (failures.length) {
    console.log('\nFAILURES:')
    failures.forEach((f) => console.log(' - ' + f))
  }
  c.close()
  process.exit(fail === 0 ? 0 : 1)
}

export { check, ev, bodyText, shot, waitFor, waitText, clickText, clickExact, setInput, setField, sheetOpen, sheetText, closeSheet, goTab, summary, sleep }
