import { ev, sleep } from './mobile-e2e.mjs'
await ev("(() => { try { window.GuinaNative.scheduleReminder('hs-shot-1','喝水提醒','现在喝一杯水吧', String(Date.now() + 3000), '', '', true); return 'OK' } catch (e) { return 'ERR ' + e } })()").then(r => console.log('sched=' + r))
process.exit(0)
