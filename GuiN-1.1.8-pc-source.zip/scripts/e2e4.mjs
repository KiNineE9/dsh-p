import fs from 'node:fs'
import { listTargets, connect, waitFor } from './cdp.mjs'

fs.mkdirSync('.tmp-shots', { recursive: true })
const results = []
function check(name, ok, detail) {
  results.push({ name: name, ok: !!ok, detail: detail === undefined ? '' : String(detail) })
  console.log((ok ? 'PASS' : 'FAIL') + ' | ' + name + (detail === undefined || detail === '' ? '' : ' | ' + detail))
}
function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms) }) }
async function waitPort(port, ms, filter) {
  const end = Date.now() + ms
  while (Date.now() < end) {
    try {
      const t = await listTargets(port)
      if (t && t.length) {
        if (!filter) return t
        const found = t.filter(function (x) { return x.url.indexOf(filter) >= 0 })
        if (found.length) return found
      }
    } catch (e) {}
    await sleep(250)
  }
  return null
}

const targets = await waitPort(9222, 25000, 'index.html')
if (!targets) { console.log('NO_CDP'); process.exit(2) }
const client = await connect(9222, 'index.html')
const ev = function (expr) { return client.evaluate(expr) }
const shot = function (name) { return Promise.race([client.shot('.tmp-shots/' + name + '.png').catch(function () { return null }), sleep(9000)]) }

const INSTALL = [
  'window.__t = {',
  '  all: function (id) { return Array.prototype.filter.call(document.querySelectorAll("[data-testid]"), function (e) { return e.getAttribute("data-testid") === id }) },',
  '  q: function (id, i) { return window.__t.all(id)[i || 0] || null },',
  '  count: function (id) { return window.__t.all(id).length },',
  '  texts: function (id) { return window.__t.all(id).map(function (e) { return e.innerText }) },',
  '  has: function (id) { return !!window.__t.q(id) },',
  '  text: function (id, i) { var e = window.__t.q(id, i); return e ? e.innerText : "" },',
  '  click: function (id, i) { var el = window.__t.q(id, i); if (!el) throw new Error("missing " + id); el.click(); return true },',
  '  clickText: function (id, needle) { var list = window.__t.all(id); for (var k = 0; k < list.length; k++) { if (list[k].innerText.indexOf(needle) >= 0) { list[k].click(); return true } } throw new Error("no " + id + " with " + needle) },',
  '  set: function (id, v) {',
  '    var el = window.__t.q(id)',
  '    if (!el) throw new Error("missing " + id)',
  '    var proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : el instanceof HTMLSelectElement ? HTMLSelectElement.prototype : HTMLInputElement.prototype',
  '    Object.getOwnPropertyDescriptor(proto, "value").set.call(el, v)',
  '    el.dispatchEvent(new Event("input", { bubbles: true }))',
  '    el.dispatchEvent(new Event("change", { bubbles: true }))',
  '    return true',
  '  },',
  '  back: function () { var btns = Array.prototype.slice.call(document.querySelectorAll("button")); for (var k = 0; k < btns.length; k++) { if (btns[k].innerText.indexOf("返回") >= 0) { btns[k].click(); return true } } return false },',
  '  state: function () { return window.guina.getState() },',
  '}',
  'true'
].join(String.fromCharCode(10))

await waitFor(client, '!!document.body', 20000, 'body')
await client.evaluate(INSTALL)
await sleep(1200)
if (await ev("__t.has('onboarding-skip')")) {
  await ev("__t.click('onboarding-skip')")
  await sleep(600)
}

// ---- 1. 新建便利贴：循环提醒选项 ----
await ev("__t.click('sticky-add-reminder')")
await waitFor(client, "!!document.querySelector('[data-testid=sticky-content]')", 8000, 'sticky form')
const hasKind = await ev("__t.has('sticky-repeat-kind')")
check('新建便利贴有循环提醒选项', hasKind)
const kindOptions = await ev("Array.prototype.map.call(__t.q('sticky-repeat-kind').options, function (o) { return o.textContent }).join('|')")
check('循环选项含不循环/每天/工作日/周六日',
  String(kindOptions).indexOf('不循环') >= 0 &&
    String(kindOptions).indexOf('每天') >= 0 &&
    String(kindOptions).indexOf('工作日') >= 0 &&
    String(kindOptions).indexOf('周六日') >= 0, kindOptions)
check('默认不循环时显示一次性提醒时间', await ev("__t.has('sticky-remind') && !__t.has('sticky-repeat-time')"))
await ev("__t.set('sticky-content', '每天喝水')")
await ev("__t.set('sticky-repeat-kind', 'daily')")
await sleep(300)
check('选每天后出现几点提醒输入', await ev("__t.has('sticky-repeat-time') && !__t.has('sticky-remind')"))

// 设成下一分钟，等 20 秒轮询到点
const nextMinute = await ev("(function(){var d=new Date(Date.now()+65000);var p=function(n){return n<10?'0'+n:''+n};return p(d.getHours())+':'+p(d.getMinutes())})()")
await ev("__t.set('sticky-repeat-time', '" + nextMinute + "')")
await sleep(300)
await shot('70-sticky-repeat-form')
await ev("__t.click('modal-confirm')")
await waitFor(client, "__t.count('sticky-card') === 1", 8000, 'sticky card')
const cardText = await ev("__t.text('sticky-card')")
check('保存后便利贴卡片显示「每天」和提醒时间', cardText.indexOf('每天') >= 0, cardText.replace(/\n/g, ' '))
const saved = await ev("__t.state().then(function (s) { var x = s.stickies.filter(function (y) { return y.content === '每天喝水' })[0]; return { kind: x && x.repeat ? x.repeat.kind : null, time: x && x.repeat ? x.repeat.time : null, future: !!(x && x.remindAt && new Date(x.remindAt).getTime() > Date.now()), notified: x ? x.notified : null, status: x ? x.status : null } })")
check('循环规则落库为每天', saved && saved.kind === 'daily', JSON.stringify(saved))
check('保存时自动算出下一次提醒时间', saved && saved.future === true && saved.notified === false, JSON.stringify(saved))
await shot('71-sticky-repeat-card')

// ---- 2. 到点弹提醒窗并显示循环文案 ----
const remTargets = await waitPort(9222, 110000, 'reminder.html')
check('循环便利贴到点弹出提醒窗', !!remTargets)
if (remTargets) {
  const rc = await connect(9222, 'reminder.html')
  await sleep(800)
  const remText = await rc.evaluate("document.body.innerText")
  check('提醒窗显示循环信息', String(remText).indexOf('循环') >= 0 && String(remText).indexOf('每天') >= 0, String(remText).replace(/\n/g, ' ').slice(0, 120))
  check('提醒窗内容正确', String(remText).indexOf('每天喝水') >= 0)
  await rc.shot('.tmp-shots/72-reminder-repeat.png').catch(function () { return null })
  await rc.evaluate("(function(){var b=document.querySelector('[data-testid=reminder-ok]');if(b)b.click();return true})()")
  await sleep(1500)
  await rc.close()
}
const closed = await waitPort(9222, 8000, 'reminder.html')
check('点知道了后提醒窗关闭', !closed)

// 顺延到下一次，而不是当天重复弹
const afterAck = await ev("__t.state().then(function (s) { var x = s.stickies.filter(function (y) { return y.content === '每天喝水' })[0]; return { kind: x && x.repeat ? x.repeat.kind : null, status: x ? x.status : null, notified: x ? x.notified : null, next: x ? x.remindAt : null, future: !!(x && x.remindAt && new Date(x.remindAt).getTime() > Date.now()) } })")
check('知道了后仍保留每天循环', afterAck && afterAck.kind === 'daily', JSON.stringify(afterAck))
check('知道了后自动顺延到下一次', afterAck && afterAck.future === true && afterAck.notified === false && afterAck.status === 'pending', JSON.stringify(afterAck))
const secondPop = await waitPort(9222, 22000, 'reminder.html')
check('顺延后当天不会重复弹窗', !secondPop)

// ---- 3. 改成工作日提醒 ----
await ev("__t.click('sticky-card')")
await waitFor(client, "!!document.querySelector('[data-testid=sticky-detail-edit]')", 8000, 'sticky detail')
await ev("__t.click('sticky-detail-edit')")
await waitFor(client, "!!document.querySelector('[data-testid=sticky-repeat-kind]')", 8000, 'edit sticky')
const editKind = await ev("__t.q('sticky-repeat-kind').value")
check('编辑时回显已保存的循环方式', editKind === 'daily', editKind)
await ev("__t.set('sticky-repeat-kind', 'weekdays')")
await sleep(250)
await ev("__t.set('sticky-repeat-time', '08:30')")
await sleep(250)
await ev("__t.click('modal-confirm')")
await sleep(900)
const edited = await ev("__t.state().then(function (s) { var x = s.stickies.filter(function (y) { return y.content === '每天喝水' })[0]; return { kind: x && x.repeat ? x.repeat.kind : null, time: x && x.repeat ? x.repeat.time : null } })")
check('改为工作日 08:30 后落库正确', edited && edited.kind === 'weekdays' && edited.time === '08:30', JSON.stringify(edited))
const cardText2 = await ev("__t.text('sticky-card')")
check('卡片文案更新为工作日', cardText2.indexOf('工作日') >= 0, cardText2.replace(/\n/g, ' '))

// ---- 4. 一次性提醒仍然正常 ----
await ev("__t.click('sticky-add-reminder')")
await waitFor(client, "!!document.querySelector('[data-testid=sticky-repeat-kind]')", 8000, 'one-off form')
await ev("__t.set('sticky-repeat-kind', 'none')")
await sleep(350)
await waitFor(client, "!!document.querySelector('[data-testid=sticky-remind]')", 5000, 'one-off time')
await ev("__t.set('sticky-content', '交电费')")
await ev("__t.set('sticky-remind', '2020-01-01T09:00')")
await sleep(250)
await ev("__t.click('modal-confirm')")
const oneOffRem = await waitPort(9222, 30000, 'reminder.html')
check('一次性便利贴到点仍会提醒', !!oneOffRem)
if (oneOffRem) {
  const rc2 = await connect(9222, 'reminder.html')
  await sleep(700)
  const t2 = await rc2.evaluate("document.body.innerText")
  check('一次性提醒窗内容正确', String(t2).indexOf('交电费') >= 0, String(t2).replace(/\n/g, ' ').slice(0, 100))
  await rc2.evaluate("(function(){var b=document.querySelector('[data-testid=reminder-done]');if(b)b.click();return true})()")
  await sleep(1200)
  await rc2.close()
}
await sleep(900)
const oneOff = await ev("__t.state().then(function (s) { var x = s.stickies.filter(function (y) { return y.content === '交电费' })[0]; return { status: x ? x.status : null, repeat: x ? x.repeat : 'missing' } })")
check('一次性便利贴标记完成后不再提醒', oneOff && oneOff.status === 'done', JSON.stringify(oneOff))
await shot('73-sticky-two-kinds')

const failed = results.filter(function (r) { return !r.ok })
console.log(JSON.stringify({ total: results.length, passed: results.length - failed.length, failed: failed }))
if (failed.length) process.exitCode = 1