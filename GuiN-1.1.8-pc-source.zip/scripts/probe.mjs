import { listTargets, connect } from './cdp.mjs'
async function waitPort(port, ms) {
  const end = Date.now() + ms
  while (Date.now() < end) {
    try { const t = await listTargets(port); if (t && t.length) return t } catch (e) {}
    await new Promise(function (r) { setTimeout(r, 300) })
  }
  return null
}
const t = await waitPort(9222, 25000)
if (!t) { console.log('NO_CDP'); process.exit(2) }
const client = await connect(9222, 'index.html')
await new Promise(function (r) { setTimeout(r, 2000) })
const info = await client.evaluate("({ title: document.title, testids: Array.from(document.querySelectorAll('[data-testid]')).map(function (e) { return e.getAttribute('data-testid') }), body: document.body.innerText.slice(0, 500) })")
await client.shot('.tmp-shots/home-initial.png')
console.log(JSON.stringify(info))
client.close()