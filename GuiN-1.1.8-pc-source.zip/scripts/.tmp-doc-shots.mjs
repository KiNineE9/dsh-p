import { ev, bodyText, shot, waitFor, waitText, clickText, setField, goTab, closeSheet, sheetText, sleep } from './mobile-e2e.mjs'

const S = (t) => console.log('[step] ' + t)
if ((await bodyText()).includes('跳过')) await clickText('跳过')
await waitText('我的分类')
S('home ready')

// 125 关于页
await goTab('设置')
await waitText('关于 GuiN')
await ev("(() => { const el = document.querySelector('.about-block'); if (el) el.scrollIntoView({ block: 'center' }); return 'OK' })()")
await sleep(500)
await shot('125-android-about')
S('shot about')

// 129 通知可靠性设置行
await ev("(() => { const rows = [...document.querySelectorAll('.row,.switch-row')]; const row = rows.find(r => (r.innerText||'').includes('电池优化')); if (row) row.scrollIntoView({ block: 'center' }); return 'OK' })()")
await sleep(500)
await shot('129-android-notify-reliability')
S('shot notify rows')

// 126 分类置顶
await goTab('首页')
await ev("(() => { const c = [...document.querySelectorAll('.cat-card')].find(e => (e.innerText||'').includes('药品')); if (c) c.click(); return 'OK' })()")
await sleep(600)
await ev("(() => { const b = document.querySelector('[aria-label=\"分类操作\"]'); if (b) b.click(); return 'OK' })()")
await waitFor(async () => (await sheetText()).includes('置顶这个分类'))
await clickText('置顶这个分类', '.sheet-panel')
await sleep(500)
await ev("(() => { const b = document.querySelector('[aria-label=\"返回\"]'); if (b) b.click(); return 'OK' })()")
await sleep(600)
await shot('126-android-category-pin')
S('shot pin')

// 127 搜索历史
await goTab('搜索')
await ev("(() => { const i = document.querySelector('[data-testid=\"search-input\"]'); if (!i) return 'NO'; const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set; setter.call(i, '收纳箱'); i.dispatchEvent(new Event('input', { bubbles: true })); i.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 13, bubbles: true })); return 'OK' })()")
await sleep(400)
await ev("(() => { const i = document.querySelector('[data-testid=\"search-input\"]'); const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set; setter.call(i, ''); i.dispatchEvent(new Event('input', { bubbles: true })); i.focus(); return 'OK' })()")
await sleep(400)
await ev("(() => { const i = document.querySelector('[data-testid=\"search-input\"]'); if (i) i.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 13, bubbles: true })); return 'OK' })()")
await sleep(300)
await shot('127-android-search-history')
S('shot search history')

// 128 模板图标自动选中
await goTab('首页')
await ev("(() => { const b = [...document.querySelectorAll('button')].find(e => (e.innerText||'').includes('新建分类')); if (b) b.click(); return 'OK' })()")
await waitFor(async () => (await sheetText()).includes('图标'))
await clickText('药品', '.sheet-panel')
await sleep(400)
await shot('128-android-template-icon')
await closeSheet()
await sleep(300)
console.log('SHOTS DONE')
process.exit(0)
