// 1.1.5 桌面端 E2E：排序按钮升/降循环、存放时间字段、+ 仅食品/药品有到期时间、提醒卡循环文案
import fs from 'node:fs'
import { listTargets, connect, waitFor } from './cdp.mjs'

const results = []
function check(name, ok, detail) {
  results.push({ name: name, ok: !!ok, detail: detail === undefined ? '' : String(detail) })
  console.log((ok ? 'PASS' : 'FAIL') + ' | ' + name + (detail === undefined || detail === '' ? '' : ' | ' + detail))
}
function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms) }) }

async function waitPort(port, ms, filter) {
  const end = Date.now() + ms
  while (Date.now() < end) {
    try {
      const t = await listTargets(port)
      if (t && t.length) {
        if (!filter) return t
        const found = t.filter(function (x) { return x.url.indexOf(filter) >= 0 })
        if (found.length) return found
      }
    } catch (e) {}
    await sleep(250)
  }
  return null
}

const targets = await waitPort(9222, 25000, 'index.html')
if (!targets) { console.log('NO_CDP'); process.exit(2) }
const client = await connect(9222, 'index.html')
const ev = function (expr) { return client.evaluate(expr) }
fs.mkdirSync('.tmp-shots', { recursive: true })
const shot = function (name) { return Promise.race([client.shot('.tmp-shots/' + name + '.png').catch(function () { return null }), sleep(9000)]) }

const INSTALL = [
  'window.__t = {',
  '  all: function (id) { return Array.prototype.filter.call(document.querySelectorAll("[data-testid]"), function (e) { return e.getAttribute("data-testid") === id }) },',
  '  q: function (id, i) { return window.__t.all(id)[i || 0] || null },',
  '  count: function (id) { return window.__t.all(id).length },',
  '  texts: function (id) { return window.__t.all(id).map(function (e) { return e.innerText }) },',
  '  has: function (id) { return !!window.__t.q(id) },',
  '  text: function (id, i) { var e = window.__t.q(id, i); return e ? e.innerText : "" },',
  '  click: function (id, i) { var el = window.__t.q(id, i); if (!el) throw new Error("missing " + id); el.click(); return true },',
  '  clickText: function (id, needle) { var list = window.__t.all(id); for (var k = 0; k < list.length; k++) { if (list[k].innerText.indexOf(needle) >= 0) { list[k].click(); return true } } throw new Error("no " + id + " with " + needle) },',
  '  fill: function (id, value, i) {',
  '    var el = window.__t.q(id, i); if (!el) throw new Error("missing " + id)',
  '    var proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype',
  '      : el instanceof HTMLSelectElement ? HTMLSelectElement.prototype',
  '      : HTMLInputElement.prototype',
  '    Object.getOwnPropertyDescriptor(proto, "value").set.call(el, value)',
  '    el.dispatchEvent(new Event("input", { bubbles: true }))',
  '    el.dispatchEvent(new Event("change", { bubbles: true }))',
  '    return true',
  '  },',
  '  dir: function (id) { var el = window.__t.q(id); return el ? el.getAttribute("data-direction") : "" },',
  '  active: function (id) { var el = window.__t.q(id); return !!el && String(el.className).split(" ").indexOf("active") >= 0 },',
  '  rowNames: function () { return Array.prototype.map.call(document.querySelectorAll("[data-testid=item-row] .item-name"), function (e) { return e.innerText.trim() }) },',
  '  state: function () { return window.guina.getState() },',
  '  body: function () { return document.body.innerText }',
  '}',
  'true'
].join(String.fromCharCode(10))

await waitFor(client, '!!document.body', 20000, 'body')
await client.evaluate(INSTALL)
await sleep(800)

if (await ev("__t.has('onboarding')")) {
  await ev("__t.click('onboarding-skip')")
  await waitFor(client, "!__t.has('onboarding')", 8000, 'onboarding closes')
}
await sleep(500)

async function backHome() {
  await ev("(function(){ var bs = Array.prototype.slice.call(document.querySelectorAll('button')); for (var i = 0; i < bs.length; i++) { if (bs[i].innerText.indexOf('返回') >= 0) { bs[i].click(); return true } } return false })()")
  await waitFor(client, "!!document.querySelector('[data-testid=add-category]')", 8000, 'home')
}
async function openCategory(name) {
  await ev("window.__t.clickText('category-card', '" + name + "')")
  await waitFor(client, "!!document.querySelector('[data-testid=category-title]')", 8000, 'category ' + name)
}
async function addItem(opts) {
  await ev("__t.click('add-item')")
  await waitFor(client, "!!document.querySelector('[data-testid=form-name]')", 8000, 'item form')
  await ev("__t.fill('form-name', " + JSON.stringify(opts.name) + ")")
  await ev("__t.click('form-location-place')")
  await ev("__t.fill('form-location-name', " + JSON.stringify(opts.location) + ")")
  if (opts.fields) {
    for (const key of Object.keys(opts.fields)) {
      const value = opts.fields[key]
      if (value === true) await ev("__t.click('form-field-" + key + "')")
      else if (value === false) await ev("__t.click('form-field-" + key + "-no')")
      else await ev("__t.fill('form-field-" + key + "', " + JSON.stringify(value) + ")")
    }
  }
  await ev("__t.click('form-submit')")
}

const today = new Date()
function plusDays(n) {
  const d = new Date(today.getTime() + n * 86400000)
  return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0')
}

// ---------- 食品：三种排序 + 升降循环 ----------
await openCategory('食品')
await waitFor(client, "!!document.querySelector('[data-testid=sort-group]')", 8000, 'sort group')
const opts = await ev("JSON.stringify(Array.prototype.map.call(document.querySelectorAll('[data-testid=sort-group] button'), function (b) { return { id: b.getAttribute('data-testid'), text: b.innerText.replace(/[ \\u2191\\u2193]/g, '') } }))")
const optList = JSON.parse(opts)
check('1 食品提供三种排序', optList.length === 3 && optList.map(function (o) { return o.id }).join(',') === 'sort-name,sort-storedAt,sort-expiresAt', opts)
check('2 默认按名称升序', (await ev("__t.dir('sort-name')")) === 'asc' && (await ev("__t.active('sort-name')")), await ev("__t.dir('sort-name')"))

await addItem({ name: '苹果', location: '冰箱', fields: { storedAt: '2025-01-10', expiresAt: plusDays(12) } })
await waitFor(client, "__t.rowNames().indexOf('苹果') >= 0", 8000, 'apple')
await addItem({ name: '香蕉', location: '冰箱', fields: { storedAt: '2025-03-05', expiresAt: plusDays(5) } })
await waitFor(client, "__t.rowNames().indexOf('香蕉') >= 0", 8000, 'banana')
await addItem({ name: '橙子', location: '果篮', fields: { storedAt: '2025-02-01', expiresAt: plusDays(2) } })
await waitFor(client, "__t.rowNames().indexOf('橙子') >= 0", 8000, 'orange')
check('3 食品新增三条并显示存放时间', (await ev("__t.texts('item-row').join('|')")).indexOf('存放 2025-01-10') >= 0, await ev("__t.texts('item-row').join(' / ')"))
check('4 食品行显示到期天数', (await ev("__t.texts('item-row').join('|')")).indexOf('还剩') >= 0)
await shot('115-01-food-sort')

const nameAsc = await ev("__t.rowNames()")
check('5 名称升序：橙子 < 苹果 < 香蕉', nameAsc[0] === '橙子' && nameAsc[1] === '苹果' && nameAsc[2] === '香蕉', JSON.stringify(nameAsc))
await ev("__t.click('sort-name')")
await sleep(450)
const nameDesc = await ev("__t.rowNames()")
check('6 再点名称变降序', (await ev("__t.dir('sort-name')")) === 'desc' && JSON.stringify(nameDesc) === JSON.stringify(nameAsc.slice().reverse()), (await ev("__t.dir('sort-name')")) + ' ' + JSON.stringify(nameDesc))

await ev("__t.click('sort-storedAt')")
await sleep(450)
const storedAsc = await ev("__t.rowNames()")
check('7 按存放时间第一次升序', (await ev("__t.dir('sort-storedAt')")) === 'asc' && storedAsc[0] === '苹果' && storedAsc[1] === '橙子' && storedAsc[2] === '香蕉', (await ev("__t.dir('sort-storedAt')")) + ' ' + JSON.stringify(storedAsc))
await ev("__t.click('sort-storedAt')")
await sleep(450)
const storedDesc = await ev("__t.rowNames()")
check('8 再点存放时间变降序', (await ev("__t.dir('sort-storedAt')")) === 'desc' && JSON.stringify(storedDesc) === JSON.stringify(storedAsc.slice().reverse()), (await ev("__t.dir('sort-storedAt')")) + ' ' + JSON.stringify(storedDesc))

await ev("__t.click('sort-expiresAt')")
await sleep(450)
const expAsc = await ev("__t.rowNames()")
check('9 按过期时间第一次升序（最早到期在前）', (await ev("__t.dir('sort-expiresAt')")) === 'asc' && expAsc[0] === '橙子' && expAsc[1] === '香蕉' && expAsc[2] === '苹果', (await ev("__t.dir('sort-expiresAt')")) + ' ' + JSON.stringify(expAsc))
await ev("__t.click('sort-expiresAt')")
await sleep(450)
const expDesc = await ev("__t.rowNames()")
check('10 再点过期时间变降序', (await ev("__t.dir('sort-expiresAt')")) === 'desc' && JSON.stringify(expDesc) === JSON.stringify(expAsc.slice().reverse()), (await ev("__t.dir('sort-expiresAt')")) + ' ' + JSON.stringify(expDesc))
await shot('115-02-food-sorted')

// 食品表单同时有存放时间与过期时间
await ev("__t.click('add-item')")
await waitFor(client, "!!document.querySelector('[data-testid=form-name]')", 8000, 'food form')
check('11 食品表单有存放时间和过期时间', (await ev("__t.has('form-field-storedAt')")) && (await ev("__t.has('form-field-expiresAt')")))
await ev("__t.click('modal-cancel')")
await sleep(300)
await backHome()

// ---------- 图书：只有名称/存放时间两种排序，无到期字段 ----------
await openCategory('图书')
await waitFor(client, "!!document.querySelector('[data-testid=sort-group]')", 8000, 'book sort group')
const bookOpts = await ev("JSON.stringify(Array.prototype.map.call(document.querySelectorAll('[data-testid=sort-group] button'), function (b) { return b.getAttribute('data-testid') }))")
check('12 图书只有名称和存放时间排序', JSON.parse(bookOpts).join(',') === 'sort-name,sort-storedAt', bookOpts)
await addItem({ name: '三体', location: '书架', fields: { storedAt: '2025-03-08' } })
await waitFor(client, "__t.rowNames().indexOf('三体') >= 0", 8000, 'book row')
check('13 图书行显示存放时间', (await ev("__t.texts('item-row').join('|')")).indexOf('存放 2025-03-08') >= 0)
await ev("__t.click('add-item')")
await waitFor(client, "!!document.querySelector('[data-testid=form-name]')", 8000, 'book form')
check('14 图书表单有存放时间、无过期时间', (await ev("__t.has('form-field-storedAt')")) && !(await ev("__t.has('form-field-expiresAt')")))
await ev("__t.click('modal-cancel')")
await sleep(300)
await backHome()

// ---------- 物品（自定义分类模板）：有存放时间、无过期时间 ----------
await openCategory('物品')
await addItem({ name: '香水', location: '卧室抽屉', fields: { storedAt: '2025-04-01' } })
await waitFor(client, "__t.rowNames().indexOf('香水') >= 0", 8000, 'item row')
check('15 物品行显示存放时间', (await ev("__t.texts('item-row').join('|')")).indexOf('存放 2025-04-01') >= 0)
await ev("__t.click('add-item')")
await waitFor(client, "!!document.querySelector('[data-testid=form-name]')", 8000, 'item form')
check('16 物品表单有存放时间、无过期时间', (await ev("__t.has('form-field-storedAt')")) && !(await ev("__t.has('form-field-expiresAt')")))
await ev("__t.click('modal-cancel')")
await sleep(300)
await backHome()

// ---------- 提醒便签：循环显示「工作日 09:00」，一次性不显示 ISO ----------
await ev("__t.click('sticky-add-reminder')")
await waitFor(client, "!!document.querySelector('[data-testid=sticky-kind-reminder]')", 8000, 'sticky form')
await ev("__t.fill('sticky-title', '工作日喝水')")
await ev("__t.fill('sticky-content', '每个工作日早上喝一杯水')")
await ev("__t.click('sticky-kind-reminder')")
await sleep(300)
await ev("__t.fill('sticky-repeat-kind', 'weekdays')")
await sleep(200)
await ev("__t.fill('sticky-repeat-time', '09:00')")
await ev("__t.click('modal-confirm')")
await waitFor(client, "!!document.querySelector('[data-testid=sticky-repeat]')", 8000, 'repeat card')
const repeatText = await ev("__t.text('sticky-repeat')")
check('17 循环提醒显示工作日与时间', repeatText.indexOf('工作日') >= 0 && repeatText.indexOf('09:00') >= 0, repeatText)
check('18 循环提醒卡片不显示 ISO 时间串', repeatText.indexOf('T09:00:00') < 0 && repeatText.indexOf('.000Z') < 0, repeatText)
await shot('115-03-repeat-reminder')

await ev("__t.click('sticky-add-reminder')")
await waitFor(client, "!!document.querySelector('[data-testid=sticky-kind-reminder]')", 8000, 'sticky form 2')
await ev("__t.fill('sticky-title', '一次性提醒')")
await ev("__t.fill('sticky-content', '十分钟后看一眼锅')")
await ev("__t.click('sticky-kind-reminder')")
await sleep(250)
await ev("__t.click('quick-10m')")
await ev("__t.click('modal-confirm')")
await waitFor(client, "__t.texts('sticky-card').join('|').indexOf('一次性提醒') >= 0", 8000, 'once card')
const cardsText = await ev("__t.texts('sticky-card').join(' || ')")
check('19 一次性提醒卡片不显示 ISO 时间串', cardsText.indexOf('T') < 0 || !/[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}\.[0-9]{3}Z/.test(cardsText), cardsText.slice(0, 200))
await shot('115-04-once-reminder')

await sleep(300)
console.log('===== RESULT ' + results.filter(function (r) { return r.ok }).length + '/' + results.length + ' =====')
process.exit(0)
