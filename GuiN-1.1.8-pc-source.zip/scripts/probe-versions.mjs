import fs from 'node:fs';
const reg = await (await fetch('https://registry.npmmirror.com/electron')).json();
const tags = reg['dist-tags'] || {};
console.log('DIST_TAGS', JSON.stringify(tags).slice(0, 600));
const versions = Object.keys(reg.versions || {});
console.log('LATEST_VERSIONS', versions.slice(-12).join(','));
