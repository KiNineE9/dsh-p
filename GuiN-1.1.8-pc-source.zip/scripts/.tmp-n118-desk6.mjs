import { spawn, execSync } from 'node:child_process'
import fs from 'node:fs'
import path from 'node:path'
import { connect, listTargets } from './cdp.mjs'
const ROOT = 'F:/DSH/GC/GuiNa'
const PROFILE = path.join(ROOT, '.tmp-n118c-profile')
const PORT = 9222
const ELECTRON = path.join(ROOT, 'node_modules/electron/dist/electron.exe')
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))
function killElectron() { try { execSync('taskkill /F /IM electron.exe /T', { stdio: 'ignore' }) } catch {} }
async function launch() {
  const env = { ...process.env }; delete env.ELECTRON_RUN_AS_NODE
  spawn(ELECTRON, [ROOT, '--remote-debugging-port=' + PORT, '--no-sandbox', '--user-data-dir=' + PROFILE], { env, stdio: 'ignore' })
  for (let i = 0; i < 120; i++) {
    try { const list = await (await fetch('http://127.0.0.1:' + PORT + '/json/list')).json(); if (list.find((t) => String(t.url).includes('index.html'))) break } catch {}
    await sleep(250)
  }
  await sleep(3000)
}
const disk = () => { try { const j = JSON.parse(fs.readFileSync(path.join(PROFILE, 'data.json'), 'utf8')); return (j.stickies || []).map((s) => ({ id: s.id, notified: s.notified, at: s.remindAt, status: s.status, repeat: s.repeat && s.repeat.kind })) } catch (e) { return 'ERR ' + e.message } }
fs.rmSync(PROFILE, { recursive: true, force: true }); fs.mkdirSync(PROFILE, { recursive: true })
const now = new Date()
const mk = (id, kind, at, repeat) => ({ id, title: '提醒-' + id, content: '内容-' + id, kind: 'reminder', pinned: false, remindAt: at, repeat: repeat || null, status: 'pending', createdAt: now.toISOString(), updatedAt: now.toISOString(), notified: false })
const state = { version: 4, categories: [], items: [], notes: [], stickies: [mk('st-once', 'once', new Date(now.getTime() - 60000).toISOString(), null), mk('st-rep', 'rep', new Date(now.getTime() - 120000).toISOString(), { kind: 'daily', time: '07:00' })], notifications: [], tombstones: [], settings: { theme: 'system', autoLaunch: false, closeToTray: true, reminderPopup: true, reminderSound: false, stickySearchHistory: true, itemSearchHistory: true, expiryTiers: { 30: true, 15: true, 7: true, 1: true } }, savedNames: { place: [], container: [] }, searchHistory: { item: [], sticky: [] }, onboardingDone: true, createdAt: now.toISOString() }
fs.writeFileSync(path.join(PROFILE, 'data.json'), JSON.stringify(state))
killElectron(); await sleep(500)
async function round(n) {
  await launch()
  const targets = await listTargets(PORT)
  console.log('R' + n + '_TARGETS ' + JSON.stringify(targets.map((t) => t.url)))
  const rem = targets.find((t) => t.url.indexOf('reminder.html') >= 0)
  if (rem) {
    const p = await connect(PORT, 'reminder.html')
    console.log('R' + n + '_TEXT ' + await p.evaluate('document.body.innerText.split(String.fromCharCode(10)).join(" | ").slice(0,200)'))
    console.log('R' + n + '_BUTTONS ' + await p.evaluate('(function(){return JSON.stringify([].slice.call(document.querySelectorAll("button")).map(function(b){return b.textContent.trim()}))})()'))
    if (n === 1) {
      await p.evaluate('(function(){var b=[].slice.call(document.querySelectorAll("button")).find(function(x){return /知道了|好的|我看到了/.test(x.textContent)});if(b)b.click();return 1})()')
      await sleep(1200)
    }
    await p.close()
  }
  console.log('R' + n + '_DISK ' + JSON.stringify(disk()))
  try { execSync('taskkill /F /IM electron.exe /T', { stdio: 'ignore' }) } catch {}
  await sleep(1500)
}
await round(1)
await round(2)
killElectron()