import { connect } from './cdp.mjs'
import fs from 'node:fs'
const port = Number(process.env.CDP_PORT || 9333)
const c = await connect(port, 'app.local')
await c.send('Page.enable')
const sleep = (ms) => new Promise(r => setTimeout(r, ms))
async function ev(expr) { const r = await c.evaluate(expr); return r && r.value !== undefined ? r.value : r }
async function shot(name) {
  const s = await c.send('Page.captureScreenshot', { format: 'png' })
  fs.writeFileSync('.tmp-shots/' + name + '.png', Buffer.from(s.data, 'base64'))
  console.log('shot ' + name)
}
async function tap(text, sel) {
  const r = await ev(`(() => { const list = [...document.querySelectorAll(${JSON.stringify(sel || 'button,[role=button]')})]; const el = list.find(e => (e.innerText||'').trim().includes(${JSON.stringify(text)})); if (!el) return 'NOTFOUND:' + list.map(e=>(e.innerText||'').trim().slice(0,20)).join('|'); el.click(); return 'OK'; })()`)
  return r
}
console.log('skip:', await tap('跳过'))
await sleep(600)
console.log(await ev('document.body.innerText.slice(0,1500)'))
await shot('phone-02-home')
c.close()
