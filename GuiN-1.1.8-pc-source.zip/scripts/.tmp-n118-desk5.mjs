import { spawn, execSync } from 'node:child_process'
import fs from 'node:fs'
import path from 'node:path'
import { connect } from './cdp.mjs'
const ROOT = 'F:/DSH/GC/GuiNa'
const PROFILE = path.join(ROOT, '.tmp-n118b-profile')
const PORT = 9222
const ELECTRON = path.join(ROOT, 'node_modules/electron/dist/electron.exe')
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))
function killElectron() { try { execSync('taskkill /F /IM electron.exe /T', { stdio: 'ignore' }) } catch {} }
async function launch() {
  const env = { ...process.env }; delete env.ELECTRON_RUN_AS_NODE
  spawn(ELECTRON, [ROOT, '--remote-debugging-port=' + PORT, '--no-sandbox', '--user-data-dir=' + PROFILE], { env, stdio: 'ignore' })
  for (let i = 0; i < 120; i++) {
    try { const list = await (await fetch('http://127.0.0.1:' + PORT + '/json/list')).json(); if (list.find((t) => String(t.url).includes('index.html'))) break } catch {}
    await sleep(250)
  }
  await sleep(2600)
}
const readDisk = () => {
  try { const j = JSON.parse(fs.readFileSync(path.join(PROFILE, 'data.json'), 'utf8')); return { notifs: (j.notifications || []).map((n) => ({ id: n.id, read: n.read, del: n.deleted })) } } catch (e) { return 'ERR ' + e.message }
}
function clickAt(p, x, y) {
  return (async () => { await p.send('Input.dispatchMouseEvent', { type: 'mousePressed', x, y, button: 'left', clickCount: 1 }); await p.send('Input.dispatchMouseEvent', { type: 'mouseReleased', x, y, button: 'left', clickCount: 1 }) })()
}
killElectron(); await sleep(500)
await launch()
let p = await connect(PORT)
const ev = (e) => p.evaluate(e)
console.log('L1_BADGE ' + await ev('(function(){var b=document.querySelector("[data-testid=bell-badge]");return b?b.textContent:"none"})()'))
await ev('(function(){document.querySelector("[data-testid=bell]").click();return 1})()')
await sleep(700)
const rectS = await ev('(function(){var b=document.querySelector("[data-testid=notif-read-all]");if(!b)return "none";var r=b.getBoundingClientRect();return JSON.stringify({x:r.x+r.width/2,y:r.y+r.height/2})})()')
console.log('READALL_RECT ' + rectS)
const r = JSON.parse(rectS); await clickAt(p, r.x, r.y); await sleep(700)
console.log('MODAL ' + await ev('(function(){var m=document.querySelector("[data-testid=modal]");return m?m.innerText.replace(/\\n/g," | ").slice(0,100):"none"})()'))
const okS = await ev('(function(){var b=document.querySelector("[data-testid=modal-confirm]");if(!b)return "none";var r=b.getBoundingClientRect();return JSON.stringify({x:r.x+r.width/2,y:r.y+r.height/2})})()')
console.log('CONFIRM_RECT ' + okS)
const r2 = JSON.parse(okS); await clickAt(p, r2.x, r2.y); await sleep(1500)
console.log('AFTER_BADGE ' + await ev('(function(){var b=document.querySelector("[data-testid=bell-badge]");return b?b.textContent:"none"})()'))
console.log('AFTER_DISK ' + JSON.stringify(readDisk()))
await p.close(); killElectron(); await sleep(1200)
await launch()
p = await connect(PORT)
const ev2 = (e) => p.evaluate(e)
console.log('L2_BADGE ' + await ev2('(function(){var b=document.querySelector("[data-testid=bell-badge]");return b?b.textContent:"none"})()'))
console.log('L2_DISK ' + JSON.stringify(readDisk()))
await p.close(); killElectron()
