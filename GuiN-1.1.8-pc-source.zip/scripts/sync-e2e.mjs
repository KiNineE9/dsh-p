import { listTargets, connect, waitFor } from './cdp.mjs'

const results = []
function check(name, ok, detail) {
  results.push({ name: name, ok: !!ok, detail: detail === undefined ? '' : String(detail) })
  console.log((ok ? 'PASS' : 'FAIL') + ' | ' + name + (detail === undefined || detail === '' ? '' : ' | ' + detail))
}
function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms) }) }

async function waitPort(port, ms, filter) {
  const end = Date.now() + ms
  while (Date.now() < end) {
    try {
      const t = await listTargets(port)
      if (t && t.length) {
        if (!filter) return t
        const found = t.filter(function (x) { return x.url.indexOf(filter) >= 0 })
        if (found.length) return found
      }
    } catch (e) {}
    await sleep(250)
  }
  return null
}

const INSTALL = [
  'window.__t = {',
  '  all: function (id) { return Array.prototype.filter.call(document.querySelectorAll("[data-testid]"), function (e) { return e.getAttribute("data-testid") === id }) },',
  '  q: function (id) { return window.__t.all(id)[0] || null },',
  '  has: function (id) { return !!window.__t.q(id) },',
  '  text: function (id) { var e = window.__t.q(id); return e ? e.innerText : "" },',
  '  value: function (id) { var e = window.__t.q(id); return e ? e.value : "" },',
  '  click: function (id) { var el = window.__t.q(id); if (!el) throw new Error("missing " + id); el.click(); return true },',
  '  set: function (id, v) {',
  '    var el = window.__t.q(id)',
  '    if (!el) throw new Error("missing " + id)',
  '    var proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : el instanceof HTMLSelectElement ? HTMLSelectElement.prototype : HTMLInputElement.prototype',
  '    Object.getOwnPropertyDescriptor(proto, "value").set.call(el, v)',
  '    el.dispatchEvent(new Event("input", { bubbles: true }))',
  '    el.dispatchEvent(new Event("change", { bubbles: true }))',
  '    return true',
  '  },',
  '  state: function () { return window.guina.getState() },',
  '  config: function () { return window.guina.getSyncConfig() },',
  '}',
  'true'
].join(String.fromCharCode(10))

async function open(port) {
  const targets = await waitPort(port, 30000, 'index.html')
  if (!targets) throw new Error('no cdp on ' + port)
  const client = await connect(port, 'index.html')
  await waitFor(client, '!!document.body', 20000, 'body')
  await client.evaluate(INSTALL)
  await sleep(1000)
  if (await client.evaluate("__t.has('onboarding-skip')")) {
    await client.evaluate("__t.click('onboarding-skip')")
    await sleep(800)
  }
  return client
}

async function until(client, expr, ms, label) {
  const end = Date.now() + ms
  while (Date.now() < end) {
    try {
      const v = await client.evaluate(expr)
      if (v) return true
    } catch (e) {}
    await sleep(300)
  }
  console.log('TIMEOUT ' + (label || expr))
  return false
}

async function acceptIncoming(client, label) {
  await until(client, "__t.has('modal-confirm') && __t.text('modal-confirm') === '接受同步'", 30000, label)
  await client.evaluate("__t.click('modal-confirm')")
  await sleep(400)
}

async function shot(client, name) {
  try {
    await Promise.race([client.shot('.tmp-shots/' + name + '.png'), sleep(8000)])
  } catch (e) {}
}

const A = await open(9222)
const B = await open(9223)

// 1. 造数据：A 加物品与便签
await A.evaluate("window.guina.createItem('cat-item', { name: '同步测试物品', locationType: 'place', locationLabel: '客厅', locationName: '电视柜', fields: {} })")
await A.evaluate("window.guina.createSticky({ kind: 'note', content: 'A 便签', pinned: false })")
await B.evaluate("window.guina.createItem('cat-item', { name: 'B 侧物品', locationType: 'place', locationLabel: '书房', locationName: '', fields: {} })")
await sleep(800)
check('A 已造物品与便签', (await A.evaluate("__t.state().then(s => s.items.some(i => i.name === '同步测试物品') && s.stickies.some(n => n.content === 'A 便签'))")) === true)

// 2. 两台进入设置页
for (const c of [A, B]) {
  if (!(await c.evaluate("__t.has('sync-card')"))) {
    await c.evaluate("__t.click('settings-btn')")
    await sleep(900)
  }
}
check('A 设置页有数据同步卡片', await A.evaluate("__t.has('sync-card')"), '')
check('B 设置页有数据同步卡片', await B.evaluate("__t.has('sync-card')"), '')
await A.evaluate("__t.set('sync-device-name', '电脑甲')")
await A.evaluate("__t.click('sync-save-name')")
await B.evaluate("__t.set('sync-device-name', '电脑乙')")
await B.evaluate("__t.click('sync-save-name')")
await sleep(500)
check('设备名保存生效', (await A.evaluate("__t.config().then(c => c.identity.name)")) === '电脑甲')

// 3. A 生成绑定码
await A.evaluate("__t.click('sync-bind-new')")
const gotCode = await until(A, "(__t.text('sync-pair-code') || '').length === 6", 20000, 'A pair code')
const code = await A.evaluate("__t.text('sync-pair-code')")
const invite = await A.evaluate("__t.value('sync-invite-text')")
check('A 生成六位数字', gotCode && /^\d{6}$/.test(code), code)
check('A 生成邀请文本与二维码', invite.length > 20 && (await A.evaluate("__t.has('sync-qr') && __t.q('sync-qr').src.indexOf('data:image/png') === 0")))
await shot(A, 'sync-01-pairing')

// 4. B 输入邀请 + 六位数字
await B.evaluate("__t.click('sync-join-open')")
await sleep(300)
await B.evaluate("__t.set('sync-join-text', " + JSON.stringify(invite) + ")")
await B.evaluate("__t.set('sync-join-code', " + JSON.stringify(code) + ")")
await B.evaluate("__t.click('sync-join-confirm')")
const bBound = await until(B, "__t.has('sync-binding')", 45000, 'B binding')
const aBound = await until(A, "__t.has('sync-binding')", 30000, 'A binding')
check('B 绑定成功并出现设备', bBound, '')
check('A 绑定成功并出现设备', aBound, '')
check('A 显示电脑乙', (await A.evaluate("__t.text('sync-binding-name')")) === '电脑乙')
check('B 显示电脑甲', (await B.evaluate("__t.text('sync-binding-name')")) === '电脑甲')
await shot(A, 'sync-02-bound')

// 5. A 合并同步（应把 B 侧物品带过来）
await A.evaluate("__t.click('sync-merge')")
await until(A, "__t.has('sync-confirm')", 3000, 'A merge confirm')
await A.evaluate("__t.click('sync-confirm-run')")
await acceptIncoming(B, 'B accept merge')
const merged = await until(A, "__t.state().then(s => s.items.some(i => i.name === 'B 侧物品'))", 60000, 'A merged B item')
check('合并后 A 有对方物品', merged, '')
const both = await until(B, "__t.state().then(s => s.items.some(i => i.name === '同步测试物品'))", 20000, 'B got A item after merge')
check('合并后 B 有对方物品', both, '')
check('合并后 A 保留自己的便签', (await A.evaluate("__t.state().then(s => s.stickies.some(n => n.content === 'A 便签'))")) === true)
await shot(A, 'sync-03-merged')

// 6. A 再发一份给 B（push）
await A.evaluate("window.guina.createItem('cat-item', { name: '推送物品', locationType: 'place', locationLabel: '厨房', locationName: '', fields: {} })")
await sleep(600)
await A.evaluate("window.guina.getSyncConfig().then(function () { return true })")
await A.evaluate("__t.click('sync-push')")
await until(A, "__t.has('sync-confirm')", 3000, 'A push confirm')
await A.evaluate("__t.click('sync-confirm-run')")
await acceptIncoming(B, 'B accept push')
const pushed = await until(B, "__t.state().then(s => s.items.some(i => i.name === '推送物品'))", 60000, 'B got pushed item')
check('发给它：B 收到新物品', pushed, '')
check('发完后 A 记录上次同步时间', (await A.evaluate("__t.config().then(c => !!c.bindings[0].lastSyncAt)")) === true)

// 7. 解绑
await A.evaluate("__t.click('sync-unbind')")
await until(A, "__t.has('sync-unbind-confirm')", 3000, 'unbind confirm')
await A.evaluate("__t.click('sync-unbind-run')")
const unbound = await until(A, "!__t.has('sync-binding')", 8000, 'A unbound')
check('解绑后绑定列表清空', unbound, '')
await shot(A, 'sync-04-unbound')

const pass = results.filter(function (r) { return r.ok }).length
const fail = results.length - pass
console.log('\n===== SYNC RESULT ' + pass + '/' + results.length + ' =====')
results.filter(function (r) { return !r.ok }).forEach(function (r) { console.log(' - FAIL ' + r.name + ' ' + r.detail) })
A.close()
B.close()
process.exit(fail === 0 ? 0 : 1)
