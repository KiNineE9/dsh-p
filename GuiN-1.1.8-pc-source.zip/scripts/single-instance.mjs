import { listTargets, connect } from './cdp.mjs'
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))
const ud = process.env.GUINA_UD || '.tmp-ud-single'
let targets = null
for (let i = 0; i < 100; i++) {
  try { targets = (await listTargets(9222)).filter((t) => t.url.indexOf('index.html') >= 0) } catch (e) { targets = null }
  if (targets && targets.length) break
  await sleep(250)
}
if (!targets || !targets.length) { console.log('NO_CDP'); process.exit(2) }
const cp = await import('node:child_process')
const second = cp.spawn('node_modules/electron/dist/electron.exe', ['.', '--no-sandbox', '--disable-gpu', '--user-data-dir=F:/DSH/GC/GuiNa/' + ud], { stdio: 'ignore' })
const secondExit = await new Promise(function (resolve) {
  const timer = setTimeout(function () { try { second.kill() } catch (e) {} resolve('timeout') }, 15000)
  second.on('exit', function (code) { clearTimeout(timer); resolve(String(code)) })
})
await sleep(1000)
const pages = (await listTargets(9222)).filter((t) => t.type === 'page').length
const client = await connect(9222, 'index.html')
const visible = await client.evaluate("!!document.querySelector('[data-testid=search-input]')")
console.log(JSON.stringify({ secondExit: secondExit, pages: pages, windowVisible: visible }))