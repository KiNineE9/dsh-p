import { listTargets, connect, waitFor } from './cdp.mjs'

const results = []
function check(name, ok, detail) {
  results.push({ name: name, ok: !!ok, detail: detail === undefined ? '' : String(detail) })
  console.log((ok ? 'PASS' : 'FAIL') + ' | ' + name + (detail === undefined || detail === '' ? '' : ' | ' + detail))
}
function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms) }) }

async function waitPort(port, ms, filter) {
  const end = Date.now() + ms
  while (Date.now() < end) {
    try {
      const t = await listTargets(port)
      if (t && t.length) {
        if (!filter) return t
        const found = t.filter(function (x) { return x.url.indexOf(filter) >= 0 })
        if (found.length) return found
      }
    } catch (e) {}
    await sleep(250)
  }
  return null
}

const targets = await waitPort(9222, 25000, 'index.html')
if (!targets) { console.log('NO_CDP'); process.exit(2) }
const client = await connect(9222, 'index.html')
const ev = function (expr) { return client.evaluate(expr) }
const shot = function (name) { return Promise.race([client.shot('.tmp-shots/' + name + '.png').catch(function () { return null }), sleep(9000)]) }

const INSTALL = [
  'window.__t = {',
  '  all: function (id) { return Array.prototype.filter.call(document.querySelectorAll("[data-testid]"), function (e) { return e.getAttribute("data-testid") === id }) },',
  '  q: function (id, i) { return window.__t.all(id)[i || 0] || null },',
  '  count: function (id) { return window.__t.all(id).length },',
  '  texts: function (id) { return window.__t.all(id).map(function (e) { return e.innerText }) },',
  '  has: function (id) { return !!window.__t.q(id) },',
  '  text: function (id, i) { var e = window.__t.q(id, i); return e ? e.innerText : "" },',
  '  click: function (id, i) { var el = window.__t.q(id, i); if (!el) throw new Error("missing " + id); el.click(); return true },',
  '  clickText: function (id, needle) { var list = window.__t.all(id); for (var k = 0; k < list.length; k++) { if (list[k].innerText.indexOf(needle) >= 0) { list[k].click(); return true } } throw new Error("no " + id + " with " + needle) },',
  '  set: function (id, v) {',
  '    var el = window.__t.q(id)',
  '    if (!el) throw new Error("missing " + id)',
  '    var proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : el instanceof HTMLSelectElement ? HTMLSelectElement.prototype : HTMLInputElement.prototype',
  '    Object.getOwnPropertyDescriptor(proto, "value").set.call(el, v)',
  '    el.dispatchEvent(new Event("input", { bubbles: true }))',
  '    el.dispatchEvent(new Event("change", { bubbles: true }))',
  '    return true',
  '  },',
  '  back: function () { var btns = Array.prototype.slice.call(document.querySelectorAll("button")); for (var k = 0; k < btns.length; k++) { if (btns[k].innerText.indexOf("返回") >= 0) { btns[k].click(); return true } } return false },',
  '  state: function () { return window.guina.getState() },',
  '}',
  'true'
].join(String.fromCharCode(10))

await waitFor(client, '!!document.body', 20000, 'body')
await client.evaluate(INSTALL)
await sleep(1200)
if (await ev("__t.has('onboarding-skip')")) {
  await ev("__t.click('onboarding-skip')")
  await sleep(600)
}

// ---- 1. 便利贴：便签 / 提醒便签 两栏 + 置顶 ----
const cols = await ev("__t.count('sticky-col-note') + '/' + __t.count('sticky-col-reminder')")
check('便签与提醒便签分成两栏', cols === '1/1', cols)
check('两栏各有独立新建按钮', (await ev("__t.count('sticky-add-note') === 1 && __t.count('sticky-add-reminder') === 1")), cols)
await shot('80-sticky-two-columns')

await ev("__t.click('sticky-add-note')")
await waitFor(client, "!!document.querySelector('[data-testid=sticky-content]')", 8000, 'note form')
check('新建便签默认选「便签」类型', await ev("!!__t.q('sticky-kind-note') && String(__t.q('sticky-kind-note').className).indexOf('on') >= 0"))
check('便签类型出现置顶选项', await ev("__t.has('sticky-pinned')"))
await ev("__t.set('sticky-content', '置顶便签')")
await ev("__t.click('sticky-pinned')")
await sleep(200)
await ev("__t.click('modal-confirm')")
await waitFor(client, "__t.count('sticky-card') === 1", 8000, 'pinned card')
const pinnedSt = await ev("__t.state().then(function (s) { var x = s.stickies[0] || {}; return { kind: x.kind, pinned: x.pinned, pinnedAt: !!x.pinnedAt, remindAt: x.remindAt } })")
check('置顶便签落库为 note + pinned', pinnedSt.kind === 'note' && pinnedSt.pinned === true && pinnedSt.pinnedAt === true, JSON.stringify(pinnedSt))
check('置顶便签卡片带置顶标记', await ev("String(__t.q('sticky-card').className).indexOf('pinned') >= 0"))

await ev("__t.click('sticky-add-note')")
await waitFor(client, "!!document.querySelector('[data-testid=sticky-content]')", 8000, 'note2 form')
await ev("__t.set('sticky-content', '普通便签')")
await ev("__t.click('modal-confirm')")
await waitFor(client, "__t.count('sticky-card') === 2", 8000, 'note2 card')
const noteSt = await ev("__t.state().then(function (s) { var x = s.stickies.filter(function (y) { return y.content === '普通便签' })[0] || {}; return { kind: x.kind, pinned: x.pinned } })")
check('普通便签默认不置顶', noteSt.kind === 'note' && noteSt.pinned === false, JSON.stringify(noteSt))
await shot('81-sticky-pinned')

await ev("__t.click('sticky-add-reminder')")
await waitFor(client, "!!document.querySelector('[data-testid=sticky-content]')", 8000, 'reminder form')
check('新建提醒便签默认选「提醒便签」类型', await ev("String(__t.q('sticky-kind-reminder').className).indexOf('on') >= 0"))
check('提醒便签有循环提醒与提醒时间', await ev("__t.has('sticky-repeat-kind') && (__t.has('sticky-remind') || __t.has('sticky-repeat-time'))"))
await ev("__t.set('sticky-content', '喝水提醒')")
await ev("__t.set('sticky-repeat-kind', 'daily')")
await sleep(300)
await ev("__t.set('sticky-repeat-time', '09:00')")
await ev("__t.click('modal-confirm')")
await sleep(900)
const remSt = await ev("__t.state().then(function (s) { var x = s.stickies.filter(function (y) { return y.content === '喝水提醒' })[0] || {}; return { kind: x.kind, repeat: x.repeat && x.repeat.kind } })")
check('提醒便签落库为 reminder + 每天循环', remSt.kind === 'reminder' && remSt.repeat === 'daily', JSON.stringify(remSt))

// ---- 2. 容器名称必填 + 详细位置选填 ----
await ev("window.__t.clickText('category-card', '物品')")
await waitFor(client, "!!document.querySelector('[data-testid=category-title]')", 8000, 'item category')
await ev("__t.click('add-item')")
await waitFor(client, "!!document.querySelector('[data-testid=form-name]')", 8000, 'item form')
await ev("__t.click('form-location-container')")
await sleep(200)
await ev("__t.set('form-name', '测试钥匙')")
await ev("__t.click('form-submit')")
await sleep(400)
const containerErr = await ev("__t.texts('form-error').join('|')")
check('选容器但不填名称时提示「请填写容器名称」', containerErr.indexOf('请填写容器名称') >= 0, containerErr)
check('详细位置输入框存在且非必填', await ev("__t.has('form-location-detail') && !__t.q('form-location-detail').required"))
await shot('82-container-required')
await ev("__t.set('form-location-name', '收纳盒')")
await ev("__t.set('form-location-detail', '上层')")
await ev("__t.click('form-submit')")
await waitFor(client, "__t.texts('item-row').join('|').indexOf('测试钥匙') >= 0", 10000, 'key row')
const keyState = await ev("__t.state().then(function (s) { var x = s.items.filter(function (i) { return i.name === '测试钥匙' })[0] || {}; return { label: x.locationLabel, detail: x.locationName, type: x.locationType } })")
check('容器名称与详细位置分别落库', keyState.type === 'container' && keyState.label === '收纳盒' && keyState.detail === '上层', JSON.stringify(keyState))
const keyRow = await ev("__t.texts('item-row').join(' || ')")
check('列表显示「收纳盒 · 上层」', keyRow.indexOf('收纳盒 · 上层') >= 0, keyRow.slice(0, 160))
await shot('83-container-detail')

// ---- 3. 保存过的名称：折叠箭头、一键填入、删除、去重置顶 ----
await ev("__t.click('add-item')")
await waitFor(client, "!!document.querySelector('[data-testid=form-name]')", 8000, 'item form 2')
await ev("__t.click('form-location-container')")
await sleep(250)
check('有历史容器名称时出现折叠箭头', await ev("__t.has('saved-toggle') && __t.q('saved-toggle').disabled !== true"))
await ev("__t.click('saved-toggle')")
await sleep(300)
const savedOpts = await ev("__t.texts('saved-name-option')")
check('保存过的容器名称出现在下拉里', savedOpts.length === 1 && savedOpts[0].indexOf('收纳盒') >= 0, savedOpts.join(' / '))
await shot('84-saved-names-list')
await ev("__t.click('saved-name-option')")
await sleep(250)
const filled = await ev("__t.q('form-location-name').value")
check('点保存过的名称可以一键填入', filled === '收纳盒', filled)
await ev("__t.click('saved-toggle')")
await sleep(300)
await ev("__t.click('saved-name-remove')")
await sleep(500)
const afterRemove = await ev("__t.state().then(function (s) { return s.savedNames.container.map(function (x) { return x.name }) })")
check('可以从列表里删除保存过的名称', afterRemove.length === 0, JSON.stringify(afterRemove))
await ev("__t.click('modal-cancel')")
await sleep(300)

// 再建两条同名容器条目，名称只保留一个并置顶
await ev("__t.click('add-item')")
await waitFor(client, "!!document.querySelector('[data-testid=form-name]')", 8000, 'item form 3')
await ev("__t.set('form-name', '收纳盒里的东西')")
await ev("__t.click('form-location-container')")
await sleep(200)
await ev("__t.set('form-location-name', '收纳盒')")
await ev("__t.click('form-submit')")
await sleep(800)
await ev("__t.click('add-item')")
await waitFor(client, "!!document.querySelector('[data-testid=form-name]')", 8000, 'item form 4')
await ev("__t.set('form-name', '另一个收纳盒东西')")
await ev("__t.click('form-location-container')")
await sleep(200)
await ev("__t.set('form-location-name', '抽屉柜')")
await ev("__t.click('form-submit')")
await sleep(700)
await ev("__t.click('add-item')")
await waitFor(client, "!!document.querySelector('[data-testid=form-name]')", 8000, 'item form 5')
await ev("__t.set('form-name', '再放回收纳盒')")
await ev("__t.click('form-location-container')")
await sleep(200)
await ev("__t.set('form-location-name', '收纳盒')")
await ev("__t.click('form-submit')")
await sleep(800)
const savedFinal = await ev("__t.state().then(function (s) { return s.savedNames.container.map(function (x) { return x.name }) })")
check('同名容器名称只保留一个且最新置顶', savedFinal.length === 2 && savedFinal[0] === '收纳盒' && savedFinal[1] === '抽屉柜', JSON.stringify(savedFinal))

// ---- 4. 手动备份：上限 5 份 / 覆盖 / 还原 / 删除 ----
const itemsBeforeBackup = await ev("__t.state().then(function (s) { return s.items.length })")
await ev("__t.click('settings-btn')")
await waitFor(client, "!!document.querySelector('[data-testid=backup-card]')", 8000, 'settings backup')
check('设置里出现手动备份卡片', await ev("__t.has('backup-create') && __t.has('backup-name-input')"))
await shot('85-backup-empty')
await ev("__t.set('backup-name-input', '备份1')")
await ev("__t.click('backup-create')")
await sleep(600)
check('手动备份成功并出现在列表', await ev("__t.count('backup-row') === 1"))
// 再建一条条目，让备份内容有差异
await ev("__t.back()")
await waitFor(client, "!!document.querySelector('[data-testid=category-card]')", 8000, 'home again')
await ev("window.__t.clickText('category-card', '物品')")
await waitFor(client, "!!document.querySelector('[data-testid=category-title]')", 8000, 'back to item category')
await ev("__t.click('add-item')")
await waitFor(client, "!!document.querySelector('[data-testid=form-name]')", 8000, 'item form backup')
await ev("__t.set('form-name', '备份之后加的')")
await ev("__t.set('form-location-name', '临时抽屉')")
await ev("__t.click('form-submit')")
await sleep(700)
const itemsAfterExtra = await ev("__t.state().then(function (s) { return s.items.length })")
check('备份后又新增了 1 条', itemsAfterExtra === itemsBeforeBackup + 1, itemsAfterExtra + ' vs ' + itemsBeforeBackup)
await ev("__t.click('settings-btn')")
await waitFor(client, "!!document.querySelector('[data-testid=backup-card]')", 8000, 'settings again')
for (let i = 2; i <= 5; i += 1) {
  await ev("__t.set('backup-name-input', '备份" + i + "')")
  await ev("__t.click('backup-create')")
  await sleep(450)
}
check('备份列表最多 5 份', await ev("__t.count('backup-row') === 5"))
await ev("__t.set('backup-name-input', '第六份')")
await ev("__t.click('backup-create')")
await sleep(600)
check('超过 5 份时要求选择覆盖', await ev("__t.has('backup-overwrite-box') && __t.count('backup-overwrite') === 5"))
await shot('86-backup-limit')
await ev("__t.click('backup-overwrite', 0)")
await sleep(700)
check('覆盖后仍是 5 份', await ev("__t.count('backup-row') === 5"))
const backupNames = await ev("__t.texts('backup-name')")
check('新备份出现在列表里', backupNames.join('|').indexOf('第六份') >= 0, backupNames.join(' / '))
// 还原最早那份（备份1，条目比现在少 1 条）
const rows = await ev("__t.count('backup-row')")
await ev("__t.click('backup-restore', " + (rows - 1) + ")")
await sleep(500)
check('还原前出现二次确认', await ev("__t.has('backup-restore-box')"))
await shot('87-backup-restore-confirm')
await ev("__t.click('backup-restore-confirm')")
await sleep(1200)
const restoredCount = await ev("__t.state().then(function (s) { return s.items.length })")
check('还原后回到备份时的数据', restoredCount === itemsBeforeBackup, restoredCount + ' vs ' + itemsBeforeBackup)
// 还原后重新进设置页，确认备份列表仍在、可以删除
if (!(await ev("__t.has('backup-row')"))) {
  await ev("__t.back()")
  await sleep(600)
  await ev("__t.click('settings-btn')")
  await waitFor(client, "!!document.querySelector('[data-testid=backup-card]')", 8000, 'settings after restore')
}
await ev("__t.click('backup-delete', 0)")
await sleep(300)
await waitFor(client, "__t.count('backup-row') === 4", 6000, 'backup deleted').catch(function () { return null })
check('可以删除单份备份', await ev("__t.count('backup-row') === 4"), await ev("String(__t.count('backup-row'))"))

// ---- 5. 退出：先关界面再清缓存，核心数据不丢 ----
await ev("__t.click('btn-quit')")
await sleep(400)
check('退出前有二次确认', await ev("__t.has('modal-confirm')"))
await ev("__t.click('modal-confirm')")
await sleep(3500)
const gone = await waitPort(9222, 7000, 'index.html').catch(function () { return null })
check('点退出后应用进程结束', !gone)

const failed = results.filter(function (r) { return !r.ok })
console.log(JSON.stringify({ total: results.length, passed: results.length - failed.length, failed: failed }))
if (failed.length) process.exitCode = 1
