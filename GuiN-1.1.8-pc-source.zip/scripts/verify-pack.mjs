// 打包产物验证：在真实打包后的 exe 上通过 CDP 操作界面并核对数据
import { connect, waitFor } from './cdp.mjs'

const port = Number(process.env.CDP_PORT || 9444)
const phase = process.env.PHASE || 'create'
const shotName = process.env.SHOT || ''
const brand = process.env.BRAND || '打包验货香水'
const sleep = function (ms) { return new Promise(function (r) { setTimeout(r, ms) }) }
const out = { ok: false, phase: phase, checks: [] }
function check (name, pass, extra) { out.checks.push({ name: name, pass: !!pass, extra: extra || '' }) }

async function waitPort (p, ms) {
  const end = Date.now() + ms
  while (Date.now() < end) {
    try {
      const res = await fetch('http://127.0.0.1:' + p + '/json/list')
      const list = await res.json()
      if (list && list.length) return list
    } catch (e) {}
    await sleep(300)
  }
  return null
}

const targets = await waitPort(port, 40000)
if (!targets) {
  out.reason = 'NO_CDP'
  console.log(JSON.stringify(out))
  process.exit(2)
}
const client = await connect(port, 'index.html')
const ev = function (expr) { return client.evaluate(expr) }
const shot = function (name) { return client.shot('.tmp-shots/' + name + '.png') }

const INSTALL = [
  'window.__t = {',
  '  all: function (id) { return Array.prototype.filter.call(document.querySelectorAll("[data-testid]"), function (e) { return e.getAttribute("data-testid") === id }) },',
  '  q: function (id, i) { return window.__t.all(id)[i || 0] || null },',
  '  count: function (id) { return window.__t.all(id).length },',
  '  texts: function (id) { return window.__t.all(id).map(function (e) { return e.innerText }) },',
  '  has: function (id) { return !!window.__t.q(id) },',
  '  click: function (id, i) { var el = window.__t.q(id, i); if (!el) throw new Error("missing " + id); el.click(); return true },',
  '  clickText: function (id, needle) { var list = window.__t.all(id); for (var k = 0; k < list.length; k++) { if (list[k].innerText.indexOf(needle) >= 0) { list[k].click(); return true } } throw new Error("no " + id + " with " + needle) },',
  '  setValue: function (el, v) { var proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : el instanceof HTMLSelectElement ? HTMLSelectElement.prototype : HTMLInputElement.prototype; Object.getOwnPropertyDescriptor(proto, "value").set.call(el, v); el.dispatchEvent(new Event("input", { bubbles: true })); el.dispatchEvent(new Event("change", { bubbles: true })); return true },',
  '  set: function (id, v) { var el = window.__t.q(id); if (!el) throw new Error("missing " + id); return window.__t.setValue(el, v) },',
  '  state: function () { return window.guina.getState() },',
  '  body: function () { return document.body.innerText }',
  '}',
  'true'
].join(String.fromCharCode(10))

await waitFor(client, '!!document.body', 25000, 'body')
await client.evaluate(INSTALL)
await sleep(900)

out.title = await ev('document.title')
check('打包后的程序窗口标题正确', out.title.indexOf('GuiN') >= 0, out.title)

if (await ev("__t.has('onboarding')")) {
  await ev("__t.click('onboarding-skip')")
  await sleep(600)
}

const before = await ev('__t.state().then(function (s) { return { items: s.items.length, cats: s.categories.length } })')
out.before = before

if (phase === 'create') {
  await ev("window.__t.clickText('category-card', '物品')")
  await waitFor(client, "!!document.querySelector('[data-testid=category-title]')", 10000, 'category page')
  check('打包版能进入分类页', true)
  await ev("__t.click('add-item')")
  await waitFor(client, "!!document.querySelector('[data-testid=form-name]')", 10000, 'item form')
  await ev("__t.set('form-name', '" + brand + "')")
  await ev("__t.click('form-location-place')")
  await ev("__t.set('form-location-name', '打包抽屉A')")
  await ev("__t.click('form-submit')")
  await waitFor(client, "__t.texts('item-row').join('|').indexOf('" + brand + "') >= 0", 12000, 'row created')
  check('打包版能新建条目并出现在列表', true)
  const after = await ev('__t.state().then(function (s) { return { items: s.items.length, notes: s.notes.length } })')
  out.after = after
  check('条目数量 +1', after.items === before.items + 1, JSON.stringify(before) + ' -> ' + JSON.stringify(after))
} else {
  await ev("window.__t.clickText('category-card', '物品')")
  await waitFor(client, "!!document.querySelector('[data-testid=category-title]')", 10000, 'category page')
  const rows = await ev("__t.texts('item-row')")
  out.rows = rows
  check('重启后条目仍在（数据落在用户目录）', rows.join('|').indexOf(brand) >= 0, rows.join(' / '))
  const hasLoc = rows.join('|').indexOf('打包抽屉A') >= 0
  check('位置信息重启后仍在', hasLoc)
}

if (shotName) await shot(shotName)
out.ok = out.checks.every(function (c) { return c.pass })
console.log(JSON.stringify(out))
client.close()
await sleep(300)
process.exit(out.ok ? 0 : 1)
