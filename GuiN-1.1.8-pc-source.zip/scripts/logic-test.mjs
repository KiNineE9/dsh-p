import { createRequire } from 'node:module'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'

const require = createRequire(import.meta.url)
const schema = require('../.tmp-test/shared/schema.js')
const search = require('../.tmp-test/shared/search.js')
const data = require('../.tmp-test/main/data.js')
const storeMod = require('../.tmp-test/main/store.js')

const results = []
function check(name, fn) {
  try { fn(); results.push({ name: name, ok: true }) }
  catch (e) { results.push({ name: name, ok: false, detail: e && e.message ? e.message : String(e) }) }
}
function eq(actual, expected, label) {
  const a = JSON.stringify(actual)
  const b = JSON.stringify(expected)
  if (a !== b) throw new Error((label || 'value') + ' expected ' + b + ' got ' + a)
}
function ok(cond, label) { if (!cond) throw new Error(label || 'expected truthy') }

check('A1 内置四大分类 + 默认设置', function () {
  const s = schema.createInitialState()
  eq(s.categories.length, 4, '分类数')
  eq(s.categories.map(function (c) { return c.id }), ['cat-book', 'cat-item', 'cat-food', 'cat-medicine'], '分类 id')
  ok(s.categories.every(function (c) { return c.builtin === true }), '内置标记')
  eq(s.settings.theme, 'system', '主题默认跟随系统')
  eq(s.settings.autoLaunch, true, '默认开机自启')
  eq(s.settings.closeToTray, true, '默认关闭窗口到托盘')
  eq(s.settings.reminderPopup, true, '默认提醒弹窗')
  eq(s.settings.reminderSound, true, '默认提示音')
  eq(s.settings.expiryTiers, { 30: true, 15: true, 7: true, 1: true }, '默认四档全开')
})
check('B1 物品必填名称与位置', function () {
  const v = schema.validateItemDraft({ name: '', locationType: 'place', locationLabel: '', locationName: '', fields: {} }, 'item', [])
  ok(v.ok === false)
  ok(v.errors.name && v.errors['locationLabel'])
})
check('B2 食品必填类型/拆封/过期时间', function () {
  const v = schema.validateItemDraft({ name: '牛奶', locationType: 'place', locationLabel: '冰箱', locationName: '', fields: {} }, 'food', [])
  ok(v.errors.foodType && v.errors.opened && v.errors.expiresAt)
  const good = schema.validateItemDraft({ name: '牛奶', locationType: 'place', locationLabel: '冰箱', locationName: '', fields: { foodType: '液体', opened: false, expiresAt: '2026-12-01' } }, 'food', [])
  ok(good.ok === true, '拆封选“否”也是合法值')
})
check('B3 图书必填存放时间', function () {
  const bad = schema.validateItemDraft({ name: '活着', locationType: 'place', locationLabel: '书架', locationName: '', fields: {} }, 'book', [])
  ok(bad.errors.storedAt)
  const good = schema.validateItemDraft({ name: '活着', locationType: 'place', locationLabel: '书架', locationName: '', fields: { storedAt: '2026-11-01' } }, 'book', [])
  ok(good.ok)
})
check('B4 自定义字段必填生效', function () {
  const cf = [{ key: 'k1', label: '颜色', type: 'text', required: true }]
  const bad = schema.validateItemDraft({ name: '香水', locationType: 'place', locationLabel: '抽屉', locationName: '', fields: { custom: {} } }, 'item', cf)
  ok(bad.errors['custom.k1'])
  const good = schema.validateItemDraft({ name: '香水', locationType: 'place', locationLabel: '抽屉', locationName: '', fields: { custom: { k1: '金色' } } }, 'item', cf)
  ok(good.ok)
})

const state = schema.createInitialState()
check('C1 新建香水条目', function () {
  const r = data.createItem(state, 'cat-item', { name: '香水', locationType: 'place', locationLabel: '卧室第二层抽屉', locationName: '', fields: {} })
  ok(r.ok, r.ok ? '' : r.error)
  ok(r.value.id)
  eq(data.countItems(state, 'cat-item'), 1, '物品分类条目数')
})
check('C2 修改存放位置', function () {
  const item = state.items[0]
  const r = data.updateItem(state, item.id, { name: item.name, locationType: 'container', locationLabel: '客厅柜子', locationName: '', fields: item.fields })
  ok(r.ok, r.ok ? '' : r.error)
  eq(state.items[0].locationLabel, '客厅柜子')
  eq(state.items[0].locationType, 'container')
})
check('C3 删除条目并级联清理备注', function () {
  const r = data.createItem(state, 'cat-item', { name: '旧钥匙', locationType: 'place', locationLabel: '抽屉', locationName: '', fields: {} })
  data.addNote(state, r.value.id, '备用钥匙')
  const del = data.deleteItem(state, r.value.id)
  ok(del.ok)
  eq(data.notesOf(state, r.value.id).length, 0, '备注级联删除')
  eq(data.findItem(state, r.value.id), undefined, '条目已删除')
})
check('D1 多条备注增改删', function () {
  const item = state.items[0]
  const n1 = data.addNote(state, item.id, '第一条备注')
  const n2 = data.addNote(state, item.id, '第二条备注')
  ok(n1.ok && n2.ok)
  eq(data.notesOf(state, item.id).length, 2, '两条备注')
  const up = data.updateNote(state, n1.value.id, '第一条备注（改）')
  ok(up.ok)
  eq(data.notesOf(state, item.id).find(function (n) { return n.id === n1.value.id }).content, '第一条备注（改）')
  ok(data.deleteNote(state, n2.value.id).ok)
  eq(data.notesOf(state, item.id).length, 1, '删除单条后剩一条')
})
check('E1 自定义分类继承图书模板 + 追加字段', function () {
  const r = data.createCategory(state, { name: '收藏卡', icon: '🎴', baseTemplate: 'book', customFields: [{ key: 'grade', label: '品级', type: 'text' }] })
  ok(r.ok, r.ok ? '' : r.error)
  eq(r.value.template, 'custom')
  eq(r.value.baseTemplate, 'book')
  const dup = data.createCategory(state, { name: '收藏卡', icon: '🎴', baseTemplate: 'book', customFields: [] })
  ok(dup.ok === false, '不允许重名分类')
  ok(data.deleteCategory(state, 'cat-book').ok === false, '内置分类不可删除')
})
check('F1 子串搜索“净”命中娃哈哈纯净水', function () {
  const s = schema.createInitialState()
  data.createItem(s, 'cat-food', { name: '娃哈哈纯净水', locationType: 'place', locationLabel: '厨房冰箱', locationName: '', fields: { foodType: '液体', opened: false, expiresAt: '2026-12-01' } })
  data.createItem(s, 'cat-item', { name: '耳机', locationType: 'container', locationLabel: '书桌抽屉', locationName: '', fields: {} })
  const hits = search.searchItems(s.items, s.categories, s.notes, '净', {})
  eq(hits.length, 1, '命中数量')
  eq(hits[0].item.name, '娃哈哈纯净水')
  eq(hits[0].categoryName, '食品')
})
check('F2 按位置搜索与分类内搜索', function () {
  const s = schema.createInitialState()
  data.createItem(s, 'cat-food', { name: '酸奶', locationType: 'place', locationLabel: '厨房冰箱', locationName: '', fields: { foodType: '液体', opened: false, expiresAt: '2026-12-01' } })
  data.createItem(s, 'cat-item', { name: '数据线', locationType: 'place', locationLabel: '厨房冰箱顶上', locationName: '', fields: {} })
  eq(search.searchItems(s.items, s.categories, s.notes, '冰箱', {}).length, 2, '全局按位置')
  const inside = search.searchItems(s.items, s.categories, s.notes, '冰箱', { categoryId: 'cat-food' })
  eq(inside.length, 1, '分类内只返回食品')
  eq(inside[0].item.name, '酸奶')
})
check('F3 繁简与全半角容错', function () {
  eq(search.toSimplified('淨水'), '净水')
  const s = schema.createInitialState()
  data.createItem(s, 'cat-item', { name: 'ABC净水', locationType: 'place', locationLabel: '冰箱', locationName: '', fields: {} })
  eq(search.searchItems(s.items, s.categories, s.notes, 'ａｂｃ', {}).length, 1, '全角大小写混合命中')
})
check('G1 名称按拼音排序', function () {
  const s = schema.createInitialState()
  data.createItem(s, 'cat-item', { name: '香蕉', locationType: 'place', locationLabel: 'A', locationName: '', fields: {} })
  data.createItem(s, 'cat-item', { name: '苹果', locationType: 'place', locationLabel: 'B', locationName: '', fields: {} })
  data.createItem(s, 'cat-item', { name: '草莓', locationType: 'place', locationLabel: 'C', locationName: '', fields: {} })
  const sorted = search.sortItems(s.items.slice(), 'name')
  eq(sorted.map(function (i) { return i.name }), ['草莓', '苹果', '香蕉'])
})
check('G2 按存放时间 / 过期时间排序', function () {
  const s = schema.createInitialState()
  const a = data.createItem(s, 'cat-book', { name: 'A书', locationType: 'place', locationLabel: 'x', locationName: '', fields: { storedAt: '2026-01-01' } })
  const b = data.createItem(s, 'cat-book', { name: 'B书', locationType: 'place', locationLabel: 'y', locationName: '', fields: { storedAt: '2026-05-01' } })
  eq(search.sortItems([b.value, a.value], 'storedAt').map(function (i) { return i.name }), ['A书', 'B书'], '存放时间默认早到晚')
  eq(search.sortItems([a.value, b.value], 'storedAt', 'desc').map(function (i) { return i.name }), ['B书', 'A书'], '存放时间倒序新到旧')
  const s2 = schema.createInitialState()
  const f1 = data.createItem(s2, 'cat-food', { name: '先过期', locationType: 'place', locationLabel: 'z', locationName: '', fields: { foodType: '固体', opened: true, expiresAt: '2026-11-20' } })
  const f2 = data.createItem(s2, 'cat-food', { name: '后过期', locationType: 'place', locationLabel: 'w', locationName: '', fields: { foodType: '固体', opened: true, expiresAt: '2027-01-20' } })
  eq(search.sortItems([f2.value, f1.value], 'expiresAt').map(function (i) { return i.name }), ['先过期', '后过期'], '过期时间早到晚')
  eq(search.sortItems([f1.value, f2.value], 'expiresAt', 'desc').map(function (i) { return i.name }), ['后过期', '先过期'], '过期时间倒序')
})
check('G3 排序方向循环与字段可见性', function () {
  eq(schema.toggleSortState({ mode: 'name', direction: 'asc' }, 'name'), { mode: 'name', direction: 'desc' })
  eq(schema.toggleSortState({ mode: 'name', direction: 'desc' }, 'name'), { mode: 'name', direction: 'asc' })
  eq(schema.toggleSortState({ mode: 'expiresAt', direction: 'desc' }, 'name'), { mode: 'name', direction: 'asc' })
  eq(schema.sortDirectionArrow('asc'), '↑')
  eq(schema.sortDirectionArrow('desc'), '↓')
  const foodOpts = schema.sortOptionsFor('food').map(function (o) { return o.mode })
  eq(foodOpts.indexOf('expiresAt') >= 0, true, '食品有到期时间排序')
  const bookOpts = schema.sortOptionsFor('book').map(function (o) { return o.mode })
  eq(bookOpts.indexOf('expiresAt'), -1, '图书没有到期时间排序')
  const bookFields = schema.getFormSchema('book', []).fields.map(function (f) { return f.key })
  eq(bookFields.indexOf('expiresAt'), -1, '图书没有到期时间字段')
  eq(bookFields.indexOf('storedAt') >= 0, true, '图书可填存放时间')
  const itemFields = schema.getFormSchema('item', []).fields.map(function (f) { return f.key })
  eq(itemFields.indexOf('storedAt') >= 0, true, '物品可填存放时间')
  const s = schema.createInitialState()
  const draft = schema.emptyDraftFor('book')
  eq(draft.fields.storedAt, schema.todayDateString(), '新建时存放时间默认今天')
})
function makeFood(s, name, expiresAt, location) {
  return data.createItem(s, 'cat-food', { name: name, locationType: 'place', locationLabel: location || '冰箱', locationName: '', fields: { foodType: '固体', opened: true, expiresAt: expiresAt } })
}
check('H1 30/15/7/1 档位与颜色分级', function () {
  eq(search.tierForDaysLeft(20), 30)
  eq(search.tierForDaysLeft(12), 15)
  eq(search.tierForDaysLeft(5), 7)
  eq(search.tierForDaysLeft(0), 1)
  eq(search.tierForDaysLeft(-3), 1)
  eq(search.tierForDaysLeft(45), null)
  eq(search.expiryLevel(20), 'normal')
  eq(search.expiryLevel(15), 'soon')
  eq(search.expiryLevel(7), 'urgent')
  eq(search.expiryLevel(1), 'critical')
  eq(search.expiryLevel(-1), 'expired')
})
check('H2 生成通知且同档位不重复', function () {
  const s = schema.createInitialState()
  const now = new Date(2026, 10, 15, 9, 0, 0)
  makeFood(s, '临期饼干', '2026-12-05')
  eq(data.syncExpiryNotifications(s, now).length, 1, '第一次生成一条')
  eq(s.notifications.length, 1)
  eq(data.syncExpiryNotifications(s, now).length, 0, '同档位不重复生成')
  eq(s.notifications.length, 1)
  eq(s.notifications[0].tier, 30)
})
check('H3 关闭档位后不再生成', function () {
  const s = schema.createInitialState()
  const now = new Date(2026, 10, 15, 9, 0, 0)
  makeFood(s, '临期酸奶', '2026-11-27')
  data.updateSettings(s, { expiryTiers: { 30: true, 15: false, 7: true, 1: true } })
  data.syncExpiryNotifications(s, now, s.settings.expiryTiers)
  eq(s.notifications.length, 0, '15 档关闭时不生成')
})
check('H4 已读/单删/批量已读/批量删除已读', function () {
  const s = schema.createInitialState()
  const now = new Date(2026, 10, 15, 9, 0, 0)
  makeFood(s, '食品A', '2026-12-05')
  makeFood(s, '食品B', '2026-12-06')
  data.syncExpiryNotifications(s, now)
  eq(data.unreadCount(s), 2)
  ok(data.markNotificationRead(s, s.notifications[0].id, true).ok)
  eq(data.unreadCount(s), 1)
  ok(data.markAllNotificationsRead(s).ok)
  eq(data.unreadCount(s), 0)
  ok(data.deleteNotification(s, s.notifications[0].id).ok)
  eq(data.visibleNotifications(s).length, 1)
  ok(data.deleteReadNotifications(s).ok)
  eq(data.visibleNotifications(s).length, 0)
})
check('H5 用户删掉的通知不再长回来', function () {
  const s = schema.createInitialState()
  const now = new Date(2026, 10, 15, 9, 0, 0)
  makeFood(s, '食品C', '2026-12-05')
  data.syncExpiryNotifications(s, now)
  data.deleteNotification(s, s.notifications[0].id)
  data.syncExpiryNotifications(s, now)
  eq(data.visibleNotifications(s).length, 0, '删除后不重复出现')
})
check('I1 到期便利贴检索与标记', function () {
  const s = schema.createInitialState()
  const now = new Date()
  const past = new Date(now.getTime() - 60 * 1000).toISOString()
  const future = new Date(now.getTime() + 3600 * 1000).toISOString()
  const a = data.createSticky(s, { content: '倒垃圾', kind: 'reminder', remindAt: past })
  data.createSticky(s, { content: '买牛奶', kind: 'reminder', remindAt: future })
  const due = data.dueStickies(s, now)
  eq(due.length, 1, '只有到点的会提醒')
  eq(due[0].content, '倒垃圾')
  data.markStickyNotified(s, a.value.id, now)
  eq(data.dueStickies(s, now).length, 0, '标记后不再重复提醒')
})
check('J1 原子写入、重启读回、备份保留 7 份', function () {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'guina-test-'))
  const st = new storeMod.Store(dir)
  st.init()
  const s = st.state
  data.createItem(s, 'cat-item', { name: '香水', locationType: 'place', locationLabel: '卧室第二层抽屉', locationName: '', fields: {} })
  st.writeNow()
  const reopened = new storeMod.Store(dir)
  reopened.init()
  eq(reopened.state.items.length, 1, '重启后数据仍在')
  eq(reopened.state.items[0].name, '香水')
  for (let i = 0; i < 10; i += 1) {
    s.items[0].locationLabel = '位置' + i
    st.writeNow()
  }
  const backups = fs.readdirSync(path.join(dir, 'backups')).filter(function (f) { return f.endsWith('.json') })
  ok(backups.length <= 7, '备份最多 7 份，实际 ' + backups.length)
  const files = fs.readdirSync(dir).filter(function (f) { return f.endsWith('.tmp') })
  eq(files.length, 0, '没有遗留临时文件')
  fs.rmSync(dir, { recursive: true, force: true })
})
check('J2 坏数据文件容错', function () {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'guina-bad-'))
  const st = new storeMod.Store(dir)
  st.init()
  fs.writeFileSync(path.join(dir, 'data.json'), '{ 这不是 json', 'utf8')
  const st2 = new storeMod.Store(dir)
  st2.init()
  eq(st2.state.categories.length, 4, '坏文件时回到内置分类')
  fs.rmSync(dir, { recursive: true, force: true })
})

const repeatMod = require('../.tmp-test/shared/repeat.js')

check('K1 循环规则解析与展示', function () {
  eq(repeatMod.describeRepeat({ kind: 'daily', time: '9:00' }), '每天 09:00')
  eq(repeatMod.describeRepeat({ kind: 'weekdays', time: '08:30' }), '工作日 08:30')
  eq(repeatMod.describeRepeat({ kind: 'weekends', time: '10:00' }), '周六日 10:00')
  eq(repeatMod.describeRepeat(null), '')
  eq(repeatMod.normalizeRepeat({ kind: 'daily', time: '25:00' }), null)
})
check('K2 每天 / 工作日 / 周六日 的下一次时间', function () {
  const sun = new Date(2026, 10, 15, 8, 0, 0)
  eq(repeatMod.nextRepeatOccurrence({ kind: 'daily', time: '09:00' }, sun).getTime(), new Date(2026, 10, 15, 9, 0, 0).getTime(), '今天还没到点就今天')
  const sunLate = new Date(2026, 10, 15, 10, 0, 0)
  eq(repeatMod.nextRepeatOccurrence({ kind: 'daily', time: '09:00' }, sunLate).getTime(), new Date(2026, 10, 16, 9, 0, 0).getTime(), '过点顺延到明天')
  const sat = new Date(2026, 10, 21, 12, 0, 0)
  eq(repeatMod.nextRepeatOccurrence({ kind: 'weekdays', time: '09:00' }, sat).getTime(), new Date(2026, 10, 23, 9, 0, 0).getTime(), '周六的下个工作日是周一')
  const mon = new Date(2026, 10, 16, 12, 0, 0)
  eq(repeatMod.nextRepeatOccurrence({ kind: 'weekends', time: '09:00' }, mon).getTime(), new Date(2026, 10, 21, 9, 0, 0).getTime(), '周一的下个周六日')
  const friLate = new Date(2026, 10, 20, 20, 0, 0)
  eq(repeatMod.nextRepeatOccurrence({ kind: 'weekdays', time: '09:00' }, friLate).getTime(), new Date(2026, 10, 23, 9, 0, 0).getTime(), '周五晚顺延到周一')
})
check('K3 便利贴循环提醒保存与顺延', function () {
  const s = schema.createInitialState()
  const op = data.createSticky(s, { content: '每天喝水', kind: 'reminder', repeat: { kind: 'daily', time: '09:00' } })
  ok(op.ok)
  eq(op.value.repeat.kind, 'daily')
  ok(new Date(op.value.remindAt).getTime() > Date.now(), '保存时算出下一次时间')
  eq(data.dueStickies(s, new Date()).length, 0, '下一次还没到时不提醒')
  const later = new Date()
  later.setDate(later.getDate() + 2)
  eq(data.dueStickies(s, later).length, 1, '到点后进入待提醒')
  const again = data.updateSticky(s, op.value.id, { repeat: { kind: 'weekdays', time: '08:30' } })
  ok(again.ok)
  eq(again.value.repeat.kind, 'weekdays')
  eq(again.value.notified, false, '改规则后重新计时')
  const futureTime = new Date(Date.now() + 3600 * 1000).toISOString()
  const off = data.updateSticky(s, op.value.id, { repeat: null, remindAt: futureTime })
  ok(off.ok)
  eq(off.value.repeat, null, '关闭循环')
  eq(off.value.remindAt, futureTime, '关闭循环后还能当一次性提醒')
  const noTime = data.updateSticky(s, op.value.id, { repeat: null, remindAt: null })
  ok(noTime.ok === false, '提醒便签必须保留一个提醒时间')
})

const backupMod = require('../.tmp-test/main/backup.js')

check('L1 便签与提醒便签两类 + 置顶', function () {
  const s = schema.createInitialState()
  const pinned = data.createSticky(s, { content: '置顶便签', kind: 'note', pinned: true })
  const normal = data.createSticky(s, { content: '普通便签', kind: 'note' })
  ok(pinned.ok && normal.ok)
  eq(pinned.value.kind, 'note')
  eq(pinned.value.pinned, true)
  ok(!!pinned.value.pinnedAt, '置顶有置顶时间')
  eq(pinned.value.remindAt, null, '便签不带提醒时间')
  eq(normal.value.pinned, false)
  const up = data.updateSticky(s, normal.value.id, { pinned: true })
  ok(up.ok)
  eq(up.value.pinned, true)
  eq(up.value.pinnedAt, up.value.pinnedAt, '置顶后有置顶时间')
  ok(!!up.value.pinnedAt)
  const off = data.updateSticky(s, normal.value.id, { pinned: false })
  eq(off.value.pinned, false)
  ok(off.value.pinnedAt === undefined, '取消置顶清掉置顶时间')
  const rem = data.createSticky(s, { content: '喝水提醒', kind: 'reminder', remindAt: new Date(Date.now() + 60000).toISOString() })
  ok(rem.ok)
  eq(rem.value.kind, 'reminder')
  const pinRem = data.updateSticky(s, rem.value.id, { pinned: true })
  eq(pinRem.value.pinned, false, '提醒便签不参与置顶')
})

check('L2 保存过的地点/容器名称：去重、最新置顶、删除', function () {
  const s = schema.createInitialState()
  data.rememberSavedName(s, 'place', '卧室')
  data.rememberSavedName(s, 'place', '客厅')
  data.rememberSavedName(s, 'place', '卧室')
  eq(s.savedNames.place.map(function (x) { return x.name }), ['卧室', '客厅'], '相同名称只留一个且最新置顶')
  data.rememberSavedName(s, 'container', '行李箱')
  data.rememberSavedName(s, 'container', '衣柜')
  eq(s.savedNames.container.map(function (x) { return x.name }), ['衣柜', '行李箱'])
  const rm = data.removeSavedName(s, 'place', '客厅')
  ok(rm.ok)
  eq(s.savedNames.place.map(function (x) { return x.name }), ['卧室'])
  ok(data.removeSavedName(s, 'place', '不存在').ok === false, '删不存在的名称要报错')
  data.rememberSavedName(s, 'place', ' 卧室 ')
  eq(s.savedNames.place.map(function (x) { return x.name }), ['卧室'], '地点列表忽略首尾空格去重')
  data.rememberSavedName(s, 'container', '  行李箱  ')
  eq(s.savedNames.container.map(function (x) { return x.name }), ['行李箱', '衣柜'], '容器列表忽略首尾空格去重')
  data.rememberSavedName(s, 'place', 'Pencil Case')
  data.rememberSavedName(s, 'place', 'pencil case')
  eq(s.savedNames.place.filter(function (x) { return x.name.toLowerCase() === 'pencil case' }).length, 1, '忽略大小写只留一个')
  ok(!s.savedNames.place.some(function (x) { return x.name === '行李箱' }), '容器名称不会混进地点列表')
  ok(!s.savedNames.container.some(function (x) { return x.name === '卧室' }), '地点名称不会混进容器列表')
  const item = data.createItem(s, 'cat-item', { name: '钥匙', locationType: 'container', locationLabel: '收纳盒', locationName: '', fields: {} })
  ok(item.ok)
  eq(s.savedNames.container[0].name, '收纳盒', '新建条目后自动记住容器名称')
  eq(s.savedNames.container.filter(function (x) { return x.name === '收纳盒' }).length, 1, '不重复')
})

check('L3 位置展示与地点/容器必填文案', function () {
  eq(schema.formatLocation('卧室', '第二层抽屉'), '卧室 · 第二层抽屉')
  eq(schema.formatLocation('卧室', ''), '卧室')
  eq(schema.formatLocation('', '第二层抽屉'), '第二层抽屉')
  const c = schema.validateItemDraft({ name: '钥匙', locationType: 'container', locationLabel: '', locationName: '', fields: {} }, 'item', [])
  eq(c.errors['locationLabel'], '请填写容器名称')
  const p = schema.validateItemDraft({ name: '钥匙', locationType: 'place', locationLabel: '', locationName: '', fields: {} }, 'item', [])
  eq(p.errors['locationLabel'], '请填写地点名称')
  const good = schema.validateItemDraft({ name: '钥匙', locationType: 'container', locationLabel: '收纳盒', locationName: '', fields: {} }, 'item', [])
  ok(good.ok, '详细位置可以不填')
})

check('L4 便签标题（可选）', function () {
  const s = schema.createInitialState()
  const a = data.createSticky(s, { content: '正文', kind: 'note', title: '  我的标题  ' })
  ok(a.ok, a.ok ? '' : a.error)
  eq(a.value.title, '我的标题')
  const noTitle = data.createSticky(s, { content: '无标题', kind: 'note' })
  eq(noTitle.value.title, undefined, '不填标题不落库')
  const up = data.updateSticky(s, a.value.id, { title: '改过的标题' })
  eq(up.value.title, '改过的标题')
  const clr = data.updateSticky(s, a.value.id, { title: '' })
  eq(clr.value.title, undefined, '清空标题')
  const long = data.createSticky(s, { content: 'x', kind: 'note', title: 'x'.repeat(80) })
  eq(long.value.title.length, 60, '标题最多 60 字')
  const r = data.createSticky(s, { content: '提醒正文', kind: 'reminder', title: '喝水', repeat: { kind: 'daily', time: '09:00' } })
  eq(r.value.title, '喝水', '提醒便签也能带标题')
})

check('L5 便签搜索复用统一匹配规则', function () {
  const s = schema.createInitialState()
  const a = data.createSticky(s, { content: '明天吃饭记得订位', kind: 'note', title: '聚餐安排' })
  const b = data.createSticky(s, { content: '买牛奶', kind: 'note' })
  const c = data.createSticky(s, { content: '喝水提醒正文', kind: 'reminder', title: '喝水', repeat: { kind: 'daily', time: '09:00' } })
  ok(a.ok && b.ok && c.ok)
  eq(search.searchStickies(s.stickies, '吃').map(function (x) { return x.id }), [a.value.id], '内容子串“吃”命中')
  eq(search.searchStickies(s.stickies, '聚餐').map(function (x) { return x.id }), [a.value.id], '标题子串命中')
  eq(search.searchStickies(s.stickies, ' 喝 水 ').map(function (x) { return x.id }), [c.value.id], '标题/内容匹配忽略空格')
  eq(search.searchStickies(s.stickies, '不存在').length, 0, '无匹配返回空')
  eq(search.searchStickies(s.stickies, '').length, 3, '空查询返回全部')
  const s2 = schema.createInitialState()
  data.createSticky(s2, { content: 'ＡＢＣ便签', kind: 'note' })
  eq(search.searchStickies(s2.stickies, 'abc').length, 1, '全角大小写容错')
})

check('M1 手动备份：上限 5 份、覆盖、还原、删除', function () {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'guina-bak-'))
  const mgr = new backupMod.BackupManager(path.join(dir, 'manual'), '1.0.0')
  mgr.ensureDir()
  const s = schema.createInitialState()
  data.createItem(s, 'cat-item', { name: '香水', locationType: 'place', locationLabel: '卧室', locationName: '', fields: {} })
  const a = mgr.create(s, '第一次')
  ok(a.ok)
  eq(a.value.name, '第一次')
  eq(mgr.count(), 1)
  for (let i = 2; i <= 5; i += 1) {
    data.createItem(s, 'cat-item', { name: '东西' + i, locationType: 'place', locationLabel: '抽屉', locationName: '', fields: {} })
    ok(mgr.create(s, '第' + i + '次').ok)
  }
  eq(mgr.count(), 5, '最多 5 份')
  const sixth = mgr.create(s, '第六次')
  ok(sixth.ok === false)
  ok(String(sixth.error).indexOf('最多保存 5') >= 0, '第六份要提示覆盖')
  const entries = mgr.list()
  const older = entries[entries.length - 1]
  const over = mgr.create(s, '覆盖掉的', older.id)
  ok(over.ok)
  eq(mgr.count(), 5, '覆盖后仍是 5 份')
  const after = mgr.list()
  ok(!after.some(function (e) { return e.id === older.id }), '被覆盖的那份已删除')
  ok(after.some(function (e) { return e.name === '覆盖掉的' }))
  const restored = mgr.restore(over.value.id)
  ok(restored.ok)
  eq(restored.value.items.length, 5, '还原得到备份时的条目数')
  ok(mgr.delete(over.value.id).ok)
  eq(mgr.count(), 4)
  ok(mgr.restore('bak-not-exist').ok === false, '还原不存在的备份要报错')
  fs.rmSync(dir, { recursive: true, force: true })
})


check('G4 按存放时间排序：旧条目用创建日期兜底、同日期按名称且随方向翻转', function () {
  const base = {
    id: 'x', categoryId: 'cat-food', locationType: 'place', locationLabel: '冰箱', locationName: '',
    createdAt: '2026-01-01T08:00:00.000Z', updatedAt: '2026-01-01T08:00:00.000Z', fields: {}
  }
  const mk = function (name, storedAt, created) {
    const it = JSON.parse(JSON.stringify(base))
    it.id = 'it-' + name
    it.name = name
    if (storedAt) it.fields.storedAt = storedAt
    if (created) it.createdAt = created
    return it
  }
  const legacy = [mk('C食品', '', '2026-01-01T08:00:00.000Z'), mk('A食品', '', '2026-02-01T08:00:00.000Z'), mk('B食品', '', '2026-03-01T08:00:00.000Z')]
  eq(search.sortItems(legacy, 'name', 'asc').map(function (i) { return i.name }), ['A食品', 'B食品', 'C食品'], '名称升序')
  eq(search.sortItems(legacy, 'storedAt', 'asc').map(function (i) { return i.name }), ['C食品', 'A食品', 'B食品'], '旧条目按创建日期升序')
  eq(search.sortItems(legacy, 'storedAt', 'desc').map(function (i) { return i.name }), ['B食品', 'A食品', 'C食品'], '旧条目按创建日期降序')
  const same = [mk('乙', '2026-05-01'), mk('甲', '2026-05-01'), mk('丙', '2026-05-01')]
  eq(search.sortItems(same, 'storedAt', 'asc').map(function (i) { return i.name }), ['丙', '甲', '乙'], '同日期按名称升序')
  eq(search.sortItems(same, 'storedAt', 'desc').map(function (i) { return i.name }), ['乙', '甲', '丙'], '同日期按名称降序（切方向能看到变化）')
  const mixed = [mk('有日期', '2026-04-01'), mk('无日期', '', '2026-03-01T00:00:00.000Z'), mk('空创建', '', '')]
  eq(search.sortItems(mixed, 'storedAt', 'asc').map(function (i) { return i.name }), ['空创建', '无日期', '有日期'], '缺 storedAt 的旧条目退到创建日期（没有创建日期排最后）')
  const exp = [mk('晚', '2026-01-01'), mk('早', '2026-01-01')]
  exp[0].fields.expiresAt = '2026-12-31'
  exp[1].fields.expiresAt = '2026-06-30'
  eq(search.sortItems(exp, 'expiresAt', 'asc').map(function (i) { return i.name }), ['早', '晚'], '过期时间升序')
})

const cameraMod = require('../.tmp-test/shared/camera.js')

check('H1 扫码挑后置主摄：排除长焦/微距/前置', function () {
  const devices = [
    { deviceId: 'cam-front', label: 'camera2 1, facing front' },
    { deviceId: 'cam-tele', label: 'camera2 2, facing back (telephoto)' },
    { deviceId: 'cam-wide', label: 'camera2 0, facing back (wide)' },
    { deviceId: 'cam-macro', label: 'camera2 3, facing back (macro)' }
  ]
  eq(cameraMod.pickMainBackCamera(devices, 'cam-tele').deviceId, 'cam-wide', '默认落在长焦时切回 wide')
  eq(cameraMod.pickMainBackCamera(devices, 'cam-front').deviceId, 'cam-wide', '默认落在前置时也切回后置主摄')
  const noWide = [{ deviceId: 'a', label: 'camera2 2, facing back (telephoto)' }, { deviceId: 'b', label: 'camera2 0, facing back' }]
  eq(cameraMod.pickMainBackCamera(noWide).deviceId, 'b', '没有 wide 字样时选非长焦那一路')
  const onlyTele = [{ deviceId: 'a', label: 'camera2 2, facing back (telephoto)' }]
  eq(cameraMod.pickMainBackCamera(onlyTele).deviceId, 'a', '只有长焦时沿用，不会返回空')
  const noLabel = [{ deviceId: 'p', label: '' }, { deviceId: 'q', label: '' }]
  eq(cameraMod.pickMainBackCamera(noLabel, 'q').deviceId, 'q', '拿不到设备名时沿用当前这一路')
})
check('H2 摄像头标签判定', function () {
  ok(cameraMod.isFrontCameraLabel('camera2 1, facing front'))
  ok(cameraMod.isFrontCameraLabel('前置摄像头'))
  ok(cameraMod.isTelephotoLabel('camera2 2, facing back (telephoto)'))
  ok(cameraMod.isTelephotoLabel('微距镜头'))
  ok(!cameraMod.isTelephotoLabel('camera2 0, facing back (wide)'))
})
const failed = results.filter(function (x) { return !x.ok })
console.log(JSON.stringify({ total: results.length, passed: results.length - failed.length, failed: failed }))
if (failed.length) process.exitCode = 1