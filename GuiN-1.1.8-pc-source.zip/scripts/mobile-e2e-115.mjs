// GuiN 安卓版 1.1.5 新功能端到端验证（WebView CDP 驱动真实 APK）
// 覆盖：提醒卡循环文案、系统闹钟工作日重复、分类长按拖拽、分类排序升降循环/存放时间、扫码面板
// 前置：pm clear com.guina.app.debug && pm grant POST_NOTIFICATIONS/CAMERA && am start ...
import { execSync } from 'node:child_process'
import fs from 'node:fs'
import { check as baseCheck, bodyText, waitText, sheetOpen, sheetText, summary, sleep } from './mobile-e2e.mjs'

const check = function (name, ok, detail) {
  console.log((ok ? 'PASS ' : 'FAIL ') + name + (ok || !detail ? '' : ' :: ' + detail))
  baseCheck(name, ok, detail)
}

const ADB = process.env.ADB || 'F:/Android/sdk/platform-tools/adb.exe'
const OUT = process.env.SHOT_DIR || '.tmp-shots/android'
fs.mkdirSync(OUT, { recursive: true })

const c = await (await import('./cdp.mjs')).connect(Number(process.env.CDP_PORT || 9333), 'app.local')
await c.send('Page.enable')
await c.send('Runtime.enable')
await c.send('Input.enable').catch(function () {})
const ev2 = async function (expr) { return c.evaluate(expr) }

async function center(sel, text) {
  const raw = await ev2('(() => { const list = [...document.querySelectorAll(' + JSON.stringify(sel) + ')]; const el = ' + (text ? 'list.find((e) => ((e.innerText || e.textContent || \'\') + \'\').replace(/\\s+/g, \' \').trim().includes(' + JSON.stringify(text) + '))' : 'list[0]') + '; if (!el) return \'null\'; el.scrollIntoView({ block: \'center\', inline: \'center\' }); const r = el.getBoundingClientRect(); return JSON.stringify({ x: r.left + r.width / 2, y: r.top + r.height / 2, w: r.width, h: r.height, text: (el.innerText || \'\').slice(0, 20) }); })()')
  if (!raw || raw === 'null') return null
  return JSON.parse(raw)
}

async function mouse(type, x, y) {
  await c.send('Input.dispatchMouseEvent', { type, x, y, button: 'left', clickCount: 1 })
}
async function tap(sel, text) {
  const p = await center(sel, text)
  if (!p) return false
  await mouse('mouseMoved', p.x, p.y)
  await mouse('mousePressed', p.x, p.y)
  await sleep(60)
  await mouse('mouseReleased', p.x, p.y)
  await sleep(280)
  return true
}
async function tapText(text, sel) {
  return tap(sel || 'button,.btn,.tab,.chip,.row,.fab', text)
}
/** 只在按钮文字完全等于 text 时点击（避免「保存」误点「保存并导入闹钟」） */
async function tapExact(text) {
  const raw = await ev2('(() => { const list = [...document.querySelectorAll(\'button,.btn\')]; const el = list.find((e) => ((e.innerText || \'\').trim() === ' + JSON.stringify(text) + ')); if (!el) return \'null\'; el.scrollIntoView({ block: \'center\' }); const r = el.getBoundingClientRect(); return JSON.stringify({ x: r.left + r.width / 2, y: r.top + r.height / 2 }); })()')
  if (!raw || raw === 'null') return false
  const p = JSON.parse(raw)
  await mouse('mouseMoved', p.x, p.y)
  await mouse('mousePressed', p.x, p.y)
  await sleep(60)
  await mouse('mouseReleased', p.x, p.y)
  await sleep(300)
  return true
}
/** 点 Seg 分段按钮并确认选中（滚动后按钮可能被底部操作条遮挡，这里手动校正再点） */
async function clickSeg(label) {
  for (let attempt = 0; attempt < 3; attempt++) {
    const raw = await ev2('(() => { const items = [...document.querySelectorAll(".seg .seg-item")]; const el = items.find((e) => (e.textContent || "").trim() === ' + JSON.stringify(label) + '); if (!el) return "null"; el.scrollIntoView({ block: "center", inline: "center" }); const sb = el.closest(".sheet-body"); if (sb) { const r0 = el.getBoundingClientRect(); const sr = sb.getBoundingClientRect(); if (r0.bottom > sr.bottom - 90) sb.scrollTop += r0.bottom - (sr.bottom - 90); else if (r0.top < sr.top + 20) sb.scrollTop -= (sr.top + 20) - r0.top; } const r = el.getBoundingClientRect(); return JSON.stringify({ x: r.left + r.width / 2, y: r.top + r.height / 2, active: el.classList.contains("active") }); })()')
    if (!raw || raw === 'null') return false
    const p = JSON.parse(raw)
    if (!p.active) {
      await mouse('mouseMoved', p.x, p.y)
      await mouse('mousePressed', p.x, p.y)
      await sleep(60)
      await mouse('mouseReleased', p.x, p.y)
      await sleep(350)
    }
    const active = await ev2('[...document.querySelectorAll(".seg .seg-item")].some((e) => (e.textContent || "").trim() === ' + JSON.stringify(label) + ' && e.classList.contains("active"))')
    if (active) return true
  }
  return false
}
async function longPress(sel, text, hold) {
  const p = await center(sel, text)
  if (!p) return false
  await mouse('mouseMoved', p.x, p.y)
  await mouse('mousePressed', p.x, p.y)
  await sleep(hold || 700)
  await mouse('mouseReleased', p.x, p.y)
  await sleep(300)
  return true
}
/** 用真实触摸事件长按拖拽分类卡片，返回拖拽过程中/释放前的目标高亮信息 */
async function touchDrag(fromText, toText, hold) {
  const a = await center('.cat-card', fromText)
  const b = await center('.cat-card', toText)
  if (!a || !b) return null
  const point = function (x, y) { return { x, y, id: 1, radiusX: 4, radiusY: 4, force: 1 } }
  await c.send('Input.dispatchTouchEvent', { type: 'touchStart', touchPoints: [point(a.x, a.y)] })
  await sleep(hold || 850)
  let mid = null
  for (let i = 1; i <= 8; i++) {
    const x = a.x + ((b.x - a.x) * i) / 8
    const y = a.y + ((b.y - a.y) * i) / 8
    await c.send('Input.dispatchTouchEvent', { type: 'touchMove', touchPoints: [point(x, y)] })
    await sleep(90)
    if (i === 7) {
      mid = await ev2('JSON.stringify({ dragging: document.querySelectorAll(".cat-card.dragging").length, drop: document.querySelectorAll(".cat-card.drop-target").length })')
    }
  }
  await c.send('Input.dispatchTouchEvent', { type: 'touchEnd', touchPoints: [] })
  await sleep(700)
  return mid ? JSON.parse(mid) : null
}
async function setFieldText(label, value) {
  return ev2('(() => { const fields = [...document.querySelectorAll(\'.field\')]; const f = fields.find((x) => { const l = (x.querySelector(\'.field-label\') || {}).textContent || \'\'; return l.trim().split(\'*\')[0].trim() === ' + JSON.stringify(label) + '; }); if (!f) return \'NO_FIELD\'; const el = f.querySelector(\'input,textarea,select\'); if (!el) return \'NO_INPUT\'; const proto = el.tagName === \'TEXTAREA\' ? window.HTMLTextAreaElement.prototype : window.HTMLInputElement.prototype; const setter = Object.getOwnPropertyDescriptor(proto, \'value\').set; setter.call(el, ' + JSON.stringify(value) + '); el.dispatchEvent(new Event(\'input\', { bubbles: true })); el.dispatchEvent(new Event(\'change\', { bubbles: true })); return \'OK\'; })()')
}
async function readState() {
  return JSON.parse(await ev2('window.GuinaNative.loadData()'))
}
function adb(shell) {
  try { return execSync('"' + ADB + '" ' + shell, { encoding: 'utf8', timeout: 20000 }) } catch (e) { return String((e && e.stdout) || '') }
}
function orderOf(state) {
  return state.categories.slice().sort(function (a, b) {
    const sa = a.pinned || a.builtin ? 0 : 1
    const sb = b.pinned || b.builtin ? 0 : 1
    if (sa !== sb) return sa - sb
    return (a.order || 0) - (b.order || 0)
  }).map(function (x) { return x.name })
}
async function cardTexts() {
  return JSON.parse(await ev2('JSON.stringify([...document.querySelectorAll(\'.sticky-card\')].map((b) => ({ text: b.innerText, kind: b.getAttribute(\'data-kind\') })))'))
}
async function itemNames() {
  return JSON.parse(await ev2('JSON.stringify([...document.querySelectorAll(\'.item-card .item-name\')].map((e) => (e.innerText || \'\').trim()))'))
}
async function closeSheetIfOpen() {
  if (await sheetOpen()) {
    const p = await center('.sheet-head button')
    if (p) { await mouse('mouseMoved', p.x, p.y); await mouse('mousePressed', p.x, p.y); await mouse('mouseReleased', p.x, p.y); await sleep(300) }
  }
}
async function goHome() {
  await tap('.tab', '首页')
  await sleep(600)
}
async function openSettings() {
  await tap('.tab', '设置')
  await sleep(700)
}
async function tapRowButton(title) {
  const raw = await ev2('(() => { const rows = [...document.querySelectorAll(\'.row\')]; const row = rows.find((r) => ((r.querySelector(\'.row-title\') || {}).textContent || \'\').includes(' + JSON.stringify(title) + ')); if (!row) return \'null\'; const b = row.querySelector(\'button\'); if (!b) return \'null\'; b.scrollIntoView({ block: \'center\' }); const r = b.getBoundingClientRect(); return JSON.stringify({ x: r.left + r.width / 2, y: r.top + r.height / 2 }); })()')
  if (!raw || raw === 'null') return false
  const p = JSON.parse(raw)
  await mouse('mouseMoved', p.x, p.y)
  await mouse('mousePressed', p.x, p.y)
  await mouse('mouseReleased', p.x, p.y)
  await sleep(400)
  return true
}
async function createCategory(name) {
  await tapText('+ 新建分类')
  await waitForSheet()
  await setFieldText('分类名称', name)
  await tapExact('保存')
  await sleep(800)
  return !(await sheetOpen())
}
async function waitForSheet() {
  for (let i = 0; i < 30; i++) { if (await sheetOpen()) return true; await sleep(150) }
  return false
}
async function waitFor(expr, ms, label) {
  const end = Date.now() + ms
  while (Date.now() < end) {
    try { if (await ev2(expr)) return true } catch (e) {}
    await sleep(200)
  }
  console.log('WAIT_TIMEOUT ' + (label || expr))
  return false
}

// ---------- 准备：跳过引导 ----------
if ((await bodyText()).includes('跳过')) {
  await tapText('跳过')
  await sleep(1200)
}
await waitFor('!!document.querySelector(".tabbar")', 10000, 'tabbar')
await goHome()

// ---------- A. 提醒卡：循环显示「工作日 09:00」，一次性不显示 ISO ----------
async function createReminder(opts) {
  await tap('.sticky-col[data-kind="reminder"] .sticky-col-add')
  await waitForSheet()
  await setFieldText('标题', opts.title)
  await setFieldText('内容', opts.content)
  if (opts.repeat) {
    await clickSeg('循环提醒')
    await sleep(300)
    await clickSeg(opts.repeat)
    await sleep(300)
    await setFieldText('提醒时间', opts.time)
  }
  if (opts.importAlarm) await tapExact('保存并导入闹钟')
  else await tapExact('保存')
  await sleep(900)
  return !(await sheetOpen())
}
check('A1 创建一次性提醒', await createReminder({ title: '一次性提醒', content: '十分钟后看一眼锅' }))
let cards = await cardTexts()
const onceCard = cards.filter(function (x) { return x.text.indexOf('一次性提醒') >= 0 })[0]
check('A2 一次性提醒卡片存在', Boolean(onceCard), JSON.stringify(cards.map(function (x) { return x.text.slice(0, 30) })))
const ISO_RE = /[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}\.[0-9]{3}Z/
check('A3 一次性提醒卡片不显示 ISO 时间串', Boolean(onceCard) && !ISO_RE.test(onceCard.text), onceCard && onceCard.text.replace(/\n/g, ' / '))
let st = await readState()
const onceSticky = st.stickies.filter(function (s) { return s.title === '一次性提醒' })[0]
check('A4 一次性提醒保存了提醒时间', Boolean(onceSticky && onceSticky.kind === 'reminder' && onceSticky.remindAt), JSON.stringify(onceSticky && { kind: onceSticky.kind, remindAt: onceSticky.remindAt }))

check('A5 创建工作日循环提醒', await createReminder({ title: '吃药提醒', content: '每天早晚各吃一次降压药', repeat: '工作日', time: '09:00' }))
cards = await cardTexts()
const repeatCard = cards.filter(function (x) { return x.text.indexOf('吃药提醒') >= 0 })[0]
check('A6 循环提醒卡片显示「工作日 09:00」', Boolean(repeatCard) && repeatCard.text.indexOf('工作日') >= 0 && repeatCard.text.indexOf('09:00') >= 0, repeatCard && repeatCard.text.replace(/\n/g, ' / '))
check('A7 循环提醒卡片不再显示 ISO 时间串', Boolean(repeatCard) && !ISO_RE.test(repeatCard.text), repeatCard && repeatCard.text.replace(/\n/g, ' / '))
st = await readState()
const repeatSticky = st.stickies.filter(function (s) { return s.title === '吃药提醒' })[0]
check('A8 循环提醒保存了 repeat 规则', Boolean(repeatSticky && repeatSticky.repeat && repeatSticky.repeat.kind === 'weekdays' && repeatSticky.repeat.time === '09:00'), JSON.stringify(repeatSticky && repeatSticky.repeat))
await c.shot(OUT + '/115-A-reminder-repeat.png').catch(function () {})

// ---------- B. 系统闹钟：工作日重复（EXTRA_DAYS） ----------
check('B1 创建并导入工作日闹钟', await (async function () {
  await tap('.sticky-col[data-kind="reminder"] .sticky-col-add')
  await waitForSheet()
  await setFieldText('标题', '工作日闹钟测试')
  await setFieldText('内容', '工作日早上提醒喝水')
  await clickSeg('循环提醒')
  await sleep(300)
  await clickSeg('工作日')
  await sleep(300)
  await setFieldText('提醒时间', '09:30')
  adb('logcat -c')
  const okTap = await tapExact('保存并导入闹钟')
  await sleep(1500)
  const savedState = await readState()
  const savedReminder = savedState.stickies.filter(function (s) { return s.title === '工作日闹钟测试' })[0]
  return okTap && !(await sheetOpen()) && Boolean(savedReminder && savedReminder.repeat && savedReminder.repeat.kind === 'weekdays')
})())
check('B2 导入闹钟 toast 正确', await waitText('已保存，并导入到系统闹钟', 5000))
let clockLog = ''
let alarmLine = ''
for (let i = 0; i < 20 && !alarmLine; i++) {
  await sleep(500)
  clockLog = adb('logcat -d -t 2000')
  const alarmMatches = clockLog.match(/[^\n]*daysOfWeek=[^\n]*/g) || []
  if (alarmMatches.length) alarmLine = alarmMatches[alarmMatches.length - 1]
}
const clockLine = (clockLog.match(/[^\n]*HandleSetApiCalls[^\n]*/g) || [])[0] || ''
check('B3 系统时钟收到导入请求', clockLine.indexOf('HandleSetApiCalls') >= 0, clockLine.slice(0, 200))
check('B4 系统闹钟按工作日重复（daysOfWeek 周一到周五）', /daysOfWeek=\[M T W Th F\]/.test(alarmLine), alarmLine.slice(0, 300))
check('B5 系统闹钟时间与提醒一致（09:30）', /hour=9/.test(alarmLine) && /minute=30/.test(alarmLine), alarmLine.slice(0, 300))
adb('shell am start -n com.guina.app.debug/com.guina.app.MainActivity')
await sleep(2500)
await waitFor('document.body.innerText.length > 0', 8000, 'back to app')
await goHome()

// ---------- C. 分类长按拖拽：同组排序 / 跨组拒绝 / 内置互调 ----------
await createCategory('拖拽分类甲')
await sleep(300)
await createCategory('拖拽分类乙')
await sleep(500)
let cats = await readState()
let names = orderOf(cats)
check('C1 新建两个普通分类排在普通区末尾', names.indexOf('拖拽分类甲') > names.indexOf('食品') && names.indexOf('拖拽分类乙') === names.length - 1, names.join(' | '))
const dragMid = await touchDrag('拖拽分类甲', '拖拽分类乙')
check('C2 长按拖动时源卡与目标卡高亮', Boolean(dragMid && dragMid.dragging === 1 && dragMid.drop === 1), JSON.stringify(dragMid))
check('C3 同组拖拽提示顺序已调整', await waitText('分类顺序已调整', 4000))
cats = await readState()
names = orderOf(cats)
check('C4 同组拖拽后两张卡位置互换', names.indexOf('拖拽分类乙') < names.indexOf('拖拽分类甲'), names.join(' | '))
check('C5 内置分类顺序不受影响', names.slice(0, 4).join('|') === '图书|物品|食品|药品', names.slice(0, 4).join('|'))
const ordersBefore = {}
cats.categories.forEach(function (x) { ordersBefore[x.id] = x.order })
await touchDrag('拖拽分类甲', '图书')
await sleep(500)
check('C6 普通分类拖到内置分类被拒绝并提示', await waitText('普通分类只能和普通分类换位置', 4000))
cats = await readState()
let sameOrder = true
cats.categories.forEach(function (x) { if (ordersBefore[x.id] !== x.order) sameOrder = false })
check('C7 跨组拖拽不改变排序', sameOrder, JSON.stringify(cats.categories.map(function (x) { return x.name + ':' + x.order })))
await touchDrag('药品', '图书')
check('C8 内置分类之间可拖拽排序', await waitText('分类顺序已调整', 4000))
cats = await readState()
names = orderOf(cats)
check('C9 内置分类顺序调整生效', names[0] === '药品' && names[1] === '图书', names.join(' | '))
await c.shot(OUT + '/115-C-category-drag.png').catch(function () {})

// ---------- D. 排序（升/降循环）与存放时间字段 ----------
await tap('.cat-card', '食品')
await waitFor('!!document.querySelector(".sort-chips")', 8000, 'sort chips')
const chipsRaw = await ev2('JSON.stringify([...document.querySelectorAll(\'.sort-chips button\')].map((b) => ({ id: b.getAttribute(\'data-testid\'), text: (b.innerText || \'\').replace(/[\\s\u2191\u2193]/g, \'\'), dir: b.getAttribute(\'data-direction\'), selected: b.classList.contains(\'selected\') })))')
const chips = JSON.parse(chipsRaw)
check('D1 食品提供三种排序按钮', chips.length === 3 && chips.map(function (x) { return x.id }).join(',') === 'sort-name,sort-storedAt,sort-expiresAt', chipsRaw)
check('D2 默认按名称升序', chips[0].id === 'sort-name' && chips[0].dir === 'asc' && chips[0].selected, JSON.stringify(chips[0]))

async function addFood(name, storedAt, expiresAt, location) {
  await tapText('条目')
  await waitForSheet()
  await setFieldText('食品名称', name)
  await setFieldText('地点名称', location)
  await setFieldText('存放时间', storedAt)
  await setFieldText('过期时间', expiresAt)
  await tapExact('保存')
  await sleep(900)
  return !(await sheetOpen())
}
check('D3 新建食品 B食品', await addFood('B食品', '2026-11-01', '2026-12-01', '冰箱'))
check('D4 新建食品 A食品', await addFood('A食品', '2026-11-10', '2026-11-20', '冰箱'))
let namesFood = await itemNames()
check('D5 名称升序 A 在 B 前', namesFood[0] === 'A食品' && namesFood[1] === 'B食品', JSON.stringify(namesFood))
const foodText = await ev2('document.body.innerText')
check('D6 食品卡片显示存放时间（存于 2026-11-01）', foodText.indexOf('存于 2026-11-01') >= 0 || foodText.indexOf('2026-11-01') >= 0, foodText.slice(0, 80))
await tap('[data-testid="sort-name"]')
await sleep(500)
namesFood = await itemNames()
check('D7 再点名称变降序', namesFood[0] === 'B食品' && namesFood[1] === 'A食品', JSON.stringify(namesFood))
await tap('[data-testid="sort-storedAt"]')
await sleep(500)
namesFood = await itemNames()
const dirStored = await ev2('document.querySelector(\'[data-testid="sort-storedAt"]\').getAttribute(\'data-direction\')')
check('D8 按存放时间第一次升序（早存放在前）', dirStored === 'asc' && namesFood[0] === 'B食品' && namesFood[1] === 'A食品', dirStored + ' ' + JSON.stringify(namesFood))
await tap('[data-testid="sort-storedAt"]')
await sleep(500)
namesFood = await itemNames()
const dirStored2 = await ev2('document.querySelector(\'[data-testid="sort-storedAt"]\').getAttribute(\'data-direction\')')
check('D9 再点存放时间变降序', dirStored2 === 'desc' && namesFood[0] === 'A食品' && namesFood[1] === 'B食品', dirStored2 + ' ' + JSON.stringify(namesFood))
await tap('[data-testid="sort-expiresAt"]')
await sleep(500)
namesFood = await itemNames()
const dirExp = await ev2('document.querySelector(\'[data-testid="sort-expiresAt"]\').getAttribute(\'data-direction\')')
check('D10 按过期时间第一次升序（早到期在前）', dirExp === 'asc' && namesFood[0] === 'A食品' && namesFood[1] === 'B食品', dirExp + ' ' + JSON.stringify(namesFood))
await tap('[data-testid="sort-expiresAt"]')
await sleep(500)
namesFood = await itemNames()
const dirExp2 = await ev2('document.querySelector(\'[data-testid="sort-expiresAt"]\').getAttribute(\'data-direction\')')
check('D11 再点过期时间变降序', dirExp2 === 'desc' && namesFood[0] === 'B食品' && namesFood[1] === 'A食品', dirExp2 + ' ' + JSON.stringify(namesFood))
await c.shot(OUT + '/115-D-food-sorted.png').catch(function () {})

// 图书 / 物品：只有存放时间，没有过期时间
await tap('.tab', '首页')
await sleep(600)
await tap('.cat-card', '图书')
await waitForSheet().catch(function () {})
await tapText('条目')
await waitForSheet()
const bookSheet = await sheetText()
check('D12 图书表单只有存放时间、没有过期时间', bookSheet.indexOf('存放时间') >= 0 && bookSheet.indexOf('过期时间') < 0, bookSheet.replace(/\n/g, ' / ').slice(0, 160))
await tapExact('取消')
await sleep(400)
await tap('.tab', '首页')
await sleep(600)
await tap('.cat-card', '物品')
await waitForSheet().catch(function () {})
await tapText('条目')
await waitForSheet()
const itemSheet = await sheetText()
check('D13 物品表单只有存放时间、没有过期时间', itemSheet.indexOf('存放时间') >= 0 && itemSheet.indexOf('过期时间') < 0, itemSheet.replace(/\n/g, ' / ').slice(0, 160))
await tapExact('取消')
await sleep(400)

// ---------- E. 扫码绑定：后置主摄、卡片面板、等比铺满 ----------
await closeSheetIfOpen()
await ev2('(() => { window.__cams = []; const cv = document.createElement("canvas"); cv.width = 1280; cv.height = 720; const ctx = cv.getContext("2d"); ctx.fillStyle = "#334155"; ctx.fillRect(0, 0, 1280, 720); ctx.fillStyle = "#e2e8f0"; ctx.fillRect(420, 120, 440, 440); window.__fakeStream = typeof cv.captureStream === "function" ? cv.captureStream(10) : null; const md = navigator.mediaDevices; md.getUserMedia = function (constraints) { window.__cams.push(constraints); return window.__fakeStream ? Promise.resolve(window.__fakeStream) : Promise.reject(new Error("test-camera-unavailable")); }; return "OK"; })()')
await goHome()
await openSettings()
check('E1 打开数据同步', await tapRowButton('数据同步'))
await waitForSheet()
await tapText('扫码绑定')
await sleep(1200)
const cams = JSON.parse(await ev2('JSON.stringify(window.__cams || [])'))
check('E2 扫码默认请求后置主摄', Boolean(cams.length >= 1 && cams[0].video && cams[0].video.facingMode && cams[0].video.facingMode.exact === 'environment'), JSON.stringify(cams[0] || null))
check('E3 扫码相机理想分辨率 1920x1080', Boolean(cams.length >= 1 && cams[0].video.width && cams[0].video.width.ideal === 1920 && cams[0].video.height && cams[0].video.height.ideal === 1080), JSON.stringify(cams[0] && cams[0].video))
check('E4 扫码改为卡片面板 scan-panel', await waitFor('!!document.querySelector(".scan-panel")', 8000, 'scan panel'))
const videoFit = await ev2('(() => { const v = document.querySelector(\'.scan-video\'); if (!v) return \'\'; const s = getComputedStyle(v); return s.objectFit; })()')
check('E5 扫码预览等比铺满取景框', String(videoFit).indexOf('cover') >= 0, videoFit)
const scanBtnList = JSON.parse(await ev2('JSON.stringify([...document.querySelectorAll(".scan-panel button")].map((b) => (b.innerText || "").trim()))'))
const torchCap = Boolean(await ev2('(() => { const v = document.querySelector(".scan-video"); if (!v || !v.srcObject) return false; const t = v.srcObject.getVideoTracks()[0]; const cap = t && t.getCapabilities ? t.getCapabilities() : null; return Boolean(cap && cap.torch); })()').catch(function () { return false }))
check('E6 面板有取消扫码与手电筒按钮（无手电筒设备隐藏）', scanBtnList.some(function (t) { return t.indexOf('取消扫码') >= 0 }) && (!torchCap || scanBtnList.some(function (t) { return t.indexOf('手电筒') >= 0 })), JSON.stringify(scanBtnList) + ' torchCap=' + torchCap)
await c.shot(OUT + '/115-E-scan-panel.png').catch(function () {})
await tapText('取消扫码')
await sleep(500)

await c.shot(OUT + '/115-final.png').catch(function () {})
summary()
