import { check, ev, bodyText, shot, waitFor, waitText, clickText, clickExact, setInput, setField, sheetOpen, sheetText, closeSheet, goTab, summary, sleep } from './mobile-e2e.mjs'

const S = (t) => console.log('[step] ' + t)
function clickIn(sel, name) {
  const js = "(() => { const el = [...document.querySelectorAll(" + JSON.stringify(sel) + ")].find(e => (e.innerText||'').includes(" + JSON.stringify(name) + ")); if (!el) return 'NOTFOUND'; el.click(); return 'OK'; })()"
  return ev(js)
}
const sheetTitleText = () => ev("(document.querySelector('.sheet-title')||{}).innerText || ''")
const setSearch = (p, v) => ev("(() => { const el = [...document.querySelectorAll('input')].find(i => (i.placeholder||'').includes(" + JSON.stringify(p) + ")); if (!el) return 'NO_INPUT'; const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set; setter.call(el, " + JSON.stringify(v) + "); el.dispatchEvent(new Event('input', { bubbles: true })); return 'OK'; })()")
const clickBell = () => ev("(() => { const b = [...document.querySelectorAll('.icon-btn')].find(x => (x.innerText||'').includes('🔔')); if (!b) return 'NO_BELL'; b.click(); return 'OK'; })()")
const dtLocal = (offsetMs) => { const d = new Date(Date.now() + offsetMs); const p = (n) => String(n).padStart(2, '0'); return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate()) + 'T' + p(d.getHours()) + ':' + p(d.getMinutes()) }

if ((await bodyText()).includes('跳过')) await clickText('跳过')
await waitText('我的分类')

// ================= T1 新建便签 =================
S('T1 新建便签')
check('T1.1 点便签栏 +', (await ev("(() => { const b = document.querySelector('.sticky-col[data-kind=\"note\"] .sticky-col-add'); if (!b) return 'NO'; b.click(); return 'OK'; })()")) === 'OK')
check('T1.2 表单标题', await waitFor(async () => (await sheetTitleText()) === '新建便签'), await sheetTitleText())
check('T1.3 填标题', (await setField('标题', '聚餐安排')) === 'OK')
check('T1.4 填内容', (await setField('内容', '明天吃饭记得订位')) === 'OK')
check('T1.5 点置顶开关', (await ev("(() => { const s = document.querySelector('.sheet-panel .switch'); if (!s) return 'NO'; s.click(); return 'OK'; })()")) === 'OK')
check('T1.6 保存便签', (await clickText('保存', '.sheet-panel')) === 'OK')
check('T1.7 便签卡出现', await waitFor(async () => (await bodyText()).includes('聚餐安排')))
check('T1.8 显示置顶标记', (await bodyText()).includes('置顶'))
check('T1.9 便签计数 1', (await ev("(document.querySelector('.sticky-col[data-kind=\"note\"] .sticky-col-count')||{}).innerText")) === '1')
await shot('p20-sticky-note')

// ================= T2 便签详情操作 =================
S('T2 便签详情')
check('T2.1 打开便签详情', (await clickIn('.sticky-card', '聚餐安排')) === 'OK' && await waitFor(async () => await sheetOpen()))
const dt = await sheetText()
check('T2.2 详情含内容', dt.includes('明天吃饭记得订位'))
check('T2.3 详情含置顶', dt.includes('置顶'))
check('T2.4 标记完成', (await clickText('标记完成', '.sheet-panel')) === 'OK' && await waitFor(async () => (await sheetText()).includes('已完成')))
check('T2.5 取消置顶', (await clickText('取消置顶', '.sheet-panel')) === 'OK' && await waitFor(async () => await ev("([...document.querySelectorAll('.sheet-panel .chips button')].some(b => (b.innerText||'').trim() === '置顶'))")))
check('T2.6 标为未完成', (await clickText('标为未完成', '.sheet-panel')) === 'OK' && await waitFor(async () => !(await sheetText()).includes('已完成')))
await shot('p21-sticky-detail')
await closeSheet()

// ================= T3 便签搜索 =================
S('T3 便签搜索')
check('T3.1 搜内容「吃」', (await setSearch('搜便签标题或内容', '吃')) === 'OK' && await waitFor(async () => (await bodyText()).includes('聚餐安排')))
check('T3.2 搜内容「订位」', (await setSearch('搜便签标题或内容', '订位')) === 'OK' && await waitFor(async () => (await bodyText()).includes('聚餐安排')))
check('T3.3 搜标题「聚餐」', (await setSearch('搜便签标题或内容', '聚餐')) === 'OK' && await waitFor(async () => (await bodyText()).includes('聚餐安排')))
check('T3.4 无匹配提示', (await setSearch('搜便签标题或内容', '不存在zzz')) === 'OK' && await waitFor(async () => (await bodyText()).includes('没有匹配')))
await shot('p22-sticky-search')
check('T3.5 清空搜索', (await setSearch('搜便签标题或内容', '')) === 'OK' && await waitFor(async () => (await bodyText()).includes('聚餐安排')))
check('T3.6 顶部搜索不含便签', await (async () => { await goTab('搜索'); await setSearch('搜索物品、存放位置、备注', '订位'); await sleep(500); const t = await bodyText(); return t.includes('没有找到') && !t.includes('聚餐安排') })())
await goTab('首页')

// ================= T4 编辑便签 =================
S('T4 编辑便签')
await clickIn('.sticky-card', '聚餐安排')
await waitFor(async () => await sheetOpen())
check('T4.1 点编辑', (await clickText('编辑', '.sheet-panel')) === 'OK' && await waitFor(async () => (await sheetTitleText()) === '编辑便签'), await sheetTitleText())
check('T4.2 改内容', (await setField('内容', '明天吃饭记得订位（已确认）')) === 'OK')
check('T4.3 保存修改', (await clickText('保存', '.sheet-panel')) === 'OK')
check('T4.4 内容已更新', await waitFor(async () => (await bodyText()).includes('（已确认）')))
await shot('p23-sticky-edited')

// ================= T5 提醒便签 =================
S('T5 新建提醒便签')
const remindAt = await ev("(() => { const d = new Date(Date.now() + 135000); const p = (n) => String(n).padStart(2, '0'); return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate()) + 'T' + p(d.getHours()) + ':' + p(d.getMinutes()); })()")
check('T5.1 点提醒栏 +', (await ev("(() => { const b = document.querySelector('.sticky-col[data-kind=\"reminder\"] .sticky-col-add'); if (!b) return 'NO'; b.click(); return 'OK'; })()")) === 'OK')
check('T5.2 表单标题', await waitFor(async () => (await sheetTitleText()) === '新建提醒便签'), await sheetTitleText())
check('T5.3 填标题', (await setField('标题', '吃药提醒')) === 'OK')
check('T5.4 填内容', (await setField('内容', '晚上八点吃降压药')) === 'OK')
check('T5.5 设置提醒时间', (await setField('提醒时间', remindAt)) === 'OK', remindAt)
check('T5.6 保存提醒', (await clickText('保存', '.sheet-panel')) === 'OK')
check('T5.7 提醒卡出现', await waitFor(async () => (await bodyText()).includes('吃药提醒')))
check('T5.8 提醒计数 1', (await ev("(document.querySelector('.sticky-col[data-kind=\"reminder\"] .sticky-col-count')||{}).innerText")) === '1')
check('T5.9 卡片显示时间', (await bodyText()).includes('今天'))
await shot('p24-reminder-card')
console.log('[info] remindAt=' + remindAt)

// ================= T6 等待提醒到达 =================
S('T6 等待提醒到达')
let popup = false
for (let i = 0; i < 90; i++) {
  if ((await bodyText()).includes('提醒时间到')) { popup = true; break }
  await sleep(2000)
}
check('T6.1 到点弹出提醒', popup)
if (popup) {
  const pt = await bodyText()
  check('T6.2 提醒显示标题和内容', pt.includes('吃药提醒') && pt.includes('晚上八点吃降压药'))
  check('T6.3 三个操作按钮', pt.includes('稍后提醒') && pt.includes('标记完成') && pt.includes('知道了'))
  await shot('p25-reminder-popup')
  check('T6.4 点知道了', (await clickText('知道了', '.reminder-card')) === 'OK')
  check('T6.5 弹层关闭', await waitFor(async () => !(await bodyText()).includes('提醒时间到')))
}

// ================= T7 到期通知 =================
S('T7 到期通知')
check('T7.1 通知按钮', (await clickBell()) === 'OK')
check('T7.2 通知面板打开', await waitFor(async () => await sheetOpen()))
const nt = await sheetText()
check('T7.3 通知面板有分类页签', nt.includes('食品') && nt.includes('药品'))
check('T7.4 药品页有内容', nt.includes('过期') || nt.includes('还剩'))
await shot('p26-notifications')
check('T7.5 全部标为已读', (await clickText('全部标为已读', '.sheet-panel')) === 'OK')
check('T7.6 已读后可删除', (await clickText('删除已读', '.sheet-panel')) === 'OK' && await waitFor(async () => !(await sheetText()).includes('还剩 6 天')))
await shot('p27-notifications-cleared')
await closeSheet()

// ================= T8 手动备份 =================
S('T8 手动备份')
await goTab('设置')
await sleep(600)
console.log('[debug] tab=' + await ev("(document.querySelector('.tab.active')||{}).innerText") + ' btns=' + await ev("JSON.stringify([...document.querySelectorAll('button')].map(b => (b.innerText||'').trim()).filter(Boolean))"))
const manageRes = await ev("(() => { const row = [...document.querySelectorAll('.row')].find(r => ((r.querySelector('.row-title')||{}).innerText||'').trim() === '手动备份'); if (!row) return 'NO_ROW'; const b = row.querySelector('button'); if (!b) return 'NO_BTN'; b.click(); return 'OK'; })()")
console.log('[debug] manageClick=' + manageRes)
check('T8.1 打开备份', manageRes === 'OK' && await waitFor(async () => (await sheetTitleText()).length > 0), manageRes + '/' + (await sheetTitleText()))
check('T8.2 备份面板标题', (await sheetTitleText()) === '手动备份', await sheetTitleText())
check('T8.3 填备份名', (await setInput("document.querySelector('.sheet-panel input')", '自动化测试备份')) === 'OK')
check('T8.4 新建备份', (await clickText('备份', '.sheet-panel')) === 'OK')
check('T8.5 列表出现备份', await waitFor(async () => (await sheetText()).includes('还原')))
check('T8.6 还原备份', (await ev("(() => { const b = [...document.querySelectorAll('.sheet-panel button.mini-btn')].find(x => ((x.innerText||'').trim() === '还原')); if (!b) return 'NO_BTN'; b.click(); return 'OK'; })()")) === 'OK')
check('T8.7 确认还原', await waitFor(async () => await ev("!!document.querySelector('.confirm-card')")))
check('T8.8 点确认还原', (await clickText('还原', '.confirm-card')) === 'OK')
check('T8.9 还原成功提示', await waitFor(async () => (await bodyText()).includes('已还原')))
await shot('p28-backups')
// 还原成功后弹层会自动关闭，重新打开备份面板确认备份仍在
const reopenRes = await ev("(() => { const row = [...document.querySelectorAll('.row')].find(r => ((r.querySelector('.row-title')||{}).innerText||'').trim() === '手动备份'); if (!row) return 'NO_ROW'; const b = row.querySelector('button'); if (!b) return 'NO_BTN'; b.click(); return 'OK'; })()")
check('T8.10 备份仍在', reopenRes === 'OK' && await waitFor(async () => (await ev("document.querySelectorAll('.sheet-panel .mini-btn.danger').length")) === 1))
check('T8.11 删除备份', (await ev("(() => { const b = document.querySelector('.sheet-panel .mini-btn.danger'); if (!b) return 'NO'; b.click(); return 'OK'; })()")) === 'OK')
check('T8.12 确认删除', await waitFor(async () => await ev("!!document.querySelector('.confirm-card')")))
await clickText('删除', '.confirm-card')
check('T8.13 备份已删除', await waitFor(async () => (await ev("document.querySelectorAll('.sheet-panel .mini-btn.danger').length")) === 0))
await closeSheet()

// ================= T9 设置 =================
S('T9 设置')
check('T9.1 设置页有外观', (await bodyText()).includes('外观'))
check('T9.2 切深色', (await clickText('深色', '.seg')) === 'OK' && await waitFor(async () => (await ev("document.documentElement.getAttribute('data-theme')")) === 'dark'))
await shot('p29-dark')
check('T9.3 切回浅色', (await clickText('浅色', '.seg')) === 'OK' && await waitFor(async () => (await ev("document.documentElement.getAttribute('data-theme')")) !== 'dark'))
check('T9.4 版本号 1.1.8', (await bodyText()).includes('版本 1.1.8'))
check('T9.5 设备信息', (await bodyText()).includes('设备信息'))
await shot('p30-settings')

// ================= T10 导出（触发 SAF） =================
S('T10 导出数据')
check('T10.1 点导出', (await clickText('导出')) === 'OK')
await sleep(1500)
console.log('[info] after export: webview body tail=' + (await bodyText()).slice(-120).replace(/\n/g, ' / '))
await shot('p31-export-saf')
summary()