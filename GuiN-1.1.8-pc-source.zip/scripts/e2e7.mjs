import { listTargets, connect, waitFor } from './cdp.mjs'

const results = []
function check(name, ok, detail) {
  results.push({ name: name, ok: !!ok, detail: detail === undefined ? '' : String(detail) })
  console.log((ok ? 'PASS' : 'FAIL') + ' | ' + name + (detail === undefined || detail === '' ? '' : ' | ' + detail))
}
function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms) }) }
async function waitPort(port, ms, filter) {
  const end = Date.now() + ms
  while (Date.now() < end) {
    try {
      const t = await listTargets(port)
      if (t && t.length) {
        if (!filter) return t
        const found = t.filter(function (x) { return x.url.indexOf(filter) >= 0 })
        if (found.length) return found
      }
    } catch (e) {}
    await sleep(250)
  }
  return null
}

const targets = await waitPort(9222, 25000, 'index.html')
if (!targets) { console.log('NO_CDP'); process.exit(2) }
const client = await connect(9222, 'index.html')
const ev = function (expr) { return client.evaluate(expr) }
const shot = function (name) { return Promise.race([client.shot('.tmp-shots/' + name + '.png').catch(function () { return null }), sleep(9000)]) }

const INSTALL = [
  'window.__t = {',
  '  all: function (id) { return Array.prototype.filter.call(document.querySelectorAll("[data-testid]"), function (e) { return e.getAttribute("data-testid") === id }) },',
  '  q: function (id, i) { return window.__t.all(id)[i || 0] || null },',
  '  count: function (id) { return window.__t.all(id).length },',
  '  texts: function (id) { return window.__t.all(id).map(function (e) { return e.innerText }) },',
  '  has: function (id) { return !!window.__t.q(id) },',
  '  text: function (id, i) { var e = window.__t.q(id, i); return e ? e.innerText : "" },',
  '  click: function (id, i) { var el = window.__t.q(id, i); if (!el) throw new Error("missing " + id); el.click(); return true },',
  '  clickText: function (id, needle) { var list = window.__t.all(id); for (var k = 0; k < list.length; k++) { if (list[k].innerText.indexOf(needle) >= 0) { list[k].click(); return true } } throw new Error("no " + id + " with " + needle) },',
  '  set: function (id, v) {',
  '    var el = window.__t.q(id)',
  '    if (!el) throw new Error("missing " + id)',
  '    var proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : el instanceof HTMLSelectElement ? HTMLSelectElement.prototype : HTMLInputElement.prototype',
  '    Object.getOwnPropertyDescriptor(proto, "value").set.call(el, v)',
  '    el.dispatchEvent(new Event("input", { bubbles: true }))',
  '    el.dispatchEvent(new Event("change", { bubbles: true }))',
  '    return true',
  '  },',
  '  back: function () { var btns = Array.prototype.slice.call(document.querySelectorAll("button")); for (var k = 0; k < btns.length; k++) { if (btns[k].innerText.indexOf("返回") >= 0) { btns[k].click(); return true } } return false },',
  '  state: function () { return window.guina.getState() },',
  '}',
  'true'
].join(String.fromCharCode(10))

const MEASURE = function (kind) {
  return '(' + function (k) {
    const col = document.querySelector('[data-testid="sticky-col-' + k + '"]')
    const board = col ? col.querySelector('.sticky-board') : null
    if (!board) return { missing: true }
    const bs = getComputedStyle(board)
    const br = board.getBoundingClientRect()
    const cards = Array.prototype.slice.call(board.querySelectorAll('[data-testid="sticky-card"]'))
    const rects = cards.map(function (c) { return c.getBoundingClientRect() })
    const tops = rects.map(function (r) { return Math.round(r.top) })
    const uniqueTops = tops.filter(function (t, i) { return tops.indexOf(t) === i })
    const visibleRows = uniqueTops.filter(function (t) { return t >= br.top - 1 && t + 40 <= br.bottom }).length
    return {
      display: bs.display,
      tracks: bs.gridTemplateColumns.split(' ').length,
      cards: cards.length,
      scrollHeight: board.scrollHeight,
      clientHeight: board.clientHeight,
      scrollWidth: board.scrollWidth,
      clientWidth: board.clientWidth,
      firstRowSameTop: rects.length >= 2 ? Math.abs(rects[0].top - rects[1].top) < 2 : false,
      thirdCardNextRow: rects.length >= 3 ? Math.abs(rects[0].top - rects[2].top) > 40 : false,
      fourthCardNextRow: rects.length >= 4 ? Math.abs(rects[0].top - rects[3].top) > 5 : false,
      visibleRows: visibleRows,
      cardWidth: rects.length ? Math.round(rects[0].width) : 0
    }
  }.toString() + ')(' + JSON.stringify(kind) + ')'
}

await waitFor(client, '!!document.body', 20000, 'body')
await client.evaluate(INSTALL)
await sleep(1200)
if (await ev("__t.has('onboarding-skip')")) {
  await ev("__t.click('onboarding-skip')")
  await sleep(700)
}

// ---- 1. 便签标题 + 超长内容省略号 + 点开看全文 ----
const LONG = '很长的便签内容'.repeat(20)
await ev("__t.click('sticky-add-note')")
await waitFor(client, "!!document.querySelector('[data-testid=sticky-content]')", 8000, 'note form')
check('新建便签有可选标题输入框', await ev("__t.has('sticky-title')"))
await ev("__t.set('sticky-title', '我的标题')")
await ev("__t.set('sticky-content', " + JSON.stringify(LONG) + ")")
await ev("__t.click('modal-confirm')")
await waitFor(client, "__t.count('sticky-card') === 1", 8000, 'note card')
const titleState = await ev("__t.state().then(function (s) { var x = s.stickies[0] || {}; return { title: x.title, contentLen: (x.content || '').length, kind: x.kind } })")
check('便签标题落库', titleState.title === '我的标题' && titleState.kind === 'note', JSON.stringify(titleState))
check('便签卡片显示标题', (await ev("__t.text('sticky-card-title')")) === '我的标题')
const clampInfo = await ev("(function(){ var c=document.querySelector('[data-testid=sticky-card] .sticky-content'); if(!c) return { missing: true }; var cs=getComputedStyle(c); return { clamp: cs.webkitLineClamp || cs.lineClamp || '', scrollH: c.scrollHeight, clientH: c.clientHeight, fullLen: c.textContent.length } })()")
check('卡片内容超出后省略显示（-webkit-line-clamp 生效）', clampInfo && String(clampInfo.clamp) === '2' && clampInfo.fullLen === LONG.length, JSON.stringify(clampInfo))
await shot('96-sticky-title-card')
await ev("__t.click('sticky-card')")
await waitFor(client, "!!document.querySelector('[data-testid=sticky-detail]')", 8000, 'sticky detail')
check('点开卡片进入详情弹窗', await ev("__t.has('sticky-detail') && __t.has('sticky-detail-content')"))
check('详情显示完整标题', (await ev("__t.text('sticky-detail-title')")) === '我的标题')
const detailLen = await ev("(__t.text('sticky-detail-content') || '').length")
check('详情显示完整内容（不省略）', detailLen === LONG.length, detailLen + '/' + LONG.length)
await shot('97-sticky-detail-full')
await ev("__t.click('sticky-detail-edit')")
await waitFor(client, "!!document.querySelector('[data-testid=sticky-title]')", 8000, 'edit title')
check('详情点编辑会回显标题', (await ev("__t.q('sticky-title').value")) === '我的标题')
await ev("__t.set('sticky-title', '改过的标题')")
await ev("__t.click('modal-confirm')")
await sleep(900)
check('标题修改后落库', (await ev("__t.state().then(function (s) { return s.stickies[0].title })")) === '改过的标题')
check('卡片标题同步更新', (await ev("__t.text('sticky-card-title')")) === '改过的标题')

// ---- 2. 提醒便签带标题，到点提醒窗显示标题 ----
const nextMinute = await ev("(function(){var d=new Date(Date.now()+65000);var p=function(n){return n<10?'0'+n:''+n};return p(d.getHours())+':'+p(d.getMinutes())})()")
await ev("__t.click('sticky-add-reminder')")
await waitFor(client, "!!document.querySelector('[data-testid=sticky-repeat-kind]')", 8000, 'reminder form')
await ev("__t.set('sticky-title', '喝水标题')")
await ev("__t.set('sticky-content', '到点喝水')")
await ev("__t.set('sticky-repeat-kind', 'daily')")
await sleep(300)
await ev("__t.set('sticky-repeat-time', '" + nextMinute + "')")
await sleep(300)
await ev("__t.click('modal-confirm')")
await waitFor(client, "__t.count('sticky-card') === 2", 8000, 'reminder card')
check('提醒便签标题落库', (await ev("__t.state().then(function (s) { var x=s.stickies.filter(function(y){return y.content==='到点喝水'})[0]||{}; return x.title })")) === '喝水标题')
const remTargets = await waitPort(9222, 110000, 'reminder.html')
check('提醒便签到点弹出提醒窗', !!remTargets)
if (remTargets) {
  const rc = await connect(9222, 'reminder.html')
  await sleep(900)
  const remTitle = await rc.evaluate("(function(){var e=document.querySelector('[data-testid=reminder-title]');return e?e.innerText:''})()")
  check('提醒窗显示便签标题', String(remTitle).indexOf('喝水标题') >= 0, String(remTitle))
  await rc.shot('.tmp-shots/98-reminder-title.png').catch(function () { return null })
  await rc.evaluate("(function(){var b=document.querySelector('[data-testid=reminder-ok]');if(b)b.click();return true})()")
  await sleep(1200)
  await rc.close()
}

// ---- 3. 便签区 3 列 × 最多 3 行 + 1/3 高度 ----
const created = await ev("(async function(){ var out=[]; for (var i=1;i<=11;i++){ out.push(await window.guina.createSticky({ content: '网格便签' + i, kind: 'note' })); } for (var j=1;j<=11;j++){ out.push(await window.guina.createSticky({ content: '网格提醒' + j, kind: 'reminder', repeat: { kind: 'daily', time: '09:00' } })); } return out.filter(function(r){return r && r.ok}).length })()")
check('补齐到 12 条便签 + 12 条提醒便签', created === 22, created)
await sleep(2000)
const noteM = await ev(MEASURE('note'))
const remM = await ev(MEASURE('reminder'))
check('便签栏共 12 张卡片', noteM.cards === 12, JSON.stringify(noteM))
check('便签栏为 3 列网格', noteM.display === 'grid' && noteM.tracks === 3, JSON.stringify(noteM))
check('便签栏同一行放 3 张卡片', noteM.firstRowSameTop === true)
check('便签栏第 4 张卡片换到下一行', noteM.fourthCardNextRow === true)
check('便签栏最多可见 3 行（3×3）', noteM.visibleRows === 3, JSON.stringify(noteM))
check('便签栏超出后纵向滚动', noteM.scrollHeight > noteM.clientHeight + 1, noteM.scrollHeight + ' > ' + noteM.clientHeight)
check('便签栏没有横向滚动', noteM.scrollWidth <= noteM.clientWidth + 1, noteM.scrollWidth + ' <= ' + noteM.clientWidth)
check('提醒便签栏同样 3 列 3 行可见', remM.display === 'grid' && remM.tracks === 3 && remM.visibleRows === 3, JSON.stringify(remM))
check('提醒便签栏超出后纵向滚动', remM.scrollHeight > remM.clientHeight + 1)
check('卡片宽度约为栏宽三分之一', noteM.cardWidth > noteM.clientWidth / 4 && noteM.cardWidth < noteM.clientWidth / 2.5, noteM.cardWidth + '/' + noteM.clientWidth)
const secM = await ev("(function(){ var r=document.querySelector('[data-testid=sticky-section]').getBoundingClientRect(); return { h: Math.round(r.height), win: window.innerHeight, ratio: Math.round(r.height / window.innerHeight * 1000) / 1000 } })()")
check('便签区高度约为界面 1/3', secM.ratio >= 0.28 && secM.ratio <= 0.40, JSON.stringify(secM))
await shot('99-sticky-grid3x3')

// ---- 4. 地点与容器名称分开保存、互不混入 ----
await ev("__t.back()")
await waitFor(client, "!!document.querySelector('[data-testid=category-card]')", 8000, 'home')
await ev("__t.clickText('category-card', '物品')")
await waitFor(client, "!!document.querySelector('[data-testid=category-title]')", 8000, 'item category')
await ev("__t.click('add-item')")
await waitFor(client, "!!document.querySelector('[data-testid=form-name]')", 8000, 'item form place')
await ev("__t.set('form-name', '卧室里的钥匙')")
await ev("__t.set('form-location-name', '卧室')")
await ev("__t.click('form-submit')")
await sleep(900)
await ev("__t.click('add-item')")
await waitFor(client, "!!document.querySelector('[data-testid=form-name]')", 8000, 'item form container')
await ev("__t.set('form-name', '抽屉柜里的钥匙')")
await ev("__t.click('form-location-container')")
await sleep(250)
await ev("__t.set('form-location-name', '抽屉柜')")
await ev("__t.click('form-submit')")
await sleep(900)
const buckets = await ev("__t.state().then(function (s) { return { place: s.savedNames.place.map(function(x){return x.name}), container: s.savedNames.container.map(function(x){return x.name}) } })")
check('地点与容器名称分开保存', JSON.stringify(buckets.place) === '["卧室"]' && JSON.stringify(buckets.container) === '["抽屉柜"]', JSON.stringify(buckets))
await ev("__t.click('add-item')")
await waitFor(client, "!!document.querySelector('[data-testid=form-name]')", 8000, 'item form reuse')
await ev("__t.click('saved-toggle')")
await sleep(300)
const placeTitle = await ev("__t.text('saved-list-title')")
const placeOpts = await ev("__t.texts('saved-name-option')")
check('地点下拉标题为保存过的地点名称', placeTitle.indexOf('地点') >= 0, placeTitle)
check('地点下拉只含地点名称', placeOpts.length === 1 && placeOpts[0].indexOf('卧室') >= 0, placeOpts.join('/'))
await shot('100-saved-names-place')
await ev("__t.click('saved-toggle')")
await sleep(250)
await ev("__t.click('form-location-container')")
await sleep(300)
await ev("__t.click('saved-toggle')")
await sleep(300)
const contTitle = await ev("__t.text('saved-list-title')")
const contOpts = await ev("__t.texts('saved-name-option')")
check('容器下拉标题为保存过的容器名称', contTitle.indexOf('容器') >= 0, contTitle)
check('容器下拉只含容器名称', contOpts.length === 1 && contOpts[0].indexOf('抽屉柜') >= 0, contOpts.join('/'))
await shot('101-saved-names-container')
// 同名忽略大小写/空格只留一个
const dedupe = await ev("__t.state().then(function (s) { return { place: s.savedNames.place.length, container: s.savedNames.container.length } })")
check('两类名称各自去重保存', dedupe.place === 1 && dedupe.container === 1, JSON.stringify(dedupe))
await ev("__t.click('modal-cancel')")
await sleep(400)

const failed = results.filter(function (r) { return !r.ok })
console.log(JSON.stringify({ total: results.length, passed: results.length - failed.length, failed: failed }))
if (failed.length) process.exitCode = 1
