// 通过 WebView CDP 截图与读取文本（安卓版调试）
import { connect } from './cdp.mjs'
import fs from 'node:fs'

const port = Number(process.env.CDP_PORT || 9333)
const out = process.env.OUT || '.tmp-shots/android.png'
const c = await connect(port, 'app.local')
await c.send('Page.enable')
const info = await c.evaluate('({title: document.title, text: (document.body.innerText||"").slice(0, 3000), html: document.body.innerHTML.length})')
console.log(JSON.stringify(info.value || info, null, 1).slice(0, 3500))
const shot = await c.send('Page.captureScreenshot', { format: 'png' })
fs.writeFileSync(out, Buffer.from(shot.data, 'base64'))
console.log('saved ' + out)
c.close()
