import { check, ev, bodyText, shot, waitFor, waitText, clickText, setField, goTab, closeSheet, sheetText, summary, sleep } from './mobile-e2e.mjs'

const S = (t) => console.log('[step] ' + t)
const toastNow = () => ev("(document.querySelector('.toast')||{}).innerText||''")

if ((await bodyText()).includes('跳过')) await clickText('跳过')
await waitText('我的分类')
S('A 首页就绪')

// ===== I 便签置顶 toast =====
await ev("(() => { const b = document.querySelector('[aria-label=\"新建便签\"]'); if (!b) return 'NO'; b.click(); return 'OK' })()")
await waitFor(async () => (await sheetText()).includes('内容'))
await setField('内容', '置顶验证便签')
await clickText('保存', '.sheet-panel')
await waitFor(async () => (await bodyText()).includes('置顶验证便签'))
check('I.1 便签创建成功', true)
await ev("(() => { const c = [...document.querySelectorAll('.sticky-card')].find(e => (e.innerText||'').includes('置顶验证便签')); if (!c) return 'NO'; c.click(); return 'OK' })()")
await waitFor(async () => (await sheetText()).includes('置顶'))
const pinClick = await ev("(() => { const p = document.querySelector('.sheet-panel'); const b = [...p.querySelectorAll('.chips button')].find(e => (e.innerText||'').trim() === '置顶'); if (!b) return 'NO'; b.click(); return 'OK' })()")
await sleep(200)
const toastPin = await toastNow()
check('I.2 便签置顶 toast 为「已置顶」', pinClick === 'OK' && toastPin.indexOf('已置顶') >= 0 && toastPin.indexOf('取消') < 0, 'click=' + pinClick + ' toast=' + toastPin)
await closeSheet()
await sleep(200)
const firstSticky = await ev("(() => { const cards = [...document.querySelectorAll('.sticky-card')]; return cards.length ? (cards[0].innerText||'').trim() : '' })()")
check('I.3 置顶便签排到最前', firstSticky.indexOf('置顶验证便签') >= 0, firstSticky)
await ev("(() => { const c = [...document.querySelectorAll('.sticky-card')].find(e => (e.innerText||'').includes('置顶验证便签')); if (c) c.click(); return 'OK' })()")
await waitFor(async () => (await sheetText()).includes('取消置顶'))
await ev("(() => { const p = document.querySelector('.sheet-panel'); const b = [...p.querySelectorAll('.chips button')].find(e => (e.innerText||'').trim() === '取消置顶'); if (b) b.click(); return 'OK' })()")
await sleep(200)
const toastUnpin = await toastNow()
check('I.4 便签取消置顶 toast 为「已取消置顶」', toastUnpin.indexOf('已取消置顶') >= 0, toastUnpin)
await closeSheet()
await sleep(200)

// ===== J 分类置顶 toast + 排序 =====
async function openCategory(name) {
  const r = await ev("(() => { const c = [...document.querySelectorAll('.cat-card')].find(e => (e.innerText||'').includes(" + JSON.stringify(name) + ")); if (!c) return 'NO'; c.click(); return 'OK' })()")
  await sleep(500)
  const back = await ev("!!document.querySelector('[aria-label=\"分类操作\"]')")
  return r === 'OK' && back
}
async function pinFromCategory(btnText) {
  await ev("(() => { const b = document.querySelector('[aria-label=\"分类操作\"]'); if (b) b.click(); return 'OK' })()")
  await waitFor(async () => (await sheetText()).includes(btnText))
  await clickText(btnText, '.sheet-panel')
  await sleep(200)
  return await toastNow()
}
async function backHome() {
  await ev("(() => { const b = document.querySelector('[aria-label=\"返回\"]'); if (b) b.click(); return 'OK' })()")
  await sleep(300)
}
check('J.1 打开「药品」分类', await openCategory('药品'))
const tPin = await pinFromCategory('置顶这个分类')
check('J.2 分类置顶 toast 为「分类已置顶」', tPin.indexOf('分类已置顶') >= 0 && tPin.indexOf('取消') < 0, tPin)
await backHome()
const order1 = await ev("(() => [...document.querySelectorAll('.cat-card .cat-name')].map(e => (e.innerText||'').trim()))()")
check('J.3 置顶分类排第一且带 📌', order1[0] && order1[0].indexOf('药品') >= 0 && order1.join('|').indexOf('📌') >= 0, JSON.stringify(order1))
check('J.4 打开「药品」分类(取消置顶前)', await openCategory('药品'))
const tUnpin = await pinFromCategory('取消置顶')
check('J.5 取消置顶 toast 为「已取消置顶」', tUnpin.indexOf('已取消置顶') >= 0, tUnpin)
await backHome()
const order2 = await ev("(() => [...document.querySelectorAll('.cat-card .cat-name')].map(e => (e.innerText||'').trim()))()")
check('J.6 取消后恢复原顺序', order2[0] && order2[0].indexOf('图书') >= 0 && order2.join('|').indexOf('📌') < 0, JSON.stringify(order2))
await shot('v-pin-toast')

// ===== K 触发 heads-up 通知（提醒 + 到期） =====
S('K 触发通知')
const fired = await ev("(() => { try { const at = Date.now() + 1500; const r = window.GuinaNative.scheduleReminder('verify-hs-1','验证提醒','置顶与通知验证', String(at), '', '', true); window.GuinaNative.notifyExpiry('测试食品','测试药品'); return String(r) } catch (e) { return 'ERR ' + e } })()")
console.log('[info] fired=' + fired)
await sleep(4000)
check('K.1 已调用原生调度与到期通知', fired.indexOf('ERR') < 0, fired)
await goTab('设置')
await waitText('测试提醒')
check('K.2 设置页「发一条」测试按钮存在', (await bodyText()).indexOf('发一条') >= 0)
console.log(summary())
process.exit(0)
