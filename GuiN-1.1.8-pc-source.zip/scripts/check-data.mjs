import { listTargets, connect } from './cdp.mjs'
const port = Number(process.argv[2] || 9334)
const deadline = Date.now() + 20000
let page = null
while (Date.now() < deadline && !page) {
  try {
    const j = await listTargets(port)
    const pages = (j || []).filter((t) => t.type === 'page')
    page = pages.find((t) => String(t.url).includes('index.html')) || pages[0] || null
  } catch (e) {}
  if (!page) await new Promise((r) => setTimeout(r, 500))
}
if (!page) { console.log(JSON.stringify({ ok: false, reason: 'no page' })); process.exit(1) }
const c = await connect(port, page.url)
try {
  const info = await c.evaluate('window.guina && window.guina.dataInfo ? window.guina.dataInfo() : null')
  const st = await c.evaluate("(async () => { const s = await window.guina.getState(); return { items: (s.items||[]).length, cats: (s.categories||[]).length } })()")
  console.log(JSON.stringify({ ok: true, title: page.title, info: JSON.parse(JSON.stringify(info)), st: JSON.parse(JSON.stringify(st)) }))
} catch (e) { console.log(JSON.stringify({ ok: false, err: String(e && e.message || e) })) }
await c.close()
process.exit(0)
