import http from 'node:http'
const port = process.argv[2] || '9333'
const deadline = Date.now() + 25000
function get(u) { return new Promise((res, rej) => { const r = http.get(u, (x) => { let d = ''; x.on('data', (c) => d += c); x.on('end', () => res(d)) }); r.on('error', rej); r.setTimeout(2000, () => { r.destroy(); rej(new Error('timeout')) }) }) }
let ok = false, title = ''
while (Date.now() < deadline && !ok) {
  try {
    const j = JSON.parse(await get('http://127.0.0.1:' + port + '/json/list'))
    const pages = j.filter((t) => t.type === 'page')
    const p = pages.find((t) => String(t.url).includes('index.html')) || pages[0]
    if (p && p.title) { title = p.title; ok = String(p.title).length > 0 }
  } catch (e) { await new Promise((r) => setTimeout(r, 500)) }
}
console.log(JSON.stringify({ ok, title }))
process.exit(ok ? 0 : 1)
