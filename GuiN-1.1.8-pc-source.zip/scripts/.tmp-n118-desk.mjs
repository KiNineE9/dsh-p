import { spawn, execSync } from 'node:child_process'
import fs from 'node:fs'
import path from 'node:path'
import { connect } from './cdp.mjs'

const ROOT = 'F:/DSH/GC/GuiNa'
const PROFILE = path.join(ROOT, '.tmp-n118-profile')
const PORT = 9222
const ELECTRON = path.join(ROOT, 'node_modules/electron/dist/electron.exe')
function sleep(ms) { return new Promise((r) => setTimeout(r, ms)) }
function killElectron() { try { execSync('taskkill /F /IM electron.exe /T', { stdio: 'ignore' }) } catch {} }

async function waitPage() {
  for (let i = 0; i < 120; i++) {
    try {
      const res = await fetch('http://127.0.0.1:' + PORT + '/json/list')
      const list = await res.json()
      const hit = list.find((t) => String(t.url).includes('index.html'))
      if (hit) return hit
    } catch {}
    await sleep(250)
  }
  throw new Error('no page')
}

function seed() {
  const today = new Date()
  const dateStr = (d) => d.toISOString().slice(0, 10)
  const plus = (n) => { const d = new Date(today.getTime() + n * 86400000); return dateStr(d) }
  const state = {
    version: 8,
    categories: [
      { id: 'cat-food', name: '食品', icon: '🍎', baseTemplate: 'food', customFields: [], order: 0, createdAt: new Date().toISOString() },
      { id: 'cat-medicine', name: '药品', icon: '💊', baseTemplate: 'medicine', customFields: [], order: 1, createdAt: new Date().toISOString() },
      { id: 'cat-book', name: '图书', icon: '📚', baseTemplate: 'book', customFields: [], order: 2, createdAt: new Date().toISOString() },
      { id: 'cat-item', name: '物品', icon: '📦', baseTemplate: 'item', customFields: [], order: 3, createdAt: new Date().toISOString() }
    ],
    items: [
      { id: 'it-food', categoryId: 'cat-food', name: '测试牛奶', locationType: 'place', locationLabel: '冰箱', locationName: '第二层', fields: { name: '测试牛奶', storedAt: dateStr(today), expiresAt: plus(5) }, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() }
    ],
    notes: [], stickies: [], tombstones: [],
    notifications: [],
    settings: { theme: 'system', autoLaunch: false, closeToTray: false, reminderPopup: true, reminderSound: false, stickySearchHistory: true, itemSearchHistory: true, expiryTiers: { 30: true, 15: true, 7: true, 1: true } },
    savedNames: { place: [], container: [] }, searchHistory: { sticky: [], item: [] }, onboardingDone: true, createdAt: new Date().toISOString()
  }
  fs.mkdirSync(PROFILE, { recursive: true })
  fs.writeFileSync(path.join(PROFILE, 'data.json'), JSON.stringify(state, null, 2))
}

async function start() {
  const env = { ...process.env }
  delete env.ELECTRON_RUN_AS_NODE
  const child = spawn(ELECTRON, [ROOT, '--remote-debugging-port=' + PORT, '--no-sandbox', '--user-data-dir=' + PROFILE], { env, stdio: 'ignore' })
  await waitPage()
  await sleep(2500)
  return child
}

async function inspect(page, label) {
  const out = await page.evaluate('(function(){var b=document.querySelector("[data-testid=bell-badge]");var t=document.querySelector("[data-testid=toast]");return JSON.stringify({badge:b?b.textContent:"",badgeVisible:b?b.offsetParent!==null:false,toast:t?t.textContent:"",title:document.title})})()')
  console.log(label + ' ' + out)
}

killElectron(); await sleep(500)
try { fs.rmSync(PROFILE, { recursive: true, force: true }) } catch {}
seed()
await start()
let p = await connect(PORT)
await inspect(p, 'LAUNCH1')
const data1 = JSON.parse(fs.readFileSync(path.join(PROFILE, 'data.json'), 'utf8'))
console.log('NOTIFS1 ' + JSON.stringify((data1.notifications || []).map((n) => ({ id: n.id, read: n.read, tier: n.tier, expiry: n.expiryDate }))))
// 打开通知面板并全部标为已读
await p.evaluate('(function(){var el=document.querySelector("[data-testid=bell]");el.click();return true})()')
await sleep(800)
const panel = await p.evaluate('(function(){var el=document.querySelector("[data-testid=notification-panel]");return el?"open":"closed"})()')
console.log('PANEL ' + panel)
const btn = await p.evaluate('(function(){var btns=[].slice.call(document.querySelectorAll("[data-testid=notification-panel] button"));var b=btns.find(function(x){return x.textContent.indexOf("全部标为已读")>=0});if(!b)return "nobtn";b.click();return "clicked"})()')
console.log('READALL ' + btn)
await sleep(1000)
await inspect(p, 'AFTER_READ')
await p.close()
const data2 = JSON.parse(fs.readFileSync(path.join(PROFILE, 'data.json'), 'utf8'))
console.log('NOTIFS2 ' + JSON.stringify((data2.notifications || []).map((n) => ({ id: n.id, read: n.read }))))
killElectron(); await sleep(1200)
await start()
p = await connect(PORT)
await inspect(p, 'LAUNCH2')
const data3 = JSON.parse(fs.readFileSync(path.join(PROFILE, 'data.json'), 'utf8'))
console.log('NOTIFS3 ' + JSON.stringify((data3.notifications || []).map((n) => ({ id: n.id, read: n.read }))))
await p.close()
killElectron()
