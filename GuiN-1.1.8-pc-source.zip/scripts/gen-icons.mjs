// GuiNa icon generator (zero dependencies).
//
// Usage: node scripts/gen-icons.mjs
//
// Produces:
//   resources/tray.png        32x32   pixel-art whirlpool tray icon (transparent background)
//   resources/tray-alert.png  32x32   whirlpool with a red "!" badge (top right)
//   resources/tray-bell.png   32x32   yellow bell shown when there are unread expiry notices
//   resources/icon.png        256x256 pixel-art whirlpool application icon
//   build/icon.ico            Windows icon: 256 + 64 + 32 PNG frames
//
// Only node:fs, node:path and node:zlib are used. The PNG encoder below is
// self-contained (CRC32 + zlib deflate + IHDR/IDAT/IEND).
//
// Pixel art: the whirlpool is drawn once on a 32x32 logical grid (one colour per
// cell, hard cell boundaries) and then upscaled with nearest-neighbour blocks
// (x8 for the 256px app icon, x2 for the 64px ICO frame, x1 for the 32px tray /
// ICO frame). No anti-aliasing is applied to it, which keeps the blocky look.
// The bell is still drawn with the original supersampled geometry helpers.

import fs from 'node:fs';
import path from 'node:path';
import zlib from 'node:zlib';

const ROOT = path.resolve(import.meta.dirname, '..');

// ---------------------------------------------------------------- PNG writer

const CRC_TABLE = (function () {
  const table = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) {
      c = (c & 1) ? (0xedb88320 ^ (c >>> 1)) : (c >>> 1);
    }
    table[n] = c >>> 0;
  }
  return table;
})();

function crc32(buffer) {
  let c = 0xffffffff;
  for (let i = 0; i < buffer.length; i++) {
    c = CRC_TABLE[(c ^ buffer[i]) & 0xff] ^ (c >>> 8);
  }
  return (c ^ 0xffffffff) >>> 0;
}

function pngChunk(type, data) {
  const typeBytes = Buffer.from(type, 'ascii');
  const payload = Buffer.concat([typeBytes, data]);
  const result = Buffer.alloc(data.length + 12);
  result.writeUInt32BE(data.length, 0);
  payload.copy(result, 4);
  result.writeUInt32BE(crc32(payload), data.length + 8);
  return result;
}

function encodePng(width, height, rgba) {
  const stride = width * 4;
  const raw = Buffer.alloc((stride + 1) * height);
  for (let y = 0; y < height; y++) {
    const row = y * (stride + 1);
    raw[row] = 0; // filter type: none
    rgba.copy(raw, row + 1, y * stride, y * stride + stride);
  }
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(width, 0);
  ihdr.writeUInt32BE(height, 4);
  ihdr[8] = 8;  // bit depth
  ihdr[9] = 6;  // color type: RGBA
  ihdr[10] = 0; // compression method
  ihdr[11] = 0; // filter method
  ihdr[12] = 0; // interlace method
  const idat = zlib.deflateSync(raw, { level: 9 });
  return Buffer.concat([
    Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]),
    pngChunk('IHDR', ihdr),
    pngChunk('IDAT', idat),
    pngChunk('IEND', Buffer.alloc(0))
  ]);
}

// ------------------------------------------------------------- raster canvas

const SS = 4; // supersampling factor per axis (bell only)
const SS_TOTAL = SS * SS;

function makeCanvas(width, height) {
  return { width: width, height: height, data: new Float64Array(width * height * 4) };
}

function blendPixel(canvas, x, y, r, g, b, sa) {
  const d = canvas.data;
  const i = (y * canvas.width + x) * 4;
  const da = d[i + 3];
  const oa = sa + da * (1 - sa);
  if (oa <= 0) {
    return;
  }
  const keep = da * (1 - sa);
  d[i] = (r * sa + d[i] * keep) / oa;
  d[i + 1] = (g * sa + d[i + 1] * keep) / oa;
  d[i + 2] = (b * sa + d[i + 2] * keep) / oa;
  d[i + 3] = oa;
}

function coverage(inside, px, py) {
  const step = 1 / SS;
  let hits = 0;
  for (let sy = 0; sy < SS; sy++) {
    for (let sx = 0; sx < SS; sx++) {
      if (inside(px + (sx + 0.5) * step, py + (sy + 0.5) * step)) {
        hits = hits + 1;
      }
    }
  }
  return hits / SS_TOTAL;
}

function paint(canvas, inside, colorFn) {
  for (let y = 0; y < canvas.height; y++) {
    for (let x = 0; x < canvas.width; x++) {
      const cov = coverage(inside, x, y);
      if (cov <= 0) {
        continue;
      }
      const color = colorFn(x + 0.5, y + 0.5);
      const alpha = cov * (color.length > 3 ? color[3] : 1);
      blendPixel(canvas, x, y, color[0], color[1], color[2], alpha);
    }
  }
}

function erase(canvas, inside) {
  for (let y = 0; y < canvas.height; y++) {
    for (let x = 0; x < canvas.width; x++) {
      const cov = coverage(inside, x, y);
      if (cov <= 0) {
        continue;
      }
      const i = (y * canvas.width + x) * 4;
      canvas.data[i + 3] = canvas.data[i + 3] * (1 - cov);
    }
  }
}

function canvasToRgba(canvas) {
  const width = canvas.width;
  const height = canvas.height;
  const data = canvas.data;
  const out = Buffer.alloc(width * height * 4);
  for (let i = 0; i < width * height; i++) {
    const a = Math.max(0, Math.min(1, data[i * 4 + 3]));
    if (a <= 0) {
      continue;
    }
    out[i * 4] = Math.round(Math.max(0, Math.min(1, data[i * 4])) * 255);
    out[i * 4 + 1] = Math.round(Math.max(0, Math.min(1, data[i * 4 + 1])) * 255);
    out[i * 4 + 2] = Math.round(Math.max(0, Math.min(1, data[i * 4 + 2])) * 255);
    out[i * 4 + 3] = Math.round(a * 255);
  }
  return out;
}

// -------------------------------------------------------------- shape helpers

function solid(color) {
  return function () {
    return color;
  };
}

function roundRectPx(x0, y0, x1, y1, radius) {
  const cx = (x0 + x1) / 2;
  const cy = (y0 + y1) / 2;
  const hw = Math.abs(x1 - x0) / 2;
  const hh = Math.abs(y1 - y0) / 2;
  const rr = Math.max(0, Math.min(radius, hw, hh));
  const innerW = hw - rr;
  const innerH = hh - rr;
  return function (x, y) {
    const dx = Math.abs(x - cx);
    const dy = Math.abs(y - cy);
    if (dx > hw || dy > hh) {
      return false;
    }
    const qx = dx - innerW;
    const qy = dy - innerH;
    if (qx <= 0 || qy <= 0) {
      return true;
    }
    return qx * qx + qy * qy <= rr * rr;
  };
}

function circlePx(cx, cy, radius) {
  return function (x, y) {
    const dx = x - cx;
    const dy = y - cy;
    return dx * dx + dy * dy <= radius * radius;
  };
}

// ------------------------------------------------------------------- palette

function rgb(hex) {
  return [
    ((hex >> 16) & 0xff) / 255,
    ((hex >> 8) & 0xff) / 255,
    (hex & 0xff) / 255
  ];
}

// Five-colour whirlpool palette: near-black outline, deep navy water, mid blue
// rim/shadow, cyan spiral arms and a pale cyan highlight + vortex eye.
const VORTEX = {
  outline: rgb(0x05070f),
  base: rgb(0x0a1b36),
  mid: rgb(0x16436e),
  arm: rgb(0x2ec4e6),
  high: rgb(0xc2f4ff),
  badgeRed: rgb(0xff3b30),
  white: [1, 1, 1]
};

// ------------------------------------------------------------ pixel vortex

const GRID = 32; // logical grid: one block per cell, upscaled by nearest neighbour

// Spiral parameters. phase = (theta / 2pi) * arms + r * twist selects one of the
// five colours per cell, so the three arms wind clockwise into the centre.
const VORTEX_STYLE = {
  arms: 3,
  twist: 1.9,    // full arm turns gained from the centre to the rim
  radius: 0.90,  // normalised disc radius (transparent outside)
  eye: 0.17,     // bright vortex eye radius
  eyeRing: 1.1,  // dark ring (in cells) around the eye, keeps it readable
  highBand: 0.12, // leading highlight width (fraction of an arm period)
  armEnd: 0.52,  // arm body ends here
  shadowBand: 0.08
};

// Pick the colour of one normalised cell. Returns null for transparent.
function vortexCellColor(dx, dy, opts) {
  const r = Math.sqrt(dx * dx + dy * dy);
  if (r > opts.radius) {
    return null;
  }
  const ring = 1 / (GRID / 2); // one logical cell in normalised units
  if (r > opts.radius - ring) {
    return VORTEX.outline;
  }
  if (r > opts.radius - ring * 2.2) {
    return VORTEX.mid;
  }
  if (r < opts.eye) {
    return VORTEX.high;
  }
  if (r < opts.eye + ring * opts.eyeRing) {
    return VORTEX.base;
  }
  const theta = Math.atan2(dy, dx);
  let phase = (theta / (2 * Math.PI)) * opts.arms + r * opts.twist;
  phase = phase - Math.floor(phase);
  if (phase < opts.highBand) {
    return VORTEX.high;
  }
  if (phase < opts.armEnd) {
    return VORTEX.arm;
  }
  if (phase < opts.armEnd + opts.shadowBand) {
    return VORTEX.mid;
  }
  return VORTEX.base;
}

// Build the 32x32 colour grid (null = transparent).
function buildVortexGrid(withBadge) {
  const cells = new Array(GRID * GRID).fill(null);
  const center = GRID / 2;
  for (let y = 0; y < GRID; y++) {
    for (let x = 0; x < GRID; x++) {
      const dx = (x + 0.5 - center) / center;
      const dy = (y + 0.5 - center) / center;
      cells[y * GRID + x] = vortexCellColor(dx, dy, VORTEX_STYLE);
    }
  }
  if (withBadge) {
    applyAlertBadge(cells);
  }
  return cells;
}

// Red "!" badge in the top-right corner. Punch a transparent halo first (so the
// mark is readable on top of the whirlpool), then a blocky red disc, then the
// white exclamation mark (2px bar, 2px dot) on the logical grid.
function applyAlertBadge(cells) {
  const cx = 24.5;
  const cy = 7.5;
  const radius = 5.4;
  const halo = 6.7;
  for (let y = 0; y < GRID; y++) {
    for (let x = 0; x < GRID; x++) {
      const dx = x + 0.5 - cx;
      const dy = y + 0.5 - cy;
      const d = Math.sqrt(dx * dx + dy * dy);
      const index = y * GRID + x;
      if (d <= halo) {
        cells[index] = null;
      }
      if (d <= radius) {
        cells[index] = VORTEX.badgeRed;
      }
    }
  }
  for (let y = 3; y <= 6; y++) {
    cells[y * GRID + 23] = VORTEX.white;
    cells[y * GRID + 24] = VORTEX.white;
  }
  for (let y = 9; y <= 10; y++) {
    cells[y * GRID + 23] = VORTEX.white;
    cells[y * GRID + 24] = VORTEX.white;
  }
}

// Render the grid at the requested pixel size, scaling each cell into a hard
// square block (no interpolation, no anti-aliasing).
function renderVortexPixels(size, withBadge) {
  const cells = buildVortexGrid(withBadge);
  const scale = size / GRID;
  const canvas = makeCanvas(size, size);
  const data = canvas.data;
  for (let y = 0; y < GRID; y++) {
    for (let x = 0; x < GRID; x++) {
      const color = cells[y * GRID + x];
      if (!color) {
        continue;
      }
      const x0 = Math.round(x * scale);
      const x1 = Math.round((x + 1) * scale);
      const y0 = Math.round(y * scale);
      const y1 = Math.round((y + 1) * scale);
      for (let py = y0; py < y1; py++) {
        let index = (py * size + x0) * 4;
        for (let px = x0; px < x1; px++) {
          data[index] = color[0];
          data[index + 1] = color[1];
          data[index + 2] = color[2];
          data[index + 3] = 1;
          index = index + 4;
        }
      }
    }
  }
  return canvas;
}

// ------------------------------------------------------------- tray icons

// The tray icon is the same whirlpool bitmap at native 32px (scale 1); the
// alert variant adds the red exclamation badge on the logical grid.
function renderTray(size, withAlert) {
  return renderVortexPixels(size, withAlert);
}

// ------------------------------------------------------------- bell icon

// A yellow bell: dome + rim + clapper, used when there are unread expiry notices.
function renderBell(size) {
  const canvas = makeCanvas(size, size);
  const bellYellow = [0xf5 / 255, 0xb9 / 255, 0x2e / 255];
  const bellDeep = [0xd6 / 255, 0x96 / 255, 0x18 / 255];
  // dome: a circle on top of a trapezoid body
  paint(canvas, circlePx(0.5 * size, 0.42 * size, 0.245 * size), solid(bellYellow));
  paint(canvas, function (x, y) {
    const t = (y - 0.42 * size) / (0.30 * size);
    if (t < 0 || t > 1) return false;
    const half = (0.245 + 0.055 * t) * size;
    return Math.abs(x - 0.5 * size) <= half;
  }, solid(bellYellow));
  // rim
  paint(canvas, roundRectPx(0.215 * size, 0.695 * size, 0.785 * size, 0.775 * size, 0.035 * size), solid(bellYellow));
  // clapper
  paint(canvas, circlePx(0.5 * size, 0.845 * size, 0.072 * size), solid(bellDeep));
  // handle on top
  paint(canvas, roundRectPx(0.455 * size, 0.115 * size, 0.545 * size, 0.235 * size, 0.045 * size), solid(bellDeep));
  return canvas;
}

// ---------------------------------------------------------- application icon

function renderAppIcon(size) {
  return renderVortexPixels(size, false);
}

// ------------------------------------------------------------------ ICO writer

function encodeIco(frames) {
  const count = frames.length;
  const header = Buffer.alloc(6);
  header.writeUInt16LE(0, 0); // reserved
  header.writeUInt16LE(1, 2); // type: icon
  header.writeUInt16LE(count, 4);
  const entries = Buffer.alloc(16 * count);
  let offset = 6 + 16 * count;
  for (let i = 0; i < count; i++) {
    const frame = frames[i];
    const base = i * 16;
    entries[base] = frame.size >= 256 ? 0 : frame.size;
    entries[base + 1] = frame.size >= 256 ? 0 : frame.size;
    entries[base + 2] = 0; // color count
    entries[base + 3] = 0; // reserved
    entries.writeUInt16LE(1, base + 4);  // color planes
    entries.writeUInt16LE(32, base + 6); // bits per pixel
    entries.writeUInt32LE(frame.png.length, base + 8);
    entries.writeUInt32LE(offset, base + 12);
    offset = offset + frame.png.length;
  }
  const parts = [header, entries];
  for (let i = 0; i < count; i++) {
    parts.push(frames[i].png);
  }
  return Buffer.concat(parts);
}

// ----------------------------------------------------------------------- main

function writeOutput(relativePath, buffer) {
  const absolutePath = path.join(ROOT, relativePath);
  fs.mkdirSync(path.dirname(absolutePath), { recursive: true });
  fs.writeFileSync(absolutePath, buffer);
  console.log(relativePath + ' wrote ' + buffer.length + ' bytes');
}

function main() {
  const trayCanvas = renderTray(32, false);
  writeOutput(path.join('resources', 'tray.png'), encodePng(32, 32, canvasToRgba(trayCanvas)));

  const alertCanvas = renderTray(32, true);
  writeOutput(path.join('resources', 'tray-alert.png'), encodePng(32, 32, canvasToRgba(alertCanvas)));

  const bellCanvas = renderBell(32);
  writeOutput(path.join('resources', 'tray-bell.png'), encodePng(32, 32, canvasToRgba(bellCanvas)));

  const iconCanvas = renderAppIcon(256);
  const iconPng = encodePng(256, 256, canvasToRgba(iconCanvas));
  writeOutput(path.join('resources', 'icon.png'), iconPng);
  writeOutput(path.join('src', 'renderer', 'src', 'assets', 'app-icon.png'), iconPng);

  const frames = [];
  const iconSizes = [256, 64, 32];
  for (let i = 0; i < iconSizes.length; i++) {
    const size = iconSizes[i];
    const rgba = canvasToRgba(renderAppIcon(size));
    frames.push({ size: size, png: encodePng(size, size, rgba) });
  }
  writeOutput(path.join('build', 'icon.ico'), encodeIco(frames));
  console.log('done: 6 files generated');
}

main();
