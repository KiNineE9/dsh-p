// 1.1.7 安卓新功能端到端：主界面长按提示已移除、物品分类兜底时间显示为可读文案、分类详情加号只新增当前分类条目、关于页版本
import { execSync } from 'node:child_process'
import fs from 'node:fs'
const ADB = 'F:/Android/sdk/platform-tools/adb.exe'
const SHOT_DIR = process.env.SHOT_DIR || '.tmp-shots/117'
fs.mkdirSync(SHOT_DIR, { recursive: true })
const { connect } = await import('./cdp.mjs')
const c = await connect(9333, 'app.local')
await c.send('Page.enable'); await c.send('Runtime.enable')
const sleep = function (ms) { return new Promise(function (r) { setTimeout(r, ms) }) }
const ev = function (e) { return c.evaluate(e) }
const results = []
function check(name, ok, detail) {
  results.push({ name: name, ok: !!ok })
  console.log((ok ? 'PASS' : 'FAIL') + ' | ' + name + (detail === undefined || detail === '' ? '' : ' | ' + detail))
}
function adb(shell) { try { return execSync('"' + ADB + '" ' + shell, { encoding: 'utf8', timeout: 30000 }) } catch (e) { return String((e && e.stdout) || '') } }
async function shot(name) {
  try { const buf = execSync('"' + ADB + '" exec-out screencap -p', { maxBuffer: 40 * 1024 * 1024 }); fs.writeFileSync(SHOT_DIR + '/' + name + '.png', buf) } catch (e) {}
}
async function center(sel, text) {
  return await ev('(() => { const list = [...document.querySelectorAll(' + JSON.stringify(sel) + ')]; const el = ' + (text ? 'list.find((e) => ((e.innerText || e.textContent || "") + "").trim().includes(' + JSON.stringify(text) + '))' : 'list[0]') + '; if (!el) return null; el.scrollIntoView({ block: "center" }); const r = el.getBoundingClientRect(); return { x: r.left + r.width / 2, y: r.top + r.height / 2 }; })()')
}
async function tapPoint(p) {
  if (!p) return false
  await c.send('Input.dispatchMouseEvent', { type: 'mouseMoved', x: p.x, y: p.y })
  await c.send('Input.dispatchMouseEvent', { type: 'mousePressed', x: p.x, y: p.y, button: 'left', clickCount: 1 })
  await sleep(70)
  await c.send('Input.dispatchMouseEvent', { type: 'mouseReleased', x: p.x, y: p.y, button: 'left', clickCount: 1 })
  await sleep(380)
  return true
}
async function tap(sel, text) { return tapPoint(await center(sel, text)) }
const bodyText = async function () { return (await ev('document.body.innerText')) || '' }
async function waitText(text, ms) {
  const end = Date.now() + (ms || 8000)
  while (Date.now() < end) { if ((await bodyText()).includes(text)) return true; await sleep(250) }
  return false
}
async function jsTap(sel, text) {
  const ok = await ev('(() => { const list = [...document.querySelectorAll(' + JSON.stringify(sel) + ')]; const el = ' + (text ? 'list.find((e) => ((e.innerText || "").trim()).indexOf(' + JSON.stringify(text) + ') >= 0)' : 'list[0]') + '; if (!el) return false; el.click(); return true; })()')
  await sleep(600)
  return ok
}
async function goHome() { await jsTap('.tabbar .tab', '首页'); await sleep(400) }
async function openCategory(name) { await tap('.cat-card', name); await sleep(900) }
async function closeSheet() { await jsTap('button[aria-label="关闭"]'); await sleep(500) }
async function reload() { await c.send('Page.reload'); await sleep(2600); if ((await bodyText()).includes('跳过')) { await tap('button', '跳过'); await sleep(1400) } }

// ---------- 造数据：物品分类两条（一条清空存放时间、一条有存放时间） ----------
const st = JSON.parse(await ev('window.GuinaNative.loadData()'))
const itemCat = st.categories.filter(function (x) { return x.baseTemplate === 'item' })[0]
if (!itemCat) { console.log('NO_ITEM_CATEGORY'); process.exit(1) }
const baseItem = { id: 'base-117', categoryId: itemCat.id, name: '基准', locationType: 'place', locationLabel: '冰箱', locationName: '', fields: {}, createdAt: '2026-01-01T00:00:00.000Z', updatedAt: '2026-01-01T00:00:00.000Z' }
const mk = function (name, storedAt, updatedAt) {
  const it = JSON.parse(JSON.stringify(baseItem))
  it.id = 'it-117-' + name
  it.name = name
  it.createdAt = '2026-01-01T00:00:00.000Z'
  it.updatedAt = updatedAt
  it.fields = { name: name }
  if (storedAt !== null) it.fields.storedAt = storedAt
  return it
}
st.items = [
  mk('无日期物品', '', '2026-11-17T06:26:33.000Z'),
  mk('有日期物品', '2025-06-06', '2026-11-16T02:00:00.000Z')
]
await ev('window.GuinaNative.saveData(' + JSON.stringify(JSON.stringify(st)) + ')')
await reload()
await goHome()

// ---------- A 主界面不再显示长按拖动排序提示 ----------
const home = await bodyText()
check('A1 主界面不再出现长按分类拖动排序提示', home.indexOf('长按分类卡片可以拖动排序') < 0, '')
check('A2 主界面不再出现普通分类只能在普通分类之间调整', home.indexOf('普通分类只能在普通分类之间调整') < 0, '')
const hintCount = await ev('[...document.querySelectorAll(".field-hint")].filter((e) => (e.innerText || "").indexOf("长按") >= 0).length')
check('A3 主界面没有残留的分类拖动提示节点', Number(hintCount) === 0, String(hintCount))
await shot('117-a-home')

// ---------- B 物品分类卡片兜底时间显示可读 ----------
await openCategory(itemCat.name)
await waitText('无日期物品', 6000)
const cards = JSON.parse(await ev('JSON.stringify([...document.querySelectorAll(".item-card")].map((e) => (e.innerText || "").replace(/\\s+/g, " ").trim()))'))
const noDate = cards.find(function (t) { return t.indexOf('无日期物品') >= 0 }) || ''
const withDate = cards.find(function (t) { return t.indexOf('有日期物品') >= 0 }) || ''
check('B1 清空存放时间的卡片显示「更新 日期 时间」', /更新 \d{4}-\d{2}-\d{2} \d{2}:\d{2}/.test(noDate), noDate)
check('B2 不再出现原始 ISO 时间串', !/\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z/.test(noDate), noDate)
check('B3 有存放时间的卡片仍显示存于日期', withDate.indexOf('存于 2025-06-06') >= 0, withDate)
const allIso = cards.filter(function (t) { return /\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z/.test(t) }).length
check('B4 分类页所有卡片都没有原始 ISO 串', allIso === 0, String(allIso))
await shot('117-b-item-date')

// ---------- C 分类详情加号只新增当前分类条目；首页加号仍是三选一 ----------
const beforeMenu = await ev('document.querySelectorAll(".fab-menu").length')
const fabLabel = await ev('(() => { const b = document.querySelector(".fab"); return b ? b.getAttribute("aria-label") : "" })()')
check('C1 分类详情里加号没有展开菜单', Number(beforeMenu) === 0, String(beforeMenu) + '/' + fabLabel)
await jsTap('.fab')
await sleep(900)
const sheetInfo = JSON.parse(await ev('(() => { const p = document.querySelector(".sheet-panel"); return JSON.stringify({ open: !!p, title: p ? ((p.querySelector(".sheet-title") || {}).innerText || "") : "", text: p ? (p.innerText || "").slice(0, 300) : "", menu: document.querySelectorAll(".fab-menu").length }); })()'))
check('C2 点加号直接打开当前分类的条目表单', sheetInfo.open === true && sheetInfo.menu === 0, JSON.stringify(sheetInfo).slice(0, 200))
check('C3 打开的是条目表单而不是写便签/新建提醒', sheetInfo.text.indexOf('物品名称') >= 0 && sheetInfo.text.indexOf('写便签') < 0, sheetInfo.text.replace(/\n/g, ' | ').slice(0, 160))
check('C4 表单里没有出现菜单里的三个动作', sheetInfo.text.indexOf('新建提醒') < 0 && sheetInfo.text.indexOf('新增条目') < 0, '')
await shot('117-c-category-fab-form')
await closeSheet()
await goHome()
await sleep(600)
const homeLabel = await ev('(() => { const b = document.querySelector(".fab"); return b ? b.getAttribute("aria-label") : "" })()')
check('C5 回到首页加号恢复为「新建」', homeLabel === '新建', homeLabel)
await jsTap('.fab')
await sleep(900)
const menuInfo = JSON.parse(await ev('(() => { const m = document.querySelector(".fab-menu"); const acts = [...document.querySelectorAll(".fab-action")].map((e) => (e.innerText || "").trim()); return JSON.stringify({ open: !!m, count: acts.length, acts: acts.join("/") }); })()'))
check('C6 首页加号仍展开三个动作', menuInfo.open === true && menuInfo.count === 3, JSON.stringify(menuInfo))
check('C7 首页三个动作分别是写便签/新建提醒/新增条目', menuInfo.acts.indexOf('写便签') >= 0 && menuInfo.acts.indexOf('新建提醒') >= 0 && menuInfo.acts.indexOf('新增条目') >= 0, menuInfo.acts)
await shot('117-d-home-fab-menu')
await jsTap('.fab-action', '写便签')
await sleep(900)
const noteSheet = await ev('(() => { const p = document.querySelector(".sheet-panel"); return p ? ((p.querySelector(".sheet-title") || {}).innerText || "") : "" })()')
check('C8 首页写便签仍能打开便签表单', String(noteSheet).indexOf('便签') >= 0, String(noteSheet))
await closeSheet()

// ---------- D 关于页版本 ----------
await jsTap('.tabbar .tab', '设置'); await sleep(1000)
await ev('window.scrollTo(0, document.body.scrollHeight)'); await sleep(800)
const aboutOk = await waitText('版本 1.1.8', 6000)
check('D1 关于页显示版本 1.1.8', aboutOk, String(await ev('(() => { const e = document.querySelector(".about-version"); return e ? e.innerText : "" })()')))
await shot('117-e-about')

const passed = results.filter(function (r) { return r.ok }).length
console.log('===== RESULT ' + passed + '/' + results.length + ' =====')
const failed = results.filter(function (r) { return !r.ok }).map(function (r) { return r.name })
if (failed.length) console.log('FAILED:', failed.join(' ; '))
await c.close()
process.exit(0)