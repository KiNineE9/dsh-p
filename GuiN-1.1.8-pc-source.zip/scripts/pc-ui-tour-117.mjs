// 1.1.7 PC 全界面巡检：铺一份样例数据后逐屏截图，并检查没有横向溢出 / 关键元素可见
import { execSync, spawn } from 'node:child_process'
import fs from 'node:fs'
const { connect } = await import('./cdp.mjs')

const ROOT = 'F:/DSH/GC/GuiNa'
const PKG = JSON.parse(fs.readFileSync(ROOT + '/package.json', 'utf8'))
const PROFILE = ROOT + '/.tmp-pc117-profile'
const SHOT_DIR = ROOT + '/.tmp-shots/pc117'
const PORT = 9222
fs.mkdirSync(SHOT_DIR, { recursive: true })
const sleep = function (ms) { return new Promise(function (r) { setTimeout(r, ms) }) }
const results = []
function check(name, ok, detail) {
  results.push({ name: name, ok: !!ok })
  console.log((ok ? 'PASS' : 'FAIL') + ' | ' + name + (detail === undefined || detail === '' ? '' : ' | ' + String(detail).slice(0, 260)))
}
function killElectron() { try { execSync('taskkill /F /IM electron.exe /T', { stdio: 'ignore' }) } catch (e) {} }
function launch() {
  const env = Object.assign({}, process.env)
  delete env.ELECTRON_RUN_AS_NODE
  const child = spawn(ROOT + '/node_modules/electron/dist/electron.exe', [ROOT, '--remote-debugging-port=' + PORT, '--no-sandbox', '--user-data-dir=' + PROFILE], { detached: true, stdio: 'ignore', env: env, cwd: ROOT })
  child.unref()
}
async function waitTarget(ms) {
  const end = Date.now() + (ms || 35000)
  while (Date.now() < end) {
    try {
      const res = await fetch('http://127.0.0.1:' + PORT + '/json/list')
      const list = await res.json()
      const t = list.find(function (x) { return x.type === 'page' && x.url.indexOf('index.html') >= 0 })
      if (t) { await sleep(1000); return true }
    } catch (e) {}
    await sleep(300)
  }
  return false
}

const now = new Date().toISOString()
function item(id, categoryId, name, locationType, label, detail, fields, created) {
  return { id: id, categoryId: categoryId, name: name, locationType: locationType, locationLabel: label, locationName: detail, fields: fields, createdAt: created, updatedAt: created }
}
const seed = {
  version: 1,
  categories: [
    { id: 'cat-tour-custom', name: '旅行收藏', icon: '🧳', template: 'custom', baseTemplate: 'item', order: 10, builtin: false, customFields: [{ key: 'ticket', label: '票据号', type: 'text' }], createdAt: now },
    { id: 'cat-tour-file', name: '文件资料', icon: '🗂️', template: 'custom', baseTemplate: 'book', order: 11, builtin: false, customFields: [{ key: 'owner', label: '归属人', type: 'text' }], createdAt: now }
  ],
  items: [
    item('it-milk', 'cat-food', '牛奶', 'place', '冰箱', '第二层', { foodType: 'liquid', opened: false, storedAt: '2026-11-10', expiresAt: '2026-11-20' }, '2026-11-10T02:00:00.000Z'),
    item('it-bread', 'cat-food', '面包', 'container', '橱柜', '左边抽屉', { foodType: 'solid', opened: true, storedAt: '2026-11-01', expiresAt: '2026-11-18' }, '2026-11-01T02:00:00.000Z'),
    item('it-egg', 'cat-food', '鸡蛋', 'place', '冰箱', '蛋架', { foodType: 'solid', opened: false, storedAt: '2026-10-30', expiresAt: '2026-11-15' }, '2026-10-30T02:00:00.000Z'),
    item('it-ibuprofen', 'cat-medicine', '布洛芬', 'container', '药箱', '上层', { medicineType: 'solid', opened: false, expiresAt: '2026-12-30', effect: '退烧止痛' }, '2026-05-01T02:00:00.000Z'),
    item('it-vc', 'cat-medicine', '维生素C', 'place', '书桌', '', { medicineType: 'solid', opened: true, expiresAt: '2027-06-01', effect: '补充维生素' }, '2026-06-01T02:00:00.000Z'),
    item('it-santi', 'cat-book', '三体', 'place', '书架', '第一层', { storedAt: '2025-01-10' }, '2025-01-10T02:00:00.000Z'),
    item('it-alive', 'cat-book', '活着', 'container', '收纳箱', '书房', { storedAt: '2025-03-05' }, '2025-03-05T02:00:00.000Z'),
    item('it-charger', 'cat-item', '充电器', 'container', '抽屉', '电视柜', { storedAt: '2026-05-01' }, '2026-05-01T02:00:00.000Z'),
    item('it-umbrella', 'cat-item', '雨伞', 'place', '玄关', '', {}, '2026-11-16T02:00:00.000Z'),
    item('it-ticket', 'cat-tour-custom', '高铁票', 'place', '钱包', '夹层', { storedAt: '2026-11-01', custom: { ticket: 'G1234' } }, '2026-11-01T02:00:00.000Z'),
    item('it-contract', 'cat-tour-file', '租房合同', 'container', '文件柜', '第二格', { storedAt: '2025-09-01', custom: { owner: '我' } }, '2025-09-01T02:00:00.000Z')
  ],
  notes: [
    { id: 'note-1', itemId: 'it-milk', content: '开了之后三天内喝完', createdAt: now, updatedAt: now },
    { id: 'note-2', itemId: 'it-milk', content: '买的是低脂的', createdAt: now, updatedAt: now }
  ],
  stickies: [
    { id: 'st-1', title: '周末取快递', content: '菜鸟驿站 18 点前', kind: 'note', pinned: true, pinnedAt: now, remindAt: null, repeat: null, status: 'pending', createdAt: now, updatedAt: now, notified: true },
    { id: 'st-2', title: '交物业费', content: '月底之前', kind: 'note', pinned: false, remindAt: null, repeat: null, status: 'pending', createdAt: now, updatedAt: now, notified: true },
    { id: 'st-3', title: '吃药提醒', content: '每天早晚各一次降压药', kind: 'reminder', pinned: false, remindAt: '2026-11-18T01:00:00.000Z', repeat: { kind: 'weekdays', time: '09:00' }, status: 'pending', createdAt: now, updatedAt: now, notified: true },
    { id: 'st-4', title: '倒垃圾', content: '厨房垃圾', kind: 'reminder', pinned: false, remindAt: '2026-11-17T12:30:00.000Z', repeat: null, status: 'pending', createdAt: now, updatedAt: now, notified: true },
    { id: 'st-5', title: '周报', content: '周五下班前发出去', kind: 'reminder', pinned: false, remindAt: '2026-11-20T09:00:00.000Z', repeat: { kind: 'daily', time: '17:00' }, status: 'pending', createdAt: now, updatedAt: now, notified: true }
  ],
  tombstones: [],
  notifications: [
    { id: 'nt-1', type: 'foodExpiring', kind: 'food', itemId: 'it-bread', tier: 1, expiryDate: '2026-11-18', read: false, deleted: false, createdAt: now },
    { id: 'nt-2', type: 'medicineExpiring', kind: 'medicine', itemId: 'it-ibuprofen', tier: 30, expiryDate: '2026-12-30', read: false, deleted: false, createdAt: now }
  ],
  settings: { theme: 'system', autoLaunch: false, closeToTray: true, reminderPopup: true, reminderSound: true, stickySearchHistory: true, itemSearchHistory: true, expiryTiers: { 30: true, 15: true, 7: true, 1: true } },
  savedNames: { place: [{ name: '冰箱', lastUsedAt: now }, { name: '书架', lastUsedAt: now }], container: [{ name: '抽屉', lastUsedAt: now }, { name: '药箱', lastUsedAt: now }] },
  searchHistory: { sticky: [{ text: '吃药', usedAt: now }], item: [{ text: '牛奶', usedAt: now }, { text: '冰箱', usedAt: now }] },
  onboardingDone: true,
  createdAt: now
}

let c = null
const ev = function (e) { return c.evaluate(e) }
const t = async function (id) { return ev('(() => { const e = document.querySelector(\'[data-testid="' + id + '"]\'); if (!e) return false; e.click(); return true; })()') }
const clickText = async function (sel, text) { return ev('(() => { const e = [...document.querySelectorAll(' + JSON.stringify(sel) + ')].find(function (x) { return ((x.innerText || "").trim()).indexOf(' + JSON.stringify(text) + ') >= 0 }); if (!e) return false; e.click(); return true; })()') }
const fill = async function (id, value) { return ev('(() => { const el = document.querySelector(\'[data-testid="' + id + '"]\'); if (!el) return false; const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype; Object.getOwnPropertyDescriptor(proto, "value").set.call(el, ' + JSON.stringify(value) + '); el.dispatchEvent(new Event("input", { bubbles: true })); el.dispatchEvent(new Event("change", { bubbles: true })); return true; })()') }
const scrollText = async function (text) { return ev('(() => { const el = [...document.querySelectorAll("h2, .card-title, .section-title")].find(function (h) { return ((h.innerText || "").trim()).indexOf(' + JSON.stringify(text) + ') >= 0 }); if (!el) return false; el.scrollIntoView({ block: "start" }); return true; })()') }
async function shot(name) {
  const r = await c.send('Page.captureScreenshot', { format: 'png' })
  fs.writeFileSync(SHOT_DIR + '/' + name + '.png', Buffer.from(r.data, 'base64'))
}
async function shotFull(name) {
  const m = await c.send('Page.getLayoutMetrics')
  const w = Math.ceil(m.cssContentSize.width)
  const h = Math.min(Math.ceil(m.cssContentSize.height), 6000)
  const r = await c.send('Page.captureScreenshot', { format: 'png', captureBeyondViewport: true, clip: { x: 0, y: 0, width: w, height: h, scale: 1 } })
  fs.writeFileSync(SHOT_DIR + '/' + name + '.png', Buffer.from(r.data, 'base64'))
}
const LAYOUT = '(() => { const vw = window.innerWidth; const sw = document.documentElement.scrollWidth; const bad = []; const els = document.querySelectorAll("body *"); for (let i = 0; i < els.length; i += 1) { const el = els[i]; const r = el.getBoundingClientRect(); if (r.width < 2 || r.height < 2) continue; const st = getComputedStyle(el); if (st.position === "fixed" || st.visibility === "hidden" || st.display === "none") continue; if (r.right > vw + 2) bad.push(((typeof el.className === "string" && el.className) ? el.className.split(" ")[0] : el.tagName) + "@" + Math.round(r.right)); } return JSON.stringify({ vw: vw, sw: sw, bad: bad.slice(0, 6) }); })()'
async function layoutInfo() { return JSON.parse(await ev(LAYOUT)) }
async function visit(name, expectSel) {
  await sleep(450)
  const l = await layoutInfo()
  await shot(name)
  const has = expectSel ? !!(await ev('!!document.querySelector(' + JSON.stringify(expectSel) + ')')) : true
  const close = !expectSel || (await ev('(() => { const r = document.querySelector(' + JSON.stringify(expectSel) + ').getBoundingClientRect(); return r.width > 2 && r.height > 2 })()'))
  check(name, l.sw <= l.vw + 1 && l.bad.length === 0 && has && close, (!has ? 'missing ' + expectSel + ' ; ' : '') + JSON.stringify(l))
}
async function backHome() { await clickText('button', '返回'); await sleep(500) }
async function openCategory(name) { await ev('window.scrollTo(0, 0)'); await sleep(250); await clickText('.category-card', name); await sleep(700) }

async function main() {
  killElectron()
  fs.rmSync(PROFILE, { recursive: true, force: true })
  launch()
  if (!(await waitTarget())) throw new Error('first launch timeout')
  c = await connect(PORT, 'index.html')
  await c.send('Page.enable'); await c.send('Runtime.enable')
  const dir = await ev('(async function () { const i = await window.guina.getDataInfo(); return i.dir })()')
  fs.writeFileSync(dir + '/data.json', JSON.stringify(seed, null, 2))
  c.close()
  killElectron()
  await sleep(2000)
  launch()
  if (!(await waitTarget())) throw new Error('second launch timeout')
  c = await connect(PORT, 'index.html')
  await c.send('Page.enable'); await c.send('Runtime.enable')
  await sleep(1200)
  if (await ev('!!document.querySelector(\'[data-testid="onboarding"]\')')) { await t('onboarding-skip'); await sleep(500) }

  // 首页：分类区 + 便签区
  await ev('window.scrollTo(0, 0)'); await sleep(400)
  await visit('01-home-top', '.category-card')
  const cards = await ev('document.querySelectorAll(".category-card").length')
  const stickies = await ev('document.querySelectorAll(".sticky-card").length')
  check('01b 首页显示 6 个分类卡片和 5 张便签', Number(cards) === 6 && Number(stickies) === 5, cards + '/' + stickies)
  await ev('document.querySelector(\'[data-testid="sticky-section"]\').scrollIntoView({ block: "start" })'); await sleep(400)
  await t('sticky-board-toggle'); await sleep(500)
  await visit('02-home-sticky-collapsed', '.sticky-section')
  await t('sticky-board-toggle'); await sleep(500)

  // 分类页：食品 / 图书 / 药品 / 物品 / 自定义
  await openCategory('食品')
  await visit('03-category-food', '.category-title')
  const foodRows = await ev('document.querySelectorAll(\'[data-testid="item-row"]\').length')
  check('03b 食品分类显示 3 条条目', Number(foodRows) === 3, foodRows)
  await t('item-more'); await sleep(400)
  await visit('04-item-menu', '.menu')
  await t('item-edit'); await sleep(700)
  await visit('05-item-form-food', '.modal')
  await t('modal-cancel'); await sleep(500)
  await t('add-item'); await sleep(700)
  await visit('06-item-form-food-new', '.modal')
  await t('modal-cancel'); await sleep(500)
  await backHome()
  await openCategory('图书')
  await visit('07-category-book', '.category-title')
  await t('add-item'); await sleep(700)
  await visit('08-item-form-book', '.modal')
  await t('modal-cancel'); await sleep(500)
  await backHome()
  await openCategory('药品')
  await visit('09-category-medicine', '.category-title')
  await t('add-item'); await sleep(700)
  await visit('10-item-form-medicine', '.modal')
  await t('modal-cancel'); await sleep(500)
  await backHome()
  await openCategory('物品')
  await visit('11-category-item', '.category-title')
  await t('add-item'); await sleep(700)
  await visit('12-item-form-item', '.modal')
  await t('modal-cancel'); await sleep(500)
  await backHome()
  await openCategory('旅行收藏')
  await visit('13-category-custom', '.category-title')
  await t('add-item'); await sleep(700)
  await visit('14-item-form-custom', '.modal')
  await t('modal-cancel'); await sleep(500)
  await backHome()

  // 备注弹窗
  await openCategory('食品')
  await t('item-more'); await sleep(300)
  await t('item-notes'); await sleep(700)
  await visit('15-item-notes', '[data-testid="notes-list"]')
  await t('modal-cancel'); await sleep(500)
  await backHome()

  // 搜索与搜索历史
  await fill('search-input', '牛奶'); await sleep(800)
  await visit('16-search-results', '.search-results')
  const hits = await ev('document.querySelectorAll(\'[data-testid="search-hit"]\').length')
  check('16b 搜索牛奶能命中条目', Number(hits) > 0, hits)
  await fill('search-input', ''); await sleep(500)
  await ev('document.querySelector(\'[data-testid="search-input"]\').focus()'); await sleep(500)
  await visit('17-search-history', '.search-history')
  await ev('document.dispatchEvent(new MouseEvent("mousedown", { bubbles: true }))'); await sleep(300)

  // 通知面板
  await t('bell'); await sleep(800)
  await visit('18-notifications-food', '[data-testid="notification-panel"]')
  await t('notif-tab-medicine'); await sleep(500)
  await visit('19-notifications-medicine', '[data-testid="notification-panel"]')
  await t('notif-close'); await sleep(500)

  // 设置页各段
  await t('settings-btn'); await sleep(900)
  await ev('window.scrollTo(0, 0)'); await sleep(400)
  await visit('20-settings-top', '[data-testid="settings-page"]')
  check('20b 设置页有外观与系统卡片', (await ev('document.body.innerText')).indexOf('外观') >= 0 && (await ev('document.body.innerText')).indexOf('系统') >= 0, '')
  await scrollText('提醒'); await sleep(500)
  await visit('21-settings-reminder', '[data-testid="btn-test-sound"]')
  await scrollText('搜索历史'); await sleep(500)
  await visit('22-settings-history', '.settings-card')
  await scrollText('数据'); await sleep(500)
  await visit('23-settings-data-sync', '[data-testid="sync-card"]')
  check('23b 同步卡片显示未绑定状态', (await ev('document.querySelector(\'[data-testid="sync-card"]\').innerText')).indexOf('还没有绑定任何设备') >= 0, '')
  await scrollText('手动备份与还原'); await sleep(500)
  await visit('24-settings-backup', '[data-testid="backup-card"]')
  await scrollText('关于'); await sleep(500)
  await visit('25-settings-about', '[data-testid="about-card"]')
  check('25b 关于页版本号为 ' + PKG.version, (await ev('document.querySelector(\'[data-testid="about-version"]\').innerText')).indexOf(PKG.version) >= 0, await ev('document.querySelector(\'[data-testid="about-version"]\').innerText'))
  await ev('window.scrollTo(0, document.body.scrollHeight)'); await sleep(500)
  await visit('26-settings-quit', '[data-testid="btn-quit"]')
  await ev('window.scrollTo(0, 0)'); await sleep(300)
  await shotFull('27-settings-full')

  // 新手引导
  await scrollText('新手引导'); await sleep(400)
  await t('btn-show-onboarding'); await sleep(900)
  await visit('28-onboarding', '[data-testid="onboarding"]')
  await t('onboarding-skip'); await sleep(600)

  // 回首页：新建分类、便签、提醒、便签详情、删除确认
  await clickText('.brand', 'GuiN'); await sleep(700)
  await t('add-category'); await sleep(800)
  await visit('29-category-form', '[data-testid="category-name"]')
  await t('modal-cancel'); await sleep(500)
  await t('sticky-add-note'); await sleep(800)
  await visit('30-sticky-form-note', '[data-testid="sticky-content"]')
  await t('modal-cancel'); await sleep(500)
  await t('sticky-add-reminder'); await sleep(800)
  await visit('31-sticky-form-reminder', '[data-testid="sticky-repeat-kind"]')
  await t('modal-cancel'); await sleep(500)
  await ev('document.querySelector(\'[data-testid="sticky-card"]\').click()'); await sleep(800)
  await visit('32-sticky-detail', '[data-testid="sticky-detail"]')
  await t('modal-cancel'); await sleep(500)
  await t('category-more'); await sleep(400)
  await visit('33-category-menu', '.menu')
  await t('category-delete'); await sleep(700)
  await visit('34-confirm-dialog', '[data-testid="modal"]')
  await t('modal-cancel'); await sleep(400)

  c.close()
  killElectron()
  const passed = results.filter(function (r) { return r.ok }).length
  console.log('===== RESULT ' + passed + '/' + results.length + ' =====')
  const failed = results.filter(function (r) { return !r.ok }).map(function (r) { return r.name })
  if (failed.length) console.log('FAILED: ' + failed.join(' ; '))
}

try { await main(); process.exit(0) } catch (e) { console.log('FATAL: ' + (e && e.stack ? e.stack : e)); killElectron(); process.exit(1) }