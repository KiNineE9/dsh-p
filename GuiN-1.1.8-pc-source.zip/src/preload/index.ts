import { contextBridge, ipcRenderer } from 'electron'
import type { GuinaApi } from '../shared/api'

function subscribe<T>(channel: string, cb: (payload: T) => void): () => void {
  const handler = function (_event: Electron.IpcRendererEvent, payload: T): void {
    cb(payload)
  }
  ipcRenderer.on(channel, handler)
  return function (): void {
    ipcRenderer.removeListener(channel, handler)
  }
}

const api: GuinaApi = {
  getState: function () { return ipcRenderer.invoke('state:get') },
  getDataInfo: function () { return ipcRenderer.invoke('data:info') },
  createCategory: function (draft) { return ipcRenderer.invoke('category:create', draft) },
  updateCategory: function (id, patch) { return ipcRenderer.invoke('category:update', id, patch) },
  deleteCategory: function (id) { return ipcRenderer.invoke('category:delete', id) },
  reorderCategories: function (ids) { return ipcRenderer.invoke('category:reorder', ids) },
  createItem: function (categoryId, draft) { return ipcRenderer.invoke('item:create', categoryId, draft) },
  updateItem: function (id, draft) { return ipcRenderer.invoke('item:update', id, draft) },
  deleteItem: function (id) { return ipcRenderer.invoke('item:delete', id) },
  removeSavedName: function (type, name) { return ipcRenderer.invoke('saved-name:remove', type, name) },
  addSearchHistory: function (kind, text) { return ipcRenderer.invoke('history:add', kind, text) },
  removeSearchHistory: function (kind, text) { return ipcRenderer.invoke('history:remove', kind, text) },
  addNote: function (itemId, content) { return ipcRenderer.invoke('note:add', itemId, content) },
  updateNote: function (id, content) { return ipcRenderer.invoke('note:update', id, content) },
  deleteNote: function (id) { return ipcRenderer.invoke('note:delete', id) },
  createSticky: function (draft) { return ipcRenderer.invoke('sticky:create', draft) },
  updateSticky: function (id, patch) { return ipcRenderer.invoke('sticky:update', id, patch) },
  deleteSticky: function (id) { return ipcRenderer.invoke('sticky:delete', id) },
  markNotificationRead: function (id, read) { return ipcRenderer.invoke('notif:read', id, read) },
  markAllNotificationsRead: function (kind) { return ipcRenderer.invoke('notif:read-all', kind) },
  deleteNotification: function (id) { return ipcRenderer.invoke('notif:delete', id) },
  deleteReadNotifications: function (kind) { return ipcRenderer.invoke('notif:delete-read', kind) },
  createBackup: function (name, overwriteId) { return ipcRenderer.invoke('backup:create', name, overwriteId) },
  listBackups: function () { return ipcRenderer.invoke('backup:list') },
  restoreBackup: function (id) { return ipcRenderer.invoke('backup:restore', id) },
  deleteBackup: function (id) { return ipcRenderer.invoke('backup:delete', id) },
  updateSettings: function (patch) { return ipcRenderer.invoke('settings:update', patch) },
  finishOnboarding: function () { return ipcRenderer.invoke('onboarding:finish') },
  showOnboarding: function () { return ipcRenderer.invoke('onboarding:show') },
  openDataFolder: function () { return ipcRenderer.invoke('app:open-data-folder') },
  openExternal: function (url) { return ipcRenderer.invoke('app:open-external', url) },
  showMainWindow: function () { return ipcRenderer.invoke('app:show') },
  quitApp: function () { return ipcRenderer.invoke('app:quit') },
  sendTestReminder: function () { return ipcRenderer.invoke('app:test-reminder') },
  getReminderPayload: function () { return ipcRenderer.invoke('reminder:get') },
  reminderAction: function (action) { return ipcRenderer.invoke('reminder:action', action) },
  getSyncDeviceInfo: function () { return ipcRenderer.invoke('sync:device-info') },
  getSyncConfig: function () { return ipcRenderer.invoke('sync:config-get') },
  saveSyncConfig: function (config) { return ipcRenderer.invoke('sync:config-save', config) },
  syncApplyState: function (state) { return ipcRenderer.invoke('sync:apply-state', state) },
  exportDataFile: function () { return ipcRenderer.invoke('data:export-json') },
  importDataFile: function () { return ipcRenderer.invoke('data:import-json') },
  onStateChanged: function (cb) { return subscribe('state:changed', cb) },
  onLocateItem: function (cb) { return subscribe('app:locate-item', cb) },
  onOpenDialog: function (cb) { return subscribe('app:open-dialog', cb) },
  onPlaySound: function (cb) { return subscribe('app:play-sound', function () { cb() }) },
  onToast: function (cb) { return subscribe('app:toast', cb) },
  onOpenSettings: function (cb) { return subscribe('app:open-settings', function () { cb() }) }
}

contextBridge.exposeInMainWorld('guina', api)
