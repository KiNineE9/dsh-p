import type { GuinaApi } from '../../shared/api'

declare global {
  interface Window {
    guina: GuinaApi
  }
}

export {}
