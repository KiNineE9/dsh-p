import type { AppState } from '../types'
import { decryptText, encryptText, importAesKey } from './crypto'
import type { SyncDeviceIdentity, SyncMode, SyncScope, SyncStats } from './types'

/** 底层连接抽象：PeerJS / 测试用内存连接都实现它 */
export interface Channel {
  send(obj: unknown): void
  onMessage(cb: (data: unknown) => void): void
  onClose(cb: (reason: string) => void): void
  close(): void
}

export function isRecord(value: unknown): value is Record<string, unknown> {
  return !!value && typeof value === 'object' && !Array.isArray(value)
}

interface Waiter {
  types: string[]
  resolve: (msg: Record<string, unknown>) => void
  reject: (err: Error) => void
  timer: ReturnType<typeof setTimeout>
}

/** 按消息类型收取消息的收件箱，先到的消息排队，后来等待的人直接取 */
export class MessageInbox {
  private queue: Array<Record<string, unknown>> = []
  private waiters: Waiter[] = []

  push(raw: unknown): void {
    if (!isRecord(raw) || typeof raw.t !== 'string') return
    const msg = raw
    const idx = this.waiters.findIndex(function (w) { return w.types.indexOf(msg.t as string) >= 0 })
    if (idx >= 0) {
      const waiter = this.waiters[idx]
      this.waiters.splice(idx, 1)
      clearTimeout(waiter.timer)
      waiter.resolve(msg)
      return
    }
    this.queue.push(msg)
  }

  next(type: string, timeoutMs: number): Promise<Record<string, unknown>> {
    return this.nextAny([type], timeoutMs)
  }

  nextAny(types: string[], timeoutMs: number): Promise<Record<string, unknown>> {
    const idx = this.queue.findIndex(function (m) { return types.indexOf(m.t as string) >= 0 })
    if (idx >= 0) return Promise.resolve(this.queue.splice(idx, 1)[0])
    return new Promise((resolve, reject) => {
      const waiter: Waiter = {
        types,
        resolve,
        reject,
        timer: 0 as unknown as ReturnType<typeof setTimeout>
      }
      waiter.timer = setTimeout(function () {
        const i = self.waiters.indexOf(waiter)
        if (i >= 0) self.waiters.splice(i, 1)
        reject(new Error('等待对方响应超时，请检查网络后重试'))
      }, timeoutMs)
      const self = this
      this.waiters.push(waiter)
    })
  }

  /** 取出当前已排队但还没被消费的消息（切换到加密通道时用来搬移缓冲） */
  drain(): Array<Record<string, unknown>> {
    const list = this.queue.slice()
    this.queue.length = 0
    return list
  }

  /** 连接断开时让所有等待中的请求立即失败 */
  fail(reason: string): void {
    const list = this.waiters.splice(0, this.waiters.length)
    for (const waiter of list) {
      clearTimeout(waiter.timer)
      waiter.reject(new Error(reason))
    }
  }
}

/** 加密消息通道：整段 JSON 加密后按 30KB 分片发送，收端拼起来解密 */
export class SecureChannel {
  private keyPromise: Promise<CryptoKey>
  private inbox = new MessageInbox()
  private parts = new Map<string, { total: number; chunks: Map<number, string> }>()
  private chain: Promise<void> = Promise.resolve()
  private closed = false

  constructor(private channel: Channel, keyB64: string) {
    this.keyPromise = importAesKey(keyB64)
    const self = this
    channel.onMessage(function (raw) {
      void self.onRaw(raw)
    })
    channel.onClose(function (reason) {
      self.inboxFail(reason)
    })
  }

  private inboxFail(reason: string): void {
    this.closed = true
    this.inbox.fail(reason)
  }

  private async onRaw(raw: unknown): Promise<void> {
    if (!isRecord(raw)) return
    const type = raw.t
    if (type === 'chunk') {
      const sid = typeof raw.sid === 'string' ? raw.sid : ''
      const seq = typeof raw.seq === 'number' ? raw.seq : -1
      const total = typeof raw.total === 'number' ? raw.total : 0
      const data = typeof raw.d === 'string' ? raw.d : ''
      if (!sid || seq < 0 || total <= 0) return
      let entry = this.parts.get(sid)
      if (!entry) {
        entry = { total, chunks: new Map<number, string>() }
        this.parts.set(sid, entry)
      }
      entry.chunks.set(seq, data)
      return
    }
    if (type === 'chunk-end') {
      const sid = typeof raw.sid === 'string' ? raw.sid : ''
      const entry = this.parts.get(sid)
      if (!entry) return
      this.parts.delete(sid)
      if (entry.chunks.size !== entry.total) return
      const pieces: string[] = []
      for (let i = 0; i < entry.total; i++) pieces.push(entry.chunks.get(i) || '')
      try {
        const key = await this.keyPromise
        const plain = await decryptText(key, pieces.join(''))
        this.inbox.push(JSON.parse(plain))
      } catch {
        /* 解密失败：数据被篡改或密钥不匹配，直接丢弃 */
      }
    }
  }

  send(obj: unknown): Promise<void> {
    const self = this
    this.chain = this.chain.then(function () { return self.doSend(obj) }).catch(function () { /* 发送失败由上层超时处理 */ })
    return this.chain
  }

  private async doSend(obj: unknown): Promise<void> {
    if (this.closed) throw new Error('连接已断开')
    const key = await this.keyPromise
    const payload = await encryptText(key, JSON.stringify(obj))
    const chunkSize = 30000
    const total = Math.max(1, Math.ceil(payload.length / chunkSize))
    const sid = Math.random().toString(36).slice(2, 10)
    for (let i = 0; i < total; i++) {
      this.channel.send({
        t: 'chunk',
        sid,
        seq: i,
        total,
        d: payload.slice(i * chunkSize, (i + 1) * chunkSize)
      })
    }
    this.channel.send({ t: 'chunk-end', sid })
  }

  /** 把切换加密通道之前就已经到达的明文消息补喂进来（避免握手与首条密文之间的竞态丢消息） */
  feed(raw: unknown): void {
    void this.onRaw(raw)
  }

  next(type: string, timeoutMs: number): Promise<Record<string, unknown>> {
    return this.inbox.next(type, timeoutMs)
  }

  nextAny(types: string[], timeoutMs: number): Promise<Record<string, unknown>> {
    return this.inbox.nextAny(types, timeoutMs)
  }

  close(): void {
    this.closed = true
    this.channel.close()
  }
}

/** 明文消息（握手阶段用） */
export interface WireHello {
  t: 'hello'
  device: SyncDeviceIdentity
  nonce: string
}
export interface WireHelloAck {
  t: 'hello-ack'
  device: SyncDeviceIdentity
  nonce: string
  mac: string
}
export interface WireHelloOk {
  t: 'hello-ok'
  mac: string
}
export interface WirePairRequest {
  t: 'pair-req'
  device: SyncDeviceIdentity
  proof: string
}
export interface WirePairOk {
  t: 'pair-ok'
  device: SyncDeviceIdentity
  keyEnc: string
}
export interface WirePairNo {
  t: 'pair-no'
  error: string
}
export interface WireSyncRequest {
  t: 'sync-req'
  mode: SyncMode
  scope: SyncScope
}
export interface WireState {
  t: 'state'
  state: AppState
}
export interface WireApplied {
  t: 'applied'
  stats?: SyncStats
}
export interface WireError {
  t: 'error'
  error: string
}
export interface WireMergeState {
  t: 'merge-state'
  state: AppState
  stats: SyncStats
}
export interface WireMergeApply {
  t: 'merge-apply'
}
export interface WireMergeDone {
  t: 'merge-done'
  stats: SyncStats
}
export interface WireReject {
  t: 'reject'
  error: string
}

/** 解析二维码/邀请码文本 */
export function encodePairingText(offer: unknown): string {
  const json = JSON.stringify(offer)
  const bytes = new TextEncoder().encode(json)
  let binary = ''
  for (let i = 0; i < bytes.length; i++) binary += String.fromCharCode(bytes[i])
  return 'GUINPAIR1:' + btoa(binary)
}

export function decodePairingText(text: string): Record<string, unknown> {
  const raw = (text || '').trim()
  const prefix = 'GUINPAIR1:'
  if (!raw.startsWith(prefix)) throw new Error('邀请内容格式不对，请重新复制')
  const binary = atob(raw.slice(prefix.length))
  const bytes = new Uint8Array(binary.length)
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i)
  const parsed: unknown = JSON.parse(new TextDecoder().decode(bytes))
  if (!isRecord(parsed)) throw new Error('邀请内容格式不对，请重新复制')
  return parsed
}
