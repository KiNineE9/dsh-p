import type { AppState, Tombstone, TombstoneKind } from '../types'

/** 墓碑保留天数：超过这个时间的删除记录会被清理 */
export const TOMBSTONE_KEEP_DAYS = 365

/** 判断一条任意数据是否像墓碑记录 */
export function isTombstoneLike(raw: unknown): boolean {
  if (!raw || typeof raw !== 'object') return false
  const t = raw as Tombstone
  if (t.kind !== 'category' && t.kind !== 'item' && t.kind !== 'note' && t.kind !== 'sticky') return false
  return typeof t.id === 'string' && typeof t.deletedAt === 'string'
}

/** 墓碑唯一键 */
export function tombstoneKey(kind: TombstoneKind, id: string): string {
  return kind + ':' + id
}

/**
 * 规整从磁盘/网络读到的墓碑列表：过滤坏记录、按 kind+id 去重（保留最新删除时间）、
 * 清理掉超过保留期的旧墓碑。
 */
export function normalizeTombstones(raw: unknown, now: number = Date.now()): Tombstone[] {
  const list = Array.isArray(raw) ? (raw as unknown[]).filter(isTombstoneLike) : []
  const byKey = new Map<string, Tombstone>()
  for (const entry of list) {
    const t = entry as Tombstone
    const key = tombstoneKey(t.kind, t.id)
    const prev = byKey.get(key)
    if (!prev || Date.parse(t.deletedAt) > Date.parse(prev.deletedAt)) byKey.set(key, t)
  }
  const cutoff = now - TOMBSTONE_KEEP_DAYS * 24 * 60 * 60 * 1000
  const out: Tombstone[] = []
  byKey.forEach(function (t) {
    const at = Date.parse(t.deletedAt)
    if (!Number.isNaN(at) && at >= cutoff) out.push(t)
  })
  out.sort(function (a, b) { return Date.parse(a.deletedAt) - Date.parse(b.deletedAt) })
  return out
}

/** 记录删除：同一 kind+id 只保留一条最新的墓碑 */
export function appendTombstone(
  state: AppState,
  kind: TombstoneKind,
  ids: string | string[],
  at: string = new Date().toISOString()
): void {
  if (!Array.isArray(state.tombstones)) state.tombstones = []
  const list = Array.isArray(ids) ? ids : [ids]
  for (const id of list) {
    if (!id) continue
    const key = tombstoneKey(kind, id)
    const idx = state.tombstones.findIndex(function (t) { return tombstoneKey(t.kind, t.id) === key })
    if (idx >= 0) state.tombstones[idx] = { kind, id, deletedAt: at }
    else state.tombstones.push({ kind, id, deletedAt: at })
  }
}

/** 清理过期墓碑（长时间使用后避免数据文件无限增长） */
export function pruneTombstones(state: AppState, now: number = Date.now()): void {
  state.tombstones = normalizeTombstones(state.tombstones, now)
}
