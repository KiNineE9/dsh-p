import { BUILTIN_CATEGORY_IDS, SAVED_NAME_LIMIT } from '../schema'
import { normalizeText } from '../search'
import type { AppState, Category, Item, Note, SavedName, StickyNote, Tombstone } from '../types'
import { normalizeTombstones, TOMBSTONE_KEEP_DAYS } from './tombstones'
import { normalizeSearchHistory } from '../history'
import type { SyncScope, SyncStats } from './types'

export interface MergeOutput {
  state: AppState
  stats: SyncStats
}

/** 两台设备类型不同时（手机 ↔ 电脑）不同步便签与提醒 */
export function scopeForKinds(localKind: string, remoteKind: string): SyncScope {
  return localKind === remoteKind ? 'full' : 'no-stickies'
}

function timeOf(value: string | undefined | null): number {
  if (!value) return 0
  const t = Date.parse(value)
  return Number.isNaN(t) ? 0 : t
}

function recordTime(r: { updatedAt?: string; createdAt?: string }): number {
  const u = timeOf(r.updatedAt)
  if (u > 0) return u
  return timeOf(r.createdAt)
}

function pickNewer<T extends { id: string; updatedAt?: string; createdAt?: string }>(a: T, b: T): T {
  const ta = recordTime(a)
  const tb = recordTime(b)
  if (ta !== tb) return ta > tb ? a : b
  return a.id <= b.id ? a : b
}

function pickEarlier<T extends { id: string; createdAt?: string }>(a: T, b: T): T {
  const ta = timeOf(a.createdAt)
  const tb = timeOf(b.createdAt)
  if (ta !== tb) return ta <= tb ? a : b
  return a.id <= b.id ? a : b
}

function unionById<T extends { id: string; updatedAt?: string; createdAt?: string }>(local: T[], remote: T[]): T[] {
  const map = new Map<string, T>()
  for (const r of local) map.set(r.id, r)
  for (const r of remote) {
    const prev = map.get(r.id)
    map.set(r.id, prev ? pickNewer(prev, r) : r)
  }
  return Array.from(map.values())
}

function deadIds(tombstones: Tombstone[], kind: Tombstone['kind']): Map<string, number> {
  const out = new Map<string, number>()
  for (const t of tombstones) {
    if (t.kind !== kind) continue
    const at = timeOf(t.deletedAt)
    const prev = out.get(t.id) || 0
    if (at > prev) out.set(t.id, at)
  }
  return out
}

function dropDead<T extends { id: string; createdAt?: string; updatedAt?: string }>(list: T[], dead: Map<string, number>): T[] {
  return list.filter(function (r) {
    const at = dead.get(r.id)
    if (!at) return true
    return recordTime(r) > at
  })
}

function categorySignature(cat: Category): string {
  const builtin = (Object.values(BUILTIN_CATEGORY_IDS) as string[]).indexOf(cat.id) >= 0 ? 'builtin' : 'custom'
  return normalizeText(cat.name) + '|' + cat.baseTemplate + '|' + builtin
}

/** 分类去重 + 名称重映射：内置分类不互相合并，自定义分类同名同模板只留一个 */
function mergeCategories(local: Category[], remote: Category[]): { list: Category[]; remap: Map<string, string>; duplicates: number } {
  const union = unionById(local, remote)
  const bySig = new Map<string, Category>()
  const remap = new Map<string, string>()
  let duplicates = 0
  for (const cat of union) {
    const sig = categorySignature(cat)
    const prev = bySig.get(sig)
    if (!prev) {
      bySig.set(sig, { ...cat })
      remap.set(cat.id, cat.id)
      continue
    }
    const keep = pickEarlier(prev, cat)
    const drop = keep === prev ? cat : prev
    const kept = { ...keep }
    bySig.set(sig, kept)
    remap.set(drop.id, kept.id)
    remap.set(kept.id, kept.id)
    duplicates++
  }
  const list = Array.from(bySig.values())
  list.sort(function (a, b) {
    if (a.order !== b.order) return a.order - b.order
    const t = timeOf(a.createdAt) - timeOf(b.createdAt)
    if (t !== 0) return t
    return a.id < b.id ? -1 : a.id > b.id ? 1 : 0
  })
  const ordered = list.map(function (c, idx) { return { ...c, order: idx } })
  return { list: ordered, remap, duplicates }
}

function itemSignature(item: Item): string {
  return [
    item.categoryId,
    normalizeText(item.name),
    normalizeText(item.locationLabel),
    normalizeText(item.locationName)
  ].join('|')
}

function mergeItems(
  local: Item[],
  remote: Item[],
  tombstones: Tombstone[],
  catRemap: Map<string, string>
): { list: Item[]; remap: Map<string, string>; duplicates: number } {
  const dead = deadIds(tombstones, 'item')
  const union = unionById(local, remote)
  const mapped: Item[] = []
  for (const item of union) {
    const categoryId = catRemap.get(item.categoryId)
    if (!categoryId) continue
    mapped.push({ ...item, categoryId })
  }
  const bySig = new Map<string, Item>()
  const remap = new Map<string, string>()
  let duplicates = 0
  for (const item of dropDead(mapped, dead)) {
    const sig = itemSignature(item)
    const prev = bySig.get(sig)
    if (!prev) {
      bySig.set(sig, item)
      remap.set(item.id, item.id)
      continue
    }
    const keep = pickEarlier(prev, item)
    const drop = keep === prev ? item : prev
    bySig.set(sig, keep)
    remap.set(drop.id, keep.id)
    remap.set(keep.id, keep.id)
    duplicates++
  }
  return { list: Array.from(bySig.values()), remap, duplicates }
}

function noteSignature(note: Note): string {
  return note.itemId + '|' + normalizeText(note.content)
}

function mergeNotes(
  local: Note[],
  remote: Note[],
  tombstones: Tombstone[],
  itemRemap: Map<string, string>
): { list: Note[]; duplicates: number } {
  const dead = deadIds(tombstones, 'note')
  const union = unionById(local, remote)
  const bySig = new Map<string, Note>()
  let duplicates = 0
  for (const note of dropDead(union, dead)) {
    const itemId = itemRemap.get(note.itemId)
    if (!itemId) continue
    const next = { ...note, itemId }
    const sig = noteSignature(next)
    const prev = bySig.get(sig)
    if (!prev) {
      bySig.set(sig, next)
      continue
    }
    bySig.set(sig, pickEarlier(prev, next))
    duplicates++
  }
  return { list: Array.from(bySig.values()), duplicates }
}

function mergeStickies(local: StickyNote[], remote: StickyNote[], tombstones: Tombstone[]): StickyNote[] {
  const dead = deadIds(tombstones, 'sticky')
  return dropDead(unionById(local, remote).map(function (s) { return { ...s } }), dead)
}

function nameKey(raw: string): string {
  return (raw || '').replace(/\s+/g, ' ').trim().toLowerCase()
}

function mergeSavedNameList(local: SavedName[], remote: SavedName[]): SavedName[] {
  const map = new Map<string, SavedName>()
  for (const entry of local.concat(remote)) {
    const name = (entry.name || '').replace(/\s+/g, ' ').trim()
    if (!name) continue
    const key = nameKey(name)
    const prev = map.get(key)
    if (!prev || timeOf(entry.lastUsedAt) > timeOf(prev.lastUsedAt)) {
      map.set(key, { name, lastUsedAt: entry.lastUsedAt })
    }
  }
  const list = Array.from(map.values())
  list.sort(function (a, b) { return timeOf(b.lastUsedAt) - timeOf(a.lastUsedAt) })
  return list.slice(0, SAVED_NAME_LIMIT)
}

function statsFor(local: AppState, merged: AppState): SyncStats {
  let added = 0
  let updated = 0
  const pairs: Array<[Array<{ id: string }>, Array<{ id: string }>]> = [
    [local.categories, merged.categories],
    [local.items, merged.items],
    [local.notes, merged.notes],
    [local.stickies, merged.stickies]
  ]
  for (const pair of pairs) {
    const before = new Map(pair[0].map(function (r) { return [r.id, JSON.stringify(r)] as [string, string] }))
    for (const record of pair[1]) {
      const prev = before.get(record.id)
      if (!prev) added++
      else if (prev !== JSON.stringify(record)) updated++
    }
  }
  const total = merged.categories.length + merged.items.length + merged.notes.length + merged.stickies.length
  return { added, updated, duplicates: 0, total }
}

/**
 * 合并双方数据（纯函数，不修改入参）：
 * - 按 id 取并集，同一条记录取更新时间较新的；
 * - 删除墓碑比记录新时，以删除为准，不会把已删内容带回来；
 * - 自定义分类同名去重，条目按「分类 + 名称 + 位置」去重，备注按「条目 + 内容」去重；
 * - 设置、引导状态、通知列表始终保留本机，避免把对方设备的偏好带过来。
 */
export function mergeStates(local: AppState, remote: AppState, scope: SyncScope): MergeOutput {
  const remoteTombstones = Array.isArray(remote.tombstones) ? remote.tombstones : []
  const localTombstones = Array.isArray(local.tombstones) ? local.tombstones : []
  const incomingTombstones = scope === 'no-stickies' ? remoteTombstones.filter(function (t) { return t.kind !== 'sticky' }) : remoteTombstones
  const tombstones = normalizeTombstones(localTombstones.concat(incomingTombstones))
  const categories = mergeCategories(local.categories, remote.categories)
  const categoryDead = deadIds(tombstones, 'category')
  const categoryList = categories.list.filter(function (c) {
    const at = categoryDead.get(c.id)
    return !at || timeOf(c.createdAt) > at
  })
  const catRemap = new Map<string, string>()
  for (const cat of categoryList) {
    const mapped = categories.remap.get(cat.id)
    catRemap.set(cat.id, mapped || cat.id)
  }
  const items = mergeItems(local.items, remote.items, tombstones, catRemap)
  const notes = mergeNotes(local.notes, remote.notes, tombstones, items.remap)
  const stickies = scope === 'no-stickies'
    ? local.stickies.map(function (s) { return { ...s } })
    : mergeStickies(local.stickies, remote.stickies, tombstones)
  const itemIds = new Set(items.list.map(function (i) { return i.id }))
  const state: AppState = {
    version: local.version,
    categories: categoryList,
    items: items.list,
    notes: notes.list,
    stickies,
    tombstones,
    notifications: (local.notifications || []).filter(function (n) { return itemIds.has(n.itemId) }),
    settings: { ...local.settings, expiryTiers: { ...local.settings.expiryTiers } },
    savedNames: {
      place: mergeSavedNameList(local.savedNames.place, remote.savedNames.place),
      container: mergeSavedNameList(local.savedNames.container, remote.savedNames.container)
    },
    searchHistory: normalizeSearchHistory(local.searchHistory),
    onboardingDone: local.onboardingDone,
    createdAt: local.createdAt
  }
  const stats = statsFor(local, state)
  stats.duplicates = categories.duplicates + items.duplicates + notes.duplicates
  return { state, stats }
}

/** 「推送 / 拉取」时整体采用对方数据，但保留本机设置、引导状态与（手机↔电脑时的）本机便签 */
export function adoptState(local: AppState, remote: AppState, scope: SyncScope): MergeOutput {
  const remoteTombstones = Array.isArray(remote.tombstones) ? remote.tombstones : []
  const localTombstones = Array.isArray(local.tombstones) ? local.tombstones : []
  const remoteKept = scope === 'no-stickies' ? remoteTombstones.filter(function (t) { return t.kind !== 'sticky' }) : remoteTombstones
  const tombstones = normalizeTombstones(localTombstones.concat(remoteKept))
  const categories = mergeCategories(remote.categories, [])
  const catRemap = categories.remap
  const items = mergeItems(remote.items, [], tombstones, catRemap)
  const notes = mergeNotes(remote.notes, [], tombstones, items.remap)
  let stickies: StickyNote[]
  if (scope === 'no-stickies') {
    stickies = local.stickies.map(function (s) { return { ...s } })
  } else {
    const dead = deadIds(tombstones, 'sticky')
    stickies = remote.stickies.map(function (s) { return { ...s } }).filter(function (s) { return !dead.has(s.id) })
  }
  const itemIds = new Set(items.list.map(function (i) { return i.id }))
  const remoteNotifications = Array.isArray(remote.notifications) ? remote.notifications : []
  const state: AppState = {
    version: local.version,
    categories: categories.list,
    items: items.list,
    notes: notes.list,
    stickies,
    tombstones,
    notifications: remoteNotifications.filter(function (n) { return itemIds.has(n.itemId) }),
    settings: { ...local.settings, expiryTiers: { ...local.settings.expiryTiers } },
    savedNames: {
      place: remote.savedNames.place.slice(0, SAVED_NAME_LIMIT),
      container: remote.savedNames.container.slice(0, SAVED_NAME_LIMIT)
    },
    searchHistory: normalizeSearchHistory(local.searchHistory),
    onboardingDone: local.onboardingDone,
    createdAt: local.createdAt
  }
  const stats = statsFor(local, state)
  stats.duplicates = categories.duplicates
  return { state, stats }
}

/** 合并时清理过期墓碑（同步写回后数据文件不至于无限增长） */
export function pruneStateTombstones(state: AppState): void {
  state.tombstones = normalizeTombstones(state.tombstones, Date.now() - TOMBSTONE_KEEP_DAYS * 24 * 60 * 60 * 1000 + 1000)
}
