/** 同步加密工具：全部基于浏览器/Node 都自带的 WebCrypto，不引第三方库 */

const CHARS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'
const CODES: Record<string, number> = {}
for (let i = 0; i < CHARS.length; i++) CODES[CHARS[i]] = i

const encoder = new TextEncoder()
const decoder = new TextDecoder()

export function bytesToB64(bytes: Uint8Array): string {
  let out = ''
  for (let i = 0; i < bytes.length; i += 3) {
    const b0 = bytes[i] & 0xff
    const b1 = i + 1 < bytes.length ? bytes[i + 1] & 0xff : 0
    const b2 = i + 2 < bytes.length ? bytes[i + 2] & 0xff : 0
    const triple = (b0 << 16) | (b1 << 8) | b2
    out += CHARS[(triple >> 18) & 63] + CHARS[(triple >> 12) & 63]
    out += i + 1 < bytes.length ? CHARS[(triple >> 6) & 63] : '='
    out += i + 2 < bytes.length ? CHARS[triple & 63] : '='
  }
  return out
}

export function b64ToBytes(text: string): Uint8Array {
  const clean = (text || '').replace(/[^A-Za-z0-9+/=]/g, '')
  const pad = clean.endsWith('==') ? 2 : clean.endsWith('=') ? 1 : 0
  const size = Math.max(0, Math.floor((clean.length * 3) / 4) - pad)
  const bytes = new Uint8Array(size)
  let pos = 0
  for (let i = 0; i < clean.length; i += 4) {
    const c0 = CODES[clean[i]] || 0
    const c1 = CODES[clean[i + 1]] || 0
    const c2 = CODES[clean[i + 2]] || 0
    const c3 = CODES[clean[i + 3]] || 0
    const triple = (c0 << 18) | (c1 << 12) | (c2 << 6) | c3
    if (pos < size) bytes[pos++] = (triple >> 16) & 0xff
    if (pos < size && clean[i + 2] !== '=') bytes[pos++] = (triple >> 8) & 0xff
    if (pos < size && clean[i + 3] !== '=') bytes[pos++] = triple & 0xff
  }
  return bytes
}

function bytesToHex(bytes: Uint8Array): string {
  let out = ''
  for (let i = 0; i < bytes.length; i++) out += bytes[i].toString(16).padStart(2, '0')
  return out
}

export function randomBytes(length: number): Uint8Array {
  const out = new Uint8Array(length)
  globalThis.crypto.getRandomValues(out)
  return out
}

export function randomHex(length: number): string {
  return bytesToHex(randomBytes(Math.ceil(length / 2))).slice(0, length)
}

/** 随机六位数字（换机绑定时人工核对） */
export function randomPairingCode(): string {
  const buf = new Uint32Array(1)
  globalThis.crypto.getRandomValues(buf)
  return String(100000 + (buf[0] % 900000))
}

export async function sha256Hex(text: string): Promise<string> {
  const digest = await globalThis.crypto.subtle.digest('SHA-256', encoder.encode(text))
  return bytesToHex(new Uint8Array(digest))
}

/** 六位数字 + 盐 派生配对密钥（PBKDF2，防止暴力猜数字） */
export async function derivePairKey(code: string, saltB64: string): Promise<CryptoKey> {
  const base = await globalThis.crypto.subtle.importKey('raw', encoder.encode(code), 'PBKDF2', false, ['deriveKey'])
  return globalThis.crypto.subtle.deriveKey(
    { name: 'PBKDF2', salt: b64ToBytes(saltB64) as unknown as BufferSource, iterations: 150000, hash: 'SHA-256' },
    base,
    { name: 'AES-GCM', length: 256 },
    false,
    ['encrypt', 'decrypt']
  )
}

/** 配对证明：用六位数字算出一个校验值给绑定方验证，不直接传数字 */
export function pairProof(nonce: string, code: string, salt: string): Promise<string> {
  return sha256Hex(nonce + '|' + code + '|' + salt)
}

export function randomSyncKey(): string {
  return bytesToB64(randomBytes(32))
}

export async function importAesKey(keyB64: string): Promise<CryptoKey> {
  return globalThis.crypto.subtle.importKey('raw', b64ToBytes(keyB64), { name: 'AES-GCM' }, false, ['encrypt', 'decrypt'])
}

export async function encryptText(key: CryptoKey, plain: string): Promise<string> {
  const iv = randomBytes(12)
  const cipher = await globalThis.crypto.subtle.encrypt({ name: 'AES-GCM', iv: iv as unknown as BufferSource }, key, encoder.encode(plain))
  const out = new Uint8Array(iv.length + cipher.byteLength)
  out.set(iv, 0)
  out.set(new Uint8Array(cipher), iv.length)
  return bytesToB64(out)
}

export async function decryptText(key: CryptoKey, payload: string): Promise<string> {
  const all = b64ToBytes(payload)
  if (all.length < 13) throw new Error('加密数据不完整')
  const iv = all.subarray(0, 12)
  const body = all.subarray(12)
  const plain = await globalThis.crypto.subtle.decrypt(
    { name: 'AES-GCM', iv: iv as unknown as BufferSource },
    key,
    body as unknown as BufferSource
  )
  return decoder.decode(plain)
}

/** 会话校验值：双方都持有 syncKey，能证明自己是已绑定的那台设备 */
export function macFor(keyB64: string, parts: string[]): Promise<string> {
  return sha256Hex(keyB64 + '|' + parts.join('|'))
}

export function newNonce(): string {
  return randomHex(24)
}

export function newSalt(): string {
  return bytesToB64(randomBytes(16))
}
