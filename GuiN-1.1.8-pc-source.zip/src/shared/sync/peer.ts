import Peer from 'peerjs'
import type { DataConnection } from 'peerjs'
import type { Channel } from './protocol'

/** 创建本机 Peer（peerId 由本机同步配置持久保存，换网络/IP 都不影响） */
export function createPeer(peerId: string): Peer {
  return new Peer(peerId, { debug: 0 })
}

export function waitPeerOpen(peer: Peer, timeoutMs = 15000): Promise<void> {
  return new Promise((resolve, reject) => {
    if (peer.open) {
      resolve()
      return
    }
    let settled = false
    const finish = function (err?: Error): void {
      if (settled) return
      settled = true
      clearTimeout(timer)
      peer.off('open', onOpen)
      peer.off('error', onError)
      if (err) reject(err)
      else resolve()
    }
    const onOpen = function (): void {
      finish()
    }
    const onError = function (err: Error): void {
      finish(err)
    }
    const timer = setTimeout(function () {
      finish(new Error('连接配对服务器超时，请检查网络'))
    }, timeoutMs)
    peer.on('open', onOpen)
    peer.on('error', onError)
  })
}

/** 主动连接已绑定设备，返回打开的数据通道 */
export function connectPeer(peer: Peer, targetId: string, timeoutMs = 20000): Promise<DataConnection> {
  return new Promise((resolve, reject) => {
    let settled = false
    const finish = function (err?: Error, conn?: DataConnection): void {
      if (settled) return
      settled = true
      clearTimeout(timer)
      peer.off('error', onError)
      if (err) reject(err)
      else if (conn) resolve(conn)
      else reject(new Error('连接失败'))
    }
    const onError = function (err: Error): void {
      const typed = err as Error & { type?: string }
      if (typed.type === 'peer-unavailable') finish(new Error('对方当前不在线，请确认对方已打开 GuiN 并连接网络'))
      else finish(new Error(err.message || '连接失败'))
    }
    const timer = setTimeout(function () {
      finish(new Error('连接对方超时，请检查两台设备是否在同一网络'))
    }, timeoutMs)
    peer.on('error', onError)
    const conn = peer.connect(targetId, { reliable: true })
    conn.on('open', function () {
      finish(undefined, conn)
    })
    conn.on('error', function (err: Error) {
      finish(err)
    })
  })
}

/** 把 PeerJS 的数据通道包装成统一 Channel */
export function channelOf(conn: DataConnection): Channel {
  let messageCb: ((data: unknown) => void) | null = null
  let closeCb: ((reason: string) => void) | null = null
  conn.on('data', function (data: unknown) {
    // PeerJS 的 binary 序列化在不同版本/两端可能把字符串原样给出，也可能给出 ArrayBuffer
    // 这里统一还原成对象，保证协议层拿到的始终是 { t: ... } 结构
    let value: unknown = data
    if (typeof value === 'string') {
      try {
        value = JSON.parse(value)
      } catch {
        return
      }
    } else if (value instanceof ArrayBuffer) {
      try {
        value = JSON.parse(new TextDecoder().decode(new Uint8Array(value)))
      } catch {
        return
      }
    }
    if (messageCb) messageCb(value)
  })
  conn.on('close', function () {
    if (closeCb) closeCb('对方断开了连接')
  })
  conn.on('error', function (err: Error) {
    if (closeCb) closeCb(err.message || '连接出错')
  })
  return {
    send: function (obj: unknown) {
      try {
        conn.send(JSON.stringify(obj))
      } catch {
        /* 通道已关闭时忽略，上层会按超时处理 */
      }
    },
    onMessage: function (cb) {
      messageCb = cb
    },
    onClose: function (cb) {
      closeCb = cb
      if (!conn.open) cb('连接已断开')
    },
    close: function () {
      try {
        conn.close()
      } catch {
        /* 已关闭 */
      }
    }
  }
}
