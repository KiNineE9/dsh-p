import type { AppState } from '../types'

/** 设备类型：电脑 / 安卓 */
export type SyncDeviceKind = 'desktop' | 'android'

/** 同步范围：完整 / 不同步便签与提醒（手机与电脑之间用这个） */
export type SyncScope = 'full' | 'no-stickies'

/** 三种同步方式：把本机推给对方 / 从对方拉取 / 合并双方差异 */
export type SyncMode = 'push' | 'pull' | 'merge'

/** 本机设备身份（持久化在独立配置文件里，不随数据导出） */
export interface SyncDeviceIdentity {
  /** 设备唯一 id，绑定关系按它匹配，换网络/换 IP 都不受影响 */
  deviceId: string
  /** PeerJS 会话 id（稳定不变，对方靠它找到这台设备） */
  peerId: string
  /** 用户自定义设备名 */
  name: string
  /** 展示用机器码，方便两台设备核对 */
  machineCode: string
  kind: SyncDeviceKind
  /** 系统版本描述，例如 Windows 11 / Android 15 */
  platform: string
  appVersion: string
}

/** 一台已绑定的设备 */
export interface SyncBinding {
  deviceId: string
  peerId: string
  /** 对方自己设置的设备名；对方改名后握手时自动刷新 */
  name: string
  /** 本机给这台设备起的备注（只影响本机显示，不随同步传播） */
  alias?: string
  machineCode: string
  kind: SyncDeviceKind
  platform: string
  appVersion: string
  /** base64 的 32 字节对称密钥，绑定握手时协商 */
  syncKey: string
  boundAt: string
  lastSyncAt: string | null
  lastMode: SyncMode | null
  /** 最近一次确认对方在线或握手成功的时间 */
  lastSeenAt?: string | null
}

/** 检测一台已绑定设备是否在线（能连上对方的 PeerJS 会话即可） */
export interface SyncOnlineResult {
  deviceId: string
  online: boolean
  checkedAt: string
  /** 离线或检测失败时的原因 */
  message?: string
}

export interface SyncConfig {
  version: number
  identity: SyncDeviceIdentity
  bindings: SyncBinding[]
}

/** 同步统计 */
export interface SyncStats {
  /** 新增到本机的记录数 */
  added: number
  /** 本机已存在但被更新/覆盖的记录数 */
  updated: number
  /** 双方重复、被去掉的记录数 */
  duplicates: number
  /** 合并后总记录数 */
  total: number
}

/** 一次同步的结果 */
export interface SyncResult {
  mode: SyncMode
  scope: SyncScope
  stats: SyncStats
  /** 对方设备名 */
  peerName: string
  at: string
}

/** 配对邀请内容（二维码里编码的就是 pairingText） */
export interface PairingOffer {
  v: 1
  kind: 'guina-pair'
  device: SyncDeviceIdentity
  nonce: string
  salt: string
}

export interface PairingSession {
  offer: PairingOffer
  /** 二维码内容 / 邀请码文本，对方粘贴或扫码 */
  text: string
  /** 换机绑定用的六位数字 */
  code: string
}

/** 同步进度阶段 */
export type SyncPhase =
  | 'idle'
  | 'starting'
  | 'waiting'
  | 'connecting'
  | 'verifying'
  | 'syncing'
  | 'applying'
  | 'done'
  | 'error'

export interface SyncProgress {
  phase: SyncPhase
  message: string
}

/** 收到的同步请求（需要用户确认） */
export interface IncomingSyncRequest {
  requestId: string
  deviceName: string
  machineCode: string
  mode: SyncMode
  scope: SyncScope
  peerName: string
}

/** 本机数据被同步改写时，返回一个回滚函数，失败时双方都能恢复 */
export type ApplyStateResult = () => Promise<void>

export interface SyncStateEffects {
  getState(): AppState
  applyState(next: AppState): Promise<ApplyStateResult>
}
