import type { Peer } from 'peerjs'
import type { DataConnection } from 'peerjs'
import type { AppState } from '../types'
import {
  decryptText,
  encryptText,
  macFor,
  newNonce,
  newSalt,
  pairProof,
  randomHex,
  randomPairingCode,
  randomSyncKey,
  sha256Hex
} from './crypto'
import { adoptState, mergeStates, scopeForKinds } from './merge'
import { channelOf, connectPeer, createPeer, waitPeerOpen } from './peer'
import { decodePairingText, encodePairingText, isRecord, MessageInbox, SecureChannel } from './protocol'
import type { Channel } from './protocol'
import type { WireHello, WireHelloAck, WireHelloOk, WirePairRequest, WireState } from './protocol'
import type {
  ApplyStateResult,
  IncomingSyncRequest,
  PairingOffer,
  PairingSession,
  SyncBinding,
  SyncConfig,
  SyncDeviceIdentity,
  SyncDeviceKind,
  SyncMode,
  SyncOnlineResult,
  SyncProgress,
  SyncResult,
  SyncScope,
  SyncStats
} from './types'

const CONFIG_VERSION = 1
const MAX_BINDINGS = 16

/** 本机同步配置的读写（桌面走 IPC 存独立文件，手机走 Android 私有目录） */
export interface SyncStorage {
  loadConfig(): Promise<SyncConfig | null>
  saveConfig(config: SyncConfig): Promise<void>
}

export interface SyncEffects {
  getState(): AppState
  /** 备份后整体应用新状态；返回回滚函数，失败时调用可恢复 */
  applyState(next: AppState): Promise<ApplyStateResult>
}

export interface SyncRuntimeOptions {
  storage: SyncStorage
  effects: SyncEffects
  device: {
    kind: SyncDeviceKind
    platform: string
    appVersion: string
    /** 默认设备名（用户可改） */
    defaultName: string
    /** 机器码派生种子，例如主机名 + 系统名；不参与网络传输身份匹配 */
    machineSeed: string
  }
  onConfig(config: SyncConfig): void
  onIncoming(request: IncomingSyncRequest, decide: (accepted: boolean) => void): void
  onProgress?(progress: SyncProgress): void
}

interface PairingContext {
  code: string
  offer: PairingOffer
  promise: Promise<SyncBinding>
  resolve: (binding: SyncBinding) => void
  reject: (err: Error) => void
  timer: ReturnType<typeof setTimeout> | null
}

function sleep(ms: number): Promise<void> {
  return new Promise(function (resolve) {
    setTimeout(resolve, ms)
  })
}

function sanitizeName(raw: string, fallback: string): string {
  const text = (raw || '').replace(/\s+/g, ' ').trim().slice(0, 24)
  return text || fallback
}

/** 已绑定设备在界面上的显示名：优先用本机备注，其次用对方设备名 */
export function bindingLabel(binding: SyncBinding): string {
  const alias = (binding.alias || '').trim()
  return alias || binding.name
}

function formatMachineCode(hex: string): string {
  const upper = hex.slice(0, 12).toUpperCase()
  return upper.slice(0, 4) + '-' + upper.slice(4, 8) + '-' + upper.slice(8, 12)
}

function countState(state: AppState): number {
  return state.categories.length + state.items.length + state.notes.length + state.stickies.length
}

/**
 * 同步运行时：负责 PeerJS 生命周期、设备绑定握手、三种同步方式。
 * 桌面端与安卓端共用这一份逻辑，只是配置存储和应用数据的方式不同。
 */
export class SyncRuntime {
  private config: SyncConfig | null = null
  private peer: Peer | null = null
  private peerStarting: Promise<Peer> | null = null
  private pairing: PairingContext | null = null
  private restartTimer: ReturnType<typeof setTimeout> | null = null
  private stopped = false

  constructor(private opts: SyncRuntimeOptions) {}

  async init(): Promise<SyncConfig> {
    const stored = await this.opts.storage.loadConfig()
    let config: SyncConfig
    if (stored && isRecord(stored) && stored.identity && Array.isArray(stored.bindings)) {
      config = stored
    } else {
      config = await this.createConfig()
    }
    config.version = CONFIG_VERSION
    config.identity.kind = this.opts.device.kind
    config.identity.platform = this.opts.device.platform
    config.identity.appVersion = this.opts.device.appVersion
    config.identity.name = sanitizeName(config.identity.name, this.opts.device.defaultName)
    config.bindings = (config.bindings || [])
      .filter(function (b) {
        return !!b && typeof b.deviceId === 'string' && typeof b.syncKey === 'string' && typeof b.peerId === 'string'
      })
      .map(function (b) {
        const alias = typeof b.alias === 'string' ? b.alias.replace(/\s+/g, ' ').trim().slice(0, 24) : ''
        if (alias) b.alias = alias
        else delete b.alias
        b.lastSeenAt = typeof b.lastSeenAt === 'string' ? b.lastSeenAt : null
        return b
      })
    this.config = config
    await this.opts.storage.saveConfig(config)
    this.opts.onConfig(config)
    return config
  }

  private createConfig(): Promise<SyncConfig> {
    const deviceId = 'dev-' + randomHex(16)
    const peerId = 'guina-' + randomHex(12)
    const self = this
    return sha256Hex(this.opts.device.machineSeed + '|' + deviceId).then(function (hex) {
      const identity: SyncDeviceIdentity = {
        deviceId,
        peerId,
        name: sanitizeName(self.opts.device.defaultName, '未命名设备'),
        machineCode: formatMachineCode(hex),
        kind: self.opts.device.kind,
        platform: self.opts.device.platform,
        appVersion: self.opts.device.appVersion
      }
      return { version: CONFIG_VERSION, identity, bindings: [] }
    })
  }

  getConfig(): SyncConfig | null {
    return this.config
  }

  private requireConfig(): SyncConfig {
    if (!this.config) throw new Error('同步还没准备好，请稍后重试')
    return this.config
  }

  private async persist(): Promise<void> {
    if (!this.config) return
    await this.opts.storage.saveConfig(this.config)
    this.opts.onConfig(this.config)
  }

  async setDeviceName(rawName: string): Promise<SyncConfig> {
    const config = this.requireConfig()
    config.identity.name = sanitizeName(rawName, config.identity.name)
    await this.persist()
    return config
  }

  async removeBinding(deviceId: string): Promise<SyncConfig> {
    const config = this.requireConfig()
    config.bindings = config.bindings.filter(function (b) {
      return b.deviceId !== deviceId
    })
    await this.persist()
    return config
  }

  /** 给已绑定设备保存备注（只影响本机显示；留空表示恢复显示对方设备名） */
  async setBindingAlias(deviceId: string, rawAlias: string): Promise<SyncConfig> {
    const config = this.requireConfig()
    const binding = config.bindings.find(function (b) {
      return b.deviceId === deviceId
    })
    if (!binding) throw new Error('这台设备还没有绑定')
    const alias = (rawAlias || '').replace(/\s+/g, ' ').trim().slice(0, 24)
    if (alias) binding.alias = alias
    else delete binding.alias
    await this.persist()
    return config
  }

  /** 检测一台已绑定设备是否在线：能连上对方的 PeerJS 会话并收到心跳即可 */
  async checkBinding(deviceId: string): Promise<SyncOnlineResult> {
    const config = this.requireConfig()
    const binding = config.bindings.find(function (b) {
      return b.deviceId === deviceId
    })
    if (!binding) throw new Error('这台设备还没有绑定')
    const checkedAt = new Date().toISOString()
    const label = bindingLabel(binding)
    this.emitProgress('connecting', '正在检测「' + label + '」是否在线…')
    let channel: Channel | null = null
    try {
      const peer = await this.ensurePeer()
      const conn = await connectPeer(peer, binding.peerId, 12000)
      channel = channelOf(conn)
      const inbox = new MessageInbox()
      channel.onMessage(function (data) {
        inbox.push(data)
      })
      channel.send({ t: 'ping', device: config.identity })
      await inbox.next('pong', 8000)
      binding.lastSeenAt = checkedAt
      await this.persist()
      this.emitProgress('done', '「' + label + '」当前在线')
      return { deviceId, online: true, checkedAt }
    } catch (err) {
      const message = err instanceof Error ? err.message : '检测失败'
      this.emitProgress('error', message)
      return { deviceId, online: false, checkedAt, message }
    } finally {
      try {
        if (channel) channel.close()
      } catch {
        /* ignore */
      }
    }
  }

  /** 握手成功后用对方最新信息刷新绑定（改名、换 peerId、升级版本都能自愈） */
  private async refreshBindingFromDevice(binding: SyncBinding, device: SyncDeviceIdentity, peerId: string): Promise<void> {
    if (device.deviceId && binding.deviceId !== device.deviceId) binding.deviceId = device.deviceId
    if (peerId && binding.peerId !== peerId) binding.peerId = peerId
    binding.name = sanitizeName(device.name, binding.name)
    const machineCode = String(device.machineCode || '')
    if (machineCode) binding.machineCode = machineCode
    if (device.platform) binding.platform = device.platform
    if (device.appVersion) binding.appVersion = device.appVersion
    binding.lastSeenAt = new Date().toISOString()
    await this.persist()
  }

  /** 先按 deviceId 精确匹配；老版本/重装导致 deviceId 变化时按机器码兜底，密钥校验通过后自动改绑 */
  private findBindingForDevice(device: SyncDeviceIdentity): SyncBinding | null {
    const config = this.requireConfig()
    const byId = config.bindings.find(function (b) {
      return b.deviceId === device.deviceId
    })
    if (byId) return byId
    const machineCode = String(device.machineCode || '').trim().toUpperCase()
    if (!machineCode) return null
    return (
      config.bindings.find(function (b) {
        return String(b.machineCode || '').trim().toUpperCase() === machineCode
      }) || null
    )
  }

  private async addBinding(binding: SyncBinding): Promise<void> {
    const config = this.requireConfig()
    config.bindings = config.bindings.filter(function (b) {
      return b.deviceId !== binding.deviceId
    })
    config.bindings.unshift(binding)
    if (config.bindings.length > MAX_BINDINGS) config.bindings = config.bindings.slice(0, MAX_BINDINGS)
    await this.persist()
  }

  private async touchBinding(deviceId: string, mode: SyncMode): Promise<void> {
    const config = this.requireConfig()
    const binding = config.bindings.find(function (b) {
      return b.deviceId === deviceId
    })
    if (!binding) return
    binding.lastSyncAt = new Date().toISOString()
    binding.lastMode = mode
    await this.persist()
  }

  /** 应用启动后调用：保持在线，随时可以接收已绑定设备的同步请求 */
  async start(): Promise<void> {
    this.stopped = false
    try {
      await this.ensurePeer()
    } catch (err) {
      this.scheduleRestart()
      this.emitProgress('error', err instanceof Error ? err.message : '同步服务未能上线')
    }
  }

  async stop(): Promise<void> {
    this.stopped = true
    if (this.restartTimer) {
      clearTimeout(this.restartTimer)
      this.restartTimer = null
    }
    this.cancelPairing()
    this.destroyPeer()
  }

  private scheduleRestart(): void {
    if (this.stopped) return
    if (this.restartTimer) clearTimeout(this.restartTimer)
    const self = this
    this.restartTimer = setTimeout(function () {
      self.restartTimer = null
      void self.start()
    }, 15000)
  }

  private destroyPeer(): void {
    const peer = this.peer
    this.peer = null
    if (peer) {
      try {
        peer.destroy()
      } catch {
        /* 已销毁 */
      }
    }
  }

  private async ensurePeer(): Promise<Peer> {
    if (this.peer && !this.peer.destroyed && this.peer.open) return this.peer
    if (this.peerStarting) return this.peerStarting
    const self = this
    this.peerStarting = this.startPeer()
    try {
      return await this.peerStarting
    } finally {
      self.peerStarting = null
    }
  }

  private async startPeer(): Promise<Peer> {
    const identity = this.requireConfig().identity
    this.destroyPeer()
    const peer = createPeer(identity.peerId)
    this.attachPeerHandlers(peer)
    try {
      await waitPeerOpen(peer, 15000)
    } catch (err) {
      try {
        peer.destroy()
      } catch {
        /* ignore */
      }
      throw new Error(err instanceof Error ? err.message : '同步服务未能上线')
    }
    this.peer = peer
    return peer
  }

  private attachPeerHandlers(peer: Peer): void {
    const self = this
    peer.on('connection', function (conn: DataConnection) {
      void self.handleConnection(conn)
    })
    peer.on('error', function (err: Error) {
      const typed = err as Error & { type?: string }
      const type = typed.type || ''
      if (type === 'network' || type === 'server-error' || type === 'socket-error' || type === 'socket-closed') {
        self.destroyPeer()
        self.scheduleRestart()
      }
    })
    peer.on('disconnected', function () {
      try {
        peer.reconnect()
      } catch {
        self.destroyPeer()
        self.scheduleRestart()
      }
    })
  }

  /* ------------------------------ 绑定流程 ------------------------------ */

  async startPairing(): Promise<PairingSession> {
    await this.ensurePeer()
    if (this.pairing) this.cancelPairing()
    const code = randomPairingCode()
    const offer: PairingOffer = {
      v: 1,
      kind: 'guina-pair',
      device: this.requireConfig().identity,
      nonce: newNonce(),
      salt: newSalt()
    }
    const text = encodePairingText(offer)
    let resolveFn: (binding: SyncBinding) => void = function () {}
    let rejectFn: (err: Error) => void = function () {}
    const promise = new Promise<SyncBinding>(function (resolve, reject) {
      resolveFn = resolve
      rejectFn = reject
    })
    const self = this
    const timer = setTimeout(function () {
      self.cancelPairing()
    }, 5 * 60 * 1000)
    this.pairing = { code, offer, promise, resolve: resolveFn, reject: rejectFn, timer }
    this.emitProgress('waiting', '等待对方扫码或粘贴邀请码…')
    return { offer, text, code }
  }

  async waitPairing(): Promise<SyncBinding> {
    if (!this.pairing) throw new Error('没有进行中的绑定')
    return this.pairing.promise
  }

  cancelPairing(): void {
    const ctx = this.pairing
    if (!ctx) return
    this.pairing = null
    if (ctx.timer) clearTimeout(ctx.timer)
    ctx.reject(new Error('已取消绑定'))
  }

  private async handleConnection(conn: DataConnection): Promise<void> {
    if (this.pairing) {
      await this.handlePairingConnection(conn)
      return
    }
    await this.handleIncomingSync(conn)
  }

  private async handlePairingConnection(conn: DataConnection): Promise<void> {
    const ctx = this.pairing
    if (!ctx) {
      try {
        conn.close()
      } catch {
        /* ignore */
      }
      return
    }
    const channel = channelOf(conn)
    const inbox = new MessageInbox()
    channel.onMessage(function (data) {
      inbox.push(data)
    })
    this.emitProgress('verifying', '正在校验六位数字…')
    try {
      const msg = await inbox.next('pair-req', 60000)
      const device = msg.device as SyncDeviceIdentity
      const expected = await pairProof(ctx.offer.nonce, ctx.code, ctx.offer.salt)
      if (String(msg.proof || '') !== expected) {
        channel.send({ t: 'pair-no', error: '六位数字不正确' })
        throw new Error('六位数字不正确')
      }
      const key = await derivePairKeyFor(ctx.code, ctx.offer.salt)
      const syncKey = randomSyncKey()
      const keyEnc = await encryptText(key, syncKey)
      channel.send({ t: 'pair-ok', device: this.requireConfig().identity, keyEnc })
      const binding = this.buildBinding(device, conn.peer, syncKey)
      await this.addBinding(binding)
      await sleep(400)
      ctx.resolve(binding)
      this.emitProgress('done', '已与「' + binding.name + '」绑定成功')
    } catch (err) {
      ctx.reject(err instanceof Error ? err : new Error('绑定失败'))
      this.emitProgress('error', err instanceof Error ? err.message : '绑定失败')
    } finally {
      try {
        channel.close()
      } catch {
        /* ignore */
      }
      if (this.pairing === ctx) this.pairing = null
    }
  }

  /** 被邀请方：粘贴邀请码并输入六位数字后完成绑定 */
  async joinPairing(text: string, code: string): Promise<SyncBinding> {
    const cleanCode = (code || '').replace(/\D/g, '')
    if (cleanCode.length !== 6) throw new Error('请输入 6 位数字')
    const raw = decodePairingText(text)
    const offer = raw as unknown as PairingOffer
    if (offer.kind !== 'guina-pair' || !offer.device || typeof offer.device.peerId !== 'string' || typeof offer.salt !== 'string') {
      throw new Error('邀请内容格式不对，请重新复制')
    }
    const my = this.requireConfig().identity
    if (offer.device.deviceId === my.deviceId) throw new Error('不能绑定本机')
    const peer = await this.ensurePeer()
    this.emitProgress('connecting', '正在连接对方设备…')
    const conn = await connectPeer(peer, offer.device.peerId, 20000)
    const channel = channelOf(conn)
    const inbox = new MessageInbox()
    channel.onMessage(function (data) {
      inbox.push(data)
    })
    try {
      this.emitProgress('verifying', '正在校验六位数字…')
      const proof = await pairProof(offer.nonce, cleanCode, offer.salt)
      const req: WirePairRequest = { t: 'pair-req', device: my, proof }
      channel.send(req)
      const res = await inbox.nextAny(['pair-ok', 'pair-no'], 30000)
      if (res.t === 'pair-no') throw new Error(String(res.error || '绑定失败'))
      const key = await derivePairKeyFor(cleanCode, offer.salt)
      const syncKey = await decryptText(key, String(res.keyEnc || ''))
      const remoteDevice = res.device as SyncDeviceIdentity
      const binding = this.buildBinding(remoteDevice, offer.device.peerId, syncKey)
      await this.addBinding(binding)
      await sleep(300)
      this.emitProgress('done', '已与「' + binding.name + '」绑定成功')
      return binding
    } finally {
      try {
        channel.close()
      } catch {
        /* ignore */
      }
    }
  }

  private buildBinding(device: SyncDeviceIdentity, peerId: string, syncKey: string): SyncBinding {
    return {
      deviceId: device.deviceId,
      peerId: peerId,
      name: sanitizeName(device.name, '未命名设备'),
      machineCode: String(device.machineCode || ''),
      kind: device.kind === 'android' ? 'android' : 'desktop',
      platform: String(device.platform || ''),
      appVersion: String(device.appVersion || ''),
      syncKey,
      boundAt: new Date().toISOString(),
      lastSyncAt: null,
      lastMode: null,
      lastSeenAt: null
    }
  }

  /* ------------------------------ 同步流程 ------------------------------ */

  private scopeFor(binding: SyncBinding): SyncScope {
    return scopeForKinds(this.requireConfig().identity.kind, binding.kind)
  }

  async sync(binding: SyncBinding, mode: SyncMode): Promise<SyncResult> {
    const config = this.requireConfig()
    const current = config.bindings.find(function (b) {
      return b.deviceId === binding.deviceId
    })
    if (!current) throw new Error('这台设备还没有绑定，请先绑定')
    const scope = this.scopeFor(current)
    const peer = await this.ensurePeer()
    this.emitProgress('connecting', '正在连接「' + bindingLabel(current) + '」…')
    const conn = await connectPeer(peer, current.peerId, 20000)
    const channel = channelOf(conn)
    const inbox = new MessageInbox()
    channel.onMessage(function (data) {
      inbox.push(data)
    })
    let rollback: ApplyStateResult | null = null
    let stats: SyncStats = { added: 0, updated: 0, duplicates: 0, total: 0 }
    try {
      this.emitProgress('verifying', '正在校验设备身份…')
      const myNonce = newNonce()
      const hello: WireHello = { t: 'hello', device: config.identity, nonce: myNonce }
      channel.send(hello)
      const ack = await inbox.nextAny(['hello-ack', 'reject'], 15000)
      if (ack.t === 'reject') throw new Error(String(ack.error || '对方拒绝了连接'))
      const ackDevice = ack.device as SyncDeviceIdentity
      if (!ackDevice || ackDevice.deviceId !== current.deviceId) throw new Error('对方设备身份不匹配')
      const ackNonce = String(ack.nonce || '')
      if (String(ack.mac || '') !== (await macFor(current.syncKey, [myNonce, ackNonce]))) {
        throw new Error('同步密钥校验失败，请解绑后重新绑定')
      }
      await this.refreshBindingFromDevice(current, ackDevice, conn.peer)
      const ok: WireHelloOk = { t: 'hello-ok', mac: await macFor(current.syncKey, [ackNonce, myNonce]) }
      channel.send(ok)
      const secure = new SecureChannel(channel, current.syncKey)
      await secure.send({ t: 'sync-req', mode, scope })
      this.emitProgress('syncing', '正在同步数据…')
      if (mode === 'push') {
        const local = this.opts.effects.getState()
        stats = { added: 0, updated: 0, duplicates: 0, total: countState(local) }
        await secure.send({ t: 'state', state: local } as WireState)
        this.emitProgress('applying', '对方正在备份并应用数据…')
        const res = await secure.nextAny(['applied', 'error', 'reject'], 120000)
        if (res.t !== 'applied') throw new Error(String(res.error || '对方没有接受这次同步'))
      } else if (mode === 'pull') {
        const res = await secure.nextAny(['state', 'error', 'reject'], 120000)
        if (res.t !== 'state') throw new Error(String(res.error || '对方没有返回数据'))
        this.emitProgress('applying', '正在备份并应用对方数据…')
        const adopted = adoptState(this.opts.effects.getState(), res.state as AppState, scope)
        rollback = await this.opts.effects.applyState(adopted.state)
        stats = adopted.stats
        await secure.send({ t: 'applied' })
        rollback = null
      } else {
        const local = this.opts.effects.getState()
        await secure.send({ t: 'state', state: local } as WireState)
        const res = await secure.nextAny(['merge-state', 'error', 'reject'], 120000)
        if (res.t !== 'merge-state') throw new Error(String(res.error || '对方没有返回数据'))
        this.emitProgress('applying', '正在合并双方数据…')
        const merged = mergeStates(local, res.state as AppState, scope)
        rollback = await this.opts.effects.applyState(merged.state)
        stats = merged.stats
        await secure.send({ t: 'merge-apply' })
        const done = await secure.nextAny(['merge-done', 'error'], 120000)
        if (done.t !== 'merge-done') {
          await rollback()
          rollback = null
          throw new Error(String(done.error || '对方合并失败，已回滚'))
        }
        rollback = null
      }
      await this.touchBinding(current.deviceId, mode)
      this.emitProgress('done', '同步完成')
      return {
        mode,
        scope,
        stats,
        peerName: bindingLabel(current),
        at: new Date().toISOString()
      }
    } catch (err) {
      if (rollback) {
        try {
          await rollback()
        } catch {
          /* 回滚失败时保留原错误提示 */
        }
      }
      const message = err instanceof Error ? err.message : '同步失败'
      this.emitProgress('error', message)
      throw new Error(message)
    } finally {
      try {
        channel.close()
      } catch {
        /* ignore */
      }
    }
  }

  private async handleIncomingSync(conn: DataConnection): Promise<void> {
    const channel = channelOf(conn)
    const inbox = new MessageInbox()
    channel.onMessage(function (data) {
      inbox.push(data)
    })
    try {
      const first = await inbox.nextAny(['hello', 'ping'], 20000)
      const device = first.device as SyncDeviceIdentity
      if (first.t === 'ping') {
        const seen = device ? this.findBindingForDevice(device) : null
        if (seen) {
          seen.lastSeenAt = new Date().toISOString()
          await this.persist()
        }
        channel.send({ t: 'pong', device: this.requireConfig().identity })
        await sleep(80)
        return
      }
      const config = this.requireConfig()
      const binding = this.findBindingForDevice(device)
      if (!binding) {
        channel.send({ t: 'reject', error: '这台设备还没有与本机绑定' })
        return
      }
      this.emitProgress('verifying', '「' + bindingLabel(binding) + '」正在连接本机…')
      const remoteNonce = String(first.nonce || '')
      const myNonce = newNonce()
      const ack: WireHelloAck = {
        t: 'hello-ack',
        device: config.identity,
        nonce: myNonce,
        mac: await macFor(binding.syncKey, [remoteNonce, myNonce])
      }
      channel.send(ack)
      const ok = await inbox.nextAny(['hello-ok', 'reject'], 15000)
      if (ok.t === 'reject') return
      if (String(ok.mac || '') !== (await macFor(binding.syncKey, [myNonce, remoteNonce]))) {
        channel.send({ t: 'reject', error: '同步密钥校验失败' })
        return
      }
      await this.refreshBindingFromDevice(binding, device, conn.peer)
      const secure = new SecureChannel(channel, binding.syncKey)
      const pending = inbox.drain()
      if (pending.length) {
        for (const item of pending) secure.feed(item)
      }
      const req = await secure.next('sync-req', 30000)
      const mode = req.mode as SyncMode
      const scope = req.scope as SyncScope
      if (mode !== 'push' && mode !== 'pull' && mode !== 'merge') throw new Error('未知的同步方式')
      const request: IncomingSyncRequest = {
        requestId: randomHex(8),
        deviceName: bindingLabel(binding),
        machineCode: binding.machineCode,
        mode,
        scope,
        peerName: bindingLabel(binding)
      }
      const accepted = await this.askIncoming(request)
      if (!accepted) {
        await secure.send({ t: 'reject', error: '本机拒绝了这次同步' })
        return
      }
      await this.runResponder(secure, binding, mode, scope)
    } catch (err) {
      this.emitProgress('error', err instanceof Error ? err.message : '接收同步失败')
    } finally {
      try {
        channel.close()
      } catch {
        /* ignore */
      }
    }
  }

  private askIncoming(request: IncomingSyncRequest): Promise<boolean> {
    const self = this
    return new Promise<boolean>(function (resolve) {
      let settled = false
      const finish = function (accepted: boolean): void {
        if (settled) return
        settled = true
        clearTimeout(timer)
        resolve(accepted)
      }
      const timer = setTimeout(function () {
        finish(false)
      }, 120000)
      try {
        self.opts.onIncoming(request, finish)
      } catch {
        finish(false)
      }
    })
  }

  private async runResponder(secure: SecureChannel, binding: SyncBinding, mode: SyncMode, scope: SyncScope): Promise<void> {
    const local = this.opts.effects.getState()
    let rollback: ApplyStateResult | null = null
    try {
      if (mode === 'push') {
        const res = await secure.next('state', 120000)
        this.emitProgress('applying', '正在备份并应用对方数据…')
        const adopted = adoptState(local, res.state as AppState, scope)
        rollback = await this.opts.effects.applyState(adopted.state)
        await secure.send({ t: 'applied', stats: adopted.stats })
        rollback = null
      } else if (mode === 'pull') {
        await secure.send({ t: 'state', state: local } as WireState)
        const res = await secure.nextAny(['applied', 'error'], 120000)
        if (res.t !== 'applied') throw new Error(String(res.error || '对方没有收到数据'))
      } else {
        const res = await secure.next('state', 120000)
        this.emitProgress('syncing', '正在合并双方数据…')
        const merged = mergeStates(local, res.state as AppState, scope)
        await secure.send({ t: 'merge-state', state: local, stats: merged.stats })
        await secure.next('merge-apply', 120000)
        this.emitProgress('applying', '正在备份并合并数据…')
        rollback = await this.opts.effects.applyState(merged.state)
        await secure.send({ t: 'merge-done', stats: merged.stats })
        rollback = null
      }
      await this.touchBinding(binding.deviceId, mode)
      this.emitProgress('done', '与「' + bindingLabel(binding) + '」同步完成')
    } catch (err) {
      if (rollback) {
        try {
          await rollback()
        } catch {
          /* ignore */
        }
      }
      try {
        await secure.send({ t: 'error', error: err instanceof Error ? err.message : '同步失败' })
      } catch {
        /* ignore */
      }
      throw err
    }
  }

  private emitProgress(phase: SyncProgress['phase'], message: string): void {
    if (this.opts.onProgress) this.opts.onProgress({ phase, message })
  }
}

/** 避免在依赖注入里暴露底层加密函数，这里做一层薄封装 */
async function derivePairKeyFor(code: string, saltB64: string): Promise<CryptoKey> {
  const { derivePairKey } = await import('./crypto')
  return derivePairKey(code, saltB64)
}
