import type { RepeatKind, RepeatRule } from './types'

export const REPEAT_LABELS: Record<RepeatKind, string> = {
  daily: '每天',
  weekdays: '工作日',
  weekends: '周六日'
}

export const REPEAT_OPTIONS: Array<{ kind: RepeatKind; label: string; hint: string }> = [
  { kind: 'daily', label: '每天', hint: '每天到点提醒一次' },
  { kind: 'weekdays', label: '工作日', hint: '周一至周五到点提醒' },
  { kind: 'weekends', label: '周六日', hint: '只在周六、周日到点提醒' }
]

export function parseRepeatTime(time: string): { hour: number; minute: number } | null {
  if (!time) return null
  const matched = /^([01]?[0-9]|2[0-3]):([0-5][0-9])$/.exec(time.trim())
  if (!matched) return null
  return { hour: Number(matched[1]), minute: Number(matched[2]) }
}

function pad2(value: number): string {
  return value < 10 ? '0' + value : String(value)
}

export function normalizeRepeat(rule: RepeatRule | null | undefined): RepeatRule | null {
  if (!rule) return null
  const kind: RepeatKind | null =
    rule.kind === 'daily' || rule.kind === 'weekdays' || rule.kind === 'weekends' ? rule.kind : null
  if (!kind) return null
  const parsed = parseRepeatTime(rule.time)
  if (!parsed) return null
  return { kind: kind, time: pad2(parsed.hour) + ':' + pad2(parsed.minute) }
}

/** 从 from 之后（严格大于）找到下一次循环提醒时间；规则无效时返回 null */
export function nextRepeatOccurrence(rule: RepeatRule | null | undefined, from: Date): Date | null {
  const normalized = normalizeRepeat(rule)
  if (!normalized) return null
  const parsed = parseRepeatTime(normalized.time)
  if (!parsed) return null
  for (let offset = 0; offset <= 8; offset += 1) {
    const candidate = new Date(
      from.getFullYear(),
      from.getMonth(),
      from.getDate() + offset,
      parsed.hour,
      parsed.minute,
      0,
      0
    )
    if (candidate.getTime() <= from.getTime()) continue
    const day = candidate.getDay()
    if (normalized.kind === 'daily') return candidate
    if (normalized.kind === 'weekdays' && day >= 1 && day <= 5) return candidate
    if (normalized.kind === 'weekends' && (day === 0 || day === 6)) return candidate
  }
  return null
}

/** 例如「每天 09:00」「工作日 08:30」「周六日 10:00」 */
export function describeRepeat(rule: RepeatRule | null | undefined): string {
  const normalized = normalizeRepeat(rule)
  if (!normalized) return ''
  return REPEAT_LABELS[normalized.kind] + ' ' + normalized.time
}