import type { Category, ExpiryTier, Item, Note, SearchHit, SortDirection, SortMode, StickyNote } from './types'
import { nowIso } from './schema'

/**
 * 常见繁体 -> 简体 对照表。
 * 用两串等长字符保存，繁体在前、简体在后，便于核对。
 */
/** 常见 繁体 -> 简体 对照（每个元素是「繁体字 + 简体字」两个字）。 */
const T2S_PAIRS = [
  '們们', '個个', '這这', '說说', '會会', '對对', '學学', '時时', '間间', '開开',
  '關关', '東东', '與与', '為为', '麼么', '車车', '門门', '書书', '買买', '賣卖',
  '進进', '過过', '還还', '裡里', '邊边', '頭头', '長长', '點点', '電电', '話话',
  '機机', '網网', '線线', '錢钱', '鐵铁', '銀银', '銅铜', '鋼钢', '筆笔', '紙纸',
  '張张', '條条', '塊块', '隻只', '雙双', '樣样', '種种', '葉叶', '華华', '藥药',
  '醫医', '療疗', '髮发', '發发', '麵面', '麥麦', '飯饭', '魚鱼', '雞鸡', '鴨鸭',
  '鵝鹅', '豬猪', '貓猫', '鳥鸟', '鹽盐', '醬酱', '湯汤', '燙烫', '熱热', '涼凉',
  '凍冻', '鮮鲜', '濃浓', '餅饼', '糕糕', '飲饮', '裝装', '壓压', '縮缩', '蓋盖',
  '標标', '籤签', '貼贴', '記记', '號号', '碼码', '憶忆', '舊旧', '壞坏', '險险',
  '檢检', '儲储', '櫃柜', '櫥橱', '屜屉', '層层', '樓楼', '廳厅', '廚厨', '臥卧',
  '衛卫', '浴浴', '陽阳', '臺台', '灣湾', '廣广', '場场', '舖铺', '圖图', '館馆',
  '盤盘', '碗碗', '鍋锅', '爐炉', '燈灯', '褲裤', '襪袜', '鏡镜', '錶表', '鐘钟',
  '傘伞', '鑰钥', '鎖锁', '鈴铃', '冊册', '頁页', '報报', '雜杂', '誌志', '專专',
  '課课', '習习', '題题', '試试', '師师', '員员', '組组', '織织', '團团', '隊队',
  '議议', '計计', '劃划', '項项', '準准', '規规', '則则', '節节', '詞词', '語语',
  '數数', '歷历', '樂乐', '術术', '體体', '運运', '動动', '遊游', '戲戏', '視视',
  '聽听', '讀读', '寫写', '畫画', '攝摄', '錄录', '頻频', '聞闻', '連连', '結结',
  '尋寻', '訊讯', '統统', '軟软', '驅驱', '檔档', '夾夹', '設设', '選选', '擇择',
  '確确', '認认', '刪删', '編编', '輯辑', '複复', '製制', '傳传', '載载', '級级',
  '復复', '備备', '雲云', '帳帐', '註注', '權权', '隱隐', '驗验', '輸输', '顯显',
  '螢萤', '徑径', '鬧闹', '週周', '剛刚', '經经', '辦办', '處处', '狀状', '態态',
  '啟启', '閉闭', '顏颜', '淺浅', '紅红', '黃黄', '綠绿', '藍蓝', '簡简', '單单',
  '難难', '寬宽', '輕轻', '乾干', '濕湿', '溫温', '庫库', '容容', '車车', '玄玄',
  '關关', '園园', '淨净', '凍冻', '準准', '義义', '啟启', '飲饮', '館馆', '實实',
] as const

const T2S_MAP: Record<string, string> = (function () {
  const map: Record<string, string> = {}
  for (const pair of T2S_PAIRS) map[pair.charAt(0)] = pair.charAt(1)
  return map
})()

/** 繁体转简体（逐字替换，未收录的字保持原样） */
export function toSimplified(text: string): string {
  let out = ''
  for (const ch of text) out += T2S_MAP[ch] || ch
  return out
}

/** 搜索前统一归一化：全角转半角、转小写、去空格、繁转简 */
export function normalizeText(text: string): string {
  if (!text) return ''
  let s = text.normalize('NFKC').toLowerCase()
  s = s.replace(/\s+/g, '')
  return toSimplified(s)
}

function hits(haystack: string, needle: string): boolean {
  return haystack.indexOf(needle) !== -1
}

/**
 * 全局 / 分类内搜索：子串包含即命中，名称、位置、备注都参与匹配。
 * 数据量千条级，纯内存过滤，单次耗时远低于 50ms。
 */
export function searchItems(
  items: Item[],
  categories: Category[],
  notes: Note[],
  query: string,
  options?: { categoryId?: string; limit?: number }
): SearchHit[] {
  const needle = normalizeText(query)
  if (!needle) return []
  const categoryMap = new Map<string, Category>()
  for (const c of categories) categoryMap.set(c.id, c)
  const notesByItem = new Map<string, Note[]>()
  for (const n of notes) {
    const list = notesByItem.get(n.itemId)
    if (list) list.push(n)
    else notesByItem.set(n.itemId, [n])
  }
  const result: SearchHit[] = []
  const limit = options && options.limit ? options.limit : Number.POSITIVE_INFINITY
  for (const item of items) {
    if (options && options.categoryId && item.categoryId !== options.categoryId) continue
    const category = categoryMap.get(item.categoryId)
    if (!category) continue
    const nameHit = hits(normalizeText(item.name), needle)
    const locText = normalizeText(item.locationLabel || '') + normalizeText(item.locationName || '')
    const locHit = hits(locText, needle)
    let noteHit = false
    if (!nameHit && !locHit) {
      const list = notesByItem.get(item.id)
      if (list) {
        for (const n of list) {
          if (hits(normalizeText(n.content), needle)) { noteHit = true; break }
        }
      }
    }
    if (!nameHit && !locHit && !noteHit) continue
    result.push({
      item,
      categoryName: category.name,
      categoryIcon: category.icon,
      matchField: nameHit ? 'name' : locHit ? 'location' : 'note'
    })
    if (result.length >= limit) break
  }
  return result
}

/**
 * 便签搜索：标题和内容都参与匹配，大小写/全半角/繁简/空格处理与物品搜索一致。
 * 复用 normalizeText，避免重复实现一套匹配规则。
 */
export function searchStickies(stickies: StickyNote[], query: string): StickyNote[] {
  const needle = normalizeText(query)
  if (!needle) return stickies.slice()
  return stickies.filter(function (sticky) {
    const titleHit = hits(normalizeText(sticky.title || ''), needle)
    const contentHit = hits(normalizeText(sticky.content), needle)
    return titleHit || contentHit
  })
}

/** 名称排序：用 zh-CN 让中文按拼音排 */
export function compareByName(a: string, b: string): number {
  return a.localeCompare(b, 'zh-CN', { numeric: true, sensitivity: 'base' })
}

/**
 * 条目的存放时间：没填时回退到创建日期。
 * 旧版本（1.1.4 及以前）建的条目没有 fields.storedAt，全部按缺失排最后会出现
 * 「点了按存放时间排序却和按名称一模一样」的错觉，所以这里用创建日期兜底。
 */
function storedAtOf(item: Item): string {
  const raw = item.fields.storedAt || ''
  if (raw) return raw
  const created = item.createdAt || ''
  return /^\d{4}-\d{2}-\d{2}/.test(created) ? created.slice(0, 10) : ''
}

/**
 * 按排序方式和方向排条目：升序/倒序由 direction 决定。
 * 存放时间缺失时回退创建日期；过期时间没有可回退的值，缺失始终排最后。
 * 日期相同时按名称排，并且名称也随升降序翻转，保证切换方向一定能看到顺序变化。
 */
export function sortItems(items: Item[], mode: SortMode, direction: SortDirection = 'asc'): Item[] {
  const copy = items.slice()
  const flip = direction === 'desc' ? -1 : 1
  if (mode === 'storedAt' || mode === 'expiresAt') {
    copy.sort(function (a, b) {
      const av = mode === 'storedAt' ? storedAtOf(a) : a.fields.expiresAt || ''
      const bv = mode === 'storedAt' ? storedAtOf(b) : b.fields.expiresAt || ''
      if (av && bv) {
        if (av === bv) return compareByName(a.name, b.name) * flip
        return (av < bv ? -1 : 1) * flip
      }
      if (av) return -1
      if (bv) return 1
      return compareByName(a.name, b.name) * flip
    })
  } else {
    copy.sort(function (a, b) { return compareByName(a.name, b.name) * flip })
  }
  return copy
}

/** 距离过期还有几天（本地时区，按自然日算）；负数表示已过期 */
export function daysUntil(expiresAt: string, now?: Date): number | null {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(expiresAt)
  if (!m) return null
  const target = new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3]))
  const base = now || new Date()
  const today = new Date(base.getFullYear(), base.getMonth(), base.getDate())
  return Math.round((target.getTime() - today.getTime()) / 86400000)
}

export type ExpiryLevel = 'normal' | 'soon' | 'urgent' | 'critical' | 'expired'

/** 临期颜色分级：>15 中性，<=15 黄，<=7 橙，<=1 红，过期灰红 */
export function expiryLevel(days: number): ExpiryLevel {
  if (days < 0) return 'expired'
  if (days <= 1) return 'critical'
  if (days <= 7) return 'urgent'
  if (days <= 15) return 'soon'
  return 'normal'
}

/** 某一天数对应应触发的提醒档位（分档触发，一档一条，不会一次堆很多条） */
export function tierForDaysLeft(days: number): ExpiryTier | null {
  if (days > 30) return null
  if (days > 15) return 30
  if (days > 7) return 15
  if (days > 1) return 7
  return 1
}

/** 通知唯一键：同一物品 + 同一档位 + 同一过期日期只提醒一次 */
export function notificationKey(itemId: string, tier: ExpiryTier, expiryDate: string): string {
  return itemId + '|' + String(tier) + '|' + expiryDate
}


export function formatDateTime(iso: string): string {
  const d = new Date(iso)
  if (Number.isNaN(d.getTime())) return ''
  const pad = function (n: number): string { return n < 10 ? '0' + n : String(n) }
  return String(d.getFullYear()) + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()) + ' ' + pad(d.getHours()) + ':' + pad(d.getMinutes())
}

export function formatDate(dateStr: string): string {
  if (!dateStr) return ''
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(dateStr)
  if (!m) return dateStr
  return m[1] + '-' + m[2] + '-' + m[3]
}

export function formatRemain(days: number): string {
  if (days < 0) return '已过期 ' + Math.abs(days) + ' 天'
  if (days === 0) return '今天到期'
  return '还剩 ' + days + ' 天'
}

export function stamp(): string {
  return nowIso()
}
