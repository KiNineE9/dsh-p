import type {
  AppSettings,
  AppState,
  BaseTemplate,
  Category,
  CustomFieldDef,
  ItemDraft,
  LocationType,
  SortDirection,
  SortMode,
  SortState,
  TemplateType,
  ValidationResult
} from './types'

export const DATA_VERSION = 1

/** 每类（地点/容器）最多保存多少个可一键填入的名称 */
export const SAVED_NAME_LIMIT = 12

/** 每类搜索历史最多保留多少条（超出后按最近使用顺序丢掉最旧的） */
export const SEARCH_HISTORY_LIMIT = 50

/** 搜索框下方一次最多展示多少条搜索历史 */
export const SEARCH_HISTORY_SHOWN = 5

export const BUILTIN_CATEGORY_IDS = {
  book: 'cat-book',
  item: 'cat-item',
  food: 'cat-food',
  medicine: 'cat-medicine'
} as const

export const TEMPLATE_LABELS: Record<TemplateType, string> = {
  book: '图书',
  item: '物品',
  food: '食品',
  medicine: '药品',
  custom: '自定义'
}

export const TEMPLATE_ICONS: Record<TemplateType, string> = {
  book: '📚',
  item: '📦',
  food: '🍎',
  medicine: '💊',
  custom: '🏷️'
}

export const BASE_TEMPLATES: BaseTemplate[] = ['book', 'item', 'food', 'medicine']

export const LOCATION_TYPE_LABELS: Record<LocationType, string> = {
  place: '地点',
  container: '容器'
}

export const DEFAULT_SETTINGS: AppSettings = {
  theme: 'system',
  autoLaunch: true,
  closeToTray: true,
  reminderPopup: true,
  reminderSound: true,
  stickySearchHistory: true,
  itemSearchHistory: true,
  expiryTiers: { 30: true, 15: true, 7: true, 1: true }
}

export function nowIso(): string {
  return new Date().toISOString()
}

export function makeId(prefix: string): string {
  return prefix + '-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 8)
}

export function createInitialState(): AppState {
  const at = nowIso()
  const categories: Category[] = BASE_TEMPLATES.map(function (base, index) {
    return {
      id: BUILTIN_CATEGORY_IDS[base],
      name: TEMPLATE_LABELS[base],
      icon: TEMPLATE_ICONS[base],
      template: base,
      baseTemplate: base,
      order: index,
      builtin: true,
      customFields: [],
      createdAt: at
    }
  })
  return {
    version: DATA_VERSION,
    categories: categories,
    items: [],
    notes: [],
    stickies: [],
    tombstones: [],
    notifications: [],
    settings: {
      theme: 'system',
      autoLaunch: true,
      closeToTray: true,
      reminderPopup: true,
      reminderSound: true,
      stickySearchHistory: true,
      itemSearchHistory: true,
      expiryTiers: { 30: true, 15: true, 7: true, 1: true }
    },
    savedNames: { place: [], container: [] },
    searchHistory: { sticky: [], item: [] },
    onboardingDone: false,
    createdAt: at
  }
}

/**
 * 「特殊区」分类：置顶分类 + 内置的四个分类。手机端长按拖动只能在特殊区内部、
 * 或者普通区内部调整，普通分类永远排在特殊区后面。
 */
export function isSpecialCategory(category: Category): boolean {
  return Boolean(category.pinned || category.builtin)
}

/** 「我的分类」展示顺序：特殊区（置顶 + 内置）在前，普通分类在后；两区内部都按 order 升序 */
export function sortCategoriesForDisplay(list: Category[]): Category[] {
  return list.slice().sort(function (a, b) {
    const ar = isSpecialCategory(a) ? 0 : 1
    const br = isSpecialCategory(b) ? 0 : 1
    if (ar !== br) return ar - br
    if (a.order !== b.order) return a.order - b.order
    return Date.parse(a.createdAt) - Date.parse(b.createdAt)
  })
}

/** 把「地点名称/容器名称」和「详细位置」拼成一行展示文案 */
export function formatLocation(label: string, detail: string): string {
  const a = (label || '').trim()
  const b = (detail || '').trim()
  if (a && b) return a + ' · ' + b
  return a || b
}

/** 某个分类模板支持的排序方式：到期时间只有「食品 / 药品」才有 */
export function sortOptionsFor(base: BaseTemplate): Array<{ mode: SortMode; label: string }> {
  const list: Array<{ mode: SortMode; label: string }> = [
    { mode: 'name', label: '按名称' },
    { mode: 'storedAt', label: '按存放时间' }
  ]
  if (base === 'food' || base === 'medicine') list.push({ mode: 'expiresAt', label: '按过期时间' })
  return list
}

/** 点同一个排序方式时在升序和倒序之间循环，点其它方式时从升序开始 */
export function toggleSortState(current: SortState, mode: SortMode): SortState {
  if (current.mode === mode) {
    const next: SortDirection = current.direction === 'asc' ? 'desc' : 'asc'
    return { mode: mode, direction: next }
  }
  return { mode: mode, direction: 'asc' }
}

/** 排序方向箭头，给排序按钮显示用 */
export function sortDirectionArrow(direction: SortDirection): string {
  return direction === 'asc' ? '↑' : '↓'
}

export interface FieldDef {
  key: string
  label: string
  type: 'number' | 'boolean' | 'text' | 'date' | 'select' | 'textarea'
  options?: string[]
  required?: boolean
  placeholder?: string
  hint?: string
}

export interface FormSchema {
  nameLabel: string
  namePlaceholder: string
  /** 地点名称 / 容器名称输入框的示例提示 */
  labelPlaceholder: string
  /** 详细位置（选填）的标题 */
  locationLabel: string
  locationPlaceholder: string
  fields: FieldDef[]
}

/** 根据分类的模板 + 自定义字段，得出表单要渲染的字段 */
export function getFormSchema(base: BaseTemplate, customFields: CustomFieldDef[]): FormSchema {
  const extra: FieldDef[] = customFields.map(function (f) {
    return {
      key: 'custom.' + f.key,
      label: f.label,
      type: f.type === 'select' ? 'select' : f.type,
      options: f.options,
      required: f.required
    }
  })
  const locationLabel = '详细位置'
  const locationPlaceholder = '选填，例如：第二层抽屉 / 夹层'
  if (base === 'book') {
    return {
      nameLabel: '书名',
      namePlaceholder: '例如：活着',
      labelPlaceholder: '例如：书架 / 卧室',
      locationLabel: locationLabel,
      locationPlaceholder: locationPlaceholder,
      fields: ([
        { key: 'storedAt', label: '存放时间', type: 'date', required: true, hint: '放进去的那天' }
      ] as FieldDef[]).concat(extra)
    }
  }
  if (base === 'food') {
    return {
      nameLabel: '食品名称',
      namePlaceholder: '例如：娃哈哈纯净水',
      labelPlaceholder: '例如：冰箱 / 厨房',
      locationLabel: locationLabel,
      locationPlaceholder: locationPlaceholder,
      fields: ([
        { key: 'foodType', label: '食品类型', type: 'select', options: ['液体', '固体'], required: true },
        { key: 'opened', label: '是否拆封', type: 'boolean', options: ['是', '否'], required: true },
        { key: 'storedAt', label: '存放时间', type: 'date', required: false, hint: '放进去的那天（选填）' },
        { key: 'expiresAt', label: '过期时间', type: 'date', required: true, hint: '到期前 30/15/7/1 天各提醒一次' }
      ] as FieldDef[]).concat(extra)
    }
  }
  if (base === 'medicine') {
    return {
      nameLabel: '药品名称',
      namePlaceholder: '例如：布洛芬缓释胶囊',
      labelPlaceholder: '例如：药箱 / 客厅',
      locationLabel: locationLabel,
      locationPlaceholder: locationPlaceholder,
      fields: ([
        { key: 'medicineType', label: '药品类型', type: 'select', options: ['液体', '固体'], required: true },
        { key: 'opened', label: '是否拆封', type: 'boolean', options: ['是', '否'], required: true },
        { key: 'storedAt', label: '存放时间', type: 'date', required: false, hint: '放进去的那天（选填）' },
        { key: 'expiresAt', label: '过期时间', type: 'date', required: true, hint: '到期前 30/15/7/1 天各提醒一次' },
        { key: 'effect', label: '药品作用', type: 'text', required: false, placeholder: '选填，例如：退烧止痛' }
      ] as FieldDef[]).concat(extra)
    }
  }
  return {
    nameLabel: '物品名称',
    namePlaceholder: '例如：香水',
    labelPlaceholder: '例如：卧室 / 抽屉柜',
    locationLabel: locationLabel,
    locationPlaceholder: locationPlaceholder,
    fields: ([
      { key: 'storedAt', label: '存放时间', type: 'date', required: false, hint: '放进去的那天（选填）' }
    ] as FieldDef[]).concat(extra)
  }
}

function isBlank(v: unknown): boolean {
  return v === undefined || v === null || (typeof v === 'string' && v.trim() === '')
}

function fieldValueOf(draft: ItemDraft, key: string): unknown {
  if (key.indexOf('custom.') === 0) {
    const custom = draft.fields.custom || {}
    return custom[key.slice(7)]
  }
  return (draft.fields as unknown as Record<string, unknown>)[key]
}

/** 校验条目草稿：名称、地点/容器名称必填；模板里 required 的字段也必填；详细位置选填 */
export function validateItemDraft(draft: ItemDraft, base: BaseTemplate, customFields: CustomFieldDef[]): ValidationResult {
  const errors: Record<string, string> = {}
  const schema = getFormSchema(base, customFields)
  if (isBlank(draft.name)) errors['name'] = '请填写 ' + schema.nameLabel
  if (isBlank(draft.locationLabel)) {
    errors['locationLabel'] = draft.locationType === 'container' ? '请填写容器名称' : '请填写地点名称'
  }
  for (const f of schema.fields) {
    if (!f.required) continue
    const value = fieldValueOf(draft, f.key)
    if (isBlank(value)) {
      const verb = f.type === 'select' || f.type === 'boolean' ? '请选择 ' : '请填写 '
      errors[f.key] = verb + f.label
    }
  }
  return { ok: Object.keys(errors).length === 0, errors: errors }
}

/** 校验新建 / 编辑分类：名称不能为空，也不能和已有分类重名 */
export function validateCategoryDraft(
  draft: { name: string; baseTemplate: BaseTemplate; icon?: string; customFields?: CustomFieldDef[] },
  categories: Category[],
  selfId?: string
): ValidationResult {
  const errors: Record<string, string> = {}
  const name = (draft.name || '').trim()
  if (!name) errors['name'] = '请填写分类名称'
  const duplicated = categories.some(function (c) {
    return c.id !== selfId && c.name.trim() === name
  })
  if (name && duplicated) errors['name'] = '已经有同名分类了'
  if (!draft.baseTemplate) errors['baseTemplate'] = '请选择字段模板'
  return { ok: Object.keys(errors).length === 0, errors: errors }
}

/** 新建条目时的空白草稿 */
export function emptyDraftFor(base: BaseTemplate, customFields?: CustomFieldDef[]): ItemDraft {
  const baseDraft: ItemDraft = {
    name: '',
    locationType: 'place',
    locationLabel: '',
    locationName: '',
    fields: {}
  }
  baseDraft.fields.storedAt = todayDateString()
  if (base === 'food') {
    baseDraft.fields.foodType = 'solid'
    baseDraft.fields.opened = false
    baseDraft.fields.expiresAt = todayDateString()
  }
  if (base === 'medicine') {
    baseDraft.fields.medicineType = 'solid'
    baseDraft.fields.opened = false
    baseDraft.fields.expiresAt = todayDateString()
    baseDraft.fields.effect = ''
  }
  if (customFields && customFields.length) baseDraft.fields.custom = {}
  return baseDraft
}

/** 本地时区的今天，格式 YYYY-MM-DD */
export function todayDateString(): string {
  const d = new Date()
  const y = d.getFullYear()
  const m = String(d.getMonth() + 1).padStart(2, '0')
  const day = String(d.getDate()).padStart(2, '0')
  return y + '-' + m + '-' + day
}

