import type { SearchHistoryKind } from './history'
import type {
  AppNotification,
  AppSettings,
  AppState,
  Category,
  CategoryDraft,
  DialogKind,
  Item,
  ItemDraft,
  LocationType,
  Note,
  NotificationKind,
  Op,
  ReminderPayload,
  RepeatRule,
  SearchHistoryEntry,
  StickyKind,
  StickyNote
} from './types'
import type { SyncConfig } from './sync/types'

/** 数据文件位置信息，设置页展示给用户看 */
export interface DataInfo {
  dir: string
  file: string
  backupDir: string
  backups: number
  /** 手动备份目录 */
  manualBackupDir: string
  /** 手动备份数量 */
  manualBackups: number
  lastSavedAt: string | null
  appVersion: string
}

/** 新建 / 编辑便利贴提交的内容 */
export interface StickyDraft {
  /** 标题（可选） */
  title?: string
  content: string
  kind: StickyKind
  remindAt?: string | null
  repeat?: RepeatRule | null
  pinned?: boolean
}

export interface StickyPatch {
  title?: string
  content?: string
  kind?: StickyKind
  pinned?: boolean
  remindAt?: string | null
  repeat?: RepeatRule | null
  status?: 'pending' | 'done'
}

/** 一份手动备份的元信息 */
export interface BackupEntry {
  id: string
  name: string
  createdAt: string
  size: number
  items: number
  notes: number
  stickies: number
}

export interface LocatePayload {
  itemId: string
  categoryId: string
}

/** 主进程提供的本机同步身份素材（默认设备名、机器码种子等） */
export interface SyncDeviceInfo {
  defaultName: string
  machineSeed: string
  platform: string
  appVersion: string
}

export interface SyncApplyResult {
  /** 应用前自动创建的手动备份，出问题时可以还原它 */
  backupId: string
}

export interface ExportDataResult {
  path: string | null
  canceled: boolean
}

export interface ImportDataResult {
  state: AppState
  backupId: string
  fileName: string
}

export interface GuinaApi {
  getState(): Promise<AppState>
  getDataInfo(): Promise<DataInfo>

  createCategory(draft: CategoryDraft): Promise<Op<Category>>
  updateCategory(
    id: string,
    patch: {
      name?: string
      icon?: string
      customFields?: Category['customFields']
      pinned?: boolean
    }
  ): Promise<Op<Category>>
  deleteCategory(id: string): Promise<Op<{ removedItems: number }>>
  reorderCategories(ids: string[]): Promise<Op<Category[]>>

  createItem(categoryId: string, draft: ItemDraft): Promise<Op<Item>>
  updateItem(id: string, draft: ItemDraft): Promise<Op<Item>>
  deleteItem(id: string): Promise<Op<{ id: string }>>

  /** 删除一个保存过的地点名称 / 容器名称 */
  removeSavedName(type: LocationType, name: string): Promise<Op<{ type: LocationType; name: string }>>

  /** 记录一条搜索历史（便签与提醒 / 物品与存放位置） */
  addSearchHistory(kind: SearchHistoryKind, text: string): Promise<Op<SearchHistoryEntry[]>>
  /** 删除一条搜索历史 */
  removeSearchHistory(
    kind: SearchHistoryKind,
    text: string
  ): Promise<Op<{ kind: SearchHistoryKind; text: string }>>

  addNote(itemId: string, content: string): Promise<Op<Note>>
  updateNote(id: string, content: string): Promise<Op<Note>>
  deleteNote(id: string): Promise<Op<{ id: string }>>

  createSticky(draft: StickyDraft): Promise<Op<StickyNote>>
  updateSticky(id: string, patch: StickyPatch): Promise<Op<StickyNote>>
  deleteSticky(id: string): Promise<Op<{ id: string }>>

  markNotificationRead(id: string, read: boolean): Promise<Op<AppNotification>>
  markAllNotificationsRead(kind: NotificationKind): Promise<Op<number>>
  deleteNotification(id: string): Promise<Op<{ id: string }>>
  deleteReadNotifications(kind: NotificationKind): Promise<Op<number>>

  /** 手动备份：name 为空时用当前日期时间；超过 5 个时先让用户选一个覆盖（overwriteId） */
  createBackup(name: string, overwriteId?: string | null): Promise<Op<BackupEntry>>
  listBackups(): Promise<BackupEntry[]>
  restoreBackup(id: string): Promise<Op<AppState>>
  deleteBackup(id: string): Promise<Op<{ id: string }>>

  updateSettings(patch: Partial<AppSettings>): Promise<Op<AppSettings>>
  finishOnboarding(): Promise<void>
  showOnboarding(): Promise<void>

  openDataFolder(): Promise<void>
  /** 用系统默认浏览器打开外部链接（只放行 https 与 mailto） */
  openExternal(url: string): Promise<void>
  showMainWindow(): Promise<void>
  quitApp(): Promise<void>
  sendTestReminder(): Promise<void>

  getReminderPayload(): Promise<ReminderPayload | null>
  reminderAction(action: 'ok' | 'snooze' | 'done'): Promise<void>

  /** 数据同步：本机身份素材与独立的同步配置文件 */
  getSyncDeviceInfo(): Promise<SyncDeviceInfo>
  getSyncConfig(): Promise<SyncConfig | null>
  saveSyncConfig(config: SyncConfig): Promise<boolean>
  /** 备份后整体应用同步来的数据，返回可回滚的备份 id */
  syncApplyState(state: unknown): Promise<Op<SyncApplyResult>>

  /** 导出 data.json 到用户选择的位置 */
  exportDataFile(): Promise<Op<ExportDataResult>>
  /** 从 data.json 导入（导入前自动备份，返回导入后的状态） */
  importDataFile(): Promise<Op<ImportDataResult>>

  onStateChanged(cb: (state: AppState) => void): () => void
  onLocateItem(cb: (payload: LocatePayload) => void): () => void
  onOpenDialog(cb: (kind: DialogKind) => void): () => void
  onPlaySound(cb: () => void): () => void
  onToast(cb: (message: string) => void): () => void
  onOpenSettings(cb: () => void): () => void
}
