import { SEARCH_HISTORY_LIMIT, SEARCH_HISTORY_SHOWN } from './schema'
import type { SearchHistory, SearchHistoryEntry } from './types'

/** 搜索历史分两类：便签与提醒 / 物品与存放位置 */
export type SearchHistoryKind = keyof SearchHistory

/** 搜索文本统一：合并连续空白、去掉首尾空格 */
export function normalizeQueryText(raw: string): string {
  return String(raw || '').replace(/\s+/g, ' ').trim()
}

/** 去重用的键：忽略大小写与空白差异 */
function historyKey(raw: string): string {
  return normalizeQueryText(raw).toLowerCase()
}

function emptySearchHistory(): SearchHistory {
  return { sticky: [], item: [] }
}

/** 过滤非法条目、去重、按最近使用倒序排列并截断到上限 */
export function normalizeSearchHistory(raw: unknown): SearchHistory {
  const out = emptySearchHistory()
  if (!raw || typeof raw !== 'object') return out
  const source = raw as Record<string, unknown>
  ;(Object.keys(out) as SearchHistoryKind[]).forEach(function (kind) {
    const list = source[kind]
    if (!Array.isArray(list)) return
    const seen = new Set<string>()
    const entries: SearchHistoryEntry[] = []
    for (const one of list) {
      if (!one || typeof one !== 'object') continue
      const item = one as { text?: unknown; usedAt?: unknown }
      const text = normalizeQueryText(typeof item.text === 'string' ? item.text : '')
      if (!text) continue
      const key = historyKey(text)
      if (seen.has(key)) continue
      seen.add(key)
      entries.push({ text: text, usedAt: typeof item.usedAt === 'string' ? item.usedAt : '' })
    }
    entries.sort(function (a, b) {
      if (a.usedAt !== b.usedAt) return a.usedAt < b.usedAt ? 1 : -1
      return 0
    })
    out[kind] = entries.slice(0, SEARCH_HISTORY_LIMIT)
  })
  return out
}

/** 记一次搜索：同一个词只留一条并置顶到第一个，超过上限丢掉最旧的 */
export function pushSearchHistory(
  list: SearchHistoryEntry[],
  rawText: string,
  at?: string
): SearchHistoryEntry[] {
  const text = normalizeQueryText(rawText)
  if (!text) return list.slice()
  const usedAt = at || new Date().toISOString()
  const key = historyKey(text)
  const rest = list.filter(function (one) {
    return historyKey(one.text) !== key
  })
  return [{ text: text, usedAt: usedAt }].concat(rest).slice(0, SEARCH_HISTORY_LIMIT)
}

/** 删除一条搜索历史（按文本匹配，忽略大小写与空白差异） */
export function removeSearchHistoryEntry(
  list: SearchHistoryEntry[],
  rawText: string
): SearchHistoryEntry[] {
  const key = historyKey(rawText)
  if (!key) return list.slice()
  return list.filter(function (one) {
    return historyKey(one.text) !== key
  })
}

/** 取最近用过的若干条文本，供搜索框下拉展示 */
export function recentSearchTexts(
  list: SearchHistoryEntry[],
  limit: number = SEARCH_HISTORY_SHOWN
): string[] {
  return list.slice(0, Math.max(0, limit)).map(function (one) {
    return one.text
  })
}
