/**
 * 摄像头挑选规则。
 *
 * OEM 多摄机型上 enumerateDevices() 的顺序并不固定，只按 facingMode 打开
 * 常常落到长焦 / 微距 / 景深那颗镜头上（用户反馈的「扫码调起长焦」）。
 * 这里把「挑后置主摄」的判断集中成纯函数，手机壳和测试共用一份实现。
 */

export interface CameraDeviceLike {
  deviceId: string
  label: string
  kind?: string
}

export interface CameraChoice {
  deviceId: string
  label: string
}

const REAR = /(back|rear|后置|背)/i
const FRONT = /(front|user|facetime|前置|前摄)/i
const TELE = /(tele|telephoto|periscope|长焦|望远|潜望|macro|微距|depth|景深|tof|mono|黑白|红外|fisheye|鱼眼)/i
const MAIN = /(wide|main|primary|主摄|广角|标准|standard|默认|camera ?0)/i

/** 前置摄像头（用于避免挑错方向） */
export function isFrontCameraLabel(label: string): boolean {
  return FRONT.test(label)
}

/** 长焦 / 微距 / 景深等非主摄镜头 */
export function isTelephotoLabel(label: string): boolean {
  return TELE.test(label)
}

/**
 * 从设备列表里挑后置主摄：
 * 1. 只保留带「后置」字样且不是前置的镜头；
 * 2. 排除长焦 / 微距 / 景深 / 黑白 / 鱼眼；
 * 3. 剩下的优先 wide / main / 主摄 / 广角；
 * 4. 都判断不出来时退回到当前正在用的那一路（不会比现在更差）。
 */
export function pickMainBackCamera(devices: CameraDeviceLike[], currentDeviceId?: string): CameraChoice | null {
  const videos = devices.filter(function (device) {
    return !device.kind || device.kind === 'videoinput'
  })
  if (videos.length === 0) return null
  const labelled = videos.filter(function (device) {
    return Boolean(device.label)
  })
  let pool = labelled.filter(function (device) {
    return REAR.test(device.label) && !FRONT.test(device.label)
  })
  if (pool.length === 0) {
    const current = currentDeviceId
      ? videos.find(function (device) {
          return device.deviceId === currentDeviceId
        })
      : undefined
    if (current) {
      pool = [current]
    } else {
      pool = labelled.filter(function (device) {
        return !isFrontCameraLabel(device.label)
      })
    }
    if (pool.length === 0) return null
  }
  const usable = pool.filter(function (device) {
    return !isTelephotoLabel(device.label)
  })
  const candidates = usable.length > 0 ? usable : pool
  const main = candidates.find(function (device) {
    return MAIN.test(device.label)
  })
  const pick = main || candidates[0]
  return { deviceId: pick.deviceId, label: pick.label }
}
