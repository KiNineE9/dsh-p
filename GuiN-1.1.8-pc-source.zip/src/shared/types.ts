/** 全局共享的数据模型：主进程持久化、渲染进程展示都用这一份定义。 */

/** 内置字段模板：图书型 / 物品型 / 食品型 / 药品型 */
export type BaseTemplate = 'book' | 'item' | 'food' | 'medicine'

/** 分类的模板类型：内置四类 + 用户自定义（自定义时继承 baseTemplate 再追加字段） */
export type TemplateType = BaseTemplate | 'custom'

/** 存放位置类型：地点（房间/区域）或容器（柜子/抽屉/盒子） */
export type LocationType = 'place' | 'container'

export type FoodType = 'liquid' | 'solid'

export type ThemeMode = 'light' | 'dark' | 'system'

/** 食品临期颜色分级 */
export type ExpiryLevel = 'normal' | 'soon' | 'urgent' | 'critical' | 'expired'

/** 到期提醒档位（天） */
export type ExpiryTier = 30 | 15 | 7 | 1

/** 自定义字段的类型 */
export type CustomFieldType = 'text' | 'number' | 'date' | 'select' | 'textarea' | 'boolean'

export interface CustomFieldDef {
  /** 稳定 key，条目里按它存值 */
  key: string
  label: string
  type: CustomFieldType
  /** type 为 select 时的选项 */
  options?: string[]
  required?: boolean
}

export interface Category {
  id: string
  name: string
  /** emoji 图标 */
  icon: string
  template: TemplateType
  /** 字段模板来源，内置分类等于 template */
  baseTemplate: BaseTemplate
  /** 排序序号，越小越靠前 */
  order: number
  /** 内置分类不可删除 */
  builtin: boolean
  customFields: CustomFieldDef[]
  /** 是否置顶显示在「我的分类」最前面 */
  pinned?: boolean
  /** 置顶时间：仅用于展示「置顶于何时」，排序以 order 为准 */
  pinnedAt?: string
  /** 置顶前的 order，取消置顶时用来恢复原位 */
  orderBeforePin?: number
  createdAt: string
}

/** 模板字段值。日期类字段存 YYYY-MM-DD（本地日期）。 */
export interface ItemFields {
  /** 图书：存放时间 */
  storedAt?: string
  /** 食品：液体 / 固体 */
  foodType?: FoodType
  /** 药品：液体 / 固体（药品类型） */
  medicineType?: FoodType
  /** 食品 / 药品：是否拆封 */
  opened?: boolean
  /** 食品 / 药品：过期时间 */
  expiresAt?: string
  /** 药品：药品作用（选填） */
  effect?: string
  /** 自定义字段值，key 对应 CustomFieldDef.key */
  custom?: Record<string, string>
}

export interface Item {
  id: string
  categoryId: string
  /** 名称（图书：书名；食品：食品名；物品：物品名） */
  name: string
  locationType: LocationType
  /** 地点名称 / 容器名称（必填，例如「卧室」「抽屉柜」） */
  locationLabel: string
  /** 详细位置（选填，例如「第二层抽屉」「夹层」） */
  locationName: string
  fields: ItemFields
  createdAt: string
  updatedAt: string
}

export interface Note {
  id: string
  itemId: string
  content: string
  createdAt: string
  updatedAt: string
}

export type StickyStatus = 'pending' | 'done'

/** 便利贴种类：普通便签（可置顶）/ 提醒便签（可定时、循环提醒） */
export type StickyKind = 'note' | 'reminder'

/** 循环提醒种类：每天 / 工作日（周一至周五）/ 周六日 */
export type RepeatKind = 'daily' | 'weekdays' | 'weekends'

/** 便利贴循环提醒规则，time 为本地时间 HH:mm */
export interface RepeatRule {
  kind: RepeatKind
  time: string
}

export interface StickyNote {
  id: string
  /** 标题（可选） */
  title?: string
  content: string
  /** 种类：note=便签（可置顶），reminder=提醒便签 */
  kind: StickyKind
  /** 便签是否置顶 */
  pinned: boolean
  /** 置顶时间，用于多个置顶之间的排序 */
  pinnedAt?: string
  /** 提醒时间 ISO 字符串；为空表示只当便签、不提醒；循环提醒时存下一次触发时间 */
  remindAt: string | null
  /** 循环提醒规则；为空表示一次性提醒或只当便签 */
  repeat?: RepeatRule | null
  status: StickyStatus
  createdAt: string
  updatedAt: string
  /** 是否已经提醒过（避免重复弹） */
  notified: boolean
  /** 最近一次提醒 / 稍后提醒的时间 */
  lastNotifiedAt?: string
}

export type NotificationType = 'foodExpiring' | 'medicineExpiring'

/** 到期提醒分栏：食品 / 药品 */
export type NotificationKind = 'food' | 'medicine'

export interface AppNotification {
  id: string
  type: NotificationType
  /** 属于食品栏还是药品栏 */
  kind: NotificationKind
  itemId: string
  tier: ExpiryTier
  /** 触发时的过期日期 YYYY-MM-DD，参与唯一键 */
  expiryDate: string
  read: boolean
  /** 用户删除后保留标记，避免下次检查又生出来 */
  deleted: boolean
  createdAt: string
}

export interface ExpiryTierSwitches {
  30: boolean
  15: boolean
  7: boolean
  1: boolean
}

export interface AppSettings {
  theme: ThemeMode
  autoLaunch: boolean
  closeToTray: boolean
  reminderPopup: boolean
  reminderSound: boolean
  /** 是否记录「便签与提醒」的搜索历史 */
  stickySearchHistory: boolean
  /** 是否记录「搜索物品或存放位置」的搜索历史 */
  itemSearchHistory: boolean
  expiryTiers: ExpiryTierSwitches
}

/** 保存过、可一键填入的地点名称 / 容器名称 */
export interface SavedName {
  name: string
  lastUsedAt: string
}

export interface SavedNames {
  place: SavedName[]
  container: SavedName[]
}

/** 同步用的删除墓碑：合并双方数据时用来判断某条记录是否已被某一方删除 */
export type TombstoneKind = 'category' | 'item' | 'note' | 'sticky'

export interface Tombstone {
  kind: TombstoneKind
  id: string
  /** 删除时间（ISO） */
  deletedAt: string
}

/** 一条搜索历史：搜索过的文本 + 最近一次使用时间 */
export interface SearchHistoryEntry {
  text: string
  usedAt: string
}

/** 两类搜索历史：便签与提醒 / 物品与存放位置 */
export interface SearchHistory {
  sticky: SearchHistoryEntry[]
  item: SearchHistoryEntry[]
}

export interface AppState {
  version: number
  categories: Category[]
  items: Item[]
  notes: Note[]
  stickies: StickyNote[]
  /** 删除记录（用于设备间合并数据，避免已删除的内容被对方同步回来） */
  tombstones: Tombstone[]
  notifications: AppNotification[]
  settings: AppSettings
  savedNames: SavedNames
  /** 搜索历史（本机使用，不参与设备间同步） */
  searchHistory: SearchHistory
  onboardingDone: boolean
  createdAt: string
}

/** 条目创建 / 编辑时前端提交的内容 */
export interface ItemDraft {
  name: string
  locationType: LocationType
  /** 地点名称 / 容器名称（必填） */
  locationLabel: string
  /** 详细位置（选填） */
  locationName: string
  fields: ItemFields
}

export interface CategoryDraft {
  name: string
  icon: string
  baseTemplate: BaseTemplate
  customFields: CustomFieldDef[]
}

/** 表单校验结果 */
export interface ValidationResult {
  ok: boolean
  errors: Record<string, string>
}


/** 主进程操作结果：成功带 value，失败带给用户看的中文提示 */
export interface OpOk<T> {
  ok: true
  value: T
}
export interface OpErr {
  ok: false
  error: string
  /** 机器可识别的错误码，前端用来决定交互（例如备份已满需要选覆盖） */
  code?: string
}
export type Op<T> = OpOk<T> | OpErr

/** 主窗口里弹出的对话框类型 */
export type DialogKind = 'new-item' | 'new-sticky' | 'new-sticky-note' | 'new-sticky-reminder' | 'settings'

/** 提醒窗口要展示的便利贴 */
export interface ReminderPayload {
  id: string
  /** 标题（可选） */
  title?: string
  content: string
  remindAt: string | null
  /** 循环提醒规则（有值说明是循环提醒） */
  repeat?: RepeatRule | null
  /** 循环提醒展示文案，例如「每天 09:00」 */
  repeatText?: string | null
}

/** 搜索命中 */
export interface SearchHit {
  item: Item
  categoryName: string
  categoryIcon: string
  /** 命中的是什么：名称 / 位置 / 备注 */
  matchField: 'name' | 'location' | 'note'
}

export type SortMode = 'name' | 'storedAt' | 'expiresAt'

/** 排序方向：升序 / 倒序 */
export type SortDirection = 'asc' | 'desc'

/** 分类内当前的排序状态；点同一个排序方式会切换升序/倒序 */
export interface SortState {
  mode: SortMode
  direction: SortDirection
}

export type MainView = 'home' | 'category' | 'settings'
