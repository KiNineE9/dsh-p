import { makeId, nowIso, SAVED_NAME_LIMIT, validateCategoryDraft, validateItemDraft } from '../shared/schema'
import {
  normalizeQueryText,
  pushSearchHistory as pushHistoryEntry,
  removeSearchHistoryEntry
} from '../shared/history'
import { daysUntil, notificationKey, tierForDaysLeft } from '../shared/search'
import { nextRepeatOccurrence, normalizeRepeat } from '../shared/repeat'
import { appendTombstone } from '../shared/sync/tombstones'
import type {
  AppNotification,
  AppSettings,
  AppState,
  Category,
  CategoryDraft,
  ExpiryTier,
  Item,
  ItemDraft,
  LocationType,
  Note,
  NotificationKind,
  SearchHistoryEntry,
  StickyKind,
  StickyNote
} from '../shared/types'

import type { Op, OpErr, OpOk, RepeatRule } from '../shared/types'
export type { Op, OpErr, OpOk }

function ok<T>(value: T): OpOk<T> {
  return { ok: true, value }
}
function err(message: string, code?: string): OpErr {
  return { ok: false, error: message, code: code }
}

/** 已删除通知的标记最多保留多少天（之后清掉，减小数据文件） */
const DELETED_NOTICE_KEEP_DAYS = 45

export function findCategory(state: AppState, id: string): Category | undefined {
  return state.categories.find(function (c) { return c.id === id })
}

export function findItem(state: AppState, id: string): Item | undefined {
  return state.items.find(function (i) { return i.id === id })
}

export function notesOf(state: AppState, itemId: string): Note[] {
  return state.notes
    .filter(function (n) { return n.itemId === itemId })
    .sort(function (a, b) { return a.createdAt < b.createdAt ? -1 : a.createdAt > b.createdAt ? 1 : 0 })
}

export function countItems(state: AppState, categoryId: string): number {
  return state.items.reduce(function (sum, i) { return i.categoryId === categoryId ? sum + 1 : sum }, 0)
}

/* ----------------------------- 分类 ----------------------------- */

export function createCategory(state: AppState, draft: CategoryDraft): Op<Category> {
  const check = validateCategoryDraft(draft, state.categories)
  if (!check.ok) return err(Object.values(check.errors)[0] || '分类信息不完整')
  const maxOrder = state.categories.reduce(function (m, c) { return Math.max(m, c.order) }, 0)
  const category: Category = {
    id: makeId('cat'),
    name: draft.name.trim(),
    icon: draft.icon || '🏷️',
    template: 'custom',
    baseTemplate: draft.baseTemplate,
    order: maxOrder + 1,
    builtin: false,
    customFields: draft.customFields || [],
    createdAt: nowIso()
  }
  state.categories.push(category)
  return ok(category)
}

export function updateCategory(
  state: AppState,
  id: string,
  patch: {
    name?: string
    icon?: string
    customFields?: Category['customFields']
    pinned?: boolean
  }
): Op<Category> {
  const category = findCategory(state, id)
  if (!category) return err('找不到这个分类')
  if (typeof patch.name === 'string') {
    const name = patch.name.trim()
    if (!name) return err('分类名不能为空')
    const dup = state.categories.some(function (c) { return c.id !== id && c.name.trim() === name })
    if (dup) return err('已经有同名分类了')
    category.name = name
  }
  if (typeof patch.icon === 'string' && patch.icon) category.icon = patch.icon
  if (Array.isArray(patch.customFields)) category.customFields = patch.customFields
  if (typeof patch.pinned === 'boolean' && patch.pinned !== Boolean(category.pinned)) {
    if (patch.pinned) {
      // 置顶：记住原位置，再把 order 放到最前面，保证新置顶的总排第一
      category.orderBeforePin = category.order
      const minOrder = state.categories.reduce(function (min, c) {
        return c.id === id ? min : Math.min(min, c.order)
      }, category.order)
      category.order = minOrder - 1
      category.pinned = true
      category.pinnedAt = nowIso()
    } else {
      // 取消置顶：恢复置顶前的顺序；没有记录时排到末尾
      const maxOrder = state.categories.reduce(function (max, c) {
        return c.id === id ? max : Math.max(max, c.order)
      }, 0)
      category.order =
        typeof category.orderBeforePin === 'number' ? category.orderBeforePin : maxOrder + 1
      delete category.orderBeforePin
      category.pinned = false
      delete category.pinnedAt
    }
  }
  return ok(category)
}

/** 删除分类会一并删除里面的条目和备注，内置分类不允许删除 */
export function deleteCategory(state: AppState, id: string): Op<{ removedItems: number }> {
  const category = findCategory(state, id)
  if (!category) return err('找不到这个分类')
  if (category.builtin) return err('内置分类不能删除，可以改名或换图标')
  const itemIds = new Set(
    state.items.filter(function (i) { return i.categoryId === id }).map(function (i) { return i.id })
  )
  state.items = state.items.filter(function (i) { return i.categoryId !== id })
  state.notes = state.notes.filter(function (n) { return !itemIds.has(n.itemId) })
  state.notifications = state.notifications.filter(function (n) { return !itemIds.has(n.itemId) })
  state.categories = state.categories.filter(function (c) { return c.id !== id })
  // 删除墓碑：同步合并时不会把这个分类和它的条目从对方设备再带回来
  appendTombstone(state, 'category', id)
  appendTombstone(state, 'item', Array.from(itemIds))
  renumberCategories(state)
  return ok({ removedItems: itemIds.size })
}

export function reorderCategories(state: AppState, orderedIds: string[]): Op<Category[]> {
  let order = 0
  for (const id of orderedIds) {
    const c = findCategory(state, id)
    if (c) c.order = order++
  }
  renumberCategories(state)
  return ok(state.categories)
}

function renumberCategories(state: AppState): void {
  state.categories.sort(function (a, b) { return a.order - b.order })
  state.categories.forEach(function (c, idx) { c.order = idx })
}

/* ------------------------- 保存过的地点/容器名称 ------------------------- */

/** 名称去重键：忽略大小写与多余空白，保证同名只留一个 */
function nameKey(raw: string): string {
  return (raw || '').replace(/\s+/g, ' ').trim().toLowerCase()
}

function nameBucket(state: AppState, type: LocationType) {
  return type === 'container' ? state.savedNames.container : state.savedNames.place
}

/** 记住用户输入过的地点/容器名称：同名只留一个、最新的排最前、最多保留 SAVED_NAME_LIMIT 个 */
export function rememberSavedName(state: AppState, type: LocationType, rawName: string): void {
  const name = (rawName || '').trim()
  if (!name) return
  const bucket = nameBucket(state, type)
  const key = nameKey(name)
  const rest = bucket.filter(function (s) { return nameKey(s.name) !== key })
  rest.unshift({ name: name, lastUsedAt: nowIso() })
  if (type === 'container') state.savedNames.container = rest.slice(0, SAVED_NAME_LIMIT)
  else state.savedNames.place = rest.slice(0, SAVED_NAME_LIMIT)
}

/** 删除一个保存过的名称（只影响一键填入的建议列表，不动已保存的条目） */
export function removeSavedName(state: AppState, type: LocationType, name: string): Op<{ type: LocationType; name: string }> {
  const bucket = nameBucket(state, type)
  const key = nameKey(name)
  const next = bucket.filter(function (s) { return nameKey(s.name) !== key })
  if (next.length === bucket.length) return err('找不到这个名称')
  if (type === 'container') state.savedNames.container = next
  else state.savedNames.place = next
  return ok({ type: type, name: name })
}

/* ----------------------------- 条目 ----------------------------- */

export function createItem(state: AppState, categoryId: string, draft: ItemDraft): Op<Item> {
  const category = findCategory(state, categoryId)
  if (!category) return err('找不到这个分类')
  const check = validateItemDraft(draft, category.baseTemplate, category.customFields)
  if (!check.ok) return err(Object.values(check.errors)[0] || '信息不完整')
  const at = nowIso()
  const item: Item = {
    id: makeId('item'),
    categoryId,
    name: draft.name.trim(),
    locationType: draft.locationType,
    locationLabel: draft.locationLabel.trim(),
    locationName: draft.locationName.trim(),
    fields: cleanFields(draft.fields),
    createdAt: at,
    updatedAt: at
  }
  state.items.push(item)
  rememberSavedName(state, item.locationType, item.locationLabel)
  return ok(item)
}

export function updateItem(state: AppState, id: string, draft: ItemDraft): Op<Item> {
  const item = findItem(state, id)
  if (!item) return err('找不到这个条目')
  const category = findCategory(state, item.categoryId)
  if (!category) return err('找不到这个分类')
  const check = validateItemDraft(draft, category.baseTemplate, category.customFields)
  if (!check.ok) return err(Object.values(check.errors)[0] || '信息不完整')
  item.name = draft.name.trim()
  item.locationType = draft.locationType
  item.locationLabel = draft.locationLabel.trim()
  item.locationName = draft.locationName.trim()
  item.fields = cleanFields(draft.fields)
  item.updatedAt = nowIso()
  rememberSavedName(state, item.locationType, item.locationLabel)
  // 过期日期变了，旧通知就作废，之后按新日期重新算
  state.notifications = state.notifications.filter(function (n) {
    if (n.itemId !== id) return true
    return n.expiryDate === (item.fields.expiresAt || '')
  })
  return ok(item)
}

export function deleteItem(state: AppState, id: string): Op<{ id: string }> {
  const item = findItem(state, id)
  if (!item) return err('找不到这个条目')
  state.items = state.items.filter(function (i) { return i.id !== id })
  state.notes = state.notes.filter(function (n) { return n.itemId !== id })
  state.notifications = state.notifications.filter(function (n) { return n.itemId !== id })
  appendTombstone(state, 'item', id)
  return ok({ id })
}

function cleanFields(fields: ItemDraft['fields']): ItemDraft['fields'] {
  const out: ItemDraft['fields'] = {}
  if (fields.storedAt) out.storedAt = fields.storedAt
  if (fields.foodType) out.foodType = fields.foodType
  if (typeof fields.opened === 'boolean') out.opened = fields.opened
  if (fields.expiresAt) out.expiresAt = fields.expiresAt
  if (fields.medicineType) out.medicineType = fields.medicineType
  if (fields.effect) out.effect = fields.effect
  if (fields.custom && Object.keys(fields.custom).length) out.custom = fields.custom
  return out
}

/* ----------------------------- 备注 ----------------------------- */

export function addNote(state: AppState, itemId: string, content: string): Op<Note> {
  if (!findItem(state, itemId)) return err('找不到这个条目')
  const text = content.trim()
  if (!text) return err('备注内容不能为空')
  const at = nowIso()
  const note: Note = { id: makeId('note'), itemId, content: text, createdAt: at, updatedAt: at }
  state.notes.push(note)
  return ok(note)
}

export function updateNote(state: AppState, id: string, content: string): Op<Note> {
  const note = state.notes.find(function (n) { return n.id === id })
  if (!note) return err('找不到这条备注')
  const text = content.trim()
  if (!text) return err('备注内容不能为空')
  note.content = text
  note.updatedAt = nowIso()
  return ok(note)
}

export function deleteNote(state: AppState, id: string): Op<{ id: string }> {
  const before = state.notes.length
  state.notes = state.notes.filter(function (n) { return n.id !== id })
  if (state.notes.length === before) return err('找不到这条备注')
  appendTombstone(state, 'note', id)
  return ok({ id })
}

/* ----------------------------- 便利贴 ----------------------------- */

/** 便签标题最大长度 */
export const STICKY_TITLE_LIMIT = 60

export interface CreateStickyInput {
  /** 标题（可选） */
  title?: string
  content: string
  kind: StickyKind
  remindAt?: string | null
  repeat?: RepeatRule | null
  pinned?: boolean
}

export function createSticky(state: AppState, draft: CreateStickyInput): Op<StickyNote> {
  const text = (draft.content || '').trim()
  if (!text) return err('先写点内容吧')
  const title = (draft.title || '').trim().slice(0, STICKY_TITLE_LIMIT)
  const kind: StickyKind = draft.kind === 'reminder' ? 'reminder' : 'note'
  const at = nowIso()
  if (kind === 'note') {
    const pinned = Boolean(draft.pinned)
    const sticky: StickyNote = {
      id: makeId('sticky'),
      title: title || undefined,
      content: text,
      kind: 'note',
      pinned: pinned,
      pinnedAt: pinned ? at : undefined,
      remindAt: null,
      repeat: null,
      status: 'pending',
      createdAt: at,
      updatedAt: at,
      notified: true
    }
    state.stickies.push(sticky)
    return ok(sticky)
  }
  const rule = normalizeRepeat(draft.repeat || null)
  if (draft.repeat && !rule) return err('循环提醒设置不正确')
  let nextRemind: string | null = draft.remindAt || null
  if (rule) {
    const next = nextRepeatOccurrence(rule, new Date())
    if (!next) return err('循环提醒设置不正确')
    nextRemind = next.toISOString()
  }
  if (!nextRemind) return err('请选择提醒时间')
  const sticky: StickyNote = {
    id: makeId('sticky'),
    title: title || undefined,
    content: text,
    kind: 'reminder',
    pinned: false,
    remindAt: nextRemind,
    repeat: rule,
    status: 'pending',
    createdAt: at,
    updatedAt: at,
    notified: false
  }
  state.stickies.push(sticky)
  return ok(sticky)
}

export function updateSticky(
  state: AppState,
  id: string,
  patch: {
    title?: string
    content?: string
    kind?: StickyKind
    pinned?: boolean
    remindAt?: string | null
    repeat?: RepeatRule | null
    status?: StickyNote['status']
  }
): Op<StickyNote> {
  const sticky = state.stickies.find(function (s) { return s.id === id })
  if (!sticky) return err('找不到这张便利贴')
  if (typeof patch.content === 'string') {
    const text = patch.content.trim()
    if (!text) return err('先写点内容吧')
    sticky.content = text
  }
  if (patch.title !== undefined) {
    const title = String(patch.title).trim().slice(0, STICKY_TITLE_LIMIT)
    sticky.title = title || undefined
  }
  if (patch.kind && patch.kind !== sticky.kind) {
    sticky.kind = patch.kind
    if (patch.kind === 'note') {
      sticky.remindAt = null
      sticky.repeat = null
      sticky.notified = true
      sticky.status = 'pending'
    } else {
      sticky.notified = false
    }
  }
  if (patch.kind === 'reminder' || sticky.kind === 'reminder') {
    if (patch.repeat !== undefined) {
      const rule = normalizeRepeat(patch.repeat)
      if (patch.repeat && !rule) return err('循环提醒设置不正确')
      sticky.repeat = rule
      if (rule) {
        const next = nextRepeatOccurrence(rule, new Date())
        if (!next) return err('循环提醒设置不正确')
        sticky.remindAt = next.toISOString()
      } else {
        sticky.remindAt = patch.remindAt === undefined ? sticky.remindAt : patch.remindAt || null
      }
      sticky.notified = false
      sticky.lastNotifiedAt = undefined
    } else if (patch.remindAt !== undefined) {
      sticky.repeat = null
      sticky.remindAt = patch.remindAt || null
      if (sticky.remindAt) {
        sticky.notified = false
        sticky.lastNotifiedAt = undefined
      }
    }
  }
  if (patch.pinned !== undefined) {
    const pinned = Boolean(patch.pinned) && sticky.kind === 'note'
    sticky.pinned = pinned
    sticky.pinnedAt = pinned ? sticky.pinnedAt || nowIso() : undefined
  }
  if (sticky.kind === 'reminder' && !sticky.remindAt && !sticky.repeat) {
    return err('请选择提醒时间')
  }
  if (patch.status) {
    sticky.status = patch.status
    if (patch.status === 'done') {
      sticky.notified = true
    } else if (sticky.repeat) {
      const next = nextRepeatOccurrence(sticky.repeat, new Date())
      if (next) {
        sticky.remindAt = next.toISOString()
        sticky.notified = false
      }
    }
  }
  sticky.updatedAt = nowIso()
  return ok(sticky)
}

export function deleteSticky(state: AppState, id: string): Op<{ id: string }> {
  const before = state.stickies.length
  state.stickies = state.stickies.filter(function (s) { return s.id !== id })
  if (state.stickies.length === before) return err('找不到这张便利贴')
  appendTombstone(state, 'sticky', id)
  return ok({ id })
}

/** 到点该提醒的便利贴（只有提醒便签会参与） */
export function dueStickies(state: AppState, now: Date): StickyNote[] {
  return state.stickies.filter(function (s) {
    if (s.kind !== 'reminder') return false
    if (s.status !== 'pending' || !s.remindAt || s.notified) return false
    const t = new Date(s.remindAt).getTime()
    return !Number.isNaN(t) && t <= now.getTime()
  })
}

export function markStickyNotified(state: AppState, id: string, now: Date): void {
  const sticky = state.stickies.find(function (s) { return s.id === id })
  if (!sticky) return
  sticky.notified = true
  sticky.lastNotifiedAt = now.toISOString()
}

/* ----------------------------- 到期通知 ----------------------------- */

/**
 * 同步到期通知：每条食品/药品按当前剩余天数落在 30/15/7/1 哪个档位，就生成那一档的通知。
 * 唯一键 = itemId + 档位 + 过期日期，用户删过的也留记录，避免又冒出来。
 */
export function syncExpiryNotifications(state: AppState, now: Date, tierSwitches?: AppSettings['expiryTiers']): AppNotification[] {
  const switches = tierSwitches || state.settings.expiryTiers
  const existing = new Set(state.notifications.map(function (n) { return notificationKey(n.itemId, n.tier, n.expiryDate) }))
  const created: AppNotification[] = []
  for (const item of state.items) {
    const category = findCategory(state, item.categoryId)
    if (!category) continue
    if (category.baseTemplate !== 'food' && category.baseTemplate !== 'medicine') continue
    const kind: NotificationKind = category.baseTemplate === 'medicine' ? 'medicine' : 'food'
    const expiresAt = item.fields.expiresAt
    if (!expiresAt) continue
    const days = daysUntil(expiresAt, now)
    if (days === null) continue
    const tier = tierForDaysLeft(days)
    if (!tier) continue
    if (!switches[tier as ExpiryTier]) continue
    const key = notificationKey(item.id, tier, expiresAt)
    if (existing.has(key)) continue
    const notification: AppNotification = {
      id: makeId('notif'),
      type: kind === 'food' ? 'foodExpiring' : 'medicineExpiring',
      kind: kind,
      itemId: item.id,
      tier,
      expiryDate: expiresAt,
      read: false,
      deleted: false,
      createdAt: nowIso()
    }
    state.notifications.push(notification)
    existing.add(key)
    created.push(notification)
  }
  return created
}

/**
 * 清掉无用的通知缓存：指向已删除条目 / 过期日期已改的旧通知，
 * 以及删除标记保留超过 45 天的记录（期间同档位/同过期日不会重复生成）。
 */
export function pruneNotifications(state: AppState, now?: Date): void {
  const itemMap = new Map<string, Item>()
  for (const i of state.items) itemMap.set(i.id, i)
  const deadline = (now ? now.getTime() : Date.now()) - DELETED_NOTICE_KEEP_DAYS * 24 * 60 * 60 * 1000
  state.notifications = state.notifications.filter(function (n) {
    const item = itemMap.get(n.itemId)
    if (!item) return false
    if ((item.fields.expiresAt || '') !== n.expiryDate) return false
    if (n.deleted) {
      const t = new Date(n.createdAt).getTime()
      if (!Number.isNaN(t) && t < deadline) return false
    }
    return true
  })
}

export function markNotificationRead(state: AppState, id: string, read: boolean): Op<AppNotification> {
  const n = state.notifications.find(function (x) { return x.id === id })
  if (!n) return err('找不到这条通知')
  n.read = read
  return ok(n)
}

export function markAllNotificationsRead(state: AppState, kind?: NotificationKind): Op<number> {
  let count = 0
  for (const n of state.notifications) {
    if (kind && n.kind !== kind) continue
    if (!n.read) {
      n.read = true
      count++
    }
  }
  return ok(count)
}

export function deleteNotification(state: AppState, id: string): Op<{ id: string }> {
  const n = state.notifications.find(function (x) { return x.id === id })
  if (!n) return err('找不到这条通知')
  n.deleted = true
  return ok({ id })
}

export function deleteReadNotifications(state: AppState, kind?: NotificationKind): Op<number> {
  let count = 0
  for (const n of state.notifications) {
    if (kind && n.kind !== kind) continue
    if (n.read && !n.deleted) {
      n.deleted = true
      count++
    }
  }
  return ok(count)
}

/** 通知面板要展示的：还没删的，按未读优先 + 时间倒序 */
export function visibleNotifications(state: AppState): AppNotification[] {
  return state.notifications
    .filter(function (n) { return !n.deleted })
    .sort(function (a, b) {
      if (a.read !== b.read) return a.read ? 1 : -1
      return a.createdAt < b.createdAt ? 1 : -1
    })
}

export function unreadCount(state: AppState): number {
  return state.notifications.reduce(function (sum, n) { return !n.read && !n.deleted ? sum + 1 : sum }, 0)
}

/* ---------------------------- 搜索历史 ---------------------------- */

/** 记录一条搜索历史；这一类历史如果在设置里被关掉就不记录 */
export function addSearchHistory(
  state: AppState,
  kind: 'item' | 'sticky',
  rawText: string
): Op<SearchHistoryEntry[]> {
  const text = normalizeQueryText(rawText)
  if (!text) return err('搜索内容为空')
  const enabled = kind === 'item' ? state.settings.itemSearchHistory : state.settings.stickySearchHistory
  if (!enabled) return err('这一类搜索历史已在设置里关闭')
  state.searchHistory[kind] = pushHistoryEntry(state.searchHistory[kind], text)
  return ok(state.searchHistory[kind])
}

/** 删除一条搜索历史（按文本匹配，忽略大小写与空白差异） */
export function removeSearchHistory(
  state: AppState,
  kind: 'item' | 'sticky',
  rawText: string
): Op<{ kind: 'item' | 'sticky'; text: string }> {
  const text = normalizeQueryText(rawText)
  state.searchHistory[kind] = removeSearchHistoryEntry(state.searchHistory[kind], text)
  return ok({ kind: kind, text: text })
}

/* ----------------------------- 设置 ----------------------------- */

export function updateSettings(state: AppState, patch: Partial<AppSettings>): AppSettings {
  state.settings = {
    ...state.settings,
    ...patch,
    expiryTiers: { ...state.settings.expiryTiers, ...(patch.expiryTiers || {}) }
  }
  return state.settings
}
