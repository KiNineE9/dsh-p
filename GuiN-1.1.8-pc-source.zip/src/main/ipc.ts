import { app, dialog, ipcMain, shell } from 'electron'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import * as db from './data'
import { normalizeState } from './store'
import type { SyncConfig } from '../shared/sync/types'
import type { AppSettings, AppState, CategoryDraft, ItemDraft, LocationType, Op } from '../shared/types'
import type { StickyDraft, StickyPatch } from '../shared/api'
import {
  applyLoginItem,
  applyRestoredState,
  applyTheme,
  checkExpiry,
  commit,
  currentState,
  dataInfo,
  handleReminderAction,
  openDataFolder,
  quitApp,
  rt,
  showMainWindow,
  testReminder
} from './core'

function run<T>(fn: (state: AppState) => Op<T>): Op<T> {
  const result = fn(currentState())
  if (result.ok) commit()
  return result
}

let expiryTimer: NodeJS.Timeout | null = null

function scheduleExpiryCheck(): void {
  if (expiryTimer) clearTimeout(expiryTimer)
  expiryTimer = setTimeout(function () {
    expiryTimer = null
    checkExpiry()
  }, 300)
}

export function registerIpc(): void {
  ipcMain.handle('state:get', function () {
    return currentState()
  })
  ipcMain.handle('data:info', function () {
    return dataInfo()
  })

  ipcMain.handle('category:create', function (_event, draft: CategoryDraft) {
    return run(function (state) { return db.createCategory(state, draft) })
  })
  ipcMain.handle('category:update', function (_event, id: string, patch: Parameters<typeof db.updateCategory>[2]) {
    return run(function (state) { return db.updateCategory(state, id, patch) })
  })
  ipcMain.handle('category:delete', function (_event, id: string) {
    return run(function (state) { return db.deleteCategory(state, id) })
  })
  ipcMain.handle('category:reorder', function (_event, ids: string[]) {
    return run(function (state) { return db.reorderCategories(state, ids) })
  })

  ipcMain.handle('history:add', function (_event, kind: 'item' | 'sticky', text: string) {
    return run(function (state) { return db.addSearchHistory(state, kind, text) })
  })
  ipcMain.handle('history:remove', function (_event, kind: 'item' | 'sticky', text: string) {
    return run(function (state) { return db.removeSearchHistory(state, kind, text) })
  })

  ipcMain.handle('item:create', function (_event, categoryId: string, draft: ItemDraft) {
    const result = run(function (state) { return db.createItem(state, categoryId, draft) })
    if (result.ok) scheduleExpiryCheck()
    return result
  })
  ipcMain.handle('item:update', function (_event, id: string, draft: ItemDraft) {
    const result = run(function (state) { return db.updateItem(state, id, draft) })
    if (result.ok) scheduleExpiryCheck()
    return result
  })
  ipcMain.handle('item:delete', function (_event, id: string) {
    const result = run(function (state) { return db.deleteItem(state, id) })
    if (result.ok) scheduleExpiryCheck()
    return result
  })
  ipcMain.handle('saved-name:remove', function (_event, type: LocationType, name: string) {
    return run(function (state) { return db.removeSavedName(state, type, name) })
  })

  ipcMain.handle('note:add', function (_event, itemId: string, content: string) {
    return run(function (state) { return db.addNote(state, itemId, content) })
  })
  ipcMain.handle('note:update', function (_event, id: string, content: string) {
    return run(function (state) { return db.updateNote(state, id, content) })
  })
  ipcMain.handle('note:delete', function (_event, id: string) {
    return run(function (state) { return db.deleteNote(state, id) })
  })

  ipcMain.handle('sticky:create', function (_event, draft: StickyDraft) {
    return run(function (state) { return db.createSticky(state, draft) })
  })
  ipcMain.handle('sticky:update', function (_event, id: string, patch: StickyPatch) {
    return run(function (state) {
      return db.updateSticky(state, id, {
        title: patch.title,
        content: patch.content,
        kind: patch.kind,
        pinned: patch.pinned,
        remindAt: patch.remindAt,
        repeat: patch.repeat,
        status: patch.status
      })
    })
  })
  ipcMain.handle('sticky:delete', function (_event, id: string) {
    return run(function (state) { return db.deleteSticky(state, id) })
  })

  ipcMain.handle('notif:read', function (_event, id: string, read: boolean) {
    return run(function (state) { return db.markNotificationRead(state, id, read) })
  })
  ipcMain.handle('notif:read-all', function (_event, kind?: 'food' | 'medicine') {
    return run(function (state) { return db.markAllNotificationsRead(state, kind) })
  })
  ipcMain.handle('notif:delete', function (_event, id: string) {
    return run(function (state) { return db.deleteNotification(state, id) })
  })
  ipcMain.handle('notif:delete-read', function (_event, kind?: 'food' | 'medicine') {
    return run(function (state) { return db.deleteReadNotifications(state, kind) })
  })

  ipcMain.handle('backup:list', function () {
    return rt.backup ? rt.backup.list() : []
  })
  ipcMain.handle('backup:create', function (_event, name: string, overwriteId?: string | null) {
    if (!rt.backup) return { ok: false as const, error: '数据还没准备好' }
    return rt.backup.create(currentState(), name, overwriteId || null)
  })
  ipcMain.handle('backup:restore', function (_event, id: string) {
    if (!rt.backup) return { ok: false as const, error: '数据还没准备好' }
    const result = rt.backup.restore(id)
    if (!result.ok) return result
    applyRestoredState(result.value)
    return { ok: true as const, value: currentState() }
  })
  ipcMain.handle('backup:delete', function (_event, id: string) {
    if (!rt.backup) return { ok: false as const, error: '数据还没准备好' }
    return rt.backup.delete(id)
  })

  ipcMain.handle('settings:update', function (_event, patch: Partial<AppSettings>) {
    const state = currentState()
    const settings = db.updateSettings(state, patch)
    applyTheme(settings)
    applyLoginItem()
    commit()
    if (patch && patch.expiryTiers) {
      setTimeout(function () { checkExpiry() }, 50)
    }
    return { ok: true as const, value: settings }
  })

  ipcMain.handle('onboarding:finish', function () {
    currentState().onboardingDone = true
    commit()
    return undefined
  })
  ipcMain.handle('onboarding:show', function () {
    currentState().onboardingDone = false
    commit()
    return undefined
  })

  ipcMain.handle('app:open-data-folder', function () {
    openDataFolder()
    return undefined
  })
  ipcMain.handle('app:open-external', function (_event, url: string) {
    if (typeof url === 'string' && /^(https:\/\/|mailto:)/.test(url)) {
      void shell.openExternal(url)
    }
    return undefined
  })
  ipcMain.handle('app:show', function () {
    showMainWindow()
    return undefined
  })
  ipcMain.handle('app:quit', function () {
    quitApp()
    return undefined
  })
  ipcMain.handle('app:test-reminder', function () {
    testReminder()
    return undefined
  })

  ipcMain.handle('reminder:get', function () {
    return rt.activeReminder
  })
  ipcMain.handle('reminder:action', function (_event, action: 'ok' | 'snooze' | 'done') {
    handleReminderAction(action)
    return undefined
  })

  /* ---------------------------- 数据同步相关 ---------------------------- */

  ipcMain.handle('sync:device-info', function () {
    const host = os.hostname() || '我的电脑'
    return {
      defaultName: host.slice(0, 24),
      machineSeed: host + '|' + process.platform + '|' + process.arch,
      platform: process.platform + ' ' + process.arch,
      appVersion: app.getVersion()
    }
  })
  ipcMain.handle('sync:config-get', function () {
    return rt.syncConfig ? rt.syncConfig.load() : null
  })
  ipcMain.handle('sync:config-save', function (_event, config: SyncConfig) {
    if (!rt.syncConfig) return false
    try {
      rt.syncConfig.save(config)
      return true
    } catch (err) {
      console.error('保存同步配置失败', err)
      return false
    }
  })

  /** 应用同步/导入的数据：先自动留一份手动备份，再整体替换（失败可还原这份备份） */
  ipcMain.handle('sync:apply-state', function (_event, raw: unknown) {
    if (!raw || typeof raw !== 'object') return { ok: false as const, error: '同步数据格式不对' }
    const backup = autoBackup('同步前自动备份')
    if (!backup.ok) return backup
    const next = normalizeState(raw)
    applyRestoredState(next)
    return { ok: true as const, value: { backupId: backup.backupId } }
  })

  ipcMain.handle('data:export-json', async function () {
    const d = new Date()
    const pad = function (n: number): string { return n < 10 ? '0' + n : String(n) }
    const name = 'GuiN-数据-' + d.getFullYear() + pad(d.getMonth() + 1) + pad(d.getDate()) + '-' + pad(d.getHours()) + pad(d.getMinutes()) + '.json'
    const target = await dialog.showSaveDialog({
      title: '导出 GuiN 数据',
      defaultPath: path.join(app.getPath('documents'), name),
      filters: [{ name: 'GuiN 数据文件', extensions: ['json'] }]
    })
    if (target.canceled || !target.filePath) {
      return { ok: true as const, value: { path: null, canceled: true } }
    }
    try {
      fs.writeFileSync(target.filePath, JSON.stringify(currentState(), null, 2), 'utf8')
      return { ok: true as const, value: { path: target.filePath, canceled: false } }
    } catch (err) {
      return { ok: false as const, error: '写文件失败：' + String(err) }
    }
  })

  ipcMain.handle('data:import-json', async function () {
    const pick = await dialog.showOpenDialog({
      title: '导入 GuiN 数据（会先自动备份当前数据）',
      filters: [{ name: 'GuiN 数据文件', extensions: ['json'] }],
      properties: ['openFile']
    })
    if (pick.canceled || !pick.filePaths[0]) {
      return { ok: false as const, error: '已取消导入', code: 'canceled' }
    }
    const file = pick.filePaths[0]
    let raw: unknown = null
    try {
      const text = fs.readFileSync(file, 'utf8')
      if (Buffer.byteLength(text, 'utf8') > 64 * 1024 * 1024) {
        return { ok: false as const, error: '文件超过 64MB，无法导入' }
      }
      raw = JSON.parse(text)
    } catch {
      return { ok: false as const, error: '这个文件不是有效的 GuiN 数据（JSON 解析失败）' }
    }
    if (!raw || typeof raw !== 'object') {
      return { ok: false as const, error: '这个文件不是 GuiN 的数据文件' }
    }
    const rec = raw as { categories?: unknown; items?: unknown }
    if (!Array.isArray(rec.categories) || !Array.isArray(rec.items)) {
      return { ok: false as const, error: '这个文件不是 GuiN 的数据文件' }
    }
    const backup = autoBackup('导入前自动备份')
    if (!backup.ok) return backup
    const next = normalizeState(raw)
    applyRestoredState(next)
    return {
      ok: true as const,
      value: { state: next, backupId: backup.backupId, fileName: path.basename(file) }
    }
  })
}

/** 自动备份：手动备份满了就先删最旧的一份，保证同步/导入前一定有备份 */
function autoBackup(name: string): { ok: true; backupId: string } | { ok: false; error: string } {
  if (!rt.backup) return { ok: false, error: '数据还没准备好' }
  let result = rt.backup.create(currentState(), name)
  if (!result.ok && result.code === 'backup-limit') {
    const oldest = rt.backup.list().slice(-1)[0]
    if (oldest) {
      rt.backup.delete(oldest.id)
      result = rt.backup.create(currentState(), name)
    }
  }
  if (!result.ok) return { ok: false, error: result.error }
  return { ok: true, backupId: result.value.id }
}
