import fs from 'node:fs'
import path from 'node:path'
import { createInitialState, DATA_VERSION, DEFAULT_SETTINGS, SAVED_NAME_LIMIT } from '../shared/schema'
import { normalizeTombstones } from '../shared/sync/tombstones'
import { normalizeSearchHistory } from '../shared/history'
import type { AppSettings, AppState, Category, Item, Note, StickyNote } from '../shared/types'

const MAX_BACKUPS = 7

/** 把读到的任意内容规整成合法的 AppState，缺失的补默认值，坏记录丢掉 */
export function normalizeState(raw: unknown): AppState {
  const base = createInitialState()
  if (!raw || typeof raw !== 'object') return base
  const r = raw as Partial<AppState>
  const state: AppState = {
    version: DATA_VERSION,
    categories: Array.isArray(r.categories)
      ? (r.categories as Category[]).filter(isCategoryLike).map(migrateCategory)
      : [],
    items: Array.isArray(r.items) ? (r.items as Item[]).filter(isItemLike).map(migrateItem) : [],
    notes: Array.isArray(r.notes) ? (r.notes as Note[]).filter(isNoteLike) : [],
    stickies: Array.isArray(r.stickies) ? (r.stickies as StickyNote[]).filter(isStickyLike).map(migrateSticky) : [],
    tombstones: normalizeTombstones(r.tombstones),
    notifications: Array.isArray(r.notifications) ? r.notifications : [],
    settings: { ...DEFAULT_SETTINGS, expiryTiers: { ...DEFAULT_SETTINGS.expiryTiers } },
    savedNames: normalizeSavedNames(r.savedNames),
    searchHistory: normalizeSearchHistory(r.searchHistory),
    onboardingDone: Boolean(r.onboardingDone),
    createdAt: typeof r.createdAt === 'string' ? r.createdAt : base.createdAt
  }
  const settings: Partial<AppSettings> = r.settings && typeof r.settings === 'object' ? (r.settings as Partial<AppSettings>) : {}
  state.settings = {
    ...DEFAULT_SETTINGS,
    ...settings,
    expiryTiers: { ...DEFAULT_SETTINGS.expiryTiers, ...(settings.expiryTiers || {}) }
  }
  // 内置分类必须始终存在，即使数据文件里被改坏
  for (const b of base.categories) {
    if (!state.categories.some(function (c) { return c.id === b.id })) state.categories.push(b)
  }
  const catIds = new Set(state.categories.map(function (c) { return c.id }))
  state.items = state.items.filter(function (i) { return catIds.has(i.categoryId) })
  const itemIds = new Set(state.items.map(function (i) { return i.id }))
  state.notes = state.notes.filter(function (n) { return itemIds.has(n.itemId) })
  state.notifications = state.notifications.filter(function (n) { return itemIds.has(n.itemId) })
  // 旧数据里的到期通知没有 kind 字段：按条目所属分类补上，保证食品/药品两栏正确归属
  const catById = new Map<string, Category>()
  for (const c of state.categories) catById.set(c.id, c)
  const itemById = new Map<string, Item>()
  for (const i of state.items) itemById.set(i.id, i)
  state.notifications = state.notifications.map(function (n) {
    const item = itemById.get(n.itemId)
    const cat = item ? catById.get(item.categoryId) : undefined
    const kind: 'food' | 'medicine' = cat && cat.baseTemplate === 'medicine' ? 'medicine' : 'food'
    return {
      ...n,
      kind: kind,
      type: kind === 'food' ? 'foodExpiring' : 'medicineExpiring'
    }
  })
  state.categories.sort(function (a, b) { return a.order - b.order })
  state.settings.expiryTiers = {
    30: Boolean(state.settings.expiryTiers[30]),
    15: Boolean(state.settings.expiryTiers[15]),
    7: Boolean(state.settings.expiryTiers[7]),
    1: Boolean(state.settings.expiryTiers[1])
  }
  return state
}

/** 旧版本条目只有 locationName（同时充当地点名），迁移成 locationLabel=旧值、详细位置为空 */
function migrateItem(item: Item): Item {
  const anyItem = item as unknown as Record<string, unknown>
  const hasLabel = typeof anyItem['locationLabel'] === 'string'
  const oldName = typeof item.locationName === 'string' ? item.locationName : ''
  return {
    ...item,
    locationLabel: hasLabel ? String(anyItem['locationLabel']) : oldName,
    locationName: hasLabel ? oldName : ''
  }
}

/** 旧版本便利贴没有 kind/pinned：有提醒时间的算提醒便签，其余算便签 */
function migrateSticky(sticky: StickyNote): StickyNote {
  const kind = sticky.kind === 'reminder' || sticky.kind === 'note' ? sticky.kind : sticky.remindAt ? 'reminder' : 'note'
  const pinned = kind === 'note' ? Boolean(sticky.pinned) : false
  return {
    ...sticky,
    title: typeof sticky.title === 'string' ? sticky.title.trim().slice(0, 60) || undefined : undefined,
    kind: kind,
    pinned: pinned,
    pinnedAt: pinned ? sticky.pinnedAt || sticky.updatedAt || sticky.createdAt : undefined,
    remindAt: kind === 'reminder' ? sticky.remindAt || null : null,
    repeat: kind === 'reminder' ? sticky.repeat || null : null,
    notified: kind === 'note' ? true : Boolean(sticky.notified)
  }
}

/** 地点与容器各自独立保存；同一分类内按忽略大小写/空格去重，最多 SAVED_NAME_LIMIT 个 */
function normalizeSavedNames(raw: unknown): AppState['savedNames'] {
  const out: AppState['savedNames'] = { place: [], container: [] }
  if (!raw || typeof raw !== 'object') return out
  const r = raw as { place?: unknown; container?: unknown }
  for (const type of ['place', 'container'] as const) {
    const list = Array.isArray(r[type]) ? (r[type] as Array<{ name?: unknown; lastUsedAt?: unknown }>) : []
    const seen = new Set<string>()
    for (const entry of list) {
      const name = typeof entry.name === 'string' ? entry.name.replace(/\s+/g, ' ').trim() : ''
      if (!name) continue
      const key = name.toLowerCase()
      if (seen.has(key)) continue
      seen.add(key)
      out[type].push({
        name: name,
        lastUsedAt: typeof entry.lastUsedAt === 'string' ? entry.lastUsedAt : new Date().toISOString()
      })
      if (out[type].length >= SAVED_NAME_LIMIT) break
    }
  }
  return out
}

/** 旧数据没有置顶字段：补成未置顶；置顶但没有时间的用创建时间兜底 */
function migrateCategory(category: Category): Category {
  const pinned = Boolean(category.pinned)
  return {
    ...category,
    pinned: pinned,
    pinnedAt: pinned ? category.pinnedAt || category.createdAt : undefined
  }
}

function isCategoryLike(c: unknown): boolean {
  if (!c || typeof c !== 'object') return false
  const o = c as Category
  return typeof o.id === 'string' && typeof o.name === 'string' && typeof o.baseTemplate === 'string'
}

function isItemLike(i: unknown): boolean {
  if (!i || typeof i !== 'object') return false
  const o = i as Item
  return (
    typeof o.id === 'string' &&
    typeof o.name === 'string' &&
    typeof o.categoryId === 'string' &&
    (typeof o.locationLabel === 'string' || typeof o.locationName === 'string')
  )
}

function isNoteLike(n: unknown): boolean {
  if (!n || typeof n !== 'object') return false
  const o = n as Note
  return typeof o.id === 'string' && typeof o.itemId === 'string' && typeof o.content === 'string'
}

function isStickyLike(s: unknown): boolean {
  if (!s || typeof s !== 'object') return false
  const o = s as StickyNote
  return typeof o.id === 'string' && typeof o.content === 'string'
}

/**
 * 数据存储：单个 JSON 文件 + 原子写入 + 滚动备份。
 * 写文件先写临时文件再 rename，断电最多丢掉最后一次未完成写入；每次写前留一份备份，保留最近 7 份。
 */
export class Store {
  readonly dir: string
  readonly file: string
  readonly backupDir: string
  state: AppState
  private saveTimer: NodeJS.Timeout | null = null

  constructor(dir: string) {
    this.dir = dir
    this.file = path.join(dir, 'data.json')
    this.backupDir = path.join(dir, 'backups')
    this.state = createInitialState()
  }

  init(): AppState {
    fs.mkdirSync(this.dir, { recursive: true })
    fs.mkdirSync(this.backupDir, { recursive: true })
    let loaded: unknown = null
    let source = 'none'
    const main = this.readJson(this.file)
    if (main.ok) {
      loaded = main.value
      source = 'main'
    } else {
      const backups = this.listBackups()
      for (const b of backups) {
        const r = this.readJson(b)
        if (r.ok) {
          loaded = r.value
          source = 'backup:' + path.basename(b)
          break
        }
      }
    }
    this.state = normalizeState(loaded)
    this.state.version = DATA_VERSION
    this.lastLoadSource = source
    this.writeNow()
    return this.state
  }

  lastLoadSource = 'none'

  private readJson(file: string): { ok: boolean; value?: unknown } {
    try {
      if (!fs.existsSync(file)) return { ok: false }
      const text = fs.readFileSync(file, 'utf8')
      if (!text.trim()) return { ok: false }
      return { ok: true, value: JSON.parse(text) }
    } catch {
      return { ok: false }
    }
  }

  listBackups(): string[] {
    try {
      return fs
        .readdirSync(this.backupDir)
        .filter(function (f) { return f.endsWith('.json') })
        .sort()
        .reverse()
        .map((f) => path.join(this.backupDir, f))
    } catch {
      return []
    }
  }

  /** 立刻落盘（写前备份） */
  writeNow(): void {
    if (this.saveTimer) {
      clearTimeout(this.saveTimer)
      this.saveTimer = null
    }
    this.backupCurrent()
    const serialized = JSON.stringify(this.state, null, 2)
    writeFileAtomic(this.file, serialized)
    this.pruneBackups()
  }

  /** 合并短时间内的多次改动，200ms 内只写一次 */
  save(): void {
    if (this.saveTimer) return
    const self = this
    this.saveTimer = setTimeout(function () {
      self.saveTimer = null
      try {
        self.writeNow()
      } catch (err) {
        console.error('写数据失败', err)
      }
    }, 200)
  }

  /** 退出前调用，确保缓存中的改动落盘 */
  flush(): void {
    if (this.saveTimer) this.writeNow()
  }

  /** 用还原后的数据整体替换当前状态（会立刻落盘） */
  replaceState(next: unknown): AppState {
    this.state = normalizeState(next)
    this.state.version = DATA_VERSION
    this.writeNow()
    return this.state
  }

  private backupCurrent(): void {
    try {
      if (!fs.existsSync(this.file)) return
      const stamp = timestampForFile(new Date())
      const target = path.join(this.backupDir, 'data-' + stamp + '.json')
      fs.copyFileSync(this.file, target)
    } catch (err) {
      console.error('备份失败', err)
    }
  }

  private pruneBackups(): void {
    try {
      const files = fs
        .readdirSync(this.backupDir)
        .filter(function (f) { return f.endsWith('.json') })
        .sort()
        .reverse()
      for (let i = MAX_BACKUPS; i < files.length; i++) {
        fs.unlinkSync(path.join(this.backupDir, files[i]))
      }
    } catch (err) {
      console.error('清理备份失败', err)
    }
  }

  /** 数据目录说明，设置页展示用 */
  describe(): { dir: string; file: string; backups: number } {
    return { dir: this.dir, file: this.file, backups: this.listBackups().length }
  }
}

export function writeFileAtomic(target: string, data: string): void {
  const tmp = target + '.tmp-' + process.pid + '-' + Date.now()
  const fd = fs.openSync(tmp, 'w')
  try {
    fs.writeFileSync(fd, data, 'utf8')
    fs.fsyncSync(fd)
  } finally {
    fs.closeSync(fd)
  }
  fs.renameSync(tmp, target)
}

function timestampForFile(d: Date): string {
  const pad = function (n: number): string { return n < 10 ? '0' + n : String(n) }
  return (
    String(d.getFullYear()) + pad(d.getMonth() + 1) + pad(d.getDate()) + '-' +
    pad(d.getHours()) + pad(d.getMinutes()) + pad(d.getSeconds()) + '-' + String(d.getMilliseconds()).padStart(3, '0')
  )
}
