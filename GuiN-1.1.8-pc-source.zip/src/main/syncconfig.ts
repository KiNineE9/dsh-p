import fs from 'node:fs'
import path from 'node:path'
import { writeFileAtomic } from './store'
import type { SyncConfig } from '../shared/sync/types'

/** 设备同步配置单独存一个文件，不放进 data.json，避免被备份/导入/同步带出 */
export class SyncConfigStore {
  readonly file: string

  constructor(dir: string) {
    this.file = path.join(dir, 'sync-device.json')
  }

  load(): SyncConfig | null {
    try {
      if (!fs.existsSync(this.file)) return null
      const text = fs.readFileSync(this.file, 'utf8')
      if (!text.trim()) return null
      const parsed = JSON.parse(text) as SyncConfig
      if (!parsed || typeof parsed !== 'object') return null
      if (!parsed.identity || typeof parsed.identity.deviceId !== 'string') return null
      if (!Array.isArray(parsed.bindings)) parsed.bindings = []
      return parsed
    } catch {
      return null
    }
  }

  save(config: SyncConfig): void {
    const dir = path.dirname(this.file)
    fs.mkdirSync(dir, { recursive: true })
    writeFileAtomic(this.file, JSON.stringify(config, null, 2))
  }
}
