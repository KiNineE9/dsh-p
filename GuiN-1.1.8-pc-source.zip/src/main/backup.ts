import fs from 'node:fs'
import path from 'node:path'
import { makeId, nowIso } from '../shared/schema'
import { normalizeState, writeFileAtomic } from './store'
import type { AppState, Op } from '../shared/types'
import type { BackupEntry } from '../shared/api'

/** 手动备份最多保留几份 */
export const MAX_MANUAL_BACKUPS = 5

interface BackupFile {
  meta: BackupEntry
  state: AppState
}

function ok<T>(value: T): { ok: true; value: T } {
  return { ok: true, value }
}

function pad2(n: number): string {
  return n < 10 ? '0' + n : String(n)
}

/** 默认备份名：当前日期时间 */
export function defaultBackupName(d: Date): string {
  return (
    d.getFullYear() + '-' + pad2(d.getMonth() + 1) + '-' + pad2(d.getDate()) + ' ' +
    pad2(d.getHours()) + ':' + pad2(d.getMinutes())
  )
}

function safeId(id: string): boolean {
  return /^bak-[a-z0-9-]+$/.test(String(id || ''))
}

/**
 * 手动备份：每份一个 JSON（meta + 完整 state），最多 5 份。
 * 与自动滚动备份（backups/，7 份）分开存放，互不影响。
 */
export class BackupManager {
  readonly dir: string
  readonly appVersion: string

  constructor(dir: string, appVersion: string) {
    this.dir = dir
    this.appVersion = appVersion
  }

  ensureDir(): void {
    fs.mkdirSync(this.dir, { recursive: true })
  }

  list(): BackupEntry[] {
    this.ensureDir()
    const out: BackupEntry[] = []
    let files: string[] = []
    try {
      files = fs.readdirSync(this.dir).filter(function (f) { return f.endsWith('.json') })
    } catch {
      return out
    }
    for (const file of files) {
      const full = path.join(this.dir, file)
      try {
        const parsed = JSON.parse(fs.readFileSync(full, 'utf8')) as Partial<BackupFile>
        const meta = parsed && parsed.meta ? parsed.meta : null
        if (!meta || typeof meta.id !== 'string' || !safeId(meta.id)) continue
        const stat = fs.statSync(full)
        out.push({
          id: meta.id,
          name: typeof meta.name === 'string' && meta.name ? meta.name : file,
          createdAt: typeof meta.createdAt === 'string' ? meta.createdAt : stat.mtime.toISOString(),
          size: typeof meta.size === 'number' && meta.size > 0 ? meta.size : stat.size,
          items: typeof meta.items === 'number' ? meta.items : 0,
          notes: typeof meta.notes === 'number' ? meta.notes : 0,
          stickies: typeof meta.stickies === 'number' ? meta.stickies : 0
        })
      } catch {
        // 坏文件跳过，不影响其它备份
      }
    }
    out.sort(function (a, b) { return a.createdAt < b.createdAt ? 1 : a.createdAt > b.createdAt ? -1 : 0 })
    return out
  }

  count(): number {
    return this.list().length
  }

  create(state: AppState, rawName: string, overwriteId?: string | null): Op<BackupEntry> {
    this.ensureDir()
    const entries = this.list()
    if (overwriteId) {
      if (!safeId(overwriteId)) return { ok: false, error: '要覆盖的备份不存在' }
      const target = entries.find(function (e) { return e.id === overwriteId })
      if (!target) return { ok: false, error: '要覆盖的备份不存在' }
      this.delete(overwriteId)
    } else if (entries.length >= MAX_MANUAL_BACKUPS) {
      return {
        ok: false,
        error: '手动备份最多保存 ' + MAX_MANUAL_BACKUPS + ' 个，请选择要覆盖的备份',
        code: 'backup-limit'
      }
    }
    let name = String(rawName || '').trim()
    if (!name) name = defaultBackupName(new Date())
    if (name.length > 40) name = name.slice(0, 40)
    const meta: BackupEntry = {
      id: makeId('bak'),
      name: name,
      createdAt: nowIso(),
      size: 0,
      items: state.items.length,
      notes: state.notes.length,
      stickies: state.stickies.length
    }
    const payload: BackupFile = { meta: meta, state: state }
    const text = JSON.stringify(payload)
    meta.size = Buffer.byteLength(text, 'utf8')
    const target = path.join(this.dir, meta.id + '.json')
    try {
      writeFileAtomic(target, JSON.stringify(payload))
    } catch (err) {
      return { ok: false, error: '写备份文件失败：' + String(err) }
    }
    return ok(meta)
  }

  restore(id: string): Op<AppState> {
    if (!safeId(id)) return { ok: false, error: '备份文件不存在' }
    const full = path.join(this.dir, id + '.json')
    try {
      if (!fs.existsSync(full)) return { ok: false, error: '备份文件不存在' }
      const parsed = JSON.parse(fs.readFileSync(full, 'utf8')) as Partial<BackupFile>
      if (!parsed || typeof parsed !== 'object' || !parsed.state || typeof parsed.state !== 'object') {
        return { ok: false, error: '备份文件已损坏，无法还原' }
      }
      return ok(normalizeState(parsed.state as unknown))
    } catch {
      return { ok: false, error: '备份文件已损坏，无法还原' }
    }
  }

  delete(id: string): Op<{ id: string }> {
    if (!safeId(id)) return { ok: false, error: '备份文件不存在' }
    const full = path.join(this.dir, id + '.json')
    try {
      if (!fs.existsSync(full)) return { ok: false, error: '备份文件不存在' }
      fs.unlinkSync(full)
      return ok({ id: id })
    } catch (err) {
      return { ok: false, error: '删除备份失败：' + String(err) }
    }
  }
}
