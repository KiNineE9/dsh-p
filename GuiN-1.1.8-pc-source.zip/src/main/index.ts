import { app } from 'electron'
import {
  checkExpiry,
  checkStickies,
  createMainWindow,
  createTray,
  initRuntime,
  rt,
  showMainWindow,
  startTimers
} from './core'
import { registerIpc } from './ipc'

const gotLock = app.requestSingleInstanceLock()

if (!gotLock) {
  app.quit()
} else {
  app.on('second-instance', function () {
    showMainWindow()
  })

  app.whenReady().then(function () {
    const loginInfo = app.getLoginItemSettings()
    rt.hiddenStart =
      process.argv.indexOf('--hidden') !== -1 || Boolean(loginInfo.wasOpenedAtLogin)
    initRuntime()
    registerIpc()
    createMainWindow()
    createTray()
    checkStickies()
    checkExpiry()
    startTimers()
  }).catch(function (err) {
    console.error('启动失败', err)
  })

  app.on('activate', function () {
    showMainWindow()
  })

  app.on('window-all-closed', function () {
    if (rt.quitRequested) app.quit()
  })

  app.on('before-quit', function () {
    rt.quitRequested = true
    if (rt.store) rt.store.flush()
  })
}
