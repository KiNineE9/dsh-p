import { app, BrowserWindow, Menu, Tray, nativeImage, nativeTheme, powerMonitor, session, shell } from 'electron'
import fs from 'node:fs'
import path from 'node:path'
import * as db from './data'
import { Store } from './store'
import { BackupManager } from './backup'
import { SyncConfigStore } from './syncconfig'
import { nowIso } from '../shared/schema'
import type { AppSettings, AppState, ReminderPayload } from '../shared/types'
import { describeRepeat, nextRepeatOccurrence } from '../shared/repeat'
import type { DataInfo } from '../shared/api'

const EXPIRY_INTERVAL_MS = 60 * 60 * 1000
const FLASH_INTERVAL_MS = 450
/** 没有待提醒便签时的兜底检查间隔（30 分钟），空闲时几乎不占 CPU */
const IDLE_REMIND_CHECK_MS = 30 * 60 * 1000

export interface Runtime {
  store: Store | null
  backup: BackupManager | null
  mainWindow: BrowserWindow | null
  reminderWindow: BrowserWindow | null
  tray: Tray | null
  trayNormal: Electron.NativeImage | null
  trayAlert: Electron.NativeImage | null
  trayBell: Electron.NativeImage | null
  trayFlashTimer: NodeJS.Timeout | null
  trayFlashOnAlert: boolean
  trayFlashUntil: number
  remindTimer: NodeJS.Timeout | null
  expiryTimer: NodeJS.Timeout | null
  quitting: boolean
  quitRequested: boolean
  hiddenStart: boolean
  activeReminder: ReminderPayload | null
  reminderQueue: ReminderPayload[]
  syncConfig: SyncConfigStore | null
}

export const rt: Runtime = {
  store: null,
  backup: null,
  mainWindow: null,
  reminderWindow: null,
  tray: null,
  trayNormal: null,
  trayAlert: null,
  trayBell: null,
  trayFlashTimer: null,
  trayFlashOnAlert: false,
  trayFlashUntil: 0,
  remindTimer: null,
  expiryTimer: null,
  quitting: false,
  quitRequested: false,
  hiddenStart: false,
  activeReminder: null,
  reminderQueue: [],
  syncConfig: null
}

export function currentState(): AppState {
  if (!rt.store) throw new Error('数据还没准备好')
  return rt.store.state
}

export function commit(): void {
  if (rt.store) rt.store.save()
  broadcast()
  updateTrayIcon()
  scheduleRemindCheck()
}

export function broadcast(): void {
  const win = rt.mainWindow
  if (!win || win.isDestroyed()) return
  win.webContents.send('state:changed', currentState())
}

export function dataInfo(): DataInfo {
  const store = rt.store
  const info = store ? store.describe() : { dir: '', file: '', backups: 0 }
  const manualDir = store ? path.join(store.dir, 'backups-manual') : ''
  const manualCount = rt.backup ? rt.backup.count() : 0
  let savedAt: string | null = null
  try {
    if (info.file) savedAt = fs.statSync(info.file).mtime.toISOString()
  } catch {
    savedAt = null
  }
  return {
    dir: info.dir,
    file: info.file,
    backupDir: path.join(info.dir, 'backups'),
    backups: info.backups,
    manualBackupDir: manualDir,
    manualBackups: manualCount,
    lastSavedAt: savedAt,
    appVersion: app.getVersion()
  }
}

function assetPath(name: string): string {
  if (app.isPackaged) return path.join(process.resourcesPath, 'resources', name)
  return path.join(app.getAppPath(), 'resources', name)
}

function preloadPath(): string {
  return path.join(app.getAppPath(), 'out', 'preload', 'index.js')
}

function loadPage(win: BrowserWindow, page: string): void {
  const devUrl = process.env['ELECTRON_RENDERER_URL']
  if (!app.isPackaged && devUrl) {
    win.loadURL(devUrl + '/' + page).catch(function (e) { console.error('加载页面失败', e) })
  } else {
    win.loadFile(path.join(app.getAppPath(), 'out', 'renderer', page)).catch(function (e) {
      console.error('加载页面失败', e)
    })
  }
}

export function createMainWindow(): BrowserWindow {
  if (rt.mainWindow && !rt.mainWindow.isDestroyed()) return rt.mainWindow
  const win = new BrowserWindow({
    width: 1180,
    height: 820,
    minWidth: 940,
    minHeight: 620,
    show: false,
    title: 'GuiN',
    autoHideMenuBar: true,
    backgroundColor: '#f6f5f2',
    webPreferences: {
      preload: preloadPath(),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false,
      spellcheck: false,
      backgroundThrottling: true
    }
  })
  rt.mainWindow = win
  win.once('ready-to-show', function () {
    if (!rt.hiddenStart) win.show()
  })
  win.on('close', function (event) {
    if (!rt.quitRequested && currentState().settings.closeToTray) {
      event.preventDefault()
      win.hide()
    }
  })
  win.on('closed', function () {
    rt.mainWindow = null
  })
  win.on('focus', function () {
    stopTrayFlash()
  })
  loadPage(win, 'index.html')
  return win
}

export function showMainWindow(): void {
  const win = rt.mainWindow && !rt.mainWindow.isDestroyed() ? rt.mainWindow : createMainWindow()
  if (win.isMinimized()) win.restore()
  win.show()
  win.focus()
  stopTrayFlash()
}

/** 退出：先隐藏窗口和托盘，静默清掉 Chromium 缓存，再真正退出（用户看来就是点了退出） */
export function quitApp(): void {
  if (rt.quitting) return
  rt.quitting = true
  rt.quitRequested = true
  try {
    if (rt.tray) {
      rt.tray.destroy()
      rt.tray = null
    }
  } catch {
    // 托盘已不可用时忽略
  }
  if (rt.mainWindow && !rt.mainWindow.isDestroyed()) rt.mainWindow.hide()
  if (rt.reminderWindow && !rt.reminderWindow.isDestroyed()) rt.reminderWindow.hide()
  if (rt.store) rt.store.flush()
  const finish = function (): void {
    app.quit()
  }
  const timer = setTimeout(finish, 2000)
  void cleanupCaches()
    .catch(function (e) { console.error('清理缓存失败', e) })
    .finally(function () {
      clearTimeout(timer)
      finish()
    })
}

/** 清理 Chromium 缓存，避免数据目录越来越大；不触碰 data.json / backups 等核心数据 */
async function cleanupCaches(): Promise<void> {
  try {
    await session.defaultSession.clearCache()
  } catch (err) {
    console.error('清理缓存失败', err)
  }
  try {
    await session.defaultSession.clearStorageData({
      storages: ['filesystem', 'shadercache', 'cachestorage', 'serviceworkers', 'indexdb', 'localstorage']
    })
  } catch (err) {
    console.error('清理存储缓存失败', err)
  }
}

export function playSound(): void {
  const win = rt.mainWindow
  if (!win || win.isDestroyed()) return
  win.webContents.send('app:play-sound')
}

export function showReminder(payload: ReminderPayload): void {
  rt.activeReminder = payload
  const existing = rt.reminderWindow
  if (existing && !existing.isDestroyed()) {
    existing.show()
    existing.focus()
    return
  }
  const win = new BrowserWindow({
    width: 460,
    height: 380,
    show: false,
    resizable: false,
    minimizable: false,
    maximizable: false,
    fullscreenable: false,
    title: '提醒',
    alwaysOnTop: true,
    backgroundColor: '#f6f5f2',
    webPreferences: {
      preload: preloadPath(),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false
    }
  })
  rt.reminderWindow = win
  win.once('ready-to-show', function () { win.show() })
  win.on('closed', function () {
    rt.reminderWindow = null
    rt.activeReminder = null
    const next = rt.reminderQueue.shift()
    if (next) {
      showReminder(next)
    } else {
      stopTrayFlash()
    }
  })
  loadPage(win, 'reminder.html')
}

export function closeReminderWindow(): void {
  const win = rt.reminderWindow
  rt.reminderWindow = null
  rt.activeReminder = null
  if (win && !win.isDestroyed()) win.close()
}

/** 托盘基础图标：有未读到期提醒时用黄色铃铛，否则普通图标 */
function baseTrayImage(): Electron.NativeImage | null {
  const unread = rt.store ? db.unreadCount(currentState()) : 0
  if (unread > 0 && rt.trayBell && !rt.trayBell.isEmpty()) return rt.trayBell
  return rt.trayNormal
}

export function updateTrayIcon(): void {
  if (!rt.tray) return
  const unread = rt.store ? db.unreadCount(currentState()) : 0
  try {
    if (!rt.trayFlashTimer) {
      const img = baseTrayImage()
      if (img && !img.isEmpty()) rt.tray.setImage(img)
    }
    rt.tray.setToolTip('GuiN' + (unread > 0 ? ' · ' + unread + ' 条未读到期提醒' : ''))
  } catch (err) {
    console.error('更新托盘图标失败', err)
  }
}

export function startTrayFlash(durationMs: number): void {
  const until = Date.now() + durationMs
  if (rt.trayFlashTimer) {
    if (until <= rt.trayFlashUntil) return
    clearInterval(rt.trayFlashTimer)
    rt.trayFlashTimer = null
  }
  rt.trayFlashUntil = until
  if (!rt.tray || !rt.trayAlert) return
  rt.trayFlashTimer = setInterval(function () {
    if (!rt.tray) return
    if (Date.now() > rt.trayFlashUntil) {
      stopTrayFlash()
      return
    }
    rt.trayFlashOnAlert = !rt.trayFlashOnAlert
    const img = rt.trayFlashOnAlert ? rt.trayAlert : baseTrayImage()
    if (img && !img.isEmpty()) rt.tray.setImage(img)
  }, FLASH_INTERVAL_MS)
}

export function stopTrayFlash(): void {
  if (rt.trayFlashTimer) {
    clearInterval(rt.trayFlashTimer)
    rt.trayFlashTimer = null
  }
  rt.trayFlashUntil = 0
  rt.trayFlashOnAlert = false
  if (rt.tray) {
    const img = baseTrayImage()
    if (img && !img.isEmpty()) rt.tray.setImage(img)
    updateTrayIcon()
  }
}

function sendOpenDialog(kind: string): void {
  showMainWindow()
  const win = rt.mainWindow
  if (!win || win.isDestroyed()) return
  win.webContents.send('app:open-dialog', kind)
}

function sendOpenSettings(): void {
  showMainWindow()
  const win = rt.mainWindow
  if (!win || win.isDestroyed()) return
  win.webContents.send('app:open-settings')
}

export function createTray(): void {
  rt.trayNormal = nativeImage.createFromPath(assetPath('tray.png'))
  rt.trayAlert = nativeImage.createFromPath(assetPath('tray-alert.png'))
  rt.trayBell = nativeImage.createFromPath(assetPath('tray-bell.png'))
  const icon = baseTrayImage()
  const tray = new Tray(icon && !icon.isEmpty() ? icon : nativeImage.createEmpty())
  rt.tray = tray
  tray.setToolTip('GuiN')
  tray.setContextMenu(
    Menu.buildFromTemplate([
      { label: '打开主界面', click: function () { showMainWindow() } },
      { label: '新建条目', click: function () { sendOpenDialog('new-item') } },
      { label: '新建便签', click: function () { sendOpenDialog('new-sticky-note') } },
      { label: '新建提醒便签', click: function () { sendOpenDialog('new-sticky-reminder') } },
      { label: '设置', click: function () { sendOpenSettings() } },
      { type: 'separator' },
      { label: '退出 GuiN', click: function () { quitApp() } }
    ])
  )
  tray.on('click', function () { showMainWindow() })
  tray.on('double-click', function () { showMainWindow() })
  updateTrayIcon()
}

export function applyTheme(settings?: AppSettings): void {
  const s = settings || currentState().settings
  nativeTheme.themeSource = s.theme
}

export function applyLoginItem(): void {
  if (process.platform !== 'win32') return
  const settings = currentState().settings
  const exePath = process.env['PORTABLE_EXECUTABLE_FILE'] || app.getPath('exe')
  const wanted = settings.autoLaunch
  try {
    const current = app.getLoginItemSettings({ path: exePath })
    if (current.openAtLogin === wanted && current.openAsHidden === wanted) return
    app.setLoginItemSettings({
      openAtLogin: wanted,
      openAsHidden: wanted,
      path: exePath,
      args: wanted ? ['--hidden'] : []
    })
  } catch (err) {
    console.error('设置开机自启失败', err)
  }
}

export function checkStickies(): void {
  if (!rt.store) return
  const state = currentState()
  const now = Date.now()
  const due = db.dueStickies(state, new Date(now))
  if (!due.length) return
  const at = nowIso()
  for (const s of due) {
    s.notified = true
    s.lastNotifiedAt = at
    s.updatedAt = at
  }
  commit()
  startTrayFlash(90 * 1000)
  if (state.settings.reminderSound) playSound()
  if (!state.settings.reminderPopup) {
    // 不弹窗时也要把循环提醒顺延到下一次，否则会一直停在「已提醒」状态
    let advanced = false
    for (const s of due) {
      if (!s.repeat) continue
      const next = nextRepeatOccurrence(s.repeat, new Date())
      if (next) {
        s.remindAt = next.toISOString()
        s.notified = false
        s.updatedAt = nowIso()
        advanced = true
      }
    }
    if (advanced) commit()
    return
  }
  for (const s of due) {
    const payload: ReminderPayload = {
      id: s.id,
      title: s.title,
      content: s.content,
      remindAt: s.remindAt,
      repeat: s.repeat || null,
      repeatText: s.repeat ? describeRepeat(s.repeat) : null
    }
    if (rt.activeReminder) rt.reminderQueue.push(payload)
    else showReminder(payload)
  }
}

/** 按最近一条待提醒便签动态安排下一次检查，空闲时不会每 20 秒醒一次 */
export function scheduleRemindCheck(): void {
  if (rt.quitting) return
  if (rt.remindTimer) {
    clearTimeout(rt.remindTimer)
    rt.remindTimer = null
  }
  const state = rt.store ? rt.store.state : null
  let delay = IDLE_REMIND_CHECK_MS
  if (state) {
    const now = Date.now()
    let next = 0
    let overdue = false
    for (const s of state.stickies) {
      if (s.kind !== 'reminder' || s.status !== 'pending' || s.notified || !s.remindAt) continue
      const t = new Date(s.remindAt).getTime()
      if (Number.isNaN(t)) continue
      if (t <= now) {
        overdue = true
        continue
      }
      if (next === 0 || t < next) next = t
    }
    if (overdue) {
      // 已经过点还没提醒（例如刚手动建了一条过去时间的提醒）：尽快检查一次
      delay = 400
    } else if (next > 0) {
      const wait = next - now + 200
      delay = Math.max(400, Math.min(wait, IDLE_REMIND_CHECK_MS))
    }
  }
  rt.remindTimer = setTimeout(function () {
    rt.remindTimer = null
    checkStickies()
    scheduleRemindCheck()
  }, delay)
}

export function checkExpiry(): void {
  if (!rt.store) return
  const state = currentState()
  db.pruneNotifications(state, new Date())
  const created = db.syncExpiryNotifications(state, new Date())
  if (created.length > 0) {
    commit()
    startTrayFlash(15 * 1000)
  }
}

export function handleReminderAction(action: 'ok' | 'snooze' | 'done'): void {
  const payload = rt.activeReminder
  if (!payload) {
    closeReminderWindow()
    return
  }
  const state = currentState()
  const sticky = state.stickies.find(function (s) { return s.id === payload.id })
  const at = nowIso()
  if (sticky) {
    if (action === 'done') {
      sticky.status = 'done'
      sticky.updatedAt = at
    } else if (action === 'snooze') {
      sticky.remindAt = new Date(Date.now() + 10 * 60 * 1000).toISOString()
      sticky.status = 'pending'
      sticky.notified = false
      sticky.updatedAt = at
    } else {
      if (sticky.repeat) {
        const next = nextRepeatOccurrence(sticky.repeat, new Date())
        if (next) sticky.remindAt = next.toISOString()
        sticky.status = 'pending'
        sticky.notified = false
      } else {
        sticky.notified = true
      }
      sticky.updatedAt = at
    }
    commit()
  }
  closeReminderWindow()
}

export function testReminder(): void {
  const state = currentState()
  const candidates = state.stickies.filter(function (s) { return s.kind === 'reminder' && s.status === 'pending' })
  const first = candidates.length ? candidates[0] : null
  const payload: ReminderPayload = first
    ? {
        id: first.id,
        title: first.title,
        content: first.content,
        remindAt: first.remindAt,
        repeat: first.repeat || null,
        repeatText: first.repeat ? describeRepeat(first.repeat) : null
      }
    : {
        id: 'demo',
        content: '这是一次测试提醒：到点啦，别忘了这件事。',
        remindAt: nowIso(),
        repeat: null,
        repeatText: null
      }
  startTrayFlash(60 * 1000)
  if (currentState().settings.reminderSound) playSound()
  if (currentState().settings.reminderPopup) showReminder(payload)
}

export function startTimers(): void {
  scheduleRemindCheck()
  if (rt.expiryTimer) clearInterval(rt.expiryTimer)
  rt.expiryTimer = setInterval(function () { checkExpiry() }, EXPIRY_INTERVAL_MS)
  powerMonitor.on('resume', function () {
    checkStickies()
    scheduleRemindCheck()
    checkExpiry()
  })
  powerMonitor.on('unlock-screen', function () {
    checkStickies()
    scheduleRemindCheck()
  })
}

/** 还原备份后的收尾：换数据、重设主题/自启、广播、重置定时器 */
export function applyRestoredState(state: AppState): void {
  if (!rt.store) return
  rt.reminderQueue = []
  closeReminderWindow()
  rt.store.replaceState(state)
  applyTheme()
  applyLoginItem()
  broadcast()
  updateTrayIcon()
  scheduleRemindCheck()
  setTimeout(function () { checkExpiry() }, 300)
}

export function initRuntime(): void {
  const dir = app.getPath('userData')
  const store = new Store(dir)
  store.init()
  rt.store = store
  rt.backup = new BackupManager(path.join(dir, 'backups-manual'), app.getVersion())
  rt.syncConfig = new SyncConfigStore(dir)
  applyTheme()
  applyLoginItem()
}

export function openDataFolder(): void {
  if (!rt.store) return
  shell.openPath(rt.store.dir).catch(function (e) { console.error('打开数据文件夹失败', e) })
}
