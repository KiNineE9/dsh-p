import { useState } from 'react'

interface OnboardingStep {
  emoji: string
  title: string
  text: string
}

const STEPS: OnboardingStep[] = [
  {
    emoji: '📦',
    title: '把东西记下来',
    text: '在分类里点「新增条目」，写清东西叫啥、放在哪儿。以后就不怕忘了。'
  },
  {
    emoji: '🔍',
    title: '找东西就搜一下',
    text: '顶部搜索框输入名字或位置，比如搜「冰箱」，就能看到冰箱里的所有东西。'
  },
  {
    emoji: '🔔',
    title: '到期和提醒别忘',
    text: '食品和药品可以填过期时间，会提前 30/15/7/1 天提醒你；便利贴也能定时提醒。'
  }
]

export interface OnboardingProps {
  onFinish: () => void
}

export default function Onboarding(props: OnboardingProps) {
  const [index, setIndex] = useState(0)
  const step = STEPS[index]
  const last = index >= STEPS.length - 1

  return (
    <div className="onboarding-mask" data-testid="onboarding">
      <div className="onboarding-card">
        <div className="onboarding-emoji">{step.emoji}</div>
        <h2 className="onboarding-title">{step.title}</h2>
        <p className="onboarding-text">{step.text}</p>
        <div className="onboarding-dots">
          {STEPS.map(function (item, dotIndex) {
            return <span className={dotIndex === index ? 'dot active' : 'dot'} key={item.title} />
          })}
        </div>
        <div className="onboarding-actions">
          <button type="button" className="btn ghost" data-testid="onboarding-skip" onClick={props.onFinish}>
            跳过
          </button>
          <button
            type="button"
            className="btn primary"
            data-testid="onboarding-next"
            onClick={function () {
              if (last) props.onFinish()
              else setIndex(index + 1)
            }}
          >
            {last ? '开始使用' : '下一步'}
          </button>
        </div>
      </div>
    </div>
  )
}
