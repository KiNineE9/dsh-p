import type { StickyNote } from '../../shared/types'
import { describeRepeat } from '../../shared/repeat'
import { formatDateTime } from '../../shared/search'
import Modal from './Modal'

export interface StickyDetailModalProps {
  sticky: StickyNote
  onClose: () => void
  onEdit: () => void
}

/** 点开便签后查看完整内容（卡片上文字会省略，这里不省略） */
export default function StickyDetailModal(props: StickyDetailModalProps) {
  const sticky = props.sticky
  const isReminder = sticky.kind === 'reminder'
  const footer = (
    <div className="foot-row">
      <button type="button" className="btn ghost" data-testid="modal-cancel" onClick={props.onClose}>
        关闭
      </button>
      <button type="button" className="btn primary" data-testid="sticky-detail-edit" onClick={props.onEdit}>
        编辑
      </button>
    </div>
  )
  return (
    <Modal title={sticky.title || (isReminder ? '提醒便签' : '便签')} onClose={props.onClose} footer={footer} width={460}>
      <div className="sticky-detail" data-testid="sticky-detail">
        {sticky.title ? (
          <h3 className="sticky-detail-title" data-testid="sticky-detail-title">
            {sticky.title}
          </h3>
        ) : null}
        <p className="sticky-detail-content" data-testid="sticky-detail-content">
          {sticky.content}
        </p>
        <div className="sticky-detail-meta">
          <span className="sticky-detail-tag" data-testid="sticky-detail-kind">
            {isReminder ? '提醒便签' : '便签'}
          </span>
          {sticky.pinned ? <span className="sticky-detail-tag">置顶</span> : null}
          {sticky.status === 'done' ? <span className="sticky-detail-tag">已完成</span> : null}
        </div>
        {sticky.repeat ? (
          <p className="sticky-detail-time" data-testid="sticky-detail-repeat">
            🔁 {describeRepeat(sticky.repeat)}
          </p>
        ) : null}
        {sticky.remindAt ? <p className="sticky-detail-time">{formatDateTime(sticky.remindAt)}</p> : null}
      </div>
    </Modal>
  )
}
