import { SyncRuntime } from '../../shared/sync/runtime'
import type { IncomingSyncRequest, SyncConfig, SyncProgress } from '../../shared/sync/types'
import type { AppState } from '../../shared/types'

type ConfigListener = (config: SyncConfig) => void
type ProgressListener = (progress: SyncProgress) => void
type IncomingHandler = (request: IncomingSyncRequest, decide: (accepted: boolean) => void) => void

let runtime: SyncRuntime | null = null
let currentState: AppState | null = null
let incomingHandler: IncomingHandler | null = null
const configListeners = new Set<ConfigListener>()
const progressListeners = new Set<ProgressListener>()

/** 让同步运行时始终能拿到最新的本机状态 */
export function setCurrentSyncState(state: AppState): void {
  currentState = state
}

export function onSyncConfig(cb: ConfigListener): () => void {
  configListeners.add(cb)
  return function () {
    configListeners.delete(cb)
  }
}

export function onSyncProgress(cb: ProgressListener): () => void {
  progressListeners.add(cb)
  return function () {
    progressListeners.delete(cb)
  }
}

export function setIncomingSyncHandler(handler: IncomingHandler | null): void {
  incomingHandler = handler
}

export function getSyncRuntime(): SyncRuntime | null {
  return runtime
}

/** 应用启动时调用一次：读/建设备身份，开始常驻在线等待已绑定设备 */
export async function bootSyncRuntime(): Promise<SyncConfig | null> {
  if (runtime) return runtime.getConfig()
  const info = await window.guina.getSyncDeviceInfo()
  const inst = new SyncRuntime({
    storage: {
      loadConfig: function () { return window.guina.getSyncConfig() },
      saveConfig: async function (config) {
        const ok = await window.guina.saveSyncConfig(config)
        if (!ok) throw new Error('保存同步配置失败，请检查磁盘权限')
      }
    },
    effects: {
      getState: function () {
        if (!currentState) throw new Error('数据还没准备好')
        return currentState
      },
      applyState: async function (next) {
        const op = await window.guina.syncApplyState(next)
        if (!op.ok) throw new Error(op.error)
        const backupId = op.value.backupId
        currentState = await window.guina.getState()
        return async function () {
          const res = await window.guina.restoreBackup(backupId)
          if (!res.ok) throw new Error(res.error)
          currentState = await window.guina.getState()
        }
      }
    },
    device: {
      kind: 'desktop',
      platform: info.platform,
      appVersion: info.appVersion,
      defaultName: info.defaultName,
      machineSeed: info.machineSeed
    },
    onConfig: function (config) {
      for (const cb of configListeners) cb(config)
    },
    onIncoming: function (request, decide) {
      if (incomingHandler) incomingHandler(request, decide)
      else decide(false)
    },
    onProgress: function (progress) {
      for (const cb of progressListeners) cb(progress)
    }
  })
  runtime = inst
  const config = await inst.init()
  void inst.start()
  return config
}

export function shutdownSyncRuntime(): void {
  if (runtime) {
    void runtime.stop()
    runtime = null
  }
}
