import type { ExpiryLevel, Item } from '../../shared/types'
import { daysUntil, expiryLevel, formatRemain } from '../../shared/search'
import { formatLocation } from '../../shared/schema'
import notifySoundUrl from './assets/notify.wav'

export function cn(...parts: Array<string | false | null | undefined>): string {
  const list: string[] = []
  for (let i = 0; i < parts.length; i += 1) {
    const part = parts[i]
    if (part) list.push(part)
  }
  return list.join(' ')
}

/** 提示音音频（resources 里的 08_03.wav 随安装包一起打包），解码一次后复用 */
let notifyBuffer: AudioBuffer | null = null
let notifyLoading: Promise<AudioBuffer | null> | null = null

function loadNotifyBuffer(ctx: AudioContext): Promise<AudioBuffer | null> {
  if (notifyBuffer) return Promise.resolve(notifyBuffer)
  if (!notifyLoading) {
    notifyLoading = fetch(notifySoundUrl)
      .then(function (response) {
        return response.arrayBuffer()
      })
      .then(function (bytes) {
        return ctx.decodeAudioData(bytes)
      })
      .then(function (buffer) {
        notifyBuffer = buffer
        return buffer
      })
      .catch(function () {
        notifyLoading = null
        return null
      })
  }
  return notifyLoading
}

/** 兜底提示音：音频文件读不出来时用振荡器发一声短提示 */
function beepWithOscillator(ctx: AudioContext): void {
  const osc = ctx.createOscillator()
  const gain = ctx.createGain()
  osc.type = 'sine'
  osc.frequency.value = 880
  gain.gain.value = 0.06
  osc.connect(gain)
  gain.connect(ctx.destination)
  osc.start()
  window.setTimeout(function () {
    try {
      osc.stop()
    } catch {
      return
    }
  }, 260)
}

/** 播放提示音：优先播 08_03.wav，失败时退回内置振荡器，音量跟随系统音量 */
export function playBeep(): void {
  try {
    const Ctor = window.AudioContext
    if (!Ctor) return
    const ctx = new Ctor()
    let closed = false
    const close = function (): void {
      if (closed) return
      closed = true
      window.setTimeout(function () {
        void ctx.close().catch(function () {
          return
        })
      }, 3000)
    }
    void loadNotifyBuffer(ctx).then(function (buffer) {
      if (!buffer) {
        beepWithOscillator(ctx)
        close()
        return
      }
      const source = ctx.createBufferSource()
      source.buffer = buffer
      const gain = ctx.createGain()
      gain.gain.value = 0.9
      source.connect(gain)
      gain.connect(ctx.destination)
      source.onended = close
      source.start()
      window.setTimeout(close, 15000)
    })
  } catch {
    return
  }
}

export interface ExpiryInfo {
  days: number
  level: ExpiryLevel
  text: string
  expired: boolean
}

export function expiryInfoFor(item: Item): ExpiryInfo | null {
  const date = item.fields.expiresAt
  if (!date) return null
  const days = daysUntil(date)
  if (days === null) return null
  return { days: days, level: expiryLevel(days), text: formatRemain(days), expired: days < 0 }
}

export function levelClass(level: ExpiryLevel): string {
  return 'level-' + level
}

/** 位置展示：地点/容器名称 + 详细位置 */
export function locationOf(item: Item): string {
  return formatLocation(item.locationLabel || '', item.locationName || '')
}

function pad2(value: number): string {
  return value < 10 ? '0' + value : String(value)
}

export function formatLocalInput(date: Date): string {
  return (
    String(date.getFullYear()) +
    '-' +
    pad2(date.getMonth() + 1) +
    '-' +
    pad2(date.getDate()) +
    'T' +
    pad2(date.getHours()) +
    ':' +
    pad2(date.getMinutes())
  )
}

export function isoFromLocalInput(value: string): string | null {
  if (!value) return null
  const date = new Date(value)
  if (Number.isNaN(date.getTime())) return null
  return date.toISOString()
}

export function localInputFromIso(iso: string | null): string {
  if (!iso) return ''
  const date = new Date(iso)
  if (Number.isNaN(date.getTime())) return ''
  return formatLocalInput(date)
}

export function minutesLater(minutes: number): string {
  const date = new Date()
  date.setMinutes(date.getMinutes() + minutes)
  return formatLocalInput(date)
}

export function tomorrowMorning(): string {
  const date = new Date()
  date.setDate(date.getDate() + 1)
  date.setHours(9, 0, 0, 0)
  return formatLocalInput(date)
}
