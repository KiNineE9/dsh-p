import { useState } from 'react'
import type { BaseTemplate, Category, CustomFieldDef, CustomFieldType } from '../../shared/types'
import { TEMPLATE_ICONS, TEMPLATE_LABELS, makeId, validateCategoryDraft } from '../../shared/schema'
import Modal from './Modal'

const ICONS: string[] = ['🏷️', '🧸', '🧰', '🎁', '👕', '🧴', '🪑', '🎒', '🧪', '🔧']
const TEMPLATE_KEYS: BaseTemplate[] = ['book', 'item', 'food', 'medicine']
/** 模板对应的图标固定排在图标列表最后，方便和模板一起快速选中 */
const TEMPLATE_ICON_LIST: string[] = TEMPLATE_KEYS.map(function (key) {
  return TEMPLATE_ICONS[key]
})
const ICON_CHOICES: string[] = ICONS.filter(function (item) {
  return TEMPLATE_ICON_LIST.indexOf(item) < 0
}).concat(TEMPLATE_ICON_LIST)
const TYPE_OPTIONS: Array<{ value: string; label: string }> = [
  { value: 'text', label: '单行文字' },
  { value: 'textarea', label: '多行文字' },
  { value: 'date', label: '日期' },
  { value: 'select', label: '下拉选项' },
  { value: 'boolean', label: '是 / 否' },
  { value: 'number', label: '数字' }
]

interface CustomRow {
  id: string
  label: string
  type: string
  options: string
}

export interface CategoryFormModalProps {
  existing: Category | null
  categories: Category[]
  onClose: () => void
  onToast: (message: string) => void
}

export default function CategoryFormModal(props: CategoryFormModalProps) {
  const existing = props.existing
  const [name, setName] = useState(existing ? existing.name : '')
  const [icon, setIcon] = useState(existing ? existing.icon : TEMPLATE_ICONS['book'])
  const [base, setBase] = useState<BaseTemplate>(existing ? existing.baseTemplate : 'book')
  const [rows, setRows] = useState<CustomRow[]>([])
  const [errors, setErrors] = useState<Record<string, string>>({})
  const [saving, setSaving] = useState(false)

  function addRow(): void {
    setRows(function (current) {
      return current.concat([{ id: makeId('row'), label: '', type: 'text', options: '' }])
    })
  }

  function updateRow(id: string, patch: Partial<CustomRow>): void {
    setRows(function (current) {
      return current.map(function (row) {
        if (row.id !== id) return row
        return { ...row, ...patch }
      })
    })
  }

  function removeRow(id: string): void {
    setRows(function (current) {
      return current.filter(function (row) {
        return row.id !== id
      })
    })
  }

  async function submit(): Promise<void> {
    const check = validateCategoryDraft(
      { name: name, baseTemplate: base },
      props.categories,
      existing ? existing.id : undefined
    )
    if (!check.ok) {
      setErrors(check.errors)
      return
    }

    const customFields: CustomFieldDef[] = []
    for (let i = 0; i < rows.length; i += 1) {
      const row = rows[i]
      const label = row.label.trim()
      if (!label) continue
      let options: string[] | undefined
      if (row.type === 'select') {
        options = row.options
          .split(/[,，]/)
          .map(function (part) {
            return part.trim()
          })
          .filter(function (part) {
            return part.length > 0
          })
        if (options.length === 0) {
          props.onToast('选了「下拉选项」的字段，要填上选项，用逗号隔开')
          return
        }
      }
      customFields.push({
        key: makeId('f'),
        label: label,
        type: row.type as unknown as CustomFieldType,
        options: options,
        required: false
      })
    }

    setErrors({})
    setSaving(true)
    try {
      const op = existing
        ? await window.guina.updateCategory(existing.id, { name: name.trim(), icon: icon })
        : await window.guina.createCategory({
            name: name.trim(),
            icon: icon,
            baseTemplate: base,
            customFields: customFields
          })
      if (op.ok) {
        props.onToast(existing ? '已保存' : '分类已创建')
        props.onClose()
      } else {
        setSaving(false)
        props.onToast(op.error)
      }
    } catch {
      setSaving(false)
      props.onToast('保存失败，请再试一次')
    }
  }

  const footer = (
    <div className="foot-row">
      <button type="button" className="btn ghost" data-testid="modal-cancel" onClick={props.onClose}>
        取消
      </button>
      <button
        type="button"
        className="btn primary"
        data-testid="modal-confirm"
        disabled={saving}
        onClick={function () {
          void submit()
        }}
      >
        {existing ? '保存' : '创建分类'}
      </button>
    </div>
  )

  return (
    <Modal title={existing ? '改名 / 换图标' : '新建分类'} onClose={props.onClose} footer={footer} width={540}>
      <label className="field">
        <span className="field-label">
          分类名
          <b className="req">*</b>
        </span>
        <input
          data-testid="category-name"
          placeholder="比如：厨房、工具箱、药箱"
          value={name}
          onChange={function (event) {
            setName(event.target.value)
          }}
        />
        {errors['name'] ? (
          <span className="field-error" data-testid="form-error">
            {errors['name']}
          </span>
        ) : null}
      </label>

      <div className="field">
        <span className="field-label">图标</span>
        <div className="icon-row">
          {ICON_CHOICES.map(function (item) {
            return (
              <button
                type="button"
                key={item}
                className={icon === item ? 'icon-choice active' : 'icon-choice'}
                onClick={function () {
                  setIcon(item)
                }}
              >
                {item}
              </button>
            )
          })}
        </div>
      </div>

      {existing ? null : (
        <div className="field">
          <span className="field-label">字段模板</span>
          <div className="template-row">
            {TEMPLATE_KEYS.map(function (key) {
              return (
                <button
                  type="button"
                  key={key}
                  className={base === key ? 'template-btn active' : 'template-btn'}
                  data-testid={'template-' + key}
                  onClick={function () {
                    setBase(key)
                    setIcon(TEMPLATE_ICONS[key])
                  }}
                >
                  <span className="template-icon">{TEMPLATE_ICONS[key]}</span>
                  <span className="template-label">{TEMPLATE_LABELS[key]}</span>
                </button>
              )
            })}
          </div>
        </div>
      )}

      {existing ? (
        <p className="field-hint">分类的字段模板建好后就固定了，这里可以改名字和图标。</p>
      ) : (
        <div className="field">
          <span className="field-label">再加几个自己的字段（可不加）</span>
          {rows.map(function (row) {
            return (
              <div className="custom-row" key={row.id}>
                <input
                  className="custom-label"
                  placeholder="字段名，比如：品牌"
                  value={row.label}
                  onChange={function (event) {
                    updateRow(row.id, { label: event.target.value })
                  }}
                />
                <select
                  className="custom-type"
                  value={row.type}
                  onChange={function (event) {
                    updateRow(row.id, { type: event.target.value })
                  }}
                >
                  {TYPE_OPTIONS.map(function (option) {
                    return (
                      <option key={option.value} value={option.value}>
                        {option.label}
                      </option>
                    )
                  })}
                </select>
                {row.type === 'select' ? (
                  <input
                    className="custom-options"
                    placeholder="选项，用逗号隔开，比如：红,蓝"
                    value={row.options}
                    onChange={function (event) {
                      updateRow(row.id, { options: event.target.value })
                    }}
                  />
                ) : null}
                <button type="button" className="btn ghost sm" onClick={function () { removeRow(row.id) }}>
                  删掉
                </button>
              </div>
            )
          })}
          <button type="button" className="btn ghost sm" data-testid="add-custom-field" onClick={addRow}>
            + 加一个字段
          </button>
        </div>
      )}
    </Modal>
  )
}
