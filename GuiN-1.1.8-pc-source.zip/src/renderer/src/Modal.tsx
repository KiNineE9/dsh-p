import { useEffect } from 'react'
import type { ReactNode } from 'react'

export interface ModalProps {
  title: string
  children: ReactNode
  onClose: () => void
  footer?: ReactNode
  width?: number
}

export default function Modal(props: ModalProps) {
  useEffect(function () {
    function onKey(event: KeyboardEvent): void {
      if (event.key === 'Escape') props.onClose()
    }
    document.addEventListener('keydown', onKey)
    return function () {
      document.removeEventListener('keydown', onKey)
    }
  }, [props.onClose])

  return (
    <div className="modal-mask">
      <div
        className="modal"
        data-testid="modal"
        role="dialog"
        aria-modal="true"
        style={props.width ? { width: String(props.width) + 'px' } : undefined}
      >
        <div className="modal-head">
          <h3 className="modal-title">{props.title}</h3>
          <button type="button" className="icon-btn" title="关闭" onClick={props.onClose}>
            ×
          </button>
        </div>
        <div className="modal-body">{props.children}</div>
        {props.footer ? <div className="modal-foot">{props.footer}</div> : null}
      </div>
    </div>
  )
}

export interface ConfirmDialogProps {
  title: string
  message: string
  confirmLabel: string
  danger: boolean
  onConfirm: () => void
  onCancel: () => void
}

export function ConfirmDialog(props: ConfirmDialogProps) {
  const footer = (
    <div className="foot-row">
      <button type="button" className="btn ghost" data-testid="modal-cancel" onClick={props.onCancel}>
        取消
      </button>
      <button
        type="button"
        className={props.danger ? 'btn danger' : 'btn primary'}
        data-testid="modal-confirm"
        onClick={props.onConfirm}
      >
        {props.confirmLabel}
      </button>
    </div>
  )

  return (
    <Modal title={props.title} onClose={props.onCancel} footer={footer} width={430}>
      <p className="confirm-text">{props.message}</p>
    </Modal>
  )
}
