import { useState } from 'react'
import type { RepeatKind, RepeatRule, StickyKind, StickyNote } from '../../shared/types'
import { parseRepeatTime, REPEAT_OPTIONS } from '../../shared/repeat'
import { isoFromLocalInput, localInputFromIso, minutesLater, tomorrowMorning } from './helpers'
import Modal from './Modal'

export interface StickyFormModalProps {
  sticky: StickyNote | null
  initialKind: StickyKind
  onClose: () => void
  onToast: (message: string) => void
}

type RepeatChoice = RepeatKind | 'none'

export default function StickyFormModal(props: StickyFormModalProps) {
  const sticky = props.sticky
  const [kind, setKind] = useState<StickyKind>(sticky ? sticky.kind : props.initialKind)
  const [title, setTitle] = useState(sticky && sticky.title ? sticky.title : '')
  const [content, setContent] = useState(sticky ? sticky.content : '')
  const [pinned, setPinned] = useState(sticky ? sticky.pinned : false)
  const [remindLocal, setRemindLocal] = useState(function () {
    return sticky ? localInputFromIso(sticky.remindAt) : ''
  })
  const [repeatKind, setRepeatKind] = useState<RepeatChoice>(function () {
    return sticky && sticky.repeat ? sticky.repeat.kind : 'none'
  })
  const [repeatTime, setRepeatTime] = useState(function () {
    return sticky && sticky.repeat ? sticky.repeat.time : '09:00'
  })
  const [saving, setSaving] = useState(false)

  const isReminder = kind === 'reminder'
  const repeatMode = isReminder && repeatKind !== 'none'

  async function save(): Promise<void> {
    const text = content.trim()
    if (!text) {
      props.onToast(isReminder ? '写点要提醒的事吧' : '写点内容吧')
      return
    }
    let repeat: RepeatRule | null = null
    if (repeatMode) {
      if (!parseRepeatTime(repeatTime)) {
        props.onToast('循环提醒的时间没填对')
        return
      }
      repeat = { kind: repeatKind as RepeatKind, time: repeatTime }
    }
    const remindAt = repeatMode ? null : isoFromLocalInput(remindLocal)
    if (!repeatMode && remindLocal && remindAt === null) {
      props.onToast('提醒时间没填对')
      return
    }
    if (isReminder && !repeatMode && remindAt === null) {
      props.onToast('请选择提醒时间，或把类型改成「便签」')
      return
    }
    setSaving(true)
    try {
      const op = sticky
        ? await window.guina.updateSticky(sticky.id, {
            title: title.trim(),
            content: text,
            kind: kind,
            pinned: pinned,
            remindAt: isReminder ? (repeatMode ? null : remindAt) : null,
            repeat: repeat
          })
        : await window.guina.createSticky({
            title: title.trim(),
            content: text,
            kind: kind,
            pinned: pinned,
            remindAt: isReminder ? (repeatMode ? null : remindAt) : null,
            repeat: repeat
          })
      if (op.ok) {
        props.onToast(sticky ? '已更新' : isReminder ? '提醒便签已添加' : '便签已添加')
        props.onClose()
      } else {
        setSaving(false)
        props.onToast(op.error)
      }
    } catch {
      setSaving(false)
      props.onToast('保存失败，请再试一次')
    }
  }

  async function toggleStatus(): Promise<void> {
    if (!sticky) return
    const next = sticky.status === 'done' ? 'pending' : 'done'
    try {
      const op = await window.guina.updateSticky(sticky.id, { status: next })
      if (op.ok) {
        props.onToast(next === 'done' ? '已标记完成' : '已恢复')
      } else {
        props.onToast(op.error)
      }
    } catch {
      props.onToast('操作失败，请再试一次')
    }
  }

  const footer = (
    <div className="foot-row">
      <button type="button" className="btn ghost" data-testid="modal-cancel" onClick={props.onClose}>
        取消
      </button>
      <button type="button" className="btn primary" data-testid="modal-confirm" disabled={saving} onClick={function () { void save() }}>
        保存
      </button>
    </div>
  )

  return (
    <Modal
      title={sticky ? '编辑' + (isReminder ? '提醒便签' : '便签') : isReminder ? '新建提醒便签' : '新建便签'}
      onClose={props.onClose}
      footer={footer}
      width={470}
    >
      <div className="field">
        <span className="field-label">类型</span>
        <div className="seg-row">
          <button
            type="button"
            className={'seg-big' + (kind === 'note' ? ' on' : '')}
            data-testid="sticky-kind-note"
            onClick={function () {
              setKind('note')
            }}
          >
            便签
            <em>随手记，可置顶</em>
          </button>
          <button
            type="button"
            className={'seg-big' + (kind === 'reminder' ? ' on' : '')}
            data-testid="sticky-kind-reminder"
            onClick={function () {
              setKind('reminder')
            }}
          >
            提醒便签
            <em>到点提醒，可循环</em>
          </button>
        </div>
      </div>

      <label className="field">
        <span className="field-label">标题（可选）</span>
        <input
          data-testid="sticky-title"
          maxLength={60}
          placeholder="给这张便签起个标题，比如：周末待办"
          value={title}
          onChange={function (event) {
            setTitle(event.target.value)
          }}
        />
      </label>

      <label className="field">
        <span className="field-label">内容</span>
        <textarea
          rows={3}
          data-testid="sticky-content"
          placeholder={isReminder ? '到点要提醒的事，比如：周五交水电费' : '随手记点事，比如：备用钥匙在鞋柜'}
          value={content}
          onChange={function (event) {
            setContent(event.target.value)
          }}
        />
      </label>

      {isReminder ? (
        <div>
          <label className="field">
            <span className="field-label">循环提醒（可选）</span>
            <select
              data-testid="sticky-repeat-kind"
              value={repeatKind}
              onChange={function (event) {
                setRepeatKind(event.target.value as RepeatChoice)
              }}
            >
              <option value="none">不循环（只提醒一次）</option>
              {REPEAT_OPTIONS.map(function (option) {
                return (
                  <option value={option.kind} key={option.kind}>
                    {option.label}
                  </option>
                )
              })}
            </select>
          </label>
          {repeatMode ? (
            <div className="field">
              <label className="field">
                <span className="field-label">每天几点提醒</span>
                <input
                  type="time"
                  step={60}
                  data-testid="sticky-repeat-time"
                  value={repeatTime}
                  onChange={function (event) {
                    setRepeatTime(event.target.value)
                  }}
                />
              </label>
              <p className="field-hint">
                到点会弹提醒窗；点「知道了」后自动安排下一次，「标记完成」会停止这张提醒便签。
              </p>
            </div>
          ) : (
            <div>
              <label className="field">
                <span className="field-label">提醒时间</span>
                <input
                  type="datetime-local"
                  data-testid="sticky-remind"
                  value={remindLocal}
                  onChange={function (event) {
                    setRemindLocal(event.target.value)
                  }}
                />
              </label>
              <div className="quick-row">
                <button type="button" className="btn ghost sm" data-testid="quick-10m" onClick={function () { setRemindLocal(minutesLater(10)) }}>
                  10 分钟后
                </button>
                <button type="button" className="btn ghost sm" data-testid="quick-1h" onClick={function () { setRemindLocal(minutesLater(60)) }}>
                  1 小时后
                </button>
                <button type="button" className="btn ghost sm" data-testid="quick-tomorrow" onClick={function () { setRemindLocal(tomorrowMorning()) }}>
                  明天上午 9 点
                </button>
              </div>
            </div>
          )}
        </div>
      ) : (
        <label className="check-row" data-testid="sticky-pin-row">
          <input
            type="checkbox"
            data-testid="sticky-pinned"
            checked={pinned}
            onChange={function (event) {
              setPinned(event.target.checked)
            }}
          />
          <span>置顶这条便签（排在便签列表最前面）</span>
        </label>
      )}

      {sticky ? (
        <div className="quick-row">
          <button type="button" className="btn ghost sm" data-testid="sticky-status" onClick={function () { void toggleStatus() }}>
            {sticky.status === 'done' ? '标为未完成' : '标记完成'}
          </button>
        </div>
      ) : null}
    </Modal>
  )
}
