import { useEffect, useRef, useState } from 'react'
import type { SearchHistoryEntry, StickyNote } from '../../shared/types'
import { describeRepeat } from '../../shared/repeat'
import { formatDateTime, searchStickies } from '../../shared/search'
import { SEARCH_HISTORY_SHOWN } from '../../shared/schema'
import { recentSearchTexts } from '../../shared/history'
import { cn } from './helpers'

export interface StickyBoardProps {
  stickies: StickyNote[]
  collapsed: boolean
  onToggleCollapse: () => void
  onAddNote: () => void
  onAddReminder: () => void
  /** 点击卡片查看完整内容 */
  onOpen: (sticky: StickyNote) => void
  onDelete: (sticky: StickyNote) => void
  onToggleDone: (sticky: StickyNote) => void
  onTogglePin: (sticky: StickyNote) => void
  /** 最近搜索过的便签关键词 */
  searchHistory: SearchHistoryEntry[]
  searchHistoryEnabled: boolean
}

function sortGroup(list: StickyNote[]): StickyNote[] {
  return list.slice().sort(function (a, b) {
    if (a.pinned !== b.pinned) return a.pinned ? -1 : 1
    if (a.pinned && b.pinned) {
      const pa = a.pinnedAt || ''
      const pb = b.pinnedAt || ''
      if (pa !== pb) return pa > pb ? -1 : 1
    }
    const ad = a.status === 'done' ? 1 : 0
    const bd = b.status === 'done' ? 1 : 0
    if (ad !== bd) return ad - bd
    return a.createdAt.localeCompare(b.createdAt)
  })
}

export default function StickyBoard(props: StickyBoardProps) {
  const now = Date.now()
  const [query, setQuery] = useState('')
  const [searchFocused, setSearchFocused] = useState(false)
  const searchWrapRef = useRef<HTMLDivElement | null>(null)
  const value = query.trim()
  const historyTexts = props.searchHistoryEnabled
    ? recentSearchTexts(props.searchHistory, SEARCH_HISTORY_SHOWN)
    : []
  const historyOpen = searchFocused && value.length === 0 && historyTexts.length > 0

  useEffect(function () {
    function onDown(event: MouseEvent): void {
      const wrap = searchWrapRef.current
      if (!wrap) return
      if (event.target instanceof Node && !wrap.contains(event.target)) setSearchFocused(false)
    }
    document.addEventListener('mousedown', onDown)
    return function () {
      document.removeEventListener('mousedown', onDown)
    }
  }, [])

  /** 记一条便签搜索历史 */
  function recordSearch(text: string): void {
    const keyword = text.trim()
    if (!keyword) return
    void window.guina.addSearchHistory('sticky', keyword)
  }
  // 便签区独立搜索：只过滤便签，不影响顶部全局搜索（全局搜索仍然只搜物品）
  const visible = value ? searchStickies(props.stickies, value) : props.stickies
  const notes = sortGroup(visible.filter(function (s) { return s.kind !== 'reminder' }))
  const reminders = sortGroup(visible.filter(function (s) { return s.kind === 'reminder' }))

  function renderCard(sticky: StickyNote) {
    const done = sticky.status === 'done'
    const isReminder = sticky.kind === 'reminder'
    const overdue =
      isReminder && !done && !sticky.repeat && sticky.remindAt !== null && new Date(sticky.remindAt).getTime() < now
    return (
      <div
        className={cn('sticky-card', done && 'done', overdue && 'overdue', sticky.pinned && 'pinned')}
        data-testid="sticky-card"
        data-kind={isReminder ? 'reminder' : 'note'}
        key={sticky.id}
        title={sticky.title || sticky.content}
        onClick={function () {
          recordSearch(query)
          props.onOpen(sticky)
        }}
      >
        {sticky.title ? (
          <div className="sticky-card-title" data-testid="sticky-card-title">
            {sticky.title}
          </div>
        ) : null}
        <div className="sticky-top">
          <span className="sticky-content">{sticky.content}</span>
          {sticky.pinned ? (
            <span className="sticky-pin-flag" data-testid="sticky-pinned-flag" title="已置顶">
              📌
            </span>
          ) : null}
          {overdue ? <span className="sticky-flag">已过点</span> : null}
        </div>
        {sticky.repeat ? (
          <span className="sticky-time" data-testid="sticky-repeat">
            🔁 {describeRepeat(sticky.repeat)}
          </span>
        ) : null}
        {sticky.remindAt ? <span className="sticky-time">{formatDateTime(sticky.remindAt)}</span> : null}
        <div className="sticky-actions">
          <button
            type="button"
            className="mini-btn"
            data-testid="sticky-pin"
            title={sticky.pinned ? '取消置顶' : '置顶这张便签'}
            onClick={function (event) {
              event.stopPropagation()
              props.onTogglePin(sticky)
            }}
          >
            {sticky.pinned ? '取消置顶' : '置顶'}
          </button>
          <button
            type="button"
            className="mini-btn"
            title={done ? '标为未完成' : '标记完成'}
            onClick={function (event) {
              event.stopPropagation()
              props.onToggleDone(sticky)
            }}
          >
            {done ? '↩' : '✓'}
          </button>
          <button
            type="button"
            className="mini-btn danger-text"
            title="删除"
            onClick={function (event) {
              event.stopPropagation()
              props.onDelete(sticky)
            }}
          >
            删除
          </button>
        </div>
      </div>
    )
  }

  function renderColumn(kind: 'note' | 'reminder', list: StickyNote[]) {
    const isReminder = kind === 'reminder'
    return (
      <div className="sticky-col" data-testid={isReminder ? 'sticky-col-reminder' : 'sticky-col-note'}>
        <div className="sticky-col-head">
          <span className="sticky-col-title">
            {isReminder ? '提醒便签' : '便签'}
            <em className="sticky-col-count">{list.length}</em>
          </span>
          <button
            type="button"
            className="btn ghost sm"
            data-testid={isReminder ? 'sticky-add-reminder' : 'sticky-add-note'}
            onClick={isReminder ? props.onAddReminder : props.onAddNote}
          >
            + 新建
          </button>
        </div>
        {list.length === 0 ? (
          <div className="sticky-empty" data-testid={isReminder ? 'sticky-empty-reminder' : 'sticky-empty-note'}>
            {value
              ? '没有匹配的' + (isReminder ? '提醒便签' : '便签') + '，换个词试试。'
              : isReminder
                ? '还没有提醒便签。点右上角「+ 新建」，设一次性或循环提醒。'
                : '还没有便签。点右上角「+ 新建」，随手记点事。'}
          </div>
        ) : (
          <div className="sticky-board">{list.map(renderCard)}</div>
        )}
      </div>
    )
  }

  return (
    <section className={cn('sticky-section', props.collapsed && 'collapsed')} data-testid="sticky-section">
      <div className="section-head">
        <h2 className="section-title">便签与提醒</h2>
        <div className="head-actions">
          <div className="sticky-search-wrap" ref={searchWrapRef}>
            <input
              className="sticky-search"
              data-testid="sticky-search"
              placeholder="搜便签标题或内容…"
              value={query}
              onChange={function (event) {
                setQuery(event.target.value)
                setSearchFocused(true)
              }}
              onFocus={function () {
                setSearchFocused(true)
              }}
              onKeyDown={function (event) {
                if (event.key === 'Escape') {
                  setQuery('')
                  setSearchFocused(false)
                }
                if (event.key === 'Enter') recordSearch(query)
              }}
            />
            {historyOpen ? (
              <div className="search-results sticky-history" data-testid="sticky-search-history">
                <div className="search-history-head">最近搜索</div>
                {historyTexts.map(function (text) {
                  return (
                    <div className="search-history-row" key={text}>
                      <button
                        type="button"
                        className="search-history-text"
                        data-testid="sticky-search-history-item"
                        onClick={function () {
                          recordSearch(text)
                          setQuery(text)
                          setSearchFocused(true)
                        }}
                      >
                        {text}
                      </button>
                      <button
                        type="button"
                        className="search-history-del"
                        data-testid="sticky-search-history-delete"
                        title="删除这条历史"
                        onClick={function () {
                          void window.guina.removeSearchHistory('sticky', text)
                        }}
                      >
                        ×
                      </button>
                    </div>
                  )
                })}
              </div>
            ) : null}
          </div>
          {value ? (
            <button type="button" className="btn ghost sm" data-testid="sticky-search-clear" onClick={function () { setQuery('') }}>
              清除
            </button>
          ) : null}
          <button type="button" className="btn ghost sm" data-testid="sticky-board-toggle" onClick={props.onToggleCollapse}>
            {props.collapsed ? '展开' : '收起'}
          </button>
        </div>
      </div>
      {props.collapsed ? null : (
        <div className="sticky-columns">
          {renderColumn('note', notes)}
          {renderColumn('reminder', reminders)}
        </div>
      )}
    </section>
  )
}
