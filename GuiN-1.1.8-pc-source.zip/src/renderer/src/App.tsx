import { useCallback, useEffect, useRef, useState } from 'react'
import type { AppState, Category, DialogKind, Item, MainView, StickyKind, StickyNote } from '../../shared/types'
import type { DataInfo } from '../../shared/api'
import TopBar from './TopBar'
import HomeView from './HomeView'
import CategoryView from './CategoryView'
import SettingsView from './SettingsView'
import NotificationPanel from './NotificationPanel'
import Onboarding from './Onboarding'
import { ConfirmDialog } from './Modal'
import ItemFormModal from './ItemFormModal'
import NotesModal from './NotesModal'
import StickyFormModal from './StickyFormModal'
import StickyDetailModal from './StickyDetailModal'
import CategoryFormModal from './CategoryFormModal'
import { playBeep } from './helpers'
import { bootSyncRuntime, onSyncProgress, setCurrentSyncState, setIncomingSyncHandler } from './syncClient'
import type { IncomingSyncRequest } from '../../shared/sync/types'

type DialogState =
  | { kind: 'item'; categoryId: string; itemId: string | null }
  | { kind: 'sticky'; stickyId: string | null; initialKind: StickyKind }
  | { kind: 'sticky-detail'; stickyId: string }
  | { kind: 'notes'; itemId: string }
  | { kind: 'category'; categoryId: string | null }
  | { kind: 'confirm'; title: string; message: string; confirmLabel: string; run: () => void }
  | null

export default function App() {
  const [state, setState] = useState<AppState | null>(null)
  const [dataInfo, setDataInfo] = useState<DataInfo | null>(null)
  const [view, setView] = useState<MainView>('home')
  const [categoryId, setCategoryId] = useState<string | null>(null)
  const [hlItemId, setHlItemId] = useState<string | null>(null)
  const [toast, setToast] = useState<string | null>(null)
  const [dialog, setDialog] = useState<DialogState>(null)
  const [notifOpen, setNotifOpen] = useState(false)
  const [stickyCollapsed, setStickyCollapsed] = useState(false)
  const [onboardingOverride, setOnboardingOverride] = useState(false)
  const [incomingSync, setIncomingSync] = useState<IncomingSyncRequest | null>(null)

  const stateRef = useRef<AppState | null>(null)
  const incomingDecideRef = useRef<((accepted: boolean) => void) | null>(null)
  const categoryIdRef = useRef<string | null>(null)
  const hlTimer = useRef<number | null>(null)
  const toastTimer = useRef<number | null>(null)

  const showToast = useCallback(function (message: string) {
    setToast(message)
    if (toastTimer.current !== null) window.clearTimeout(toastTimer.current)
    toastTimer.current = window.setTimeout(function () {
      setToast(null)
      toastTimer.current = null
    }, 2500)
  }, [])

  const locateItem = useCallback(function (itemId: string, targetCategoryId: string) {
    setView('category')
    setCategoryId(targetCategoryId)
    setNotifOpen(false)
    setHlItemId(itemId)
    if (hlTimer.current !== null) window.clearTimeout(hlTimer.current)
    hlTimer.current = window.setTimeout(function () {
      setHlItemId(null)
      hlTimer.current = null
    }, 2000)
  }, [])

  const handleDialog = useCallback(
    function (kind: DialogKind) {
      if (kind === 'settings') {
        setView('settings')
        setNotifOpen(false)
        return
      }
      if (kind === 'new-sticky' || kind === 'new-sticky-note' || kind === 'new-sticky-reminder') {
        setDialog({
          kind: 'sticky',
          stickyId: null,
          initialKind: kind === 'new-sticky-reminder' ? 'reminder' : 'note'
        })
        return
      }
      const current = stateRef.current
      if (!current || current.categories.length === 0) {
        showToast('先在首页建一个分类吧')
        return
      }
      let target = current.categories[0].id
      const remembered = categoryIdRef.current
      if (remembered) {
        const found = current.categories.find(function (category) {
          return category.id === remembered
        })
        if (found) target = found.id
      }
      setDialog({ kind: 'item', categoryId: target, itemId: null })
    },
    [showToast]
  )

  useEffect(
    function () {
      stateRef.current = state
      if (state) setCurrentSyncState(state)
    },
    [state]
  )

  // 同步服务：启动后常驻在线，接收已绑定设备的同步请求
  useEffect(
    function () {
      let alive = true
      setIncomingSyncHandler(function (request, decide) {
        incomingDecideRef.current = decide
        setIncomingSync(request)
      })
      const offProgress = onSyncProgress(function (progress) {
        if (progress.phase === 'done' || progress.phase === 'error') showToast(progress.message)
      })
      void bootSyncRuntime()
        .then(function (config) {
          if (!alive || !config) return
        })
        .catch(function (err) {
          if (alive) showToast(err instanceof Error ? err.message : '同步服务启动失败')
        })
      return function () {
        alive = false
        offProgress()
        setIncomingSyncHandler(null)
      }
    },
    [showToast]
  )

  function answerIncoming(accepted: boolean): void {
    if (incomingDecideRef.current) incomingDecideRef.current(accepted)
    incomingDecideRef.current = null
    setIncomingSync(null)
  }

  useEffect(
    function () {
      categoryIdRef.current = categoryId
    },
    [categoryId]
  )

  useEffect(
    function () {
      let alive = true
      window.guina
        .getState()
        .then(function (next) {
          if (alive) setState(next)
        })
        .catch(function () {
          if (alive) showToast('读取数据失败，请重新打开程序')
        })
      window.guina
        .getDataInfo()
        .then(function (info) {
          if (alive) setDataInfo(info)
        })
        .catch(function () {
          return
        })

      const offs: Array<() => void> = [
        window.guina.onStateChanged(function (next) {
          setState(next)
        }),
        window.guina.onLocateItem(function (payload) {
          locateItem(payload.itemId, payload.categoryId)
        }),
        window.guina.onOpenDialog(function (kind) {
          handleDialog(kind)
        }),
        window.guina.onPlaySound(function () {
          playBeep()
        }),
        window.guina.onToast(function (message) {
          showToast(message)
        }),
        window.guina.onOpenSettings(function () {
          setView('settings')
          setNotifOpen(false)
        })
      ]

      return function () {
        alive = false
        for (let i = 0; i < offs.length; i += 1) offs[i]()
      }
    },
    [showToast, locateItem, handleDialog]
  )

  useEffect(function () {
    return function () {
      if (hlTimer.current !== null) window.clearTimeout(hlTimer.current)
      if (toastTimer.current !== null) window.clearTimeout(toastTimer.current)
    }
  }, [])

  if (!state) {
    return (
      <div className="app-loading">
        <span className="loading-emoji">📦</span>
        <p>正在打开…</p>
      </div>
    )
  }

  const currentCategory = categoryId
    ? state.categories.find(function (category) {
        return category.id === categoryId
      }) || null
    : null

  const showOnboarding = onboardingOverride || !state.onboardingDone

  function closeDialog(): void {
    setDialog(null)
  }

  function goHome(): void {
    setView('home')
    setCategoryId(null)
    setHlItemId(null)
    setNotifOpen(false)
  }

  function openCategory(id: string): void {
    setCategoryId(id)
    setView('category')
    setHlItemId(null)
    setNotifOpen(false)
  }

  function openSettings(): void {
    setView('settings')
    setNotifOpen(false)
  }

  function openNewItem(targetCategoryId: string): void {
    setDialog({ kind: 'item', categoryId: targetCategoryId, itemId: null })
  }

  function openEditItem(item: Item): void {
    setDialog({ kind: 'item', categoryId: item.categoryId, itemId: item.id })
  }

  function openNotes(item: Item): void {
    setDialog({ kind: 'notes', itemId: item.id })
  }

  function openNewSticky(kind: StickyKind): void {
    setDialog({ kind: 'sticky', stickyId: null, initialKind: kind })
  }

  function openStickyDetail(sticky: StickyNote): void {
    setDialog({ kind: 'sticky-detail', stickyId: sticky.id })
  }

  function openEditSticky(sticky: StickyNote): void {
    setDialog({ kind: 'sticky', stickyId: sticky.id, initialKind: sticky.kind })
  }

  function openNewCategory(): void {
    setDialog({ kind: 'category', categoryId: null })
  }

  function openEditCategory(category: Category): void {
    setDialog({ kind: 'category', categoryId: category.id })
  }

  function askConfirm(title: string, message: string, confirmLabel: string, run: () => void): void {
    setDialog({ kind: 'confirm', title: title, message: message, confirmLabel: confirmLabel, run: run })
  }

  function deleteItem(item: Item): void {
    askConfirm('删除这条记录？', '「' + item.name + '」删除后不可恢复。', '删除', function () {
      void window.guina.deleteItem(item.id).then(function (op) {
        if (op.ok) showToast('已删除')
        else showToast(op.error)
      })
    })
  }

  function deleteCategory(category: Category): void {
    const current = stateRef.current
    let count = 0
    if (current) {
      for (let i = 0; i < current.items.length; i += 1) {
        if (current.items[i].categoryId === category.id) count += 1
      }
    }
    askConfirm(
      '删除这个分类？',
      '「' + category.name + '」里还有 ' + count + ' 个条目，删除分类会连同里面的 ' + count + ' 个条目一起删除，删除后不可恢复。',
      '删除分类',
      function () {
        void window.guina.deleteCategory(category.id).then(function (op) {
          if (!op.ok) {
            showToast(op.error)
            return
          }
          showToast('分类已删除')
          setCategoryId(null)
          setView('home')
        })
      }
    )
  }

  function deleteSticky(sticky: StickyNote): void {
    askConfirm('删除这张便利贴？', '「' + sticky.content + '」删除后不可恢复。', '删除', function () {
      void window.guina.deleteSticky(sticky.id).then(function (op) {
        if (op.ok) showToast('已删除')
        else showToast(op.error)
      })
    })
  }

  function toggleStickyDone(sticky: StickyNote): void {
    const next = sticky.status === 'done' ? 'pending' : 'done'
    void window.guina.updateSticky(sticky.id, { status: next }).then(function (op) {
      if (!op.ok) showToast(op.error)
    })
  }

  function toggleCategoryPin(category: Category): void {
    void window.guina.updateCategory(category.id, { pinned: !category.pinned }).then(function (op) {
      if (op.ok) showToast(category.pinned ? '已取消置顶' : '分类已置顶')
      else showToast(op.error)
    })
  }

  function toggleStickyPin(sticky: StickyNote): void {
    void window.guina.updateSticky(sticky.id, { pinned: !sticky.pinned }).then(function (op) {
      if (op.ok) showToast(sticky.pinned ? '已取消置顶' : '已置顶')
      else showToast(op.error)
    })
  }

  function refreshDataInfo(): void {
    void window.guina
      .getDataInfo()
      .then(function (info) {
        setDataInfo(info)
      })
      .catch(function () {
        return
      })
  }

  function quitApp(): void {
    askConfirm('退出应用？', '退出后就不再收到提醒了。', '退出', function () {
      void window.guina.quitApp()
    })
  }

  function showOnboardingAgain(): void {
    setOnboardingOverride(true)
    void window.guina.showOnboarding()
  }

  function finishOnboarding(): void {
    setOnboardingOverride(false)
    void window.guina.finishOnboarding()
  }

  function renderDialog() {
    if (!dialog) return null
    if (!state) return null
    if (dialog.kind === 'item') {
      const targetCategory = state.categories.find(function (category) {
        return category.id === dialog.categoryId
      })
      if (!targetCategory) return null
      const wantedId = dialog.itemId
      const item = wantedId
        ? state.items.find(function (candidate) {
            return candidate.id === wantedId
          }) || null
        : null
      return (
        <ItemFormModal
          category={targetCategory}
          item={item}
          savedNames={state.savedNames}
          onClose={closeDialog}
          onToast={showToast}
        />
      )
    }
    if (dialog.kind === 'sticky') {
      const wantedId = dialog.stickyId
      const sticky = wantedId
        ? state.stickies.find(function (candidate) {
            return candidate.id === wantedId
          }) || null
        : null
      return (
        <StickyFormModal
          sticky={sticky}
          initialKind={dialog.initialKind}
          onClose={closeDialog}
          onToast={showToast}
        />
      )
    }
    if (dialog.kind === 'sticky-detail') {
      const sticky = state.stickies.find(function (candidate) {
        return candidate.id === dialog.stickyId
      })
      if (!sticky) return null
      return (
        <StickyDetailModal
          sticky={sticky}
          onClose={closeDialog}
          onEdit={function () {
            openEditSticky(sticky)
          }}
        />
      )
    }
    if (dialog.kind === 'notes') {
      const wantedId = dialog.itemId
      const item = state.items.find(function (candidate) {
        return candidate.id === wantedId
      })
      if (!item) return null
      const notes = state.notes.filter(function (note) {
        return note.itemId === wantedId
      })
      return <NotesModal item={item} notes={notes} onClose={closeDialog} onToast={showToast} />
    }
    if (dialog.kind === 'category') {
      const wantedId = dialog.categoryId
      const existing = wantedId
        ? state.categories.find(function (candidate) {
            return candidate.id === wantedId
          }) || null
        : null
      return (
        <CategoryFormModal
          existing={existing}
          categories={state.categories}
          onClose={closeDialog}
          onToast={showToast}
        />
      )
    }
    const confirm = dialog
    return (
      <ConfirmDialog
        title={confirm.title}
        message={confirm.message}
        confirmLabel={confirm.confirmLabel}
        danger
        onCancel={closeDialog}
        onConfirm={function () {
          setDialog(null)
          confirm.run()
        }}
      />
    )
  }

  return (
    <div className="app">
      <TopBar
        state={state}
        onLocate={locateItem}
        notificationsOpen={notifOpen}
        onToggleNotifications={function () {
          setNotifOpen(!notifOpen)
        }}
        onOpenSettings={openSettings}
        onGoHome={goHome}
        searchHistory={state.searchHistory.item}
        searchHistoryEnabled={state.settings.itemSearchHistory}
      />

      {notifOpen ? (
        <NotificationPanel
          state={state}
          onClose={function () {
            setNotifOpen(false)
          }}
          onLocate={locateItem}
          onToast={showToast}
          onAskConfirm={askConfirm}
        />
      ) : null}

      <main className="app-main">
        {view === 'home' ? (
          <HomeView
            state={state}
            stickyCollapsed={stickyCollapsed}
            onToggleStickyCollapse={function () {
              setStickyCollapsed(!stickyCollapsed)
            }}
            onNewStickyNote={function () {
              openNewSticky('note')
            }}
            onNewStickyReminder={function () {
              openNewSticky('reminder')
            }}
            onOpenSticky={openStickyDetail}
            onDeleteSticky={deleteSticky}
            onToggleStickyDone={toggleStickyDone}
            onToggleStickyPin={toggleStickyPin}
            onOpenCategory={openCategory}
            onNewCategory={openNewCategory}
            onEditCategory={openEditCategory}
            onDeleteCategory={deleteCategory}
            onToggleCategoryPin={toggleCategoryPin}
          />
        ) : null}

        {view === 'category' && currentCategory ? (
          <CategoryView
            key={currentCategory.id}
            state={state}
            category={currentCategory}
            hlItemId={hlItemId}
            onBack={goHome}
            onNewItem={openNewItem}
            onEditItem={openEditItem}
            onNotes={openNotes}
            onDeleteItem={deleteItem}
          />
        ) : null}

        {view === 'category' && !currentCategory ? (
          <div className="empty-box">
            <div className="empty-emoji">🧭</div>
            <p className="empty-text">找不到这个分类了，回首页看看吧。</p>
            <button type="button" className="btn primary" onClick={goHome}>
              回到首页
            </button>
          </div>
        ) : null}

        {view === 'settings' ? (
          <SettingsView
            settings={state.settings}
            dataInfo={dataInfo}
            onToast={showToast}
            onQuit={quitApp}
            onShowOnboarding={showOnboardingAgain}
            onBack={goHome}
            onRefreshData={refreshDataInfo}
          />
        ) : null}
      </main>

      {showOnboarding ? <Onboarding onFinish={finishOnboarding} /> : null}
      {renderDialog()}
      {incomingSync ? (
        <ConfirmDialog
          title="有设备请求同步"
          message={
            '「' + incomingSync.deviceName + '」请求' +
            (incomingSync.mode === 'push' ? '把它的数据同步到本机' : incomingSync.mode === 'pull' ? '读取本机数据' : '合并双方数据') +
            '。机器码 ' + incomingSync.machineCode + '，请核对是不是你绑定的设备。接受后会先自动备份本机数据。' +
            (incomingSync.scope === 'no-stickies' ? '手机 ↔ 电脑同步不会同步便签与提醒。' : '')
          }
          confirmLabel="接受同步"
          danger={false}
          onCancel={function () { answerIncoming(false) }}
          onConfirm={function () { answerIncoming(true) }}
        />
      ) : null}
      {toast ? (
        <div className="toast" data-testid="toast">
          {toast}
        </div>
      ) : null}
    </div>
  )
}
