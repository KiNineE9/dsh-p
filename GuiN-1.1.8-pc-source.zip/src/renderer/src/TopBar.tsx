import appIcon from './assets/app-icon.png'
import { useEffect, useMemo, useRef, useState } from 'react'
import type { AppState, SearchHistoryEntry } from '../../shared/types'
import { LOCATION_TYPE_LABELS, SEARCH_HISTORY_SHOWN } from '../../shared/schema'
import { searchItems } from '../../shared/search'
import { recentSearchTexts } from '../../shared/history'
import { locationOf } from './helpers'

export interface TopBarProps {
  state: AppState
  onLocate: (itemId: string, categoryId: string) => void
  notificationsOpen: boolean
  onToggleNotifications: () => void
  onOpenSettings: () => void
  onGoHome: () => void
  /** 最近搜索过的物品 / 存放位置关键词 */
  searchHistory: SearchHistoryEntry[]
  searchHistoryEnabled: boolean
}

export default function TopBar(props: TopBarProps) {
  const [query, setQuery] = useState('')
  const [focused, setFocused] = useState(false)
  const boxRef = useRef<HTMLDivElement | null>(null)

  const hits = useMemo(
    function () {
      const value = query.trim()
      if (!value) return []
      return searchItems(props.state.items, props.state.categories, props.state.notes, value, { limit: 8 })
    },
    [props.state, query]
  )

  const open = focused && query.trim().length > 0
  const historyTexts = props.searchHistoryEnabled
    ? recentSearchTexts(props.searchHistory, SEARCH_HISTORY_SHOWN)
    : []
  const historyOpen = focused && query.trim().length === 0 && historyTexts.length > 0

  /** 记一条搜索历史：搜索框下拉里的「最近搜索」靠它更新 */
  function recordSearch(text: string): void {
    const value = text.trim()
    if (!value) return
    void window.guina.addSearchHistory('item', value)
  }
  const unread = props.state.notifications.filter(function (note) {
    return !note.read && !note.deleted
  }).length

  useEffect(function () {
    function onDown(event: MouseEvent): void {
      const box = boxRef.current
      if (!box) return
      if (event.target instanceof Node && !box.contains(event.target)) {
        setFocused(false)
      }
    }
    document.addEventListener('mousedown', onDown)
    return function () {
      document.removeEventListener('mousedown', onDown)
    }
  }, [])

  function pick(itemId: string, categoryId: string): void {
    recordSearch(query)
    setQuery('')
    setFocused(false)
    props.onLocate(itemId, categoryId)
  }

  return (
    <header className="topbar">
      <button type="button" className="brand" onClick={props.onGoHome}>
        <img className="brand-icon" src={appIcon} alt="" />
        <span className="brand-text">
          <span className="brand-name">GuiN</span>
          <span className="brand-tip">个人生活记忆库 · 东西放哪儿一搜就知道</span>
        </span>
      </button>

      <div className="search-wrap" ref={boxRef}>
        <input
          className="search-input"
          data-testid="search-input"
          placeholder="搜索物品或存放位置…"
          value={query}
          onChange={function (event) {
            setQuery(event.target.value)
            setFocused(true)
          }}
          onFocus={function () {
            setFocused(true)
          }}
          onKeyDown={function (event) {
            if (event.key === 'Escape') {
              setFocused(false)
            }
            if (event.key === 'Enter' && hits.length > 0) {
              pick(hits[0].item.id, hits[0].item.categoryId)
            }
          }}
        />
        {open ? (
          <div className="search-results" data-testid="search-results">
            {hits.length === 0 ? (
              <div className="search-empty">没找到，换个词试试</div>
            ) : (
              hits.map(function (hit) {
                return (
                  <button
                    type="button"
                    className="search-hit"
                    data-testid="search-hit"
                    key={hit.item.id}
                    onClick={function () {
                      pick(hit.item.id, hit.item.categoryId)
                    }}
                  >
                    <span className="hit-name">{hit.item.name}</span>
                    <span className="hit-sub">
                      {hit.categoryIcon} {hit.categoryName} · {LOCATION_TYPE_LABELS[hit.item.locationType]}{' '}
                      {locationOf(hit.item)}
                    </span>
                  </button>
                )
              })
            )}
          </div>
        ) : null}
        {historyOpen ? (
          <div className="search-results search-history" data-testid="search-history">
            <div className="search-history-head">最近搜索</div>
            {historyTexts.map(function (text) {
              return (
                <div className="search-history-row" key={text}>
                  <button
                    type="button"
                    className="search-history-text"
                    data-testid="search-history-item"
                    onClick={function () {
                      recordSearch(text)
                      setQuery(text)
                      setFocused(true)
                    }}
                  >
                    {text}
                  </button>
                  <button
                    type="button"
                    className="search-history-del"
                    data-testid="search-history-delete"
                    title="删除这条历史"
                    onClick={function () {
                      void window.guina.removeSearchHistory('item', text)
                    }}
                  >
                    ×
                  </button>
                </div>
              )
            })}
          </div>
        ) : null}
      </div>

      <div className="top-actions">
        <button
          type="button"
          className={props.notificationsOpen ? 'icon-btn bell active' : 'icon-btn bell'}
          data-testid="bell"
          title="到期提醒"
          onClick={props.onToggleNotifications}
        >
          <span className="bell-icon">🔔</span>
          <span className="bell-exclaim">!</span>
          {unread > 0 ? (
            <span className="bell-badge" data-testid="bell-badge">
              {'!' + unread}
            </span>
          ) : null}
        </button>
        <button type="button" className="icon-btn" data-testid="settings-btn" title="设置" onClick={props.onOpenSettings}>
          ⚙️
        </button>
      </div>
    </header>
  )
}
