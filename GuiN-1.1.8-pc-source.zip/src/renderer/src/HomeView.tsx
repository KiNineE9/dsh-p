import { useEffect, useState } from 'react'
import type { AppState, Category, StickyNote } from '../../shared/types'
import { sortCategoriesForDisplay } from '../../shared/schema'
import StickyBoard from './StickyBoard'

export interface HomeViewProps {
  state: AppState
  stickyCollapsed: boolean
  onToggleStickyCollapse: () => void
  onNewStickyNote: () => void
  onNewStickyReminder: () => void
  onOpenSticky: (sticky: StickyNote) => void
  onDeleteSticky: (sticky: StickyNote) => void
  onToggleStickyDone: (sticky: StickyNote) => void
  onToggleStickyPin: (sticky: StickyNote) => void
  onOpenCategory: (categoryId: string) => void
  onNewCategory: () => void
  onEditCategory: (category: Category) => void
  onDeleteCategory: (category: Category) => void
  onToggleCategoryPin: (category: Category) => void
}

export default function HomeView(props: HomeViewProps) {
  const [menuId, setMenuId] = useState<string | null>(null)

  useEffect(function () {
    if (menuId === null) return
    function onDown(event: MouseEvent): void {
      const target = event.target
      if (!(target instanceof Element)) return
      if (!target.closest('.category-menu-wrap')) {
        setMenuId(null)
      }
    }
    document.addEventListener('mousedown', onDown)
    return function () {
      document.removeEventListener('mousedown', onDown)
    }
  }, [menuId])

  const categories = sortCategoriesForDisplay(props.state.categories)

  function countItems(categoryId: string): number {
    let total = 0
    for (let i = 0; i < props.state.items.length; i += 1) {
      if (props.state.items[i].categoryId === categoryId) total += 1
    }
    return total
  }

  return (
    <div className="home-view">
      <StickyBoard
        stickies={props.state.stickies}
        collapsed={props.stickyCollapsed}
        onToggleCollapse={props.onToggleStickyCollapse}
        onAddNote={props.onNewStickyNote}
        onAddReminder={props.onNewStickyReminder}
        onOpen={props.onOpenSticky}
        onDelete={props.onDeleteSticky}
        onToggleDone={props.onToggleStickyDone}
        onTogglePin={props.onToggleStickyPin}
        searchHistory={props.state.searchHistory.sticky}
        searchHistoryEnabled={props.state.settings.stickySearchHistory}
      />

      <section className="category-section">
        <div className="section-head">
          <h2 className="section-title">我的分类</h2>
          <button type="button" className="btn primary sm" data-testid="add-category" onClick={props.onNewCategory}>
            + 新建分类
          </button>
        </div>

        <div className="category-grid">
          {categories.map(function (category) {
            const count = countItems(category.id)
            const menuOpen = menuId === category.id
            return (
              <div
                className="category-card"
                data-testid="category-card"
                key={category.id}
                onClick={function () {
                  setMenuId(null)
                  props.onOpenCategory(category.id)
                }}
              >
                <div className="cat-icon">{category.icon}</div>
                <div className="cat-body">
                  <div className="cat-name">
                    {category.name}
                    {category.pinned ? (
                      <span className="cat-pin" title="已置顶">
                        📌
                      </span>
                    ) : null}
                  </div>
                  <div className="cat-count">{count + ' 件'}</div>
                </div>
                <div className="category-menu-wrap">
                    <button
                      type="button"
                      className="cat-more"
                      data-testid="category-more"
                      title="更多"
                      onClick={function (event) {
                        event.stopPropagation()
                        setMenuId(menuOpen ? null : category.id)
                      }}
                    >
                      ⋯
                    </button>
                    {menuOpen ? (
                      <div className="menu category-menu">
                        <button
                          type="button"
                          className="menu-item"
                          data-testid="category-pin"
                          onClick={function (event) {
                            event.stopPropagation()
                            setMenuId(null)
                            props.onToggleCategoryPin(category)
                          }}
                        >
                          {category.pinned ? '取消置顶' : '置顶分类'}
                        </button>
                        <button
                          type="button"
                          className="menu-item"
                          data-testid="category-edit"
                          onClick={function (event) {
                            event.stopPropagation()
                            setMenuId(null)
                            props.onEditCategory(category)
                          }}
                        >
                          改名 / 换图标
                        </button>
                        <button
                          type="button"
                          className="menu-item danger"
                          data-testid="category-delete"
                          onClick={function (event) {
                            event.stopPropagation()
                            setMenuId(null)
                            props.onDeleteCategory(category)
                          }}
                        >
                          删除分类
                        </button>
                      </div>
                    ) : null}
                </div>
              </div>
            )
          })}
        </div>
      </section>
    </div>
  )
}
