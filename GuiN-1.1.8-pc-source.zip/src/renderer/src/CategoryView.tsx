import { useEffect, useMemo, useRef, useState } from 'react'
import type { AppState, BaseTemplate, Category, Item, SortState } from '../../shared/types'
import { LOCATION_TYPE_LABELS, sortDirectionArrow, sortOptionsFor, toggleSortState } from '../../shared/schema'
import { formatDate, formatDateTime, searchItems, sortItems } from '../../shared/search'
import { cn, expiryInfoFor, locationOf, levelClass } from './helpers'

export interface CategoryViewProps {
  state: AppState
  category: Category
  hlItemId: string | null
  onBack: () => void
  onNewItem: (categoryId: string) => void
  onEditItem: (item: Item) => void
  onNotes: (item: Item) => void
  onDeleteItem: (item: Item) => void
}

interface ItemRowProps {
  item: Item
  base: BaseTemplate
  notesCount: number
  highlighted: boolean
  onEdit: (item: Item) => void
  onNotes: (item: Item) => void
  onDelete: (item: Item) => void
}

function ItemRow(props: ItemRowProps) {
  const [menuOpen, setMenuOpen] = useState(false)
  const menuRef = useRef<HTMLDivElement | null>(null)
  const rowRef = useRef<HTMLElement | null>(null)

  // 从全局搜索/提醒定位过来时，滚动到高亮条目，保证双列布局下也能立刻看到
  useEffect(
    function () {
      if (props.highlighted && rowRef.current) {
        rowRef.current.scrollIntoView({ block: 'nearest', behavior: 'smooth' })
      }
    },
    [props.highlighted]
  )

  useEffect(function () {
    if (!menuOpen) return
    function onDown(event: MouseEvent): void {
      const box = menuRef.current
      if (box && event.target instanceof Node && !box.contains(event.target)) {
        setMenuOpen(false)
      }
    }
    document.addEventListener('mousedown', onDown)
    return function () {
      document.removeEventListener('mousedown', onDown)
    }
  }, [menuOpen])

  const info = props.base === 'food' || props.base === 'medicine' ? expiryInfoFor(props.item) : null

  return (
    <article ref={rowRef} className={cn('item-row', props.highlighted && 'hl-item')} data-testid="item-row">
      <button
        type="button"
        className="item-main"
        onClick={function () {
          props.onEdit(props.item)
        }}
      >
        <span className="item-name">{props.item.name}</span>
        <span className="item-loc">
          <span className="loc-tag">{LOCATION_TYPE_LABELS[props.item.locationType]}</span>
          <span className="loc-name">{locationOf(props.item)}</span>
        </span>
      </button>

      <div className="item-side">
        {props.base === 'book' ? (
          <span className="item-meta">
            存放 {props.item.fields.storedAt ? formatDate(props.item.fields.storedAt) : '未填'}
          </span>
        ) : null}
        {props.base !== 'book' && props.item.fields.storedAt ? (
          <span className="item-meta">存放 {formatDate(props.item.fields.storedAt)}</span>
        ) : null}
        {props.base === 'food' || props.base === 'medicine' ? (
          info ? (
            <span className="expiry-wrap">
              <span className={cn('item-meta', levelClass(info.level))}>{info.text}</span>
              {info.expired ? <span className="tag expired-tag">已过期</span> : null}
            </span>
          ) : (
            <span className="item-meta">没填过期时间</span>
          )
        ) : null}
        {props.base === 'item' ? <span className="item-meta">更新 {formatDateTime(props.item.updatedAt)}</span> : null}

        {props.notesCount > 0 ? (
          <button
            type="button"
            className="note-count"
            data-testid="item-notes-count"
            onClick={function () {
              props.onNotes(props.item)
            }}
          >
            备注 {props.notesCount}
          </button>
        ) : null}

        <div className="menu-wrap" ref={menuRef}>
          <button
            type="button"
            className="btn ghost sm"
            data-testid="item-more"
            onClick={function () {
              setMenuOpen(!menuOpen)
            }}
          >
            ⋯ 更多
          </button>
          {menuOpen ? (
            <div className="menu">
              <button
                type="button"
                className="menu-item"
                data-testid="item-edit"
                onClick={function () {
                  setMenuOpen(false)
                  props.onEdit(props.item)
                }}
              >
                编辑
              </button>
              <button
                type="button"
                className="menu-item"
                data-testid="item-notes"
                onClick={function () {
                  setMenuOpen(false)
                  props.onNotes(props.item)
                }}
              >
                管理备注
              </button>
              <button
                type="button"
                className="menu-item danger"
                data-testid="item-delete"
                onClick={function () {
                  setMenuOpen(false)
                  props.onDelete(props.item)
                }}
              >
                删除
              </button>
            </div>
          ) : null}
        </div>
      </div>
    </article>
  )
}

export default function CategoryView(props: CategoryViewProps) {
  const category = props.category
  const [query, setQuery] = useState('')
  const [sort, setSort] = useState<SortState>({ mode: 'name', direction: 'asc' })

  const noteCount = useMemo(
    function () {
      const map: Record<string, number> = {}
      const notes = props.state.notes
      for (let i = 0; i < notes.length; i += 1) {
        const current = notes[i]
        map[current.itemId] = (map[current.itemId] || 0) + 1
      }
      return map
    },
    [props.state.notes]
  )

  const options = useMemo(
    function () {
      return sortOptionsFor(category.baseTemplate)
    },
    [category.baseTemplate]
  )

  const items = useMemo(
    function () {
      const value = query.trim()
      let list: Item[]
      if (value) {
        list = searchItems(props.state.items, props.state.categories, props.state.notes, value, {
          categoryId: category.id,
          limit: 500
        }).map(function (hit) {
          return hit.item
        })
      } else {
        list = props.state.items.filter(function (item) {
          return item.categoryId === category.id
        })
      }
      return sortItems(list, sort.mode, sort.direction)
    },
    [props.state.items, props.state.categories, props.state.notes, query, category.id, sort]
  )

  const hasAny = props.state.items.some(function (item) {
    return item.categoryId === category.id
  })

  return (
    <div className="category-view">
      <div className="category-head">
        <button type="button" className="btn ghost" onClick={props.onBack}>
          ← 返回
        </button>
        <h2 className="category-title" data-testid="category-title">
          <span className="cat-title-icon">{category.icon}</span>
          {category.name}
        </h2>
      </div>

      <div className="category-tools">
        <input
          className="cat-search"
          data-testid="cat-search"
          placeholder="在这个分类里搜索…"
          value={query}
          onChange={function (event) {
            setQuery(event.target.value)
          }}
        />
        <div className="sort-group" data-testid="sort-group">
          {options.map(function (option) {
            const active = sort.mode === option.mode
            return (
              <button
                key={option.mode}
                type="button"
                className={cn('sort-btn', active && 'active')}
                data-testid={'sort-' + option.mode}
                data-direction={active ? sort.direction : ''}
                onClick={function () {
                  setSort(function (current) {
                    return toggleSortState(current, option.mode)
                  })
                }}
              >
                {option.label}
                {active ? ' ' + sortDirectionArrow(sort.direction) : ''}
              </button>
            )
          })}
        </div>
        <button
          type="button"
          className="btn primary"
          data-testid="add-item"
          onClick={function () {
            props.onNewItem(category.id)
          }}
        >
          + 新增条目
        </button>
      </div>

      {items.length > 0 ? (
        <div className="item-list">
          {items.map(function (item) {
            return (
              <ItemRow
                key={item.id}
                item={item}
                base={category.baseTemplate}
                notesCount={noteCount[item.id] || 0}
                highlighted={props.hlItemId === item.id}
                onEdit={props.onEditItem}
                onNotes={props.onNotes}
                onDelete={props.onDeleteItem}
              />
            )
          })}
        </div>
      ) : null}

      {items.length === 0 && hasAny ? (
        <div className="empty-box">
          <div className="empty-emoji">🔍</div>
          <p className="empty-text">这个分类里没找到「{query.trim()}」，换个词试试。</p>
          <button
            type="button"
            className="btn ghost"
            onClick={function () {
              setQuery('')
            }}
          >
            清除搜索
          </button>
        </div>
      ) : null}

      {items.length === 0 && !hasAny ? (
        <div className="empty-box">
          <div className="empty-emoji">🗂️</div>
          <p className="empty-text">这里还空着：点右上角「+ 新增条目」，记下第一件东西放在哪儿。</p>
        </div>
      ) : null}
    </div>
  )
}
