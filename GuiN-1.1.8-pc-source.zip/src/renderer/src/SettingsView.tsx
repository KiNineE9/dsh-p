import { useCallback, useEffect, useState } from 'react'
import type { AppSettings, ExpiryTier, ExpiryTierSwitches, ThemeMode } from '../../shared/types'
import type { BackupEntry, DataInfo } from '../../shared/api'
import { formatDateTime } from '../../shared/search'
import { playBeep } from './helpers'
import SyncSection from './SyncSection'

export interface SettingsViewProps {
  settings: AppSettings
  dataInfo: DataInfo | null
  onToast: (message: string) => void
  onQuit: () => void
  onShowOnboarding: () => void
  onBack: () => void
  onRefreshData: () => void
}

interface ThemeChoice {
  mode: ThemeMode
  label: string
  testid: string
}

const THEMES: ThemeChoice[] = [
  { mode: 'light', label: '浅色', testid: 'theme-light' },
  { mode: 'dark', label: '深色', testid: 'theme-dark' },
  { mode: 'system', label: '跟随系统', testid: 'theme-system' }
]

interface TierChoice {
  tier: ExpiryTier
  label: string
  testid: string
}

const TIERS: TierChoice[] = [
  { tier: 30, label: '提前 30 天', testid: 'tier-30' },
  { tier: 15, label: '提前 15 天', testid: 'tier-15' },
  { tier: 7, label: '提前 7 天', testid: 'tier-7' },
  { tier: 1, label: '提前 1 天', testid: 'tier-1' }
]

interface SwitchRowProps {
  testid: string
  label: string
  hint?: string
  on: boolean
  onToggle: () => void
}

function SwitchRow(props: SwitchRowProps) {
  return (
    <div className="setting-row">
      <div className="setting-info">
        <span className="setting-label">{props.label}</span>
        {props.hint ? <span className="setting-hint">{props.hint}</span> : null}
      </div>
      <button
        type="button"
        className={props.on ? 'switch on' : 'switch'}
        data-testid={props.testid}
        role="switch"
        aria-checked={props.on}
        onClick={props.onToggle}
      >
        <span className="switch-track">
          <span className="switch-thumb" />
        </span>
      </button>
    </div>
  )
}

interface BackupSectionProps {
  onToast: (message: string) => void
  onRefresh: () => void
  dir: string
}

function BackupSection(props: BackupSectionProps) {
  const [list, setList] = useState<BackupEntry[]>([])
  const [name, setName] = useState('')
  const [pickOverwrite, setPickOverwrite] = useState(false)
  const [busy, setBusy] = useState(false)
  const [pendingRestore, setPendingRestore] = useState<string | null>(null)

  const reload = useCallback(function () {
    void window.guina
      .listBackups()
      .then(function (res) {
        setList(res)
      })
      .catch(function () {
        return
      })
  }, [])

  useEffect(
    function () {
      reload()
    },
    [reload]
  )

  const full = list.length >= 5

  async function doCreate(overwriteId?: string): Promise<void> {
    if (busy) return
    setBusy(true)
    try {
      const op = await window.guina.createBackup(name.trim(), overwriteId)
      if (op.ok) {
        props.onToast('已备份：' + op.value.name)
        setName('')
        setPickOverwrite(false)
        reload()
        props.onRefresh()
      } else {
        if (op.code === 'backup-limit') {
          setPickOverwrite(true)
        }
        props.onToast(op.error)
      }
    } catch {
      props.onToast('备份失败，请再试一次')
    }
    setBusy(false)
  }

  async function doDelete(id: string): Promise<void> {
    try {
      const op = await window.guina.deleteBackup(id)
      if (op.ok) {
        props.onToast('已删除这份备份')
        reload()
        props.onRefresh()
      } else {
        props.onToast(op.error)
      }
    } catch {
      props.onToast('删除失败，请再试一次')
    }
  }

  async function doRestore(id: string): Promise<void> {
    setBusy(true)
    try {
      const op = await window.guina.restoreBackup(id)
      if (op.ok) {
        props.onToast('已还原到所选备份')
        setPendingRestore(null)
        reload()
        props.onRefresh()
      } else {
        props.onToast(op.error)
      }
    } catch {
      props.onToast('还原失败，请再试一次')
    }
    setBusy(false)
  }

  return (
    <section className="settings-card" data-testid="backup-card">
      <h2 className="card-title">手动备份与还原</h2>
      <p className="setting-hint">
        {'备份保存在 ' + props.dir + '，最多保留 5 份，超出时需要选择覆盖其中一份。'}
      </p>
      <div className="backup-create">
        <input
          data-testid="backup-name-input"
          placeholder="备份名称（可不填，默认当前日期时间）"
          value={name}
          onChange={function (event) {
            setName(event.target.value)
          }}
        />
        <button
          type="button"
          className="btn primary"
          data-testid="backup-create"
          disabled={busy}
          onClick={function () {
            if (full) {
              setPickOverwrite(true)
              props.onToast('备份已有 5 份，请先选择要覆盖的备份')
              return
            }
            void doCreate()
          }}
        >
          立即备份
        </button>
      </div>

      {pickOverwrite && full ? (
        <div className="backup-overwrite" data-testid="backup-overwrite-box">
          <p className="setting-hint">已满 5 份，点下面某一行的「覆盖此备份」用新数据替换它。</p>
        </div>
      ) : null}

      {list.length === 0 ? (
        <p className="setting-hint" data-testid="backup-empty">
          还没有手动备份。
        </p>
      ) : (
        <div className="backup-list">
          {list.map(function (entry) {
            const meta =
              formatDateTime(entry.createdAt) +
              ' · ' +
              entry.items +
              ' 条目 / ' +
              entry.stickies +
              ' 便签 · ' +
              Math.max(1, Math.round(entry.size / 1024)) +
              ' KB'
            return (
              <div className="backup-row" data-testid="backup-row" key={entry.id}>
                <div className="backup-info">
                  <span className="backup-name" data-testid="backup-name">
                    {entry.name}
                  </span>
                  <span className="setting-hint">{meta}</span>
                </div>
                <div className="backup-actions">
                  {pickOverwrite && full ? (
                    <button
                      type="button"
                      className="btn ghost sm"
                      data-testid="backup-overwrite"
                      onClick={function () {
                        void doCreate(entry.id)
                      }}
                    >
                      覆盖此备份
                    </button>
                  ) : null}
                  <button
                    type="button"
                    className="btn ghost sm"
                    data-testid="backup-restore"
                    onClick={function () {
                      setPendingRestore(entry.id)
                    }}
                  >
                    还原
                  </button>
                  <button
                    type="button"
                    className="btn ghost sm danger-text"
                    data-testid="backup-delete"
                    onClick={function () {
                      void doDelete(entry.id)
                    }}
                  >
                    删除
                  </button>
                </div>
              </div>
            )
          })}
        </div>
      )}

      {pendingRestore ? (
        <div className="backup-confirm" data-testid="backup-restore-box">
          <p className="setting-hint">
            还原会用这份备份覆盖当前全部数据。建议先点上方「立即备份」保存一份当前数据，方便回滚。
          </p>
          <div className="quick-row">
            <button
              type="button"
              className="btn ghost sm"
              data-testid="backup-restore-cancel"
              onClick={function () {
                setPendingRestore(null)
              }}
            >
              取消
            </button>
            <button
              type="button"
              className="btn primary sm"
              data-testid="backup-restore-confirm"
              disabled={busy}
              onClick={function () {
                if (pendingRestore) void doRestore(pendingRestore)
              }}
            >
              确认还原
            </button>
          </div>
        </div>
      ) : null}
    </section>
  )
}

export default function SettingsView(props: SettingsViewProps) {
  const settings = props.settings

  function save(patch: Partial<AppSettings>): void {
    void window.guina.updateSettings(patch).then(function (op) {
      if (!op.ok) props.onToast(op.error)
    })
  }

  async function doExportData(): Promise<void> {
    try {
      const op = await window.guina.exportDataFile()
      if (!op.ok) {
        props.onToast(op.error)
        return
      }
      if (op.value.canceled) return
      props.onToast('已导出到 ' + (op.value.path || ''))
    } catch {
      props.onToast('导出失败，请再试一次')
    }
  }

  async function doImportData(): Promise<void> {
    try {
      const op = await window.guina.importDataFile()
      if (!op.ok) {
        if (op.code !== 'canceled') props.onToast(op.error)
        return
      }
      props.onToast(
        '已导入「' + op.value.fileName + '」：' +
        op.value.state.items.length + ' 个条目 / ' +
        op.value.state.stickies.length + ' 条便签'
      )
      props.onRefreshData()
    } catch {
      props.onToast('导入失败，请再试一次')
    }
  }

  function toggleTier(tier: ExpiryTier): void {
    const next: ExpiryTierSwitches = {
      30: settings.expiryTiers[30],
      15: settings.expiryTiers[15],
      7: settings.expiryTiers[7],
      1: settings.expiryTiers[1]
    }
    next[tier] = !next[tier]
    save({ expiryTiers: next })
  }

  const dir = props.dataInfo ? props.dataInfo.dir : '正在读取…'
  const version = props.dataInfo ? props.dataInfo.appVersion : '—'
  const backupCount = props.dataInfo ? props.dataInfo.backups : 0
  const manualDir = props.dataInfo ? props.dataInfo.manualBackupDir : dir
  const lastSaved =
    props.dataInfo && props.dataInfo.lastSavedAt ? '上次保存 ' + formatDateTime(props.dataInfo.lastSavedAt) : '还没保存过'

  return (
    <div className="settings-page" data-testid="settings-page">
      <div className="settings-head">
        <button type="button" className="btn ghost" onClick={props.onBack}>
          ← 返回首页
        </button>
        <h1 className="page-title">设置</h1>
      </div>

      <section className="settings-card">
        <h2 className="card-title">外观</h2>
        <div className="theme-row">
          {THEMES.map(function (item) {
            return (
              <button
                type="button"
                key={item.mode}
                className={settings.theme === item.mode ? 'theme-btn active' : 'theme-btn'}
                data-testid={item.testid}
                onClick={function () {
                  save({ theme: item.mode })
                }}
              >
                {item.label}
              </button>
            )
          })}
        </div>
        <p className="setting-hint">选了就立刻生效。</p>
      </section>

      <section className="settings-card">
        <h2 className="card-title">系统</h2>
        <SwitchRow
          testid="toggle-auto-launch"
          label="开机自动启动"
          on={settings.autoLaunch}
          onToggle={function () {
            save({ autoLaunch: !settings.autoLaunch })
          }}
        />
        <SwitchRow
          testid="toggle-close-to-tray"
          label="关闭窗口时最小化到托盘"
          hint="关闭后点右上角 × 会退出程序。"
          on={settings.closeToTray}
          onToggle={function () {
            save({ closeToTray: !settings.closeToTray })
          }}
        />
      </section>

      <section className="settings-card">
        <h2 className="card-title">提醒</h2>
        <SwitchRow
          testid="toggle-reminder-popup"
          label="提醒弹窗"
          hint="到点了弹一个小窗口提醒你。"
          on={settings.reminderPopup}
          onToggle={function () {
            save({ reminderPopup: !settings.reminderPopup })
          }}
        />
        <SwitchRow
          testid="toggle-reminder-sound"
          label="提示音"
          on={settings.reminderSound}
          onToggle={function () {
            save({ reminderSound: !settings.reminderSound })
          }}
        />
        <div className="quick-row">
          <button
            type="button"
            className="btn ghost sm"
            data-testid="btn-test-sound"
            onClick={function () {
              playBeep()
              props.onToast('已播放测试提示音；如果没听到，请检查系统音量是否静音')
            }}
          >
            测试提示音
          </button>
        </div>
        <p className="setting-hint">提示音跟随系统音量，到点提醒时会播放一声短促提示音。</p>
        <div className="setting-sub-title">食品 / 药品到期提醒档位</div>
        <p className="setting-hint">会提前多久提醒你，可以多选。</p>
        {TIERS.map(function (item) {
          return (
            <SwitchRow
              key={item.testid}
              testid={item.testid}
              label={item.label}
              on={settings.expiryTiers[item.tier]}
              onToggle={function () {
                toggleTier(item.tier)
              }}
            />
          )
        })}
      </section>

      <section className="settings-card">
        <h2 className="card-title">搜索历史</h2>
        <SwitchRow
          testid="toggle-search-history-item"
          label="记录「搜索物品或存放位置」的历史"
          hint="默认开启；搜索过的词会出现在搜索框下拉里，最多保留 50 条、显示最近 5 条。"
          on={settings.itemSearchHistory}
          onToggle={function () {
            save({ itemSearchHistory: !settings.itemSearchHistory })
          }}
        />
        <SwitchRow
          testid="toggle-search-history-sticky"
          label="记录「便签与提醒」的搜索历史"
          hint="默认开启；关掉后不再记录新的关键词，已记录的也会隐藏。"
          on={settings.stickySearchHistory}
          onToggle={function () {
            save({ stickySearchHistory: !settings.stickySearchHistory })
          }}
        />
      </section>

      <section className="settings-card">
        <h2 className="card-title">新手引导</h2>
        <p className="setting-hint">忘了怎么用？再看一遍。</p>
        <button type="button" className="btn ghost" data-testid="btn-show-onboarding" onClick={props.onShowOnboarding}>
          重新查看新手引导
        </button>
      </section>

      <section className="settings-card">
        <h2 className="card-title">数据</h2>
        <p className="setting-hint path-text">{dir}</p>
        <p className="setting-hint">
          {'会自动备份最近 7 份，现在有 ' + backupCount + ' 份，' + lastSaved + '。'}
        </p>
        <button
          type="button"
          className="btn ghost"
          data-testid="btn-open-data"
          onClick={function () {
            void window.guina.openDataFolder()
          }}
        >
          打开数据文件夹
        </button>
        <div className="quick-row">
          <button
            type="button"
            className="btn ghost sm"
            data-testid="btn-export-data"
            onClick={function () {
              void doExportData()
            }}
          >
            导出 data.json
          </button>
          <button
            type="button"
            className="btn ghost sm"
            data-testid="btn-import-data"
            onClick={function () {
              void doImportData()
            }}
          >
            导入 data.json
          </button>
        </div>
        <p className="setting-hint">
          导出的文件可以拿到另一台设备（电脑或手机）导入；导入前会自动备份当前数据。
        </p>
      </section>

      <SyncSection onToast={props.onToast} />

      <BackupSection onToast={props.onToast} onRefresh={props.onRefreshData} dir={manualDir} />

      <section className="settings-card about-card" data-testid="about-card">
        <h2 className="card-title">关于</h2>
        <div className="about-head">
          <span className="about-logo">📦</span>
          <div className="about-title">
            <p className="about-name" data-testid="about-name">GuiN</p>
            <p className="setting-hint">使用 DSH 制作的个人生活记忆库软件 · 开源</p>
          </div>
        </div>
        <ul className="about-list">
          <li className="about-row">
            <span className="about-key">GitHub</span>
            <button
              type="button"
              className="about-link"
              data-testid="about-github"
              onClick={function () {
                void window.guina.openExternal('https://github.com/KiNineE9')
              }}
            >
              @KiNineE9
            </button>
          </li>
          <li className="about-row">
            <span className="about-key">Bilibili</span>
            <button
              type="button"
              className="about-link"
              data-testid="about-bilibili"
              onClick={function () {
                void window.guina.openExternal('https://space.bilibili.com/28867358')
              }}
            >
              @梦境薇凉i
            </button>
          </li>
          <li className="about-row">
            <span className="about-key">邮箱</span>
            <button
              type="button"
              className="about-link"
              data-testid="about-email"
              onClick={function () {
                void window.guina.openExternal('mailto:1332004191@qq.com')
              }}
            >
              1332004191@qq.com
            </button>
          </li>
          <li className="about-row">
            <span className="about-key">授权</span>
            <span className="about-value" data-testid="about-license">仅限个人使用</span>
          </li>
          <li className="about-row">
            <span className="about-key">同步</span>
            <span className="about-value" data-testid="about-sync-credit">
              数据同步功能基于 PeerJS 制作（MIT，© Michelle Bu / Eric Zhang）
            </span>
          </li>
          <li className="about-row">
            <span className="about-key">项目</span>
            <button
              type="button"
              className="about-link"
              data-testid="about-peerjs"
              onClick={function () {
                void window.guina.openExternal('https://github.com/peers/peerjs')
              }}
            >
              github.com/peers/peerjs
            </button>
          </li>
          <li className="about-row">
            <span className="about-key">版本</span>
            <span className="about-value" data-testid="about-version">版本 {version}</span>
          </li>
        </ul>
      </section>

      <section className="settings-card">
        <h2 className="card-title">退出</h2>
        <p className="setting-hint">退出后就不再收到提醒了。退出时会自动清理缓存文件，不影响你保存的数据。</p>
        <button type="button" className="btn danger" data-testid="btn-quit" onClick={props.onQuit}>
          退出应用
        </button>
      </section>
    </div>
  )
}
