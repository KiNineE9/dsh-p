import { useCallback, useEffect, useState } from 'react'
import QRCode from 'qrcode'
import type { PairingSession, SyncBinding, SyncConfig, SyncMode, SyncProgress, SyncResult } from '../../shared/sync/types'
import { formatDateTime } from '../../shared/search'
import { getSyncRuntime, onSyncConfig, onSyncProgress } from './syncClient'
import { bindingLabel } from '../../shared/sync/runtime'

export interface SyncSectionProps {
  onToast: (message: string) => void
}

interface PendingSync {
  binding: SyncBinding
  mode: SyncMode
}

const MODE_LABEL: Record<SyncMode, string> = {
  push: '把本机数据发给对方',
  pull: '从对方获取数据',
  merge: '合并双方数据'
}

function kindText(kind: SyncBinding['kind']): string {
  return kind === 'android' ? '手机 / 平板' : '电脑'
}

function statsText(result: SyncResult): string {
  if (result.mode === 'push') return '已把本机数据发送给「' + result.peerName + '」'
  if (result.mode === 'pull') return '已从「' + result.peerName + '」获取数据'
  return (
    '合并完成：新增 ' +
    result.stats.added +
    ' 条、更新 ' +
    result.stats.updated +
    ' 条、跳过重复 ' +
    result.stats.duplicates +
    ' 条'
  )
}

export default function SyncSection(props: SyncSectionProps) {
  const [config, setConfig] = useState<SyncConfig | null>(null)
  const [name, setName] = useState('')
  const [busy, setBusy] = useState('')
  const [progress, setProgress] = useState<SyncProgress | null>(null)
  const [session, setSession] = useState<PairingSession | null>(null)
  const [qr, setQr] = useState('')
  const [joinOpen, setJoinOpen] = useState(false)
  const [joinText, setJoinText] = useState('')
  const [joinCode, setJoinCode] = useState('')
  const [pending, setPending] = useState<PendingSync | null>(null)
  const [pendingUnbind, setPendingUnbind] = useState<string | null>(null)
  const [checking, setChecking] = useState('')
  const [online, setOnline] = useState<Record<string, { online: boolean; checkedAt: string }>>({})
  const [aliasEditing, setAliasEditing] = useState<string | null>(null)
  const [aliasDraft, setAliasDraft] = useState('')

  const applyConfig = useCallback(function (next: SyncConfig): void {
    setConfig(next)
    setName(next.identity.name)
  }, [])

  useEffect(
    function () {
      let alive = true
      void window.guina.getSyncConfig().then(function (stored) {
        if (!alive || !stored) return
        applyConfig(stored)
      })
      const offConfig = onSyncConfig(function (next) {
        applyConfig(next)
      })
      const offProgress = onSyncProgress(function (next) {
        setProgress(next)
      })
      return function () {
        alive = false
        offConfig()
        offProgress()
      }
    },
    [applyConfig]
  )

  async function saveName(): Promise<void> {
    const rt = getSyncRuntime()
    if (!rt) return
    try {
      const next = await rt.setDeviceName(name)
      setConfig(next)
      props.onToast('设备名已改为「' + next.identity.name + '」')
    } catch (err) {
      props.onToast(err instanceof Error ? err.message : '改名失败')
    }
  }

  async function beginPairing(): Promise<void> {
    const rt = getSyncRuntime()
    if (!rt) {
      props.onToast('同步服务还没准备好，请稍后再试')
      return
    }
    setBusy('pairing')
    try {
      const started = await rt.startPairing()
      setSession(started)
      const dataUrl = await QRCode.toDataURL(started.text, { margin: 1, width: 220 })
      setQr(dataUrl)
      const binding = await rt.waitPairing()
      props.onToast('已与「' + binding.name + '」绑定成功')
    } catch (err) {
      props.onToast(err instanceof Error ? err.message : '绑定失败')
    } finally {
      setSession(null)
      setQr('')
      setBusy('')
    }
  }

  function cancelPairing(): void {
    const rt = getSyncRuntime()
    if (rt) rt.cancelPairing()
    setSession(null)
    setQr('')
    setBusy('')
  }

  async function copyInvite(): Promise<void> {
    if (!session) return
    try {
      await navigator.clipboard.writeText(session.text)
      props.onToast('邀请文本已复制，发给对方即可')
    } catch {
      props.onToast('复制失败，请手动选中文本复制')
    }
  }

  async function doJoin(): Promise<void> {
    const rt = getSyncRuntime()
    if (!rt) return
    if (!joinText.trim()) {
      props.onToast('请先粘贴对方发来的邀请文本')
      return
    }
    setBusy('join')
    try {
      const binding = await rt.joinPairing(joinText.trim(), joinCode)
      props.onToast('已与「' + binding.name + '」绑定成功')
      setJoinOpen(false)
      setJoinText('')
      setJoinCode('')
    } catch (err) {
      props.onToast(err instanceof Error ? err.message : '绑定失败')
    } finally {
      setBusy('')
    }
  }

  async function runSync(target: PendingSync): Promise<void> {
    const rt = getSyncRuntime()
    if (!rt) return
    setBusy(target.mode + ':' + target.binding.deviceId)
    setPending(null)
    try {
      const result = await rt.sync(target.binding, target.mode)
      props.onToast(statsText(result))
    } catch (err) {
      props.onToast(err instanceof Error ? err.message : '同步失败')
    } finally {
      setBusy('')
    }
  }

  async function unbind(deviceId: string): Promise<void> {
    const rt = getSyncRuntime()
    if (!rt) return
    try {
      const next = await rt.removeBinding(deviceId)
      setConfig(next)
      setPendingUnbind(null)
      props.onToast('已解绑这台设备')
    } catch (err) {
      props.onToast(err instanceof Error ? err.message : '解绑失败')
    }
  }

  async function checkOnline(deviceId: string): Promise<void> {
    const rt = getSyncRuntime()
    if (!rt) return
    setChecking(deviceId)
    try {
      const result = await rt.checkBinding(deviceId)
      setOnline(function (prev) {
        const next = Object.assign({}, prev)
        next[deviceId] = { online: result.online, checkedAt: result.checkedAt }
        return next
      })
      props.onToast(result.online ? '设备在线，可以同步' : '设备不在线：' + (result.message || '请确认对方已打开 GuiN 并联网'))
    } catch (err) {
      props.onToast(err instanceof Error ? err.message : '检测失败')
    } finally {
      setChecking('')
    }
  }

  function beginAlias(binding: SyncBinding): void {
    setAliasEditing(binding.deviceId)
    setAliasDraft(binding.alias || '')
  }

  async function saveAlias(binding: SyncBinding): Promise<void> {
    const rt = getSyncRuntime()
    if (!rt) return
    try {
      const next = await rt.setBindingAlias(binding.deviceId, aliasDraft)
      setConfig(next)
      setAliasEditing(null)
      const saved = next.bindings.find(function (b) { return b.deviceId === binding.deviceId })
      props.onToast(saved && saved.alias ? '备注已保存为「' + saved.alias + '」' : '已清除备注，恢复显示对方设备名')
    } catch (err) {
      props.onToast(err instanceof Error ? err.message : '保存备注失败')
    }
  }

  const bindings = config ? config.bindings : []
  const identity = config ? config.identity : null

  return (
    <section className="settings-card" data-testid="sync-card">
      <h2 className="card-title">数据同步（手机 / 电脑互传）</h2>
      <p className="setting-hint">
        {'同一网络下优先局域网直连，不在同一网络时自动走 P2P。数据和绑定信息端到端加密，同步前会自动备份，失败会回滚。'}
      </p>

      {identity ? (
        <div className="sync-identity">
          <div className="sync-name-row">
            <span className="setting-label">设备名</span>
            <input
              className="input"
              data-testid="sync-device-name"
              value={name}
              maxLength={24}
              onChange={function (event) {
                setName(event.target.value)
              }}
            />
            <button type="button" className="btn ghost sm" data-testid="sync-save-name" onClick={function () { void saveName() }}>
              保存
            </button>
          </div>
          <p className="setting-hint">
            {'机器码：'}
            <code className="sync-code" data-testid="sync-machine-code">{identity.machineCode}</code>
            {'（对方可核对这台设备）'}
          </p>
        </div>
      ) : (
        <p className="setting-hint" data-testid="sync-loading">正在读取本机同步身份…</p>
      )}

      <div className="setting-sub-title">已绑定设备（{bindings.length}）</div>
      {bindings.length === 0 ? (
        <p className="setting-hint" data-testid="sync-binding-empty">
          还没有绑定任何设备。点下面的「绑定新设备」生成二维码和六位数字，让另一台设备扫或输入。
        </p>
      ) : (
        <div className="sync-bindings">
          {bindings.map(function (binding) {
            const last = binding.lastSyncAt ? formatDateTime(binding.lastSyncAt) : '还没同步过'
            const busyKey = busy
            const presence = online[binding.deviceId]
            return (
              <div className="sync-device" data-testid="sync-binding" key={binding.deviceId}>
                <div className="sync-device-head">
                  <span className="sync-device-name" data-testid="sync-binding-name">{bindingLabel(binding)}</span>
                  {binding.alias ? <span className="sync-device-alias-note">备注</span> : null}
                  <span className="sync-device-tag">{kindText(binding.kind)}</span>
                  <span
                    className={'sync-online' + (presence ? (presence.online ? ' on' : ' off') : '')}
                    data-testid="sync-online-badge"
                  >
                    {checking === binding.deviceId ? '检测中…' : presence ? (presence.online ? '在线' : '离线') : '未检测'}
                  </span>
                </div>
                <p className="setting-hint" data-testid="sync-binding-meta">
                  {'机器码 ' + binding.machineCode + ' · 上次同步 ' + last}
                  {binding.lastSeenAt ? ' · 上次在线 ' + formatDateTime(binding.lastSeenAt) : ''}
                </p>
                {aliasEditing === binding.deviceId ? (
                  <div className="sync-alias-row">
                    <input
                      className="input"
                      data-testid="sync-alias-input"
                      value={aliasDraft}
                      maxLength={24}
                      placeholder="给这台设备起个备注；留空则显示对方设备名"
                      onChange={function (event) { setAliasDraft(event.target.value) }}
                    />
                    <button type="button" className="btn primary sm" data-testid="sync-alias-save" onClick={function () { void saveAlias(binding) }}>
                      保存
                    </button>
                    <button type="button" className="btn ghost sm" data-testid="sync-alias-cancel" onClick={function () { setAliasEditing(null) }}>
                      取消
                    </button>
                  </div>
                ) : null}
                <div className="sync-device-actions">
                  <button
                    type="button"
                    className="btn ghost sm"
                    data-testid="sync-check-online"
                    disabled={!!busyKey || checking === binding.deviceId}
                    onClick={function () { void checkOnline(binding.deviceId) }}
                  >
                    {checking === binding.deviceId ? '检测中…' : '检测在线'}
                  </button>
                  <button
                    type="button"
                    className="btn ghost sm"
                    data-testid="sync-alias-edit"
                    disabled={!!busyKey}
                    onClick={function () { beginAlias(binding) }}
                  >
                    备注
                  </button>
                  <button
                    type="button"
                    className="btn ghost sm"
                    data-testid="sync-push"
                    disabled={!!busyKey}
                    onClick={function () { setPending({ binding, mode: 'push' }) }}
                  >
                    发给它
                  </button>
                  <button
                    type="button"
                    className="btn ghost sm"
                    data-testid="sync-pull"
                    disabled={!!busyKey}
                    onClick={function () { setPending({ binding, mode: 'pull' }) }}
                  >
                    从它获取
                  </button>
                  <button
                    type="button"
                    className="btn ghost sm"
                    data-testid="sync-merge"
                    disabled={!!busyKey}
                    onClick={function () { setPending({ binding, mode: 'merge' }) }}
                  >
                    合并
                  </button>
                  <button
                    type="button"
                    className="btn ghost sm danger-text"
                    data-testid="sync-unbind"
                    disabled={!!busyKey}
                    onClick={function () { setPendingUnbind(binding.deviceId) }}
                  >
                    解绑
                  </button>
                </div>
                {identity && binding.kind !== identity.kind ? (
                  <p className="setting-hint" data-testid="sync-scope-hint">
                    手机 ↔ 电脑同步只同步分类、条目和备注，不同步便签与提醒（便签属于各自设备）。
                  </p>
                ) : null}
                {pending && pending.binding.deviceId === binding.deviceId ? (
                  <div className="sync-confirm" data-testid="sync-confirm">
                    <p className="setting-hint">
                      {'确定要' + MODE_LABEL[pending.mode] + '吗？同步前会自动备份双方数据。'}
                    </p>
                    <div className="quick-row">
                      <button type="button" className="btn ghost sm" data-testid="sync-confirm-cancel" onClick={function () { setPending(null) }}>
                        取消
                      </button>
                      <button
                        type="button"
                        className="btn primary sm"
                        data-testid="sync-confirm-run"
                        disabled={!!busyKey}
                        onClick={function () { void runSync(pending) }}
                      >
                        开始
                      </button>
                    </div>
                  </div>
                ) : null}
                {pendingUnbind === binding.deviceId ? (
                  <div className="sync-confirm" data-testid="sync-unbind-confirm">
                    <p className="setting-hint">解绑后这台设备需要重新扫码/邀请码才能再同步。</p>
                    <div className="quick-row">
                      <button type="button" className="btn ghost sm" data-testid="sync-unbind-cancel" onClick={function () { setPendingUnbind(null) }}>
                        取消
                      </button>
                      <button type="button" className="btn danger sm" data-testid="sync-unbind-run" onClick={function () { void unbind(binding.deviceId) }}>
                        确认解绑
                      </button>
                    </div>
                  </div>
                ) : null}
              </div>
            )
          })}
        </div>
      )}

      {session ? (
        <div className="sync-pairing" data-testid="sync-pairing">
          <p className="setting-hint">用另一台设备扫描下面的二维码，或把邀请文本复制过去；对方需要输入这个六位数字：</p>
          <div className="sync-pair-code" data-testid="sync-pair-code">{session.code}</div>
          {qr ? <img className="sync-qr" data-testid="sync-qr" src={qr} alt="配对二维码" /> : null}
          <textarea
            className="textarea sync-invite"
            data-testid="sync-invite-text"
            readOnly
            value={session.text}
          />
          <div className="quick-row">
            <button type="button" className="btn ghost sm" data-testid="sync-copy-invite" onClick={function () { void copyInvite() }}>
              复制邀请文本
            </button>
            <button type="button" className="btn ghost sm" data-testid="sync-cancel-pairing" onClick={cancelPairing}>
              取消绑定
            </button>
          </div>
          {progress ? <p className="setting-hint" data-testid="sync-pair-status">{progress.message}</p> : null}
        </div>
      ) : (
        <div className="quick-row">
          <button type="button" className="btn primary sm" data-testid="sync-bind-new" disabled={!!busy} onClick={function () { void beginPairing() }}>
            绑定新设备
          </button>
          <button
            type="button"
            className="btn ghost sm"
            data-testid="sync-join-open"
            onClick={function () { setJoinOpen(!joinOpen) }}
          >
            我是被绑定方
          </button>
        </div>
      )}

      {joinOpen ? (
        <div className="sync-join" data-testid="sync-join-box">
          <p className="setting-hint">把对方显示的邀请文本粘贴到这里，再输入对方告诉你的六位数字。</p>
          <textarea
            className="textarea"
            data-testid="sync-join-text"
            placeholder="粘贴邀请文本"
            value={joinText}
            onChange={function (event) { setJoinText(event.target.value) }}
          />
          <div className="quick-row">
            <input
              className="input sync-code-input"
              data-testid="sync-join-code"
              placeholder="六位数字"
              inputMode="numeric"
              maxLength={6}
              value={joinCode}
              onChange={function (event) { setJoinCode(event.target.value.replace(/\D/g, '')) }}
            />
            <button type="button" className="btn primary sm" data-testid="sync-join-confirm" disabled={busy === 'join'} onClick={function () { void doJoin() }}>
              确认绑定
            </button>
          </div>
        </div>
      ) : null}

      {progress && !session ? (
        <p className="setting-hint" data-testid="sync-progress">{progress.message}</p>
      ) : null}
    </section>
  )
}
