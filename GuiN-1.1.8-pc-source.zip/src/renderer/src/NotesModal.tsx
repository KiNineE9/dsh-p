import { useState } from 'react'
import type { Item, Note } from '../../shared/types'
import { formatDateTime } from '../../shared/search'
import Modal from './Modal'

export interface NotesModalProps {
  item: Item
  notes: Note[]
  onClose: () => void
  onToast: (message: string) => void
}

export default function NotesModal(props: NotesModalProps) {
  const [text, setText] = useState('')
  const [editingId, setEditingId] = useState<string | null>(null)
  const [editText, setEditText] = useState('')
  const [deletingId, setDeletingId] = useState<string | null>(null)

  const list = props.notes
    .slice()
    .sort(function (a, b) {
      return a.createdAt.localeCompare(b.createdAt)
    })

  async function addNote(): Promise<void> {
    const content = text.trim()
    if (!content) {
      props.onToast('先写点备注内容吧')
      return
    }
    try {
      const op = await window.guina.addNote(props.item.id, content)
      if (op.ok) {
        setText('')
        props.onToast('备注已添加')
      } else {
        props.onToast(op.error)
      }
    } catch {
      props.onToast('添加失败，请再试一次')
    }
  }

  async function saveEdit(id: string): Promise<void> {
    const content = editText.trim()
    if (!content) {
      props.onToast('备注不能是空的')
      return
    }
    try {
      const op = await window.guina.updateNote(id, content)
      if (op.ok) {
        setEditingId(null)
        setEditText('')
        props.onToast('备注已改好')
      } else {
        props.onToast(op.error)
      }
    } catch {
      props.onToast('保存失败，请再试一次')
    }
  }

  async function removeNote(id: string): Promise<void> {
    try {
      const op = await window.guina.deleteNote(id)
      if (op.ok) {
        setDeletingId(null)
        props.onToast('备注已删除')
      } else {
        props.onToast(op.error)
      }
    } catch {
      props.onToast('删除失败，请再试一次')
    }
  }

  const footer = (
    <div className="foot-row">
      <button type="button" className="btn ghost" data-testid="modal-cancel" onClick={props.onClose}>
        关闭
      </button>
    </div>
  )

  return (
    <Modal title={'备注 · ' + props.item.name} onClose={props.onClose} footer={footer} width={520}>
      <div className="note-add-row">
        <input
          className="note-input"
          data-testid="note-input"
          placeholder="写点备注，比如放在第几层、什么时候买的…"
          value={text}
          onChange={function (event) {
            setText(event.target.value)
          }}
        />
        <button type="button" className="btn primary" data-testid="note-add" onClick={function () { void addNote() }}>
          添加备注
        </button>
      </div>

      <div className="notes-list" data-testid="notes-list">
        {list.length === 0 ? <p className="notes-empty">还没有备注，在上面写一条吧。</p> : null}
        {list.map(function (note) {
          const editing = editingId === note.id
          return (
            <div className="note-item" data-testid="note-item" key={note.id}>
              {editing ? (
                <div className="note-edit-box">
                  <textarea
                    rows={2}
                    value={editText}
                    onChange={function (event) {
                      setEditText(event.target.value)
                    }}
                  />
                  <div className="note-actions">
                    <button type="button" className="btn ghost sm" onClick={function () { setEditingId(null) }}>
                      取消
                    </button>
                    <button type="button" className="btn primary sm" onClick={function () { void saveEdit(note.id) }}>
                      保存
                    </button>
                  </div>
                </div>
              ) : (
                <div className="note-view">
                  <p className="note-content">{note.content}</p>
                  <span className="note-time">{formatDateTime(note.createdAt)}</span>
                  <div className="note-actions">
                    <button
                      type="button"
                      className="btn ghost sm"
                      data-testid="note-edit"
                      onClick={function () {
                        setEditingId(note.id)
                        setEditText(note.content)
                        setDeletingId(null)
                      }}
                    >
                      改
                    </button>
                    <button
                      type="button"
                      className="btn ghost sm danger-text"
                      data-testid="note-delete"
                      onClick={function () {
                        setDeletingId(note.id)
                        setEditingId(null)
                      }}
                    >
                      删
                    </button>
                  </div>
                </div>
              )}
              {deletingId === note.id ? (
                <div className="note-confirm">
                  <span>删除这条备注？删除后不可恢复。</span>
                  <button type="button" className="btn ghost sm" data-testid="modal-cancel" onClick={function () { setDeletingId(null) }}>
                    取消
                  </button>
                  <button type="button" className="btn danger sm" data-testid="modal-confirm" onClick={function () { void removeNote(note.id) }}>
                    删除
                  </button>
                </div>
              ) : null}
            </div>
          )
        })}
      </div>
    </Modal>
  )
}
