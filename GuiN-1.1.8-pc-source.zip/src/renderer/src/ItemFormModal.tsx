import { useMemo, useState } from 'react'
import type { Category, Item, ItemDraft, LocationType, SavedNames } from '../../shared/types'
import type { FieldDef } from '../../shared/schema'
import { emptyDraftFor, getFormSchema, validateItemDraft } from '../../shared/schema'
import Modal from './Modal'

export interface ItemFormModalProps {
  category: Category
  item: Item | null
  savedNames: SavedNames
  onClose: () => void
  onToast: (message: string) => void
}

function draftFromItem(item: Item): ItemDraft {
  const fields = item.fields
  return {
    name: item.name,
    locationType: item.locationType,
    locationLabel: item.locationLabel || '',
    locationName: item.locationName || '',
    fields: {
      storedAt: fields.storedAt,
      foodType: fields.foodType,
      medicineType: fields.medicineType,
      opened: fields.opened,
      expiresAt: fields.expiresAt,
      effect: fields.effect,
      custom: fields.custom ? { ...fields.custom } : undefined
    }
  }
}

function readField(draft: ItemDraft, key: string): string | boolean {
  if (key.indexOf('custom.') === 0) {
    const ck = key.slice('custom.'.length)
    const record = draft.fields.custom
    if (!record) return ''
    const value = record[ck]
    return value === undefined ? '' : value
  }
  if (key === 'opened') return draft.fields.opened === true
  if (key === 'foodType') return draft.fields.foodType === 'liquid' ? '液体' : '固体'
  if (key === 'medicineType') return draft.fields.medicineType === 'liquid' ? '液体' : '固体'
  if (key === 'storedAt') return draft.fields.storedAt || ''
  if (key === 'expiresAt') return draft.fields.expiresAt || ''
  const raw = (draft.fields as unknown as Record<string, unknown>)[key]
  return raw === undefined || raw === null ? '' : String(raw)
}

function isTrueValue(value: string | boolean): boolean {
  return value === true || value === 'true' || value === '是'
}

function writeField(draft: ItemDraft, key: string, value: string | boolean): ItemDraft {
  const next: ItemDraft = { ...draft, fields: { ...draft.fields } }
  if (key.indexOf('custom.') === 0) {
    const ck = key.slice('custom.'.length)
    const record: Record<string, string> = { ...(draft.fields.custom || {}) }
    record[ck] = typeof value === 'boolean' ? (value ? 'true' : 'false') : value
    next.fields.custom = record
    return next
  }
  if (key === 'opened') {
    next.fields.opened = value === true || value === 'true'
  } else if (key === 'foodType') {
    next.fields.foodType = value === '液体' || value === 'liquid' ? 'liquid' : 'solid'
  } else if (key === 'medicineType') {
    next.fields.medicineType = value === '液体' || value === 'liquid' ? 'liquid' : 'solid'
  } else if (key === 'storedAt') {
    next.fields.storedAt = String(value)
  } else if (key === 'expiresAt') {
    next.fields.expiresAt = String(value)
  } else {
    const record = next.fields as unknown as Record<string, unknown>
    record[key] = typeof value === 'boolean' ? value : String(value)
  }
  return next
}

function FieldError(props: { message: string | undefined }) {
  if (!props.message) return null
  return (
    <span className="field-error" data-testid="form-error">
      {props.message}
    </span>
  )
}

export default function ItemFormModal(props: ItemFormModalProps) {
  const category = props.category
  const [draft, setDraft] = useState<ItemDraft>(function () {
    if (props.item) return draftFromItem(props.item)
    return emptyDraftFor(category.baseTemplate)
  })
  const [errors, setErrors] = useState<Record<string, string>>({})
  const [saving, setSaving] = useState(false)
  const [pickOpen, setPickOpen] = useState(false)
  const schema = useMemo(
    function () {
      return getFormSchema(category.baseTemplate, category.customFields)
    },
    [category]
  )

  const savedForType = props.savedNames[draft.locationType] || []
  const labelCaption = draft.locationType === 'container' ? '容器名称' : '地点名称'
  const labelPlaceholder =
    draft.locationType === 'container' ? '例如：行李箱、衣柜、收纳盒' : schema.labelPlaceholder

  function changeField(key: string, value: string | boolean): void {
    setDraft(function (current) {
      return writeField(current, key, value)
    })
  }

  function switchType(type: LocationType): void {
    setDraft(function (current) {
      if (current.locationType === type) return current
      return { ...current, locationType: type }
    })
    setPickOpen(false)
  }

  async function removeSaved(name: string): Promise<void> {
    try {
      const op = await window.guina.removeSavedName(draft.locationType, name)
      if (op.ok) props.onToast('已删除保存的名称：' + name)
      else props.onToast(op.error)
    } catch {
      props.onToast('删除失败，请再试一次')
    }
  }

  async function submit(): Promise<void> {
    const check = validateItemDraft(draft, category.baseTemplate, category.customFields)
    if (!check.ok) {
      setErrors(check.errors)
      return
    }
    setErrors({})
    setSaving(true)
    try {
      const op = props.item
        ? await window.guina.updateItem(props.item.id, draft)
        : await window.guina.createItem(category.id, draft)
      if (op.ok) {
        props.onToast(props.item ? '已更新' : '已记好：' + draft.name.trim())
        props.onClose()
      } else {
        setSaving(false)
        props.onToast(op.error)
      }
    } catch {
      setSaving(false)
      props.onToast('保存失败，请再试一次')
    }
  }

  function inputType(type: string): string {
    if (type === 'number') return 'number'
    if (type === 'date') return 'date'
    return 'text'
  }

  function renderField(field: FieldDef) {
    const value = readField(draft, field.key)
    const kind: string = field.type
    const label = (
      <span className="field-label">
        {field.label}
        {field.required ? <b className="req">*</b> : null}
      </span>
    )
    const testid = 'form-field-' + field.key

    if (kind === 'boolean') {
      const on = isTrueValue(value)
      return (
        <div className="field" key={field.key}>
          {label}
          <div className="seg">
            <button
              type="button"
              className={on ? 'seg-btn active' : 'seg-btn'}
              data-testid={testid}
              onClick={function () {
                changeField(field.key, true)
              }}
            >
              是
            </button>
            <button
              type="button"
              className={on ? 'seg-btn' : 'seg-btn active'}
              data-testid={testid + '-no'}
              onClick={function () {
                changeField(field.key, false)
              }}
            >
              否
            </button>
          </div>
          {field.hint ? <span className="field-hint">{field.hint}</span> : null}
          <FieldError message={errors[field.key]} />
        </div>
      )
    }

    if (kind === 'textarea') {
      return (
        <label className="field" key={field.key}>
          {label}
          <textarea
            rows={3}
            data-testid={testid}
            placeholder={field.placeholder || ''}
            value={String(value)}
            onChange={function (event) {
              changeField(field.key, event.target.value)
            }}
          />
          <FieldError message={errors[field.key]} />
        </label>
      )
    }

    if (kind === 'select') {
      const options = field.options || []
      return (
        <label className="field" key={field.key}>
          {label}
          <select
            data-testid={testid}
            value={String(value)}
            onChange={function (event) {
              changeField(field.key, event.target.value)
            }}
          >
            <option value="">请选择</option>
            {options.map(function (option) {
              return (
                <option key={option} value={option}>
                  {option}
                </option>
              )
            })}
          </select>
          <FieldError message={errors[field.key]} />
        </label>
      )
    }

    return (
      <label className="field" key={field.key}>
        {label}
        <input
          type={inputType(kind)}
          data-testid={testid}
          placeholder={field.placeholder || ''}
          value={String(value)}
          onChange={function (event) {
            changeField(field.key, event.target.value)
          }}
        />
        {field.hint ? <span className="field-hint">{field.hint}</span> : null}
        <FieldError message={errors[field.key]} />
      </label>
    )
  }

  const footer = (
    <div className="foot-row">
      <button type="button" className="btn ghost" data-testid="modal-cancel" onClick={props.onClose}>
        取消
      </button>
      <button type="button" className="btn primary" data-testid="form-submit" disabled={saving} onClick={function () { void submit() }}>
        {props.item ? '保存' : '记下来'}
      </button>
    </div>
  )

  return (
    <Modal title={props.item ? '编辑条目' : '新增条目'} onClose={props.onClose} footer={footer} width={520}>
      <label className="field">
        <span className="field-label">
          {schema.nameLabel}
          <b className="req">*</b>
        </span>
        <input
          data-testid="form-name"
          placeholder={schema.namePlaceholder}
          value={draft.name}
          onChange={function (event) {
            const value = event.target.value
            setDraft(function (current) {
              return { ...current, name: value }
            })
          }}
        />
        <FieldError message={errors['name']} />
      </label>

      <div className="field">
        <span className="field-label">存放在</span>
        <div className="seg">
          <button
            type="button"
            className={draft.locationType === 'place' ? 'seg-btn active' : 'seg-btn'}
            data-testid="form-location-place"
            onClick={function () {
              switchType('place')
            }}
          >
            地点
          </button>
          <button
            type="button"
            className={draft.locationType === 'container' ? 'seg-btn active' : 'seg-btn'}
            data-testid="form-location-container"
            onClick={function () {
              switchType('container')
            }}
          >
            容器
          </button>
        </div>
      </div>

      <div className="field">
        <span className="field-label">
          {labelCaption}
          <b className="req">*</b>
        </span>
        <div className="input-with-pick">
          <input
            data-testid="form-location-name"
            placeholder={labelPlaceholder}
            value={draft.locationLabel}
            onChange={function (event) {
              const value = event.target.value
              setDraft(function (current) {
                return { ...current, locationLabel: value }
              })
            }}
          />
          <button
            type="button"
            className={savedForType.length > 0 ? 'pick-toggle' : 'pick-toggle disabled'}
            data-testid="saved-toggle"
            title={savedForType.length > 0 ? '选择保存过的名称' : '还没有保存过的名称'}
            disabled={savedForType.length === 0}
            onClick={function () {
              setPickOpen(!pickOpen)
            }}
          >
            {pickOpen ? '▴' : '▾'}
          </button>
        </div>
        <FieldError message={errors['locationLabel']} />
        {pickOpen && savedForType.length > 0 ? (
          <div className="pick-list" data-testid="saved-list">
            <div className="pick-head" data-testid="saved-list-title">
              {draft.locationType === 'container' ? '保存过的容器名称' : '保存过的地点名称'}
            </div>
            {savedForType.map(function (entry) {
              return (
                <div className="pick-row" key={entry.name}>
                  <button
                    type="button"
                    className="pick-name"
                    data-testid="saved-name-option"
                    onClick={function () {
                      setDraft(function (current) {
                        return { ...current, locationLabel: entry.name }
                      })
                      setPickOpen(false)
                    }}
                  >
                    {entry.name}
                  </button>
                  <button
                    type="button"
                    className="pick-remove"
                    data-testid="saved-name-remove"
                    title="删除这个保存过的名称"
                    onClick={function () {
                      void removeSaved(entry.name)
                    }}
                  >
                    ×
                  </button>
                </div>
              )
            })}
            <p className="field-hint">点名称一键填入；点 × 删除这个保存过的名称。</p>
          </div>
        ) : null}
      </div>

      <label className="field">
        <span className="field-label">{schema.locationLabel}</span>
        <input
          data-testid="form-location-detail"
          placeholder={schema.locationPlaceholder}
          value={draft.locationName}
          onChange={function (event) {
            const value = event.target.value
            setDraft(function (current) {
              return { ...current, locationName: value }
            })
          }}
        />
        <FieldError message={errors['locationName']} />
      </label>

      {schema.fields.map(renderField)}
    </Modal>
  )
}
