import { useEffect, useMemo, useRef, useState } from 'react'
import type { AppNotification, AppState, ExpiryLevel, NotificationKind } from '../../shared/types'
import { daysUntil, expiryLevel } from '../../shared/search'
import { cn, levelClass, locationOf } from './helpers'

export interface NotificationPanelProps {
  state: AppState
  onClose: () => void
  onLocate: (itemId: string, categoryId: string) => void
  onToast: (message: string) => void
  onAskConfirm: (title: string, message: string, confirmLabel: string, run: () => void) => void
}

interface TabDef {
  kind: NotificationKind
  label: string
  short: string
  empty: string
}

const TABS: TabDef[] = [
  { kind: 'food', label: '食品到期提醒', short: '食品', empty: '现在没有要提醒的食品，放心吃吧。' },
  { kind: 'medicine', label: '药品到期提醒', short: '药品', empty: '现在没有要提醒的药品，安心用吧。' }
]

function remainText(days: number | null): string {
  if (days === null) return '到期时间未知'
  if (days < 0) return '已过期'
  if (days === 0) return '今天到期'
  return '还剩 ' + days + ' 天过期'
}

function tabOf(kind: NotificationKind): TabDef {
  return kind === 'medicine' ? TABS[1] : TABS[0]
}

export default function NotificationPanel(props: NotificationPanelProps) {
  const panelRef = useRef<HTMLDivElement | null>(null)
  const [tab, setTab] = useState<NotificationKind>('food')
  // 已读只由用户手动点「标为已读 / 标为未读」决定（1.1.8）
  useEffect(function () {
    function onKey(event: KeyboardEvent): void {
      if (event.key === 'Escape') props.onClose()
    }
    document.addEventListener('keydown', onKey)
    return function () {
      document.removeEventListener('keydown', onKey)
    }
  }, [props.onClose])

  const grouped = useMemo(function () {
    const map: Record<NotificationKind, AppNotification[]> = { food: [], medicine: [] }
    const list = props.state.notifications.filter(function (note) {
      return !note.deleted
    })
    for (let i = 0; i < list.length; i += 1) {
      const note = list[i]
      if (note.kind === 'medicine') map.medicine.push(note)
      else map.food.push(note)
    }
    const kinds: NotificationKind[] = ['food', 'medicine']
    for (let k = 0; k < kinds.length; k += 1) {
      map[kinds[k]].sort(function (a, b) {
        const ar = a.read ? 1 : 0
        const br = b.read ? 1 : 0
        if (ar !== br) return ar - br
        return b.createdAt.localeCompare(a.createdAt)
      })
    }
    return map
  }, [props.state.notifications])

  const activeTab = tabOf(tab)
  const list = grouped[tab]

  function unreadOf(kind: NotificationKind): number {
    return grouped[kind].reduce(function (sum, note) {
      return note.read ? sum : sum + 1
    }, 0)
  }

  function toggleRead(note: AppNotification): void {
    void window.guina.markNotificationRead(note.id, !note.read).then(function (op) {
      if (!op.ok) props.onToast(op.error)
    })
  }

  function removeOne(note: AppNotification): void {
    void window.guina.deleteNotification(note.id).then(function (op) {
      if (!op.ok) props.onToast(op.error)
    })
  }

  function readAll(): void {
    const current = tabOf(tab)
    props.onAskConfirm(
      current.short + '提醒全部标为已读？',
      '只影响「' + current.label + '」这一栏，另一栏不受影响。',
      '全部已读',
      function () {
        void window.guina.markAllNotificationsRead(tab).then(function (op) {
          if (op.ok) props.onToast(current.short + '提醒已全部标为已读')
          else props.onToast(op.error)
        })
      }
    )
  }

  function deleteRead(): void {
    const current = tabOf(tab)
    props.onAskConfirm(
      '删除' + current.short + '的已读提醒？',
      '只删除「' + current.label + '」里已读的提醒，删除后不可恢复；另一栏不受影响。',
      '删除已读',
      function () {
        void window.guina.deleteReadNotifications(tab).then(function (op) {
          if (op.ok) props.onToast('已删除' + current.short + '的已读提醒')
          else props.onToast(op.error)
        })
      }
    )
  }

  return (
    <div className="notification-panel" data-testid="notification-panel" ref={panelRef}>
      <div className="notif-head">
        <h3 className="notif-title">到期提醒</h3>
        <div className="notif-head-actions">
          <button type="button" className="btn ghost sm" data-testid="notif-close" onClick={props.onClose}>
            关闭
          </button>
        </div>
      </div>

      <div className="notif-tabs">
        {TABS.map(function (item) {
          const unread = unreadOf(item.kind)
          return (
            <button
              type="button"
              key={item.kind}
              className={cn('notif-tab', tab === item.kind && 'active')}
              data-testid={'notif-tab-' + item.kind}
              onClick={function () {
                setTab(item.kind)
              }}
            >
              {item.short}
              {unread > 0 ? <span className="notif-tab-badge">{unread}</span> : null}
            </button>
          )
        })}
      </div>

      <div className="notif-bar">
        <span className="notif-bar-text">
          {activeTab.label} · 共 {list.length} 条
        </span>
        <button type="button" className="btn ghost sm" data-testid="notif-read-all" onClick={readAll}>
          全部标为已读
        </button>
        <button type="button" className="btn ghost sm" data-testid="notif-delete-read" onClick={deleteRead}>
          删除已读
        </button>
      </div>

      <div className="notif-list">
        {list.length === 0 ? (
          <div className="notif-empty" data-testid="notif-empty">
            {activeTab.empty}
          </div>
        ) : null}
        {list.map(function (note) {
          const item = props.state.items.find(function (candidate) {
            return candidate.id === note.itemId
          })
          const days = item && item.fields.expiresAt ? daysUntil(item.fields.expiresAt) : null
          const level: ExpiryLevel | null = days === null ? null : expiryLevel(days)
          return (
            <div className={note.read ? 'notif-item read' : 'notif-item'} data-testid="notif-item" key={note.id}>
              <div className="notif-row">
                <span className="notif-name">{item ? item.name : '这条记录已删除'}</span>
                <span className={cn('notif-remain', level ? levelClass(level) : '')}>{remainText(days)}</span>
              </div>
              <div className="notif-sub">
                {item ? locationOf(item) : '找不到原来的记录'}
                {note.read ? ' · 已读' : ''}
              </div>
              <div className="notif-actions">
                <button
                  type="button"
                  className="btn ghost sm"
                  data-testid="notif-locate"
                  disabled={!item}
                  onClick={function () {
                    if (item) props.onLocate(item.id, item.categoryId)
                  }}
                >
                  定位
                </button>
                <button type="button" className="btn ghost sm" data-testid="notif-read" onClick={function () { toggleRead(note) }}>
                  {note.read ? '标为未读' : '标为已读'}
                </button>
                <button
                  type="button"
                  className="btn ghost sm danger-text"
                  data-testid="notif-delete"
                  onClick={function () {
                    removeOne(note)
                  }}
                >
                  删除
                </button>
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}
