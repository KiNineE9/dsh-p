import { useEffect, useState } from 'react'
import { createRoot } from 'react-dom/client'
import type { ReminderPayload } from '../../shared/types'
import { formatDateTime } from '../../shared/search'
import './styles.css'

function ReminderApp() {
  const [payload, setPayload] = useState<ReminderPayload | null>(null)
  const [loaded, setLoaded] = useState(false)

  useEffect(function () {
    let alive = true
    window.guina
      .getReminderPayload()
      .then(function (next) {
        if (alive) {
          setPayload(next)
          setLoaded(true)
        }
      })
      .catch(function () {
        if (alive) setLoaded(true)
      })
    return function () {
      alive = false
    }
  }, [])

  async function act(action: 'ok' | 'snooze' | 'done'): Promise<void> {
    try {
      if (payload) await window.guina.reminderAction(action)
    } catch {
      return
    }
    window.close()
  }

  return (
    <div className="reminder-page">
      <div className="reminder-card">
        <div className="reminder-head">
          <span className="reminder-icon">🔔</span>
          <span className="reminder-title">提醒</span>
        </div>
        {!loaded ? (
          <p className="reminder-empty">正在打开…</p>
        ) : payload ? (
          <div className="reminder-body">
            {payload.title ? <p className="reminder-subject" data-testid="reminder-title">{payload.title}</p> : null}
            <p className="reminder-content">{payload.content}</p>
            {payload.remindAt ? <p className="reminder-time">{formatDateTime(payload.remindAt)}</p> : null}
            {payload.repeatText ? (
              <p className="reminder-time" data-testid="reminder-repeat">
                循环：{payload.repeatText}
              </p>
            ) : null}
          </div>
        ) : (
          <p className="reminder-empty">没有待处理的提醒</p>
        )}
        <div className="reminder-actions">
          <button
            type="button"
            className="btn primary"
            data-testid="reminder-ok"
            onClick={function () {
              void act('ok')
            }}
          >
            知道了
          </button>
          <button
            type="button"
            className="btn ghost"
            data-testid="reminder-snooze"
            onClick={function () {
              void act('snooze')
            }}
          >
            稍后提醒（10分钟）
          </button>
          <button
            type="button"
            className="btn ghost"
            data-testid="reminder-done"
            onClick={function () {
              void act('done')
            }}
          >
            标记完成
          </button>
        </div>
      </div>
    </div>
  )
}

const container = document.getElementById('reminder-root')

if (container) {
  const root = createRoot(container)
  root.render(<ReminderApp />)
}
