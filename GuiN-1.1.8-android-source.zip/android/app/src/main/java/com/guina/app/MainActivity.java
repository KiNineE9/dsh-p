package com.guina.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.AlarmClock;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.webkit.ConsoleMessage;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/**
 * 单 Activity + WebView 壳：assets/web 里的前端通过 https://app.local/ 加载，
 * 数据、备份、提醒、导入导出全部走 NativeBridge（与 mobile/src/bridge.ts 对应）。
 */
public class MainActivity extends Activity {
    private static final String APP_HOST = "app.local";
    private static final String START_URL = "https://" + APP_HOST + "/index.html";
    private static final int REQ_EXPORT = 101;
    private static final int REQ_IMPORT = 102;
    private static final int REQ_NOTIF = 103;
    private static final int REQ_CAMERA = 104;
    private static final int MAX_IMPORT_BYTES = 32 * 1024 * 1024;

    private WebView webView;
    private DataRepository repo;
    private String pendingExport = null;
    private boolean backPending = false;
    private PermissionRequest pendingWebPermission = null;
    private int insetTop = 0;
    private int insetRight = 0;
    private int insetBottom = 0;
    private int insetLeft = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        repo = new DataRepository(this);
        NotificationHelper.ensureChannels(this);
        ReminderScheduler.rescheduleAll(this);
        ReminderScheduler.scheduleDailyExpiryCheck(this);

        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setLoadWithOverviewMode(false);
        settings.setUseWideViewPort(false);
        settings.setTextZoom(100);
        settings.setMediaPlaybackRequiresUserGesture(false);
        if (BuildConfig.DEBUG) WebView.setWebContentsDebuggingEnabled(true);

        webView.setBackgroundColor(colorForTheme(isDarkMode()));
        webView.setWebViewClient(new GuiNWebClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onConsoleMessage(ConsoleMessage message) {
                Log.d("GuiN", message.message() + " @" + message.lineNumber());
                return true;
            }

            /** 扫码绑定需要摄像头：WebView 请求摄像头时先拿系统权限再授予。 */
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        boolean wantsVideo = false;
                        for (String resource : request.getResources()) {
                            if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(resource)) wantsVideo = true;
                        }
                        if (!wantsVideo) {
                            request.deny();
                            return;
                        }
                        if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                            request.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});
                        } else {
                            pendingWebPermission = request;
                            requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_CAMERA);
                        }
                    }
                });
            }
        });
        webView.addJavascriptInterface(new NativeBridge(this, repo), "GuinaNative");
        setContentView(webView);
        setupWindowInsets();

        applyTheme(isDarkMode());
        webView.loadUrl(START_URL);
    }

    /** Android 15 起系统强制 edge-to-edge：读真实系统栏高度，用 CSS 变量给网页留出安全区。 */
    private void setupWindowInsets() {
        if (Build.VERSION.SDK_INT < 30) return;
        getWindow().setDecorFitsSystemWindows(false);
        getWindow().getDecorView().setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            @Override
            public WindowInsets onApplyWindowInsets(View view, WindowInsets insets) {
                android.graphics.Insets bars = insets.getInsets(
                        WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                insetTop = bars.top;
                insetRight = bars.right;
                insetBottom = bars.bottom;
                insetLeft = bars.left;
                pushInsets();
                return insets;
            }
        });
        getWindow().getDecorView().requestApplyInsets();
    }

    private void pushInsets() {
        if (webView == null) return;
        float density = getResources().getDisplayMetrics().density;
        if (density <= 0) density = 1f;
        final int top = Math.round(insetTop / density);
        final int right = Math.round(insetRight / density);
        final int bottom = Math.round(insetBottom / density);
        final int left = Math.round(insetLeft / density);
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (webView == null) return;
                webView.evaluateJavascript(
                        "window.__setInsets&&window.__setInsets(" + top + "," + right + "," + bottom + "," + left + ")",
                        null);
            }
        });
    }

    private boolean isDarkMode() {
        SharedPreferences prefs = getSharedPreferences("guina_ui", MODE_PRIVATE);
        return prefs.getBoolean("dark", false);
    }

    private static int colorForTheme(boolean dark) {
        return Color.parseColor(dark ? "#1c1d1f" : "#f6f5f2");
    }

    /** 只从 assets/web 提供前端文件，不访问网络。 */
    private class GuiNWebClient extends WebViewClient {
        @Override
        public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
            Uri uri = request.getUrl();
            if (uri == null || !APP_HOST.equals(uri.getHost())) return null;
            return serveAsset(uri.getPath());
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            Uri uri = request.getUrl();
            if (uri == null) return false;
            if (APP_HOST.equals(uri.getHost())) return false;
            openExternal(uri.toString());
            return true;
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            pushInsets();
        }
    }

    private WebResourceResponse serveAsset(String rawPath) {
        String path = rawPath == null ? "" : rawPath;
        if (path.startsWith("/")) path = path.substring(1);
        if (path.isEmpty()) path = "index.html";
        try {
            InputStream in = getAssets().open("web/" + path);
            WebResourceResponse response = new WebResourceResponse(mimeOf(path), "UTF-8", in);
            Map<String, String> headers = new HashMap<>();
            headers.put("Cache-Control", "no-store");
            response.setResponseHeaders(headers);
            return response;
        } catch (Exception e) {
            if (!path.contains(".")) {
                try {
                    return new WebResourceResponse("text/html", "UTF-8", getAssets().open("web/index.html"));
                } catch (Exception ignored) {
                }
            }
            return new WebResourceResponse("text/plain", "UTF-8",
                    new ByteArrayInputStream("404 Not Found".getBytes(StandardCharsets.UTF_8)));
        }
    }

    private static String mimeOf(String path) {
        String p = path.toLowerCase(Locale.US);
        if (p.endsWith(".html") || p.endsWith(".htm")) return "text/html";
        if (p.endsWith(".js") || p.endsWith(".mjs")) return "application/javascript";
        if (p.endsWith(".css")) return "text/css";
        if (p.endsWith(".json")) return "application/json";
        if (p.endsWith(".png")) return "image/png";
        if (p.endsWith(".jpg") || p.endsWith(".jpeg")) return "image/jpeg";
        if (p.endsWith(".svg")) return "image/svg+xml";
        if (p.endsWith(".webp")) return "image/webp";
        if (p.endsWith(".woff2")) return "font/woff2";
        if (p.endsWith(".woff")) return "font/woff";
        if (p.endsWith(".ttf")) return "font/ttf";
        if (p.endsWith(".ico")) return "image/x-icon";
        return "application/octet-stream";
    }

    public String buildInfoJson() {
        JSONObject o = new JSONObject();
        try {
            String versionName = "1.1.8";
            try {
                versionName = getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
            } catch (Exception ignored) {
            }
            DisplayMetrics dm = getResources().getDisplayMetrics();
            o.put("version", versionName);
            o.put("versionName", versionName);
            o.put("sdk", Build.VERSION.SDK_INT);
            o.put("model", Build.MODEL);
            o.put("manufacturer", Build.MANUFACTURER);
            o.put("dataDir", repo.getRoot().getAbsolutePath());
            o.put("width", Math.round(dm.widthPixels / dm.density));
            o.put("height", Math.round(dm.heightPixels / dm.density));
            float density = dm.density > 0 ? dm.density : 1f;
            JSONObject insets = new JSONObject();
            insets.put("top", Math.round(insetTop / density));
            insets.put("right", Math.round(insetRight / density));
            insets.put("bottom", Math.round(insetBottom / density));
            insets.put("left", Math.round(insetLeft / density));
            o.put("insets", insets);
            o.put("notificationPermission", hasNotificationPermission());
            o.put("ignoringBatteryOptimizations", isIgnoringBatteryOptimizations());
            o.put("canScheduleExactAlarms", canScheduleExactAlarms());
        } catch (Exception ignored) {
        }
        return o.toString();
    }

    private boolean hasNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33) {
            return checkSelfPermission("android.permission.POST_NOTIFICATIONS") == PackageManager.PERMISSION_GRANTED;
        }
        return true;
    }

    public void applyTheme(final boolean dark) {
        getSharedPreferences("guina_ui", MODE_PRIVATE).edit().putBoolean("dark", dark).apply();
        final int bg = colorForTheme(dark);
        int flags = View.SYSTEM_UI_FLAG_LAYOUT_STABLE;
        if (!dark) flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
        if (Build.VERSION.SDK_INT >= 26 && !dark) flags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        final int uiFlags = flags;
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                getWindow().setStatusBarColor(bg);
                getWindow().setNavigationBarColor(bg);
                getWindow().getDecorView().setSystemUiVisibility(uiFlags);
                if (Build.VERSION.SDK_INT >= 30) {
                    WindowInsetsController controller = getWindow().getInsetsController();
                    if (controller != null) {
                        int bars = WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS
                                | WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS;
                        controller.setSystemBarsAppearance(dark ? 0 : bars, bars);
                    }
                }
                if (webView != null) webView.setBackgroundColor(bg);
            }
        });
    }

    public void exportData(final String json, final String filename) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (json == null) {
                    evalExport(false, "没有可导出的内容");
                    return;
                }
                pendingExport = json;
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                intent.putExtra(Intent.EXTRA_TITLE, filename == null || filename.isEmpty() ? "guina-data.json" : filename);
                try {
                    startActivityForResult(intent, REQ_EXPORT);
                } catch (Exception e) {
                    pendingExport = null;
                    evalExport(false, "无法打开系统文件选择器");
                }
            }
        });
    }

    public void importData() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/json", "text/plain", "application/octet-stream"});
                try {
                    startActivityForResult(intent, REQ_IMPORT);
                } catch (Exception e) {
                    evalImport("");
                }
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != REQ_CAMERA) return;
        PermissionRequest request = pendingWebPermission;
        pendingWebPermission = null;
        if (request == null) return;
        boolean granted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
        if (granted) request.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});
        else request.deny();
    }

    public void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && !hasNotificationPermission()) {
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, REQ_NOTIF);
        }
    }

    /** 是否已经在系统的电池优化白名单里（允许后台运行） */
    public boolean isIgnoringBatteryOptimizations() {
        if (Build.VERSION.SDK_INT < 23) return true;
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        return pm != null && pm.isIgnoringBatteryOptimizations(getPackageName());
    }

    /** 弹系统对话框请求忽略电池优化；没有权限时退回系统的电池优化列表 */
    public void requestIgnoreBatteryOptimization() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (Build.VERSION.SDK_INT < 23 || isIgnoringBatteryOptimizations()) {
                    Toast.makeText(MainActivity.this, "GuiN 已经允许后台运行了", Toast.LENGTH_SHORT).show();
                    return;
                }
                try {
                    Intent intent = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                            Uri.parse("package:" + getPackageName()));
                    startActivity(intent);
                } catch (Exception e) {
                    try {
                        startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
                    } catch (Exception ignored) {
                        Toast.makeText(MainActivity.this, "请到系统设置 → 电池 → 电池优化里允许 GuiN", Toast.LENGTH_LONG).show();
                    }
                }
            }
        });
    }

    /** 打开品牌自带的自启动管理页（没有统一入口，逐个尝试后回到应用详情页） */
    public void openAutoStartSettings() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                String[][] candidates = new String[][]{
                        {"com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity"},
                        {"com.huawei.systemmanager", "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity"},
                        {"com.huawei.systemmanager", "com.huawei.systemmanager.optimize.process.ProtectActivity"},
                        {"com.coloros.safecenter", "com.coloros.safecenter.permission.startup.StartupAppListActivity"},
                        {"com.coloros.safecenter", "com.coloros.safecenter.startupapp.StartupAppListActivity"},
                        {"com.oppo.safe", "com.oppo.safe.permission.startup.StartupAppListActivity"},
                        {"com.vivo.permissionmanager", "com.vivo.permissionmanager.activity.BgStartUpManagerActivity"},
                        {"com.iqoo.secure", "com.iqoo.secure.ui.phoneoptimize.AddWhiteListActivity"},
                        {"com.sec.android.app.launcher", "com.android.launcher3.settings.AdvancedSettingsActivity"}
                };
                for (String[] c : candidates) {
                    try {
                        Intent intent = new Intent();
                        intent.setClassName(c[0], c[1]);
                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(intent);
                        return;
                    } catch (Exception ignored) {
                    }
                }
                try {
                    Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                            Uri.parse("package:" + getPackageName()));
                    startActivity(intent);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "请到系统设置 → 应用 → 自启动里允许 GuiN", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    /** Android 12+ 精确闹钟权限；没有时提醒可能晚几分钟 */
    public boolean canScheduleExactAlarms() {
        if (Build.VERSION.SDK_INT < 31) return true;
        AlarmManager am = (AlarmManager) getSystemService(ALARM_SERVICE);
        return am == null || am.canScheduleExactAlarms();
    }

    /** 打开精确闹钟授权页 */
    public void openExactAlarmSettings() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (Build.VERSION.SDK_INT >= 31) {
                    try {
                        startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                                Uri.parse("package:" + getPackageName())));
                        return;
                    } catch (Exception ignored) {
                    }
                }
                try {
                    startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                            Uri.parse("package:" + getPackageName())));
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "请到系统设置 → 应用 → 闹钟和提醒里允许 GuiN", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    /** 把提醒便签一键写进系统「时钟 / 闹钟」应用；返回实际使用的导入方式（silent / guided） */
    public String addSystemAlarm(final String title, final String triggerAt, final String repeatKind) {
        final int[] days = alarmDaysFor(repeatKind);
        final String mode = effectiveAlarmMode(days != null);
        final boolean guided = ALARM_MODE_GUIDED.equals(mode);
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                long at;
                try {
                    at = Long.parseLong(triggerAt == null ? "" : triggerAt.trim());
                } catch (Exception e) {
                    at = System.currentTimeMillis() + 60 * 1000L;
                }
                // 循环提醒保留原来的时分（即使第一次时间已过），一次性提醒才顺延到现在之后
                if (days == null && at <= System.currentTimeMillis()) {
                    at = System.currentTimeMillis() + 60 * 1000L;
                }
                Calendar cal = Calendar.getInstance();
                cal.setTimeInMillis(at);
                try {
                    Intent intent = new Intent(AlarmClock.ACTION_SET_ALARM);
                    intent.putExtra(AlarmClock.EXTRA_HOUR, cal.get(Calendar.HOUR_OF_DAY));
                    intent.putExtra(AlarmClock.EXTRA_MINUTES, cal.get(Calendar.MINUTE));
                    intent.putExtra(AlarmClock.EXTRA_MESSAGE, title == null ? "" : title);
                    // 部分国产 ROM 的时钟应用在静默导入时会丢掉重复星期，这些机型改为打开编辑页让用户确认
                    intent.putExtra(AlarmClock.EXTRA_SKIP_UI, !guided);
                    if (days != null) intent.putExtra(AlarmClock.EXTRA_DAYS, days);
                    Log.i("GuiNAlarm", "setAlarm mode=" + mode + " repeat=" + (repeatKind == null ? "" : repeatKind)
                            + " hour=" + cal.get(Calendar.HOUR_OF_DAY) + " minute=" + cal.get(Calendar.MINUTE));
                    startActivity(intent);
                    if (guided) {
                        Toast.makeText(MainActivity.this,
                                "已打开时钟应用，确认「重复」后点保存", Toast.LENGTH_LONG).show();
                    } else {
                        Toast.makeText(MainActivity.this, canScheduleExactAlarms()
                                ? "已导入到系统闹钟"
                                : "已导入到系统闹钟；建议在设置里打开「精确闹钟」", Toast.LENGTH_LONG).show();
                    }
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "没有找到可用的闹钟应用", Toast.LENGTH_LONG).show();
                }
            }
        });
        return mode;
    }

    // ---- 系统闹钟导入：识别时钟应用 + 兼容模式 ----

    private static final String ALARM_PREFS = "guina_alarm";
    private static final String KEY_ALARM_MODE = "alarm_mode";
    private static final String ALARM_MODE_AUTO = "auto";
    private static final String ALARM_MODE_SILENT = "silent";
    private static final String ALARM_MODE_GUIDED = "guided";
    /** 这些 ROM 的时钟应用在静默导入（SKIP_UI）时会丢掉 EXTRA_DAYS，只建一次性闹钟 */
    private static final String[] SILENT_REPEAT_BLOCKLIST = {
            "coloros", "oplus", "oppo", "realme", "miui", "xiaomi", "redmi", "poco",
            "vivo", "iqoo", "bbk", "huawei", "honor", "emui", "meizu", "oneplus"
    };

    private String alarmModePref() {
        return getSharedPreferences(ALARM_PREFS, MODE_PRIVATE).getString(KEY_ALARM_MODE, ALARM_MODE_AUTO);
    }

    /** 设置页读取：识别到的时钟应用、当前方式、是否已知会丢重复 */
    public String getAlarmInfo() {
        String pkg = clockPackageName();
        try {
            JSONObject o = new JSONObject();
            o.put("clockPackage", pkg);
            o.put("clockLabel", clockAppLabel(pkg));
            o.put("manufacturer", Build.MANUFACTURER == null ? "" : Build.MANUFACTURER);
            o.put("mode", alarmModePref());
            o.put("ignoresRepeat", clockDropsRepeatSilently(pkg));
            o.put("effective", effectiveAlarmMode(true));
            o.put("resolved", !pkg.isEmpty());
            return o.toString();
        } catch (Exception e) {
            return "";
        }
    }

    /** 设置页切换导入方式：auto / silent / guided */
    public void setAlarmMode(String mode) {
        String next = ALARM_MODE_AUTO;
        if (ALARM_MODE_SILENT.equals(mode) || ALARM_MODE_GUIDED.equals(mode)) next = mode;
        getSharedPreferences(ALARM_PREFS, MODE_PRIVATE).edit().putString(KEY_ALARM_MODE, next).apply();
    }

    /** 自检：用「打开时钟确认」的方式建一个工作日 07:30 的测试闹钟，让用户看时钟里是否显示循环 */
    public void runAlarmSelfCheck() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    Intent intent = new Intent(AlarmClock.ACTION_SET_ALARM);
                    intent.putExtra(AlarmClock.EXTRA_HOUR, 7);
                    intent.putExtra(AlarmClock.EXTRA_MINUTES, 30);
                    intent.putExtra(AlarmClock.EXTRA_MESSAGE, "GuiN 自检：请确认「重复」为工作日");
                    intent.putExtra(AlarmClock.EXTRA_SKIP_UI, false);
                    intent.putExtra(AlarmClock.EXTRA_DAYS, alarmDaysFor("weekdays"));
                    startActivity(intent);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "没有找到可用的闹钟应用", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    /** 当前默认的时钟应用包名；没有可用时钟应用时为空串 */
    private String clockPackageName() {
        try {
            Intent probe = new Intent(AlarmClock.ACTION_SET_ALARM);
            ResolveInfo info = getPackageManager().resolveActivity(probe, PackageManager.MATCH_DEFAULT_ONLY);
            if (info == null || info.activityInfo == null || info.activityInfo.packageName == null) return "";
            return info.activityInfo.packageName;
        } catch (Exception e) {
            return "";
        }
    }

    private String clockAppLabel(String pkg) {
        if (pkg == null || pkg.isEmpty()) return "";
        try {
            PackageManager pm = getPackageManager();
            return String.valueOf(pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)));
        } catch (Exception e) {
            return pkg;
        }
    }

    /** 品牌字符串（厂商 + 品牌），部分 ROM 的时钟包名是 AOSP 的 com.android.deskclock，只能靠品牌识别 */
    private String brandName() {
        String maker = Build.MANUFACTURER == null ? "" : Build.MANUFACTURER;
        String brand = Build.BRAND == null ? "" : Build.BRAND;
        return (maker + " " + brand).toLowerCase(Locale.ROOT).trim();
    }

    private boolean clockDropsRepeatSilently(String pkg) {
        String name = pkg == null ? "" : pkg.toLowerCase(Locale.ROOT);
        String brand = brandName();
        for (String key : SILENT_REPEAT_BLOCKLIST) {
            if ((!name.isEmpty() && name.contains(key)) || (!brand.isEmpty() && brand.contains(key))) return true;
        }
        return false;
    }

    /** 一次性恒为静默；循环时按用户选择，auto 则根据识别到的时钟应用决定 */
    private String effectiveAlarmMode(boolean hasRepeat) {
        if (!hasRepeat) return ALARM_MODE_SILENT;
        String pref = alarmModePref();
        if (ALARM_MODE_SILENT.equals(pref) || ALARM_MODE_GUIDED.equals(pref)) return pref;
        // 识别不到时钟应用时，静默导入可能丢重复规则，直接打开确认更稳妥
        if (clockPackageName().isEmpty()) return ALARM_MODE_GUIDED;
        return clockDropsRepeatSilently(clockPackageName()) ? ALARM_MODE_GUIDED : ALARM_MODE_SILENT;
    }

    /** 循环提醒对应系统闹钟的重复星期；Calendar 里周日=1…周六=7 */
    private int[] alarmDaysFor(String repeatKind) {
        String kind = repeatKind == null ? "" : repeatKind.trim();
        if ("daily".equals(kind)) {
            return new int[]{Calendar.SUNDAY, Calendar.MONDAY, Calendar.TUESDAY, Calendar.WEDNESDAY,
                    Calendar.THURSDAY, Calendar.FRIDAY, Calendar.SATURDAY};
        }
        if ("weekdays".equals(kind)) {
            return new int[]{Calendar.MONDAY, Calendar.TUESDAY, Calendar.WEDNESDAY, Calendar.THURSDAY,
                    Calendar.FRIDAY};
        }
        if ("weekends".equals(kind)) {
            return new int[]{Calendar.SATURDAY, Calendar.SUNDAY};
        }
        return null;
    }

    public void openExternal(final String url) {
        if (url == null || url.isEmpty()) return;
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "无法打开这个链接", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_EXPORT) {
            String json = pendingExport;
            pendingExport = null;
            if (resultCode == RESULT_OK && data != null && data.getData() != null && json != null) {
                try {
                    OutputStream out = getContentResolver().openOutputStream(data.getData());
                    if (out == null) throw new Exception("无法写入");
                    out.write(json.getBytes(StandardCharsets.UTF_8));
                    out.flush();
                    out.close();
                    evalExport(true, "已导出");
                } catch (Exception e) {
                    evalExport(false, "导出失败：" + e.getMessage());
                }
            } else {
                evalExport(false, "已取消导出");
            }
        } else if (requestCode == REQ_IMPORT) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                try {
                    InputStream in = getContentResolver().openInputStream(data.getData());
                    if (in == null) throw new Exception("无法读取");
                    ByteArrayOutputStream buffer = new ByteArrayOutputStream();
                    byte[] buf = new byte[8192];
                    int total = 0;
                    int n;
                    while ((n = in.read(buf)) > 0) {
                        total += n;
                        if (total > MAX_IMPORT_BYTES) throw new Exception("文件太大");
                        buffer.write(buf, 0, n);
                    }
                    in.close();
                    evalImport(new String(buffer.toByteArray(), StandardCharsets.UTF_8));
                } catch (Exception e) {
                    evalImport("");
                    toastOnUiThread("导入失败：" + e.getMessage());
                }
            } else {
                evalImport("");
            }
        }
    }

    private void toastOnUiThread(final String message) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void evalExport(final boolean ok, final String message) {
        evalJs("window.__nativeExportResult && window.__nativeExportResult(" + ok + ", "
                + JSONObject.quote(message == null ? "" : message) + ")");
    }

    private void evalImport(String json) {
        evalJs("window.__nativeImportResult && window.__nativeImportResult("
                + JSONObject.quote(json == null ? "" : json) + ")");
    }

    private void evalJs(final String script) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (webView != null) webView.evaluateJavascript(script, null);
            }
        });
    }

    @Override
    public void onBackPressed() {
        if (webView == null) {
            super.onBackPressed();
            return;
        }
        if (backPending) return;
        backPending = true;
        webView.evaluateJavascript(
                "(function(){try{return window.__handleBack?String(window.__handleBack()):'0'}catch(e){return '0'}})()",
                new ValueCallback<String>() {
                    @Override
                    public void onReceiveValue(String value) {
                        backPending = false;
                        String v = value == null ? "" : value.replace("\"", "").trim();
                        if (!"1".equals(v)) finish();
                    }
                });
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) webView.onResume();
    }

    @Override
    protected void onPause() {
        if (webView != null) webView.onPause();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
