package com.guina.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

import org.json.JSONObject;

import java.util.Calendar;
import java.util.Map;

/** 提醒调度：AlarmManager + SharedPreferences 保存待触发提醒（循环提醒由接收器自行顺延）。 */
public final class ReminderScheduler {
    static final String PREFS = "guina_reminders";
    static final String PREFIX = "reminder:";
    private static final String DAILY_EXPIRY = "daily_expiry";
    private static final int EXPIRY_REQUEST_CODE = 99001;

    private ReminderScheduler() {
    }

    private static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    static void schedule(Context context, String id, String title, String content, long at, String repeatKind, String repeatTime, boolean sound) {
        if (id == null || id.isEmpty()) return;
        long now = System.currentTimeMillis();
        if (at < now + 1000) at = now + 1000;
        try {
            JSONObject o = new JSONObject();
            o.put("id", id);
            o.put("title", title == null ? "" : title);
            o.put("content", content == null ? "" : content);
            o.put("at", at);
            o.put("kind", repeatKind == null ? "" : repeatKind);
            o.put("time", repeatTime == null ? "" : repeatTime);
            o.put("sound", sound);
            prefs(context).edit().putString(PREFIX + id, o.toString()).apply();
        } catch (Exception e) {
            return;
        }
        setAlarm(context, id, at);
    }

    static void reschedule(Context context, String id) {
        String raw = prefs(context).getString(PREFIX + id, null);
        if (raw == null) return;
        try {
            long at = new JSONObject(raw).optLong("at", 0);
            setAlarm(context, id, Math.max(at, System.currentTimeMillis() + 1500));
        } catch (Exception ignored) {
        }
    }

    static String read(Context context, String id) {
        return prefs(context).getString(PREFIX + id, null);
    }

    static void update(Context context, String id, String raw) {
        prefs(context).edit().putString(PREFIX + id, raw).apply();
    }

    static void remove(Context context, String id) {
        prefs(context).edit().remove(PREFIX + id).apply();
    }

    static void setAlarm(Context context, String id, long at) {
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        Intent intent = new Intent(context, AlarmReceiver.class);
        intent.setAction("com.guina.app.REMINDER");
        intent.putExtra("id", id);
        PendingIntent pi = PendingIntent.getBroadcast(
                context,
                requestCode(id),
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        try {
            if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
            } else {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
            }
        } catch (SecurityException e) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
        }
    }

    static void cancel(Context context, String id) {
        if (id == null || id.isEmpty()) return;
        prefs(context).edit().remove(PREFIX + id).apply();
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        Intent intent = new Intent(context, AlarmReceiver.class);
        intent.setAction("com.guina.app.REMINDER");
        intent.putExtra("id", id);
        PendingIntent pi = PendingIntent.getBroadcast(
                context,
                requestCode(id),
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        try {
            am.cancel(pi);
        } catch (Exception ignored) {
        }
        pi.cancel();
    }

    static int requestCode(String id) {
        return (id.hashCode() & 0x7fffffff) % 100000;
    }

    static void rescheduleAll(Context context) {
        long now = System.currentTimeMillis();
        SharedPreferences p = prefs(context);
        for (Map.Entry<String, ?> entry : p.getAll().entrySet()) {
            String key = entry.getKey();
            if (!key.startsWith(PREFIX)) continue;
            try {
                JSONObject o = new JSONObject(String.valueOf(entry.getValue()));
                long at = o.optLong("at", 0);
                setAlarm(context, key.substring(PREFIX.length()), Math.max(at, now + 2000));
            } catch (Exception ignored) {
            }
        }
    }

    /** 与桌面版 nextRepeatOccurrence 一致：每天 / 工作日 / 周六日。 */
    static long computeNext(String kind, String time, long from) {
        if (kind == null || kind.isEmpty()) return -1;
        int hour = 9;
        int minute = 0;
        try {
            String[] parts = (time == null ? "09:00" : time).split(":");
            hour = Integer.parseInt(parts[0].trim());
            minute = parts.length > 1 ? Integer.parseInt(parts[1].trim()) : 0;
            if (hour < 0 || hour > 23 || minute < 0 || minute > 59) return -1;
        } catch (Exception e) {
            return -1;
        }
        Calendar fromCal = Calendar.getInstance();
        fromCal.setTimeInMillis(from);
        for (int offset = 0; offset <= 8; offset++) {
            Calendar candidate = Calendar.getInstance();
            candidate.set(Calendar.YEAR, fromCal.get(Calendar.YEAR));
            candidate.set(Calendar.MONTH, fromCal.get(Calendar.MONTH));
            candidate.set(Calendar.DAY_OF_MONTH, fromCal.get(Calendar.DAY_OF_MONTH) + offset);
            candidate.set(Calendar.HOUR_OF_DAY, hour);
            candidate.set(Calendar.MINUTE, minute);
            candidate.set(Calendar.SECOND, 0);
            candidate.set(Calendar.MILLISECOND, 0);
            if (candidate.getTimeInMillis() <= from) continue;
            int day = candidate.get(Calendar.DAY_OF_WEEK);
            if ("daily".equals(kind)) return candidate.getTimeInMillis();
            if ("weekdays".equals(kind) && day >= Calendar.MONDAY && day <= Calendar.FRIDAY) return candidate.getTimeInMillis();
            if ("weekends".equals(kind) && (day == Calendar.SATURDAY || day == Calendar.SUNDAY)) return candidate.getTimeInMillis();
        }
        return -1;
    }

    static void scheduleDailyExpiryCheck(Context context) {
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.HOUR_OF_DAY, 9);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        if (cal.getTimeInMillis() <= System.currentTimeMillis()) cal.add(Calendar.DAY_OF_YEAR, 1);
        Intent intent = new Intent(context, ExpiryCheckReceiver.class);
        intent.setAction("com.guina.app.EXPIRY_CHECK");
        PendingIntent pi = PendingIntent.getBroadcast(
                context,
                EXPIRY_REQUEST_CODE,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        try {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), pi);
        } catch (Exception ignored) {
        }
    }
}
