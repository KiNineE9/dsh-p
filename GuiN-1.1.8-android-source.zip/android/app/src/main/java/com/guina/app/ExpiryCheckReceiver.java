package com.guina.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/** 每日后台检查：读 data.json，统计 7 天内到期的食品/药品，发一条汇总通知。 */
public class ExpiryCheckReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        try {
            DataRepository repo = new DataRepository(context);
            String json = repo.loadData();
            if (json != null && !json.isEmpty()) {
                JSONObject state = new JSONObject(json);
                Map<String, String> templates = new HashMap<>();
                JSONArray categories = state.optJSONArray("categories");
                if (categories != null) {
                    for (int i = 0; i < categories.length(); i++) {
                        JSONObject c = categories.optJSONObject(i);
                        if (c != null) templates.put(c.optString("id", ""), c.optString("baseTemplate", ""));
                    }
                }
                int food = 0;
                int medicine = 0;
                JSONArray items = state.optJSONArray("items");
                if (items != null) {
                    SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
                    long today = todayStart();
                    for (int i = 0; i < items.length(); i++) {
                        JSONObject item = items.optJSONObject(i);
                        if (item == null) continue;
                        String template = templates.get(item.optString("categoryId", ""));
                        if (!"food".equals(template) && !"medicine".equals(template)) continue;
                        JSONObject fields = item.optJSONObject("fields");
                        String expiresAt = fields == null ? "" : fields.optString("expiresAt", "");
                        if (expiresAt.isEmpty()) continue;
                        long days;
                        try {
                            Date date = fmt.parse(expiresAt);
                            days = date == null ? Long.MIN_VALUE : (date.getTime() - today) / (24 * 60 * 60 * 1000L);
                        } catch (Exception e) {
                            continue;
                        }
                        if (days < 0 || days > 7) continue;
                        if ("food".equals(template)) food++;
                        else medicine++;
                    }
                }
                // 已经读过的到期提醒不再每天重复弹（1.1.8）：
                // 有提醒记录时按未读数量统计，没有记录时退回按条目数量统计。
                JSONArray notices = state.optJSONArray("notifications");
                if (notices != null && notices.length() > 0) {
                    food = 0;
                    medicine = 0;
                    for (int i = 0; i < notices.length(); i++) {
                        JSONObject n = notices.optJSONObject(i);
                        if (n == null) continue;
                        if (n.optBoolean("read", false) || n.optBoolean("deleted", false)) continue;
                        if ("medicine".equals(n.optString("kind", ""))) medicine++;
                        else food++;
                    }
                }
                if (food > 0 || medicine > 0) NotificationHelper.notifyExpirySummary(context, food, medicine);
            }
        } catch (Exception ignored) {
        }
        ReminderScheduler.scheduleDailyExpiryCheck(context);
    }

    private static long todayStart() {
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        return cal.getTimeInMillis();
    }
}
