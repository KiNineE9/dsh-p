package com.guina.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;

/** 通知渠道 + 提醒/到期通知。 */
public final class NotificationHelper {
    /** 渠道声音创建后不能修改，所以带声音的渠道用新 id，并清掉旧渠道。 */
    private static final String CHANNEL_REMINDER = "reminders-v2";
    private static final String CHANNEL_REMINDER_SILENT = "reminders-silent-v2";
    private static final String CHANNEL_EXPIRY = "expiry-v3";
    private static final String LEGACY_REMINDER = "reminders";
    private static final String LEGACY_EXPIRY = "expiry";
    private static final String LEGACY_EXPIRY_V2 = "expiry-v2";
    private static final int EXPIRY_NOTIFICATION_ID = 99001;
    private static final int TEST_NOTIFICATION_ID = 99002;

    private NotificationHelper() {
    }

    /** 提示音固定走「通知」音频流，音量跟随手机的通知音量。 */
    private static AudioAttributes notificationAttributes() {
        return new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build();
    }

    private static Uri notificationSoundUri() {
        return RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
    }

    static void ensureChannels(Context context) {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        nm.deleteNotificationChannel(LEGACY_REMINDER);
        nm.deleteNotificationChannel(LEGACY_EXPIRY);
        nm.deleteNotificationChannel(LEGACY_EXPIRY_V2);
        NotificationChannel reminders = new NotificationChannel(
                CHANNEL_REMINDER, "便签提醒", NotificationManager.IMPORTANCE_HIGH);
        reminders.setDescription("到点的提醒便签会在这里弹出，并播放通知提示音");
        reminders.setSound(notificationSoundUri(), notificationAttributes());
        reminders.enableVibration(true);
        nm.createNotificationChannel(reminders);
        NotificationChannel silent = new NotificationChannel(
                CHANNEL_REMINDER_SILENT, "便签提醒（静音）", NotificationManager.IMPORTANCE_HIGH);
        silent.setDescription("关闭提醒声音时使用，只显示通知不出声");
        silent.setSound(null, null);
        silent.enableVibration(false);
        nm.createNotificationChannel(silent);
        // 到期提醒用「重要」渠道，系统才会以横幅（heads-up）弹出来，而不是只躺在通知栏里
        NotificationChannel expiry = new NotificationChannel(
                CHANNEL_EXPIRY, "到期提醒", NotificationManager.IMPORTANCE_HIGH);
        expiry.setDescription("食品、药品临期提醒，会以横幅弹出并播放通知提示音");
        expiry.setSound(notificationSoundUri(), notificationAttributes());
        expiry.enableVibration(true);
        expiry.setShowBadge(true);
        expiry.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        nm.createNotificationChannel(expiry);
    }

    private static Notification.Builder builder(Context context, String channel) {
        if (Build.VERSION.SDK_INT >= 26) return new Notification.Builder(context, channel);
        return new Notification.Builder(context);
    }

    private static PendingIntent openApp(Context context) {
        Intent intent = new Intent(context, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) flags |= PendingIntent.FLAG_IMMUTABLE;
        return PendingIntent.getActivity(context, 0, intent, flags);
    }

    static void notifyReminder(Context context, String id, String title, String content,
                               String repeatKind, String repeatTime, boolean sound) {
        ensureChannels(context);
        String heading = title == null || title.trim().isEmpty() ? "GuiN 提醒" : title.trim();
        String text = content == null ? "" : content.trim();
        String repeatText = repeatText(repeatKind, repeatTime);
        String sub = repeatText.isEmpty() ? "提醒" : "循环：" + repeatText;
        String channel = sound ? CHANNEL_REMINDER : CHANNEL_REMINDER_SILENT;
        Notification.Builder b = builder(context, channel);
        b.setSmallIcon(R.drawable.ic_notify)
                .setContentTitle(heading)
                .setContentText(text)
                .setSubText(sub)
                .setStyle(new Notification.BigTextStyle().bigText(text))
                .setAutoCancel(true)
                .setContentIntent(openApp(context))
                .setWhen(System.currentTimeMillis())
                .setShowWhen(true)
                .setCategory(Notification.CATEGORY_ALARM)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setPriority(Notification.PRIORITY_HIGH)
                .setOnlyAlertOnce(false);
        if (Build.VERSION.SDK_INT < 26) {
            if (sound) {
                b.setDefaults(Notification.DEFAULT_SOUND | Notification.DEFAULT_VIBRATE);
                b.setSound(notificationSoundUri());
            }
        }
        try {
            NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) nm.notify(Math.abs(id.hashCode() % 100000), b.build());
        } catch (Exception ignored) {
        }
    }

    /** 设置页「测试提醒」：发一条不下声的通知，再直接播放一声提示音，保证只响一次。 */
    static void notifyTest(Context context, String title, String content) {
        ensureChannels(context);
        String heading = title == null || title.trim().isEmpty() ? "GuiN 测试提醒" : title.trim();
        String text = content == null ? "" : content.trim();
        Notification.Builder b = builder(context, CHANNEL_REMINDER_SILENT);
        b.setSmallIcon(R.drawable.ic_notify)
                .setContentTitle(heading)
                .setContentText(text)
                .setStyle(new Notification.BigTextStyle().bigText(text))
                .setAutoCancel(true)
                .setContentIntent(openApp(context))
                .setWhen(System.currentTimeMillis())
                .setShowWhen(true);
        if (Build.VERSION.SDK_INT < 26) {
            b.setDefaults(0);
            b.setSound(null);
        }
        try {
            NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) nm.notify(TEST_NOTIFICATION_ID, b.build());
        } catch (Exception ignored) {
        }
        playTestSound(context);
    }

    /** 设置页「测试提醒」用：直接播放一声通知提示音，不依赖通知是否被拦截。 */
    static void playTestSound(Context context) {
        try {
            Uri uri = notificationSoundUri();
            if (uri == null) return;
            Ringtone ringtone = RingtoneManager.getRingtone(context, uri);
            if (ringtone == null) return;
            ringtone.setAudioAttributes(notificationAttributes());
            ringtone.play();
        } catch (Exception ignored) {
        }
    }

    /** App 里已经把到期提醒都看过了：清掉通知栏里那条汇总通知（1.1.8）。 */
    static void cancelExpirySummary(Context context) {
        try {
            NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) nm.cancel(EXPIRY_NOTIFICATION_ID);
        } catch (Exception ignored) {
        }
    }

    static void notifyExpirySummary(Context context, int food, int medicine) {
        if (food <= 0 && medicine <= 0) return;
        ensureChannels(context);
        StringBuilder text = new StringBuilder();
        if (food > 0) text.append(food).append(" 件食品");
        if (medicine > 0) {
            if (text.length() > 0) text.append("、");
            text.append(medicine).append(" 件药品");
        }
        text.append("在 7 天内到期，点开检查一下。");
        Notification.Builder b = builder(context, CHANNEL_EXPIRY);
        b.setSmallIcon(R.drawable.ic_notify)
                .setContentTitle("到期提醒")
                .setContentText(text.toString())
                .setStyle(new Notification.BigTextStyle().bigText(text.toString()))
                .setAutoCancel(true)
                .setContentIntent(openApp(context))
                .setWhen(System.currentTimeMillis())
                .setCategory(Notification.CATEGORY_ALARM)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setPriority(Notification.PRIORITY_HIGH)
                .setOnlyAlertOnce(false);
        if (Build.VERSION.SDK_INT < 26) {
            b.setDefaults(Notification.DEFAULT_SOUND | Notification.DEFAULT_VIBRATE);
        }
        try {
            NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) nm.notify(EXPIRY_NOTIFICATION_ID, b.build());
        } catch (Exception ignored) {
        }
    }

    private static String repeatText(String kind, String time) {
        if (kind == null || kind.isEmpty()) return "";
        String label;
        if ("daily".equals(kind)) label = "每天";
        else if ("weekdays".equals(kind)) label = "工作日";
        else if ("weekends".equals(kind)) label = "周六日";
        else return "";
        return label + " " + (time == null || time.isEmpty() ? "09:00" : time);
    }
}
