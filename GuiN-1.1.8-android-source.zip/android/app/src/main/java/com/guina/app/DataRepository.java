package com.guina.app;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

/**
 * 本地数据仓库：data.json 原子写入 + 自动滚动备份 7 份 + 手动备份（最多 5 份由界面控制）。
 * 目录结构：files/data.json、files/backups/（自动）、files/backups-manual/（手动）。
 */
public final class DataRepository {
    private static final int MAX_AUTO_BACKUPS = 7;
    private static final int MAX_READ_BYTES = 64 * 1024 * 1024;

    private final Context context;
    private final File root;
    private final File dataFile;
    private final File autoDir;
    private final File manualDir;
    private final File syncConfigFile;

    public DataRepository(Context context) {
        this.context = context.getApplicationContext();
        this.root = this.context.getFilesDir();
        this.dataFile = new File(root, "data.json");
        this.autoDir = new File(root, "backups");
        this.manualDir = new File(root, "backups-manual");
        this.syncConfigFile = new File(root, "sync-device.json");
    }

    /** 同步设备配置（设备身份 + 已绑定设备），单独存文件，不随 data.json 导出。 */
    public synchronized String loadSyncConfig() {
        if (!syncConfigFile.exists()) return "";
        try {
            return readText(syncConfigFile);
        } catch (Exception e) {
            return "";
        }
    }

    public synchronized String saveSyncConfig(String json) {
        if (json == null || json.isEmpty()) return "同步配置为空";
        try {
            if (!root.exists()) root.mkdirs();
            writeAtomic(syncConfigFile, json);
            return "OK";
        } catch (Exception e) {
            return "保存失败：" + e.getMessage();
        }
    }

    public File getRoot() {
        return root;
    }

    public synchronized String loadData() {
        if (!dataFile.exists()) return "";
        try {
            return readText(dataFile);
        } catch (Exception e) {
            return "";
        }
    }

    public synchronized String saveData(String json) {
        if (json == null || json.isEmpty()) return "数据为空，未保存";
        try {
            ensureDirs();
            String current = dataFile.exists() ? readText(dataFile) : "";
            if (current.equals(json)) return "OK";
            if (!current.isEmpty()) writeAutoBackup(current);
            writeAtomic(dataFile, json);
            return "OK";
        } catch (Exception e) {
            return "保存失败：" + e.getMessage();
        }
    }

    public synchronized String listBackups() {
        JSONArray arr = new JSONArray();
        File[] files = manualDir.listFiles();
        if (files == null) return arr.toString();
        List<JSONObject> metas = new ArrayList<>();
        for (File f : files) {
            if (!f.getName().endsWith(".json")) continue;
            try {
                JSONObject env = new JSONObject(readText(f));
                JSONObject meta = new JSONObject();
                meta.put("id", env.optString("id", f.getName().substring(0, f.getName().length() - 5)));
                meta.put("name", env.optString("name", ""));
                meta.put("time", env.optString("time", ""));
                meta.put("size", env.optLong("size", 0));
                metas.add(meta);
            } catch (Exception ignored) {
                // 坏文件直接跳过
            }
        }
        Collections.sort(metas, new Comparator<JSONObject>() {
            @Override
            public int compare(JSONObject a, JSONObject b) {
                return b.optString("time", "").compareTo(a.optString("time", ""));
            }
        });
        for (JSONObject m : metas) arr.put(m);
        return arr.toString();
    }

    public synchronized String createBackup(String name, String json) {
        if (json == null || json.isEmpty()) return "";
        try {
            ensureDirs();
            String id = "bak-" + System.currentTimeMillis() + "-" + Long.toString(System.nanoTime() % 100000, 36);
            String time = isoNow();
            int size = json.getBytes(StandardCharsets.UTF_8).length;
            String label = name == null ? "" : name.trim();
            JSONObject env = new JSONObject();
            env.put("id", id);
            env.put("name", label);
            env.put("time", time);
            env.put("size", size);
            env.put("data", json);
            writeAtomic(new File(manualDir, id + ".json"), env.toString());
            JSONObject meta = new JSONObject();
            meta.put("id", id);
            meta.put("name", label);
            meta.put("time", time);
            meta.put("size", size);
            return meta.toString();
        } catch (Exception e) {
            return "";
        }
    }

    public synchronized String restoreBackup(String id) {
        File f = manualFile(id);
        if (f == null || !f.exists()) return "";
        try {
            return new JSONObject(readText(f)).optString("data", "");
        } catch (Exception e) {
            return "";
        }
    }

    public synchronized String deleteBackup(String id) {
        File f = manualFile(id);
        if (f != null && f.exists()) f.delete();
        return "OK";
    }

    private File manualFile(String id) {
        if (id == null || id.isEmpty()) return null;
        for (int i = 0; i < id.length(); i++) {
            char c = id.charAt(i);
            boolean safe = (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9')
                    || c == '-' || c == '_' || c == '.';
            if (!safe) return null;
        }
        if (id.contains("..")) return null;
        return new File(manualDir, id + ".json");
    }

    private void ensureDirs() {
        if (!root.exists()) root.mkdirs();
        if (!autoDir.exists()) autoDir.mkdirs();
        if (!manualDir.exists()) manualDir.mkdirs();
    }

    private void writeAutoBackup(String content) {
        if (!autoDir.exists()) autoDir.mkdirs();
        String stamp = new SimpleDateFormat("yyyyMMdd-HHmmss-SSS", Locale.US).format(new Date());
        File target = new File(autoDir, "auto-" + stamp + ".json");
        try {
            writeAtomic(target, content);
        } catch (Exception ignored) {
            return;
        }
        File[] files = autoDir.listFiles();
        if (files == null || files.length <= MAX_AUTO_BACKUPS) return;
        List<File> sorted = new ArrayList<>(Arrays.asList(files));
        Collections.sort(sorted, new Comparator<File>() {
            @Override
            public int compare(File a, File b) {
                return a.getName().compareTo(b.getName());
            }
        });
        for (int i = 0; i < sorted.size() - MAX_AUTO_BACKUPS; i++) sorted.get(i).delete();
    }

    private static void writeAtomic(File target, String content) throws Exception {
        File parent = target.getParentFile();
        if (parent != null && !parent.exists()) parent.mkdirs();
        File tmp = new File(parent, target.getName() + ".tmp");
        FileOutputStream out = new FileOutputStream(tmp);
        try {
            out.write(content.getBytes(StandardCharsets.UTF_8));
            out.flush();
            out.getFD().sync();
        } finally {
            out.close();
        }
        if (target.exists() && !target.delete()) throw new Exception("无法覆盖旧文件");
        if (!tmp.renameTo(target)) throw new Exception("写入文件失败");
    }

    private static String readText(File file) throws Exception {
        InputStream in = new FileInputStream(file);
        try {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int total = 0;
            int n;
            while ((n = in.read(buf)) > 0) {
                total += n;
                if (total > MAX_READ_BYTES) throw new Exception("文件过大");
                out.write(buf, 0, n);
            }
            return new String(out.toByteArray(), StandardCharsets.UTF_8);
        } finally {
            in.close();
        }
    }

    private static String isoNow() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US);
        sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
        return sdf.format(new Date());
    }
}
