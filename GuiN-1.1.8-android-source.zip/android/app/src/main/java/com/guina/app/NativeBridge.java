package com.guina.app;

import android.webkit.JavascriptInterface;

/** WebView 与原生之间的桥，方法签名与 mobile/src/bridge.ts 一一对应。 */
public class NativeBridge {
    private final MainActivity activity;
    private final DataRepository repo;

    NativeBridge(MainActivity activity, DataRepository repo) {
        this.activity = activity;
        this.repo = repo;
    }

    @JavascriptInterface
    public String loadData() {
        return repo.loadData();
    }

    @JavascriptInterface
    public String saveData(String json) {
        return repo.saveData(json);
    }

    @JavascriptInterface
    public String listBackups() {
        return repo.listBackups();
    }

    @JavascriptInterface
    public String createBackup(String name, String json) {
        return repo.createBackup(name, json);
    }

    @JavascriptInterface
    public String restoreBackup(String id) {
        return repo.restoreBackup(id);
    }

    @JavascriptInterface
    public String deleteBackup(String id) {
        return repo.deleteBackup(id);
    }

    @JavascriptInterface
    public void scheduleReminder(String id, String title, String content, String triggerAt, String repeatKind, String repeatTime, boolean sound) {
        long at;
        try {
            at = Long.parseLong(triggerAt == null ? "" : triggerAt.trim());
        } catch (Exception e) {
            at = System.currentTimeMillis() + 60 * 1000L;
        }
        ReminderScheduler.schedule(activity, id, title, content, at, repeatKind, repeatTime, sound);
    }

    @JavascriptInterface
    public void cancelReminder(String id) {
        ReminderScheduler.cancel(activity, id);
    }

    @JavascriptInterface
    public void notifyTest(String title, String content) {
        NotificationHelper.notifyTest(activity, title, content);
    }

    @JavascriptInterface
    public void clearExpiryNotifications() {
        NotificationHelper.cancelExpirySummary(activity);
    }

    @JavascriptInterface
    public void exportData(String json, String filename) {
        activity.exportData(json, filename);
    }

    @JavascriptInterface
    public void importData() {
        activity.importData();
    }

    @JavascriptInterface
    public String getInfo() {
        return activity.buildInfoJson();
    }

    @JavascriptInterface
    public void openExternal(String url) {
        activity.openExternal(url);
    }

    @JavascriptInterface
    public void setTheme(String dark) {
        activity.applyTheme("1".equals(dark));
    }

    @JavascriptInterface
    public void requestNotificationPermission() {
        activity.requestNotificationPermission();
    }

    @JavascriptInterface
    public String isIgnoringBatteryOptimizations() {
        return activity.isIgnoringBatteryOptimizations() ? "1" : "0";
    }

    @JavascriptInterface
    public void requestIgnoreBatteryOptimization() {
        activity.requestIgnoreBatteryOptimization();
    }

    @JavascriptInterface
    public void openAutoStartSettings() {
        activity.openAutoStartSettings();
    }

    @JavascriptInterface
    public String canScheduleExactAlarms() {
        return activity.canScheduleExactAlarms() ? "1" : "0";
    }

    @JavascriptInterface
    public void openExactAlarmSettings() {
        activity.openExactAlarmSettings();
    }

    @JavascriptInterface
    public String addSystemAlarm(String title, String triggerAt, String repeatKind) {
        return activity.addSystemAlarm(title, triggerAt, repeatKind);
    }

    @JavascriptInterface
    public String getAlarmInfo() {
        return activity.getAlarmInfo();
    }

    @JavascriptInterface
    public void setAlarmMode(String mode) {
        activity.setAlarmMode(mode);
    }

    @JavascriptInterface
    public void runAlarmSelfCheck() {
        activity.runAlarmSelfCheck();
    }

    @JavascriptInterface
    public void setBadge(String count) {
        // 安卓没有桌面托盘角标；未读数在应用内底部导航上显示
    }

    @JavascriptInterface
    public String loadSyncConfig() {
        return repo.loadSyncConfig();
    }

    @JavascriptInterface
    public String saveSyncConfig(String json) {
        return repo.saveSyncConfig(json);
    }
}
