package com.guina.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import org.json.JSONObject;

public class AlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        String id = intent.getStringExtra("id");
        if (id == null) return;
        String raw = ReminderScheduler.read(context, id);
        if (raw == null) return;
        try {
            JSONObject o = new JSONObject(raw);
            String title = o.optString("title", "");
            String content = o.optString("content", "");
            String kind = o.optString("kind", "");
            String time = o.optString("time", "");
            boolean sound = o.optBoolean("sound", true);
            NotificationHelper.notifyReminder(context, id, title, content, kind, time, sound);
            if (!kind.isEmpty()) {
                long next = ReminderScheduler.computeNext(kind, time, System.currentTimeMillis() + 1000);
                if (next > 0) {
                    o.put("at", next);
                    ReminderScheduler.update(context, id, o.toString());
                    ReminderScheduler.reschedule(context, id);
                } else {
                    ReminderScheduler.remove(context, id);
                }
            } else {
                ReminderScheduler.remove(context, id);
            }
        } catch (Exception ignored) {
        }
    }
}
