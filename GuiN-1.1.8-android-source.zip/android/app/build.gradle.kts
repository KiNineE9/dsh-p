plugins {
    id("com.android.application")
}

android {
    namespace = "com.guina.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.guina.app"
        minSdk = 24
        targetSdk = 35
        versionCode = 12
        versionName = "1.1.8"
        resourceConfigurations += listOf("zh", "en")
    }

    signingConfigs {
        create("release") {
            storeFile = file("../guina-release.jks")
            storePassword = "guina2024"
            keyAlias = "guina"
            keyPassword = "guina2024"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            isShrinkResources = false
            signingConfig = signingConfigs.getByName("release")
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
        debug {
            applicationIdSuffix = ".debug"
            versionNameSuffix = "-debug"
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    buildFeatures {
        buildConfig = true
    }
}
