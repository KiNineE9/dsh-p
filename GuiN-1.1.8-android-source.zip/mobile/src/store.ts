import { createInitialState, DATA_VERSION, DEFAULT_SETTINGS, SAVED_NAME_LIMIT } from '../../src/shared/schema'
import type { AppNotification, AppSettings, AppState, Category, Item, Note, NotificationKind, Op, SearchHistoryEntry, StickyNote } from '../../src/shared/types'
import { normalizeTombstones } from '../../src/shared/sync/tombstones'
import { normalizeSearchHistory, type SearchHistoryKind } from '../../src/shared/history'
import * as db from '../../src/main/data'
import * as bridge from './bridge'

/** 手动备份最多保留 5 份（自动备份 7 份由 Android 壳落盘时维护，不在这里管） */
export const MAX_MANUAL_BACKUPS = 5

/** 把任意读到的内容规整成合法 AppState —— 与桌面版 src/main/store.ts 的逻辑保持一致 */
export function normalizeState(raw: unknown): AppState {
  const base = createInitialState()
  if (!raw || typeof raw !== 'object') return base
  const r = raw as Partial<AppState>
  const state: AppState = {
    version: DATA_VERSION,
    categories: Array.isArray(r.categories)
      ? (r.categories as Category[]).filter(isCategoryLike).map(migrateCategory)
      : [],
    items: Array.isArray(r.items) ? (r.items as Item[]).filter(isItemLike).map(migrateItem) : [],
    notes: Array.isArray(r.notes) ? (r.notes as Note[]).filter(isNoteLike) : [],
    stickies: Array.isArray(r.stickies) ? (r.stickies as StickyNote[]).filter(isStickyLike).map(migrateSticky) : [],
    tombstones: normalizeTombstones(r.tombstones),
    notifications: Array.isArray(r.notifications) ? r.notifications : [],
    settings: { ...DEFAULT_SETTINGS, expiryTiers: { ...DEFAULT_SETTINGS.expiryTiers } },
    savedNames: normalizeSavedNames(r.savedNames),
    searchHistory: normalizeSearchHistory(r.searchHistory),
    onboardingDone: Boolean(r.onboardingDone),
    createdAt: typeof r.createdAt === 'string' ? r.createdAt : base.createdAt
  }
  const settings: Partial<AppSettings> = r.settings && typeof r.settings === 'object' ? (r.settings as Partial<AppSettings>) : {}
  state.settings = {
    ...DEFAULT_SETTINGS,
    ...settings,
    expiryTiers: { ...DEFAULT_SETTINGS.expiryTiers, ...(settings.expiryTiers || {}) }
  }
  for (const b of base.categories) {
    if (!state.categories.some(function (c) { return c.id === b.id })) state.categories.push(b)
  }
  const catIds = new Set(state.categories.map(function (c) { return c.id }))
  state.items = state.items.filter(function (i) { return catIds.has(i.categoryId) })
  const itemIds = new Set(state.items.map(function (i) { return i.id }))
  state.notes = state.notes.filter(function (n) { return itemIds.has(n.itemId) })
  state.notifications = state.notifications.filter(function (n) { return itemIds.has(n.itemId) })
  const catById = new Map<string, Category>()
  for (const c of state.categories) catById.set(c.id, c)
  const itemById = new Map<string, Item>()
  for (const i of state.items) itemById.set(i.id, i)
  state.notifications = state.notifications.map(function (n) {
    const item = itemById.get(n.itemId)
    const cat = item ? catById.get(item.categoryId) : undefined
    const kind: 'food' | 'medicine' = cat && cat.baseTemplate === 'medicine' ? 'medicine' : 'food'
    return {
      ...n,
      kind: kind,
      type: kind === 'food' ? 'foodExpiring' : 'medicineExpiring'
    }
  })
  state.categories.sort(function (a, b) { return a.order - b.order })
  state.settings.expiryTiers = {
    30: Boolean(state.settings.expiryTiers[30]),
    15: Boolean(state.settings.expiryTiers[15]),
    7: Boolean(state.settings.expiryTiers[7]),
    1: Boolean(state.settings.expiryTiers[1])
  }
  return state
}

function migrateItem(item: Item): Item {
  const anyItem = item as unknown as Record<string, unknown>
  const hasLabel = typeof anyItem['locationLabel'] === 'string'
  const oldName = typeof item.locationName === 'string' ? item.locationName : ''
  return {
    ...item,
    locationLabel: hasLabel ? String(anyItem['locationLabel']) : oldName,
    locationName: hasLabel ? oldName : ''
  }
}

function migrateSticky(sticky: StickyNote): StickyNote {
  const kind = sticky.kind === 'reminder' || sticky.kind === 'note' ? sticky.kind : sticky.remindAt ? 'reminder' : 'note'
  const pinned = kind === 'note' ? Boolean(sticky.pinned) : false
  return {
    ...sticky,
    title: typeof sticky.title === 'string' ? sticky.title.trim().slice(0, 60) || undefined : undefined,
    kind: kind,
    pinned: pinned,
    pinnedAt: pinned ? sticky.pinnedAt || sticky.updatedAt || sticky.createdAt : undefined,
    remindAt: kind === 'reminder' ? sticky.remindAt || null : null,
    repeat: kind === 'reminder' ? sticky.repeat || null : null,
    notified: kind === 'note' ? true : Boolean(sticky.notified)
  }
}

function normalizeSavedNames(raw: unknown): AppState['savedNames'] {
  const out: AppState['savedNames'] = { place: [], container: [] }
  if (!raw || typeof raw !== 'object') return out
  const r = raw as { place?: unknown; container?: unknown }
  for (const type of ['place', 'container'] as const) {
    const list = Array.isArray(r[type]) ? (r[type] as Array<{ name?: unknown; lastUsedAt?: unknown }>) : []
    const seen = new Set<string>()
    for (const entry of list) {
      const name = typeof entry.name === 'string' ? entry.name.replace(/\s+/g, ' ').trim() : ''
      if (!name) continue
      const key = name.toLowerCase()
      if (seen.has(key)) continue
      seen.add(key)
      out[type].push({
        name: name,
        lastUsedAt: typeof entry.lastUsedAt === 'string' ? entry.lastUsedAt : new Date().toISOString()
      })
      if (out[type].length >= SAVED_NAME_LIMIT) break
    }
  }
  return out
}

/** 旧数据没有置顶字段：补成未置顶；置顶但没有时间的用创建时间兜底 */
function migrateCategory(category: Category): Category {
  const pinned = Boolean(category.pinned)
  return {
    ...category,
    pinned: pinned,
    pinnedAt: pinned ? category.pinnedAt || category.createdAt : undefined
  }
}

function isCategoryLike(c: unknown): boolean {
  if (!c || typeof c !== 'object') return false
  const o = c as Category
  return typeof o.id === 'string' && typeof o.name === 'string' && typeof o.baseTemplate === 'string'
}

function isItemLike(i: unknown): boolean {
  if (!i || typeof i !== 'object') return false
  const o = i as Item
  return (
    typeof o.id === 'string' &&
    typeof o.name === 'string' &&
    typeof o.categoryId === 'string' &&
    (typeof o.locationLabel === 'string' || typeof o.locationName === 'string')
  )
}

function isNoteLike(n: unknown): boolean {
  if (!n || typeof n !== 'object') return false
  const o = n as Note
  return typeof o.id === 'string' && typeof o.itemId === 'string' && typeof o.content === 'string'
}

function isStickyLike(s: unknown): boolean {
  if (!s || typeof s !== 'object') return false
  const o = s as StickyNote
  return typeof o.id === 'string' && typeof o.content === 'string'
}

type Listener = () => void

/**
 * 手机端状态容器：内存里持有一份 AppState，所有改动都走 data.ts 里的纯函数，
 * 成功后立刻通过 bridge 落盘（Android 侧原子写 + 自动备份），再通知界面刷新。
 */
class MobileStore {
  state: AppState = createInitialState()
  dataDir = ''
  onSaveError: ((message: string) => void) | null = null
  private listeners: Set<Listener> = new Set()
  private saveTimer: number | null = null

  init(): void {
    let parsed: unknown = null
    const raw = bridge.loadData()
    if (raw && raw.trim()) {
      try {
        parsed = JSON.parse(raw)
      } catch {
        parsed = null
      }
    }
    this.state = normalizeState(parsed)
    this.state.version = DATA_VERSION
    const info = bridge.getInfo()
    this.dataDir = info.dataDir
    this.persistNow()
    this.emit()
  }

  subscribe(listener: Listener): () => void {
    this.listeners.add(listener)
    return () => {
      this.listeners.delete(listener)
    }
  }

  private emit(): void {
    this.listeners.forEach(function (fn) {
      try {
        fn()
      } catch (err) {
        console.error(err)
      }
    })
  }

  /** 改动完成后的统一收尾：立刻落盘并通知界面 */
  commit(): void {
    this.persistNow()
    this.emit()
  }

  persistNow(): void {
    if (this.saveTimer !== null) {
      window.clearTimeout(this.saveTimer)
      this.saveTimer = null
    }
    try {
      bridge.saveData(JSON.stringify(this.state))
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err)
      if (this.onSaveError) this.onSaveError('保存失败：' + message)
    }
  }

  /** 合并短时间内的连续改动，避免频繁写盘 */
  private schedulePersist(): void {
    if (this.saveTimer !== null) return
    const self = this
    this.saveTimer = window.setTimeout(function () {
      self.saveTimer = null
      self.persistNow()
    }, 150)
  }

  private done<T>(op: Op<T>): Op<T> {
    if (op.ok) this.commit()
    return op
  }

  /* ----------------------------- 分类 ----------------------------- */

  createCategory(draft: Parameters<typeof db.createCategory>[1]): Op<Category> {
    return this.done(db.createCategory(this.state, draft))
  }

  updateCategory(id: string, patch: Parameters<typeof db.updateCategory>[2]): Op<Category> {
    return this.done(db.updateCategory(this.state, id, patch))
  }

  deleteCategory(id: string): Op<{ removedItems: number }> {
    return this.done(db.deleteCategory(this.state, id))
  }

  reorderCategories(ids: string[]): Op<Category[]> {
    return this.done(db.reorderCategories(this.state, ids))
  }

  /* ----------------------------- 条目 ----------------------------- */

  createItem(categoryId: string, draft: Parameters<typeof db.createItem>[2]): Op<Item> {
    return this.done(db.createItem(this.state, categoryId, draft))
  }

  updateItem(id: string, draft: Parameters<typeof db.updateItem>[2]): Op<Item> {
    return this.done(db.updateItem(this.state, id, draft))
  }

  deleteItem(id: string): Op<{ id: string }> {
    return this.done(db.deleteItem(this.state, id))
  }

  removeSavedName(type: 'place' | 'container', name: string): Op<{ type: string; name: string }> {
    return this.done(db.removeSavedName(this.state, type, name))
  }

  /* --------------------------- 搜索历史 --------------------------- */

  addSearchHistory(kind: SearchHistoryKind, text: string): Op<SearchHistoryEntry[]> {
    return this.done(db.addSearchHistory(this.state, kind, text))
  }

  removeSearchHistory(kind: SearchHistoryKind, text: string): Op<{ kind: SearchHistoryKind; text: string }> {
    return this.done(db.removeSearchHistory(this.state, kind, text))
  }

  /* ----------------------------- 备注 ----------------------------- */

  addNote(itemId: string, content: string): Op<Note> {
    return this.done(db.addNote(this.state, itemId, content))
  }

  updateNote(id: string, content: string): Op<Note> {
    return this.done(db.updateNote(this.state, id, content))
  }

  deleteNote(id: string): Op<{ id: string }> {
    return this.done(db.deleteNote(this.state, id))
  }

  /* ----------------------------- 便签 ----------------------------- */

  createSticky(input: Parameters<typeof db.createSticky>[1]): Op<StickyNote> {
    return this.done(db.createSticky(this.state, input))
  }

  updateSticky(id: string, patch: Parameters<typeof db.updateSticky>[2]): Op<StickyNote> {
    return this.done(db.updateSticky(this.state, id, patch))
  }

  deleteSticky(id: string): Op<{ id: string }> {
    return this.done(db.deleteSticky(this.state, id))
  }

  /* ----------------------------- 通知 ----------------------------- */

  markNotificationRead(id: string, read: boolean): Op<AppNotification> {
    return this.done(db.markNotificationRead(this.state, id, read))
  }

  markAllNotificationsRead(kind?: NotificationKind): Op<number> {
    return this.done(db.markAllNotificationsRead(this.state, kind))
  }

  deleteNotification(id: string): Op<{ id: string }> {
    return this.done(db.deleteNotification(this.state, id))
  }

  deleteReadNotifications(kind?: NotificationKind): Op<number> {
    return this.done(db.deleteReadNotifications(this.state, kind))
  }

  /* ----------------------------- 设置 ----------------------------- */

  updateSettings(patch: Partial<AppSettings>): void {
    db.updateSettings(this.state, patch)
    this.commit()
  }

  finishOnboarding(): void {
    this.state.onboardingDone = true
    this.commit()
  }

  showOnboarding(): void {
    this.state.onboardingDone = false
    this.commit()
  }

  /* --------------------------- 手动备份 --------------------------- */

  listBackups(): bridge.NativeBackup[] {
    return bridge.listBackups()
  }

  createBackup(name?: string): { ok: boolean; error?: string; backup?: bridge.NativeBackup } {
    const existing = bridge.listBackups()
    if (existing.length >= MAX_MANUAL_BACKUPS) {
      return { ok: false, error: '手动备份最多 5 份，先删掉一份再备份' }
    }
    const label = name && name.trim() ? name.trim().slice(0, 40) : defaultBackupName()
    const created = bridge.createBackup(label, JSON.stringify(this.state))
    if (!created) return { ok: false, error: '备份失败，请再试一次' }
    return { ok: true, backup: created }
  }

  restoreBackup(id: string): { ok: boolean; error?: string } {
    const json = bridge.restoreBackup(id)
    if (!json) return { ok: false, error: '找不到这份备份' }
    const parsed = this.parseState(json)
    if (!parsed) return { ok: false, error: '这份备份内容不完整，无法还原' }
    this.state = parsed
    this.commit()
    return { ok: true }
  }

  deleteBackup(id: string): boolean {
    return bridge.deleteBackup(id)
  }

  /* --------------------------- 导入导出 --------------------------- */

  exportJson(): string {
    return JSON.stringify(this.state, null, 2)
  }

  replaceStateFromJson(text: string): { ok: boolean; error?: string } {
    const parsed = this.parseState(text)
    if (!parsed) return { ok: false, error: '文件内容不是 GuiN 的数据，请选择导出的 data.json' }
    this.state = parsed
    this.commit()
    return { ok: true }
  }

  private parseState(text: string): AppState | null {
    try {
      const parsed = JSON.parse(text) as Record<string, unknown>
      if (!parsed || typeof parsed !== 'object') return null
      if (!Array.isArray(parsed['categories']) || !Array.isArray(parsed['items'])) return null
      const next = normalizeState(parsed)
      next.version = DATA_VERSION
      return next
    } catch {
      return null
    }
  }

  /* ----------------------------- 派生 ----------------------------- */

  unreadCount(): number {
    return db.unreadCount(this.state)
  }

  /** 进入前台时重新读盘（原生通知里的操作可能已经改过数据） */
  reload(): void {
    let parsed: unknown = null
    const raw = bridge.loadData()
    if (raw && raw.trim()) {
      try {
        parsed = JSON.parse(raw)
      } catch {
        parsed = null
      }
    }
    const next = normalizeState(parsed)
    next.version = DATA_VERSION
    this.state = next
    this.emit()
  }

  /** 不落盘、只通知界面（原生侧已经写过盘时用） */
  refresh(): void {
    this.emit()
  }
}

function defaultBackupName(): string {
  const d = new Date()
  const pad = function (n: number): string { return n < 10 ? '0' + n : String(n) }
  return '手动备份 ' + d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()) + ' ' + pad(d.getHours()) + ':' + pad(d.getMinutes())
}

export const store = new MobileStore()

/** 记一条搜索历史（搜索框下拉的「最近搜索」靠它更新） */
export function recordSearchHistory(kind: SearchHistoryKind, text: string): void {
  const keyword = text.trim()
  if (!keyword) return
  store.addSearchHistory(kind, keyword)
}
