/**
 * 与 Android 壳通信的桥。桌面浏览器里没有 window.GuinaNative，
 * 会自动退回 localStorage + 下载文件，方便在电脑上调试手机界面。
 */

export interface Inset {
  top: number
  right: number
  bottom: number
  left: number
}

export interface NativeInfo {
  version: string
  versionName: string
  sdk: number
  model: string
  manufacturer: string
  dataDir: string
  width: number
  height: number
  insets: Inset
  notificationPermission: boolean
  /** 是否已忽略电池优化（false 时通知可能被系统延迟） */
  ignoringBatteryOptimizations?: boolean
  /** 是否允许精确闹钟（Android 12+，不允许时提醒可能晚几分钟） */
  canScheduleExactAlarms?: boolean
}

export interface NativeBackup {
  id: string
  name: string
  time: string
  size: number
}

interface NativeApi {
  loadData(): string
  saveData(json: string): string
  listBackups(): string
  createBackup(name: string, json: string): string
  restoreBackup(id: string): string
  deleteBackup(id: string): string
  scheduleReminder(
    id: string,
    title: string,
    content: string,
    triggerAt: string,
    repeatKind: string,
    repeatTime: string,
    sound: boolean
  ): void
  cancelReminder(id: string): void
  notifyTest(title: string, content: string): void
  clearExpiryNotifications(): void
  exportData(json: string, filename: string): void
  importData(): void
  getInfo(): string
  openExternal(url: string): void
  setTheme(dark: string): void
  requestNotificationPermission(): void
  isIgnoringBatteryOptimizations(): string
  requestIgnoreBatteryOptimization(): void
  openAutoStartSettings(): void
  canScheduleExactAlarms(): string
  openExactAlarmSettings(): void
  addSystemAlarm(title: string, triggerAt: string, repeatKind: string): string
  getAlarmInfo(): string
  setAlarmMode(mode: string): void
  runAlarmSelfCheck(): void
  setBadge(count: string): void
  loadSyncConfig(): string
  saveSyncConfig(json: string): string
}

declare global {
  interface Window {
    GuinaNative?: NativeApi
    __nativeExportResult?: (ok: boolean, message: string) => void
    __nativeImportResult?: (json: string) => void
    __handleBack?: () => string
  }
}

const native: NativeApi | undefined = typeof window !== 'undefined' ? window.GuinaNative : undefined

export const isNative = Boolean(native)
export const isBrowser = !native

const LS_DATA = 'guina-mobile-data'
const LS_BACKUPS = 'guina-mobile-backups'
const LS_SYNC = 'guina-mobile-sync'

interface FallbackBackup extends NativeBackup {
  json: string
}

function readFallbackBackups(): FallbackBackup[] {
  try {
    const raw = localStorage.getItem(LS_BACKUPS)
    if (!raw) return []
    const parsed = JSON.parse(raw)
    return Array.isArray(parsed) ? (parsed as FallbackBackup[]) : []
  } catch {
    return []
  }
}

function writeFallbackBackups(list: FallbackBackup[]): void {
  try {
    localStorage.setItem(LS_BACKUPS, JSON.stringify(list))
  } catch {
    return
  }
}

export function loadData(): string {
  if (native) {
    try {
      return native.loadData() || ''
    } catch {
      return ''
    }
  }
  try {
    return localStorage.getItem(LS_DATA) || ''
  } catch {
    return ''
  }
}

export function saveData(json: string): void {
  if (native) {
    const result = native.saveData(json)
    if (result !== 'OK') throw new Error(result || '保存失败')
    return
  }
  localStorage.setItem(LS_DATA, json)
}

export function getInfo(): NativeInfo {
  if (native) {
    try {
      const raw = native.getInfo()
      if (raw) {
        const parsed = JSON.parse(raw) as Partial<NativeInfo>
        return {
          version: parsed.version || '1.0.3',
          versionName: parsed.versionName || '1.0.3',
          sdk: parsed.sdk || 0,
          model: parsed.model || 'Android',
          manufacturer: parsed.manufacturer || '',
          dataDir: parsed.dataDir || '',
          width: parsed.width || window.innerWidth,
          height: parsed.height || window.innerHeight,
          insets: parsed.insets || { top: 0, right: 0, bottom: 0, left: 0 },
          notificationPermission: Boolean(parsed.notificationPermission),
          ignoringBatteryOptimizations: Boolean(parsed.ignoringBatteryOptimizations),
          canScheduleExactAlarms: Boolean(parsed.canScheduleExactAlarms)
        }
      }
    } catch {
      // fallthrough
    }
  }
  return {
    version: 'dev',
    versionName: '1.0.3',
    sdk: 0,
    model: '浏览器调试',
    manufacturer: '',
    dataDir: 'localStorage',
    width: window.innerWidth,
    height: window.innerHeight,
    insets: { top: 0, right: 0, bottom: 0, left: 0 },
    notificationPermission: true,
    ignoringBatteryOptimizations: true,
    canScheduleExactAlarms: true
  }
}

export function listBackups(): NativeBackup[] {
  if (native) {
    try {
      const raw = native.listBackups()
      const parsed = raw ? JSON.parse(raw) : []
      return Array.isArray(parsed) ? (parsed as NativeBackup[]) : []
    } catch {
      return []
    }
  }
  return readFallbackBackups().map(function (b) {
    return { id: b.id, name: b.name, time: b.time, size: b.size }
  })
}

export function createBackup(name: string, json: string): NativeBackup | null {
  if (native) {
    try {
      const raw = native.createBackup(name, json)
      return raw ? (JSON.parse(raw) as NativeBackup) : null
    } catch {
      return null
    }
  }
  const list = readFallbackBackups()
  const backup: FallbackBackup = {
    id: 'bak-' + Date.now() + '-' + Math.random().toString(36).slice(2, 6),
    name: name,
    time: new Date().toISOString(),
    size: json.length,
    json: json
  }
  list.unshift(backup)
  writeFallbackBackups(list.slice(0, 5))
  return { id: backup.id, name: backup.name, time: backup.time, size: backup.size }
}

export function restoreBackup(id: string): string {
  if (native) {
    try {
      return native.restoreBackup(id) || ''
    } catch {
      return ''
    }
  }
  const found = readFallbackBackups().find(function (b) {
    return b.id === id
  })
  return found ? found.json : ''
}

export function deleteBackup(id: string): boolean {
  if (native) {
    try {
      return native.deleteBackup(id) === 'OK'
    } catch {
      return false
    }
  }
  const list = readFallbackBackups()
  const next = list.filter(function (b) {
    return b.id !== id
  })
  writeFallbackBackups(next)
  return next.length !== list.length
}

export function scheduleReminder(
  id: string,
  title: string,
  content: string,
  triggerAtMillis: number,
  repeatKind: string,
  repeatTime: string,
  sound: boolean
): void {
  if (!native) return
  try {
    native.scheduleReminder(id, title || '', content || '', String(triggerAtMillis), repeatKind || '', repeatTime || '', sound)
  } catch {
    return
  }
}

export function cancelReminder(id: string): void {
  if (!native) return
  try {
    native.cancelReminder(id)
  } catch {
    return
  }
}

export function notifyTest(title: string, content: string): void {
  if (!native) return
  try {
    native.notifyTest(title, content)
  } catch {
    return
  }
}

/** 到期提醒都看过了：清掉通知栏里那条汇总通知（1.1.8） */
export function clearExpiryNotifications(): void {
  if (!native) return
  try {
    native.clearExpiryNotifications()
  } catch {
    return
  }
}

export function requestNotificationPermission(): void {
  if (!native) return
  try {
    native.requestNotificationPermission()
  } catch {
    return
  }
}

export function setTheme(dark: boolean): void {
  if (!native) return
  try {
    native.setTheme(dark ? '1' : '0')
  } catch {
    return
  }
}

/* --------------------- 通知可靠性（电池优化 / 自启动 / 精确闹钟） --------------------- */

export function isIgnoringBatteryOptimizations(): boolean {
  if (!native) return true
  try {
    return native.isIgnoringBatteryOptimizations() === '1'
  } catch {
    return false
  }
}

export function requestIgnoreBatteryOptimization(): void {
  if (!native) return
  try {
    native.requestIgnoreBatteryOptimization()
  } catch {
    return
  }
}

export function openAutoStartSettings(): void {
  if (!native) return
  try {
    native.openAutoStartSettings()
  } catch {
    return
  }
}

export function canScheduleExactAlarms(): boolean {
  if (!native) return true
  try {
    return native.canScheduleExactAlarms() === '1'
  } catch {
    return false
  }
}

export function openExactAlarmSettings(): void {
  if (!native) return
  try {
    native.openExactAlarmSettings()
  } catch {
    return
  }
}

export type AlarmImportMode = 'auto' | 'silent' | 'guided'

export interface SystemAlarmInfo {
  /** 系统默认时钟应用的包名 */
  clockPackage: string
  /** 时钟应用在桌面显示的名字 */
  clockLabel: string
  /** 用户选择的导入方式 */
  mode: AlarmImportMode
  /** 循环导入时最终会用的方式（auto 已按识别结果折算） */
  effective: AlarmImportMode
  /** 这台手机的时钟在静默导入时已知会丢重复规则 */
  ignoresRepeat: boolean
  /** 是否检测到可用的时钟应用 */
  resolved: boolean
  /** 手机厂商（识别不到时钟包名时也能按品牌判断是否要打开确认） */
  manufacturer: string
}

/** 识别到的系统时钟应用与当前导入方式（浏览器里返回 null） */
export function getAlarmInfo(): SystemAlarmInfo | null {
  if (!native) return null
  try {
    const raw = native.getAlarmInfo()
    if (!raw) return null
    const parsed = JSON.parse(raw) as Partial<SystemAlarmInfo>
    const mode: AlarmImportMode = parsed.mode === 'silent' || parsed.mode === 'guided' ? parsed.mode : 'auto'
    const effective: AlarmImportMode =
      parsed.effective === 'silent' || parsed.effective === 'guided' ? parsed.effective : mode
    return {
      clockPackage: parsed.clockPackage || '',
      clockLabel: parsed.clockLabel || '',
      mode: mode,
      effective: effective,
      ignoresRepeat: Boolean(parsed.ignoresRepeat),
      resolved: Boolean(parsed.resolved),
      manufacturer: parsed.manufacturer || ''
    }
  } catch {
    return null
  }
}

/** 切换系统闹钟导入方式：auto 自动识别 / silent 静默导入 / guided 打开时钟确认 */
export function setAlarmMode(mode: AlarmImportMode): void {
  if (!native) return
  try {
    native.setAlarmMode(mode)
  } catch {
    return
  }
}

/** 自检：打开时钟应用并预选「工作日」，让用户自己确认循环是否生效 */
export function runAlarmSelfCheck(): void {
  if (!native) return
  try {
    native.runAlarmSelfCheck()
  } catch {
    return
  }
}

/**
 * 把提醒写进系统「时钟 / 闹钟」应用（只有原生壳支持，浏览器里返回空串）。
 * repeatKind 取 'daily' | 'weekdays' | 'weekends'，空串表示一次性闹钟。
 * 返回实际使用的导入方式：silent 静默写入 / guided 打开时钟让用户确认。
 */
export function addSystemAlarm(title: string, triggerAtMillis: number, repeatKind: string): string {
  if (!native) return ''
  try {
    return native.addSystemAlarm(title || '', String(triggerAtMillis), repeatKind || '') || ''
  } catch {
    return ''
  }
}

export function setBadge(count: number): void {
  if (!native) return
  try {
    native.setBadge(String(count))
  } catch {
    return
  }
}

export function openExternal(url: string): void {
  if (native) {
    try {
      native.openExternal(url)
      return
    } catch {
      // fallthrough
    }
  }
  window.open(url, '_blank')
}

let exportResolver: ((message: string) => void) | null = null
let importResolver: ((json: string | null) => void) | null = null

if (typeof window !== 'undefined') {
  window.__nativeExportResult = function (ok: boolean, message: string): void {
    const run = exportResolver
    exportResolver = null
    if (run) run(ok ? '' : message || '导出失败')
  }
  window.__nativeImportResult = function (json: string): void {
    const run = importResolver
    importResolver = null
    if (run) run(json ? json : null)
  }
}

export function exportData(json: string, filename: string): Promise<string> {
  if (native) {
    return new Promise(function (resolve) {
      exportResolver = resolve
      try {
        native.exportData(json, filename)
      } catch (err) {
        exportResolver = null
        resolve('导出失败：' + String(err))
      }
    })
  }
  const blob = new Blob([json], { type: 'application/json' })
  const url = URL.createObjectURL(blob)
  const link = document.createElement('a')
  link.href = url
  link.download = filename
  document.body.appendChild(link)
  link.click()
  document.body.removeChild(link)
  window.setTimeout(function () {
    URL.revokeObjectURL(url)
  }, 1000)
  return Promise.resolve('')
}

export function importData(): Promise<string | null> {
  if (native) {
    return new Promise(function (resolve) {
      importResolver = resolve
      try {
        native.importData()
      } catch (err) {
        importResolver = null
        resolve(null)
      }
    })
  }
  return new Promise(function (resolve) {
    const input = document.createElement('input')
    input.type = 'file'
    input.accept = '.json,application/json'
    input.onchange = function () {
      const file = input.files && input.files[0]
      if (!file) {
        resolve(null)
        return
      }
      const reader = new FileReader()
      reader.onload = function () {
        resolve(typeof reader.result === 'string' ? reader.result : null)
      }
      reader.onerror = function () {
        resolve(null)
      }
      reader.readAsText(file)
    }
    input.click()
  })
}

/* ------------------------- 同步设备配置 ------------------------- */

export function loadSyncConfig(): string {
  if (native) {
    try {
      return native.loadSyncConfig() || ''
    } catch {
      return ''
    }
  }
  try {
    return localStorage.getItem(LS_SYNC) || ''
  } catch {
    return ''
  }
}

export function saveSyncConfig(json: string): void {
  if (native) {
    const result = native.saveSyncConfig(json)
    if (result !== 'OK') throw new Error(result || '保存同步配置失败')
    return
  }
  localStorage.setItem(LS_SYNC, json)
}
