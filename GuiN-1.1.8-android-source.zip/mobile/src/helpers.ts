import type { ExpiryLevel, Item, ThemeMode } from '../../src/shared/types'
import { daysUntil, expiryLevel, formatDate, formatDateTime, formatRemain } from '../../src/shared/search'
import { formatLocation } from '../../src/shared/schema'
import { setTheme } from './bridge'

export function cn(...parts: Array<string | false | null | undefined>): string {
  const list: string[] = []
  for (let i = 0; i < parts.length; i += 1) {
    const part = parts[i]
    if (part) list.push(part)
  }
  return list.join(' ')
}

/** 桌面版同款提示音：880Hz 短促一声 */
export function playBeep(): void {
  try {
    const Ctor = window.AudioContext
    if (!Ctor) return
    const ctx = new Ctor()
    const osc = ctx.createOscillator()
    const gain = ctx.createGain()
    osc.type = 'sine'
    osc.frequency.value = 880
    gain.gain.value = 0.06
    osc.connect(gain)
    gain.connect(ctx.destination)
    osc.start()
    window.setTimeout(function () {
      try {
        osc.stop()
        void ctx.close()
      } catch {
        return
      }
    }, 260)
  } catch {
    return
  }
}

export interface ExpiryInfo {
  days: number
  level: ExpiryLevel
  text: string
  expired: boolean
}

export function expiryInfoFor(item: Item): ExpiryInfo | null {
  const date = item.fields.expiresAt
  if (!date) return null
  const days = daysUntil(date)
  if (days === null) return null
  return { days: days, level: expiryLevel(days), text: formatRemain(days), expired: days < 0 }
}

export function levelClass(level: ExpiryLevel): string {
  return 'level-' + level
}

export function locationOf(item: Item): string {
  return formatLocation(item.locationLabel || '', item.locationName || '')
}

function pad2(value: number): string {
  return value < 10 ? '0' + value : String(value)
}

export function formatLocalInput(date: Date): string {
  return (
    String(date.getFullYear()) +
    '-' +
    pad2(date.getMonth() + 1) +
    '-' +
    pad2(date.getDate()) +
    'T' +
    pad2(date.getHours()) +
    ':' +
    pad2(date.getMinutes())
  )
}

export function isoFromLocalInput(value: string): string | null {
  if (!value) return null
  const date = new Date(value)
  if (Number.isNaN(date.getTime())) return null
  return date.toISOString()
}

export function localInputFromIso(iso: string | null): string {
  if (!iso) return ''
  const date = new Date(iso)
  if (Number.isNaN(date.getTime())) return ''
  return formatLocalInput(date)
}

export function minutesLater(minutes: number): string {
  const date = new Date()
  date.setMinutes(date.getMinutes() + minutes)
  return formatLocalInput(date)
}

export function tomorrowMorning(): string {
  const date = new Date()
  date.setDate(date.getDate() + 1)
  date.setHours(9, 0, 0, 0)
  return formatLocalInput(date)
}

export function dayText(date: Date): string {
  const today = new Date()
  const sameDay =
    date.getFullYear() === today.getFullYear() &&
    date.getMonth() === today.getMonth() &&
    date.getDate() === today.getDate()
  if (sameDay) return '今天'
  const yesterday = new Date()
  yesterday.setDate(yesterday.getDate() - 1)
  if (
    date.getFullYear() === yesterday.getFullYear() &&
    date.getMonth() === yesterday.getMonth() &&
    date.getDate() === yesterday.getDate()
  ) {
    return '昨天'
  }
  return formatDate(date.toISOString())
}

export function shortDateTime(iso: string | null): string {
  if (!iso) return ''
  const date = new Date(iso)
  if (Number.isNaN(date.getTime())) return ''
  return dayText(date) + ' ' + pad2(date.getHours()) + ':' + pad2(date.getMinutes())
}

export { formatDate, formatDateTime, formatRemain }

/** 主题：system 跟随系统；同时把状态栏图标深浅告诉原生壳 */
export function applyTheme(mode: ThemeMode): void {
  const media = window.matchMedia('(prefers-color-scheme: dark)')
  const dark = mode === 'dark' || (mode === 'system' && media.matches)
  document.documentElement.dataset.theme = dark ? 'dark' : 'light'
  document.documentElement.style.colorScheme = dark ? 'dark' : 'light'
  const meta = document.querySelector('meta[name="theme-color"]')
  if (meta) meta.setAttribute('content', dark ? '#1c1d1f' : '#f6f5f2')
  setTheme(dark)
}

/** 自定义下拉选项的显示值 */
export function fieldText(value: unknown): string {
  if (value === undefined || value === null) return ''
  if (typeof value === 'boolean') return value ? '是' : '否'
  return String(value)
}
