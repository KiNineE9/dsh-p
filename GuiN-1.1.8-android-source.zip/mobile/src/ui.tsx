import { useEffect, type ReactNode } from 'react'
import { recentSearchTexts, type SearchHistoryKind } from '../../src/shared/history'
import { SEARCH_HISTORY_SHOWN } from '../../src/shared/schema'
import type { AppState } from '../../src/shared/types'
import { store } from './store'

export function Sheet(props: {
  title: string
  onClose: () => void
  children: ReactNode
  footer?: ReactNode
}) {
  useEffect(() => {
    const prev = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    return function () {
      document.body.style.overflow = prev
    }
  }, [])
  return (
    <div className="sheet-mask" onClick={props.onClose}>
      <div className="sheet-panel" onClick={function (e) { e.stopPropagation() }}>
        <div className="sheet-handle" />
        <div className="sheet-head">
          <div className="sheet-title">{props.title}</div>
          <button className="icon-btn plain" onClick={props.onClose} aria-label="关闭">
            ✕
          </button>
        </div>
        <div className="sheet-body">{props.children}</div>
        {props.footer ? <div className="sheet-foot">{props.footer}</div> : null}
      </div>
    </div>
  )
}

export function ConfirmDialog(props: {
  title: string
  body?: string
  okText?: string
  cancelText?: string
  danger?: boolean
  onCancel: () => void
  onOk: () => void
}) {
  return (
    <div className="confirm-mask" onClick={props.onCancel}>
      <div className="confirm-card" onClick={function (e) { e.stopPropagation() }}>
        <div className="confirm-title">{props.title}</div>
        {props.body ? <div className="confirm-body">{props.body}</div> : null}
        <div className="confirm-actions">
          <button className="btn ghost" onClick={props.onCancel}>
            {props.cancelText || '取消'}
          </button>
          <button className={'btn ' + (props.danger ? 'danger' : 'primary')} onClick={props.onOk}>
            {props.okText || '确定'}
          </button>
        </div>
      </div>
    </div>
  )
}

export function Toast(props: { message: string }) {
  return <div className="toast">{props.message}</div>
}

export function Switch(props: { on: boolean; onChange: (next: boolean) => void }) {
  return (
    <button
      className={'switch' + (props.on ? ' on' : '')}
      onClick={function () { props.onChange(!props.on) }}
      role="switch"
      aria-checked={props.on}
    />
  )
}

export function Seg<T extends string>(props: {
  value: T
  options: Array<{ value: T; label: string }>
  onChange: (next: T) => void
  /** 可选的 data-testid 前缀，按钮会变成 testId-value */
  testId?: string
}) {
  return (
    <div className="seg">
      {props.options.map(function (opt) {
        return (
          <button
            key={opt.value}
            className={'seg-item' + (opt.value === props.value ? ' active' : '')}
            data-testid={props.testId ? props.testId + '-' + opt.value : undefined}
            onClick={function () { props.onChange(opt.value) }}
          >
            {opt.label}
          </button>
        )
      })}
    </div>
  )
}

export function Field(props: {
  label: string
  required?: boolean
  error?: string
  hint?: string
  children: ReactNode
}) {
  return (
    <div className="field">
      <div className="field-label">
        {props.label}
        {props.required ? <span className="req">*</span> : null}
      </div>
      {props.children}
      {props.error ? <div className="field-error">{props.error}</div> : null}
      {!props.error && props.hint ? <div className="field-hint">{props.hint}</div> : null}
    </div>
  )
}

/** 搜索历史列表：手机端搜索框和便签搜索共用，最多显示 5 条，可逐条删除 */
export function SearchHistoryList(props: {
  state: AppState
  kind: SearchHistoryKind
  testId: string
  onPick: (text: string) => void
}) {
  const enabled =
    props.kind === 'item' ? props.state.settings.itemSearchHistory : props.state.settings.stickySearchHistory
  if (!enabled) return null
  const texts = recentSearchTexts(props.state.searchHistory[props.kind], SEARCH_HISTORY_SHOWN)
  if (!texts.length) return null
  return (
    <div className="history" data-testid={props.testId}>
      <div className="history-head">最近搜索</div>
      {texts.map(function (text) {
        return (
          <div className="history-row" key={text}>
            <button
              className="history-text"
              data-testid={props.testId + '-item'}
              onClick={function () { props.onPick(text) }}
            >
              <span className="history-icon">🕘</span>
              <span className="history-word">{text}</span>
            </button>
            <button
              className="history-del"
              data-testid={props.testId + '-delete'}
              onClick={function () { store.removeSearchHistory(props.kind, text) }}
              aria-label="删除这条历史"
            >
              ×
            </button>
          </div>
        )
      })}
    </div>
  )
}

export function EmptyState(props: { icon?: string; text: string; action?: ReactNode }) {
  return (
    <div className="empty">
      {props.icon ? <span className="empty-icon">{props.icon}</span> : null}
      <div>{props.text}</div>
      {props.action ? <div style={{ marginTop: 10 }}>{props.action}</div> : null}
    </div>
  )
}

export function SwitchRow(props: {
  title: string
  sub?: string
  on: boolean
  onChange: (next: boolean) => void
}) {
  return (
    <div className="row">
      <div className="row-main">
        <div className="row-title">{props.title}</div>
        {props.sub ? <div className="row-sub">{props.sub}</div> : null}
      </div>
      <Switch on={props.on} onChange={props.onChange} />
    </div>
  )
}
