import { useEffect, useRef, useState } from 'react'
import type { StickyKind, StickyNote } from '../../src/shared/types'
import { sortCategoriesForDisplay } from '../../src/shared/schema'
import { store } from './store'
import * as bridge from './bridge'
import { applyTheme, playBeep } from './helpers'
import { collectDue, handleReminderAction, resyncAll, syncExpiry } from './reminders'
import { HomeScreen } from './screens/HomeScreen'
import { CategoryScreen } from './screens/CategoryScreen'
import { SearchScreen } from './screens/SearchScreen'
import { SettingsScreen } from './screens/SettingsScreen'
import { OnboardingScreen } from './screens/OnboardingScreen'
import { ItemFormSheet } from './sheets/ItemFormSheet'
import { ItemDetailSheet } from './sheets/ItemDetailSheet'
import { StickyFormSheet } from './sheets/StickyFormSheet'
import { StickyDetailSheet } from './sheets/StickyDetailSheet'
import { CategoryFormSheet } from './sheets/CategoryFormSheet'
import { NotificationsSheet } from './sheets/NotificationsSheet'
import { BackupsSheet } from './sheets/BackupsSheet'
import { ReminderPopup } from './sheets/ReminderPopup'
import { SyncSheet } from './sheets/SyncSheet'
import { ConfirmDialog, Sheet, Toast } from './ui'
import { bootSyncRuntime, onSyncProgress, setIncomingSyncHandler } from './syncClient'
import type { IncomingSyncRequest } from '../../src/shared/sync/types'

type Tab = 'home' | 'search' | 'settings'

type SheetState =
  | { kind: 'item-form'; categoryId: string; itemId?: string }
  | { kind: 'item-detail'; itemId: string }
  | { kind: 'sticky-form'; stickyId?: string; initialKind: StickyKind }
  | { kind: 'sticky-detail'; stickyId: string }
  | { kind: 'category-form'; categoryId?: string }
  | { kind: 'category-actions'; categoryId: string }
  | { kind: 'pick-category' }
  | { kind: 'notifications' }
  | { kind: 'backups' }
  | { kind: 'sync' }

interface ConfirmState {
  title: string
  body?: string
  okText?: string
  danger?: boolean
  onOk: () => void
}

function todayStamp(): string {
  const d = new Date()
  const pad = function (n: number): string { return n < 10 ? '0' + n : String(n) }
  return d.getFullYear() + pad(d.getMonth() + 1) + pad(d.getDate())
}

export default function App() {
  const [state, setState] = useState(store.state)
  const [tab, setTab] = useState<Tab>('home')
  const [categoryId, setCategoryId] = useState<string | null>(null)
  const [sheet, setSheet] = useState<SheetState | null>(null)
  const [toastText, setToastText] = useState('')
  const [confirmState, setConfirmState] = useState<ConfirmState | null>(null)
  const [incomingSync, setIncomingSync] = useState<IncomingSyncRequest | null>(null)
  const incomingDecideRef = useRef<((accepted: boolean) => void) | null>(null)
  const [queue, setQueue] = useState<StickyNote[]>([])
  const [fabOpen, setFabOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)
  const toastTimer = useRef<number | null>(null)
  const stateRef = useRef(state)
  stateRef.current = state

  function toast(message: string): void {
    setToastText(message)
    if (toastTimer.current !== null) window.clearTimeout(toastTimer.current)
    toastTimer.current = window.setTimeout(function () {
      setToastText('')
      toastTimer.current = null
    }, 2500)
  }

  function confirm(opts: ConfirmState): void {
    setConfirmState(opts)
  }

  // 订阅 store 的变化
  useEffect(function () {
    return store.subscribe(function () {
      setState({ ...store.state })
    })
  }, [])

  // 同步服务：常驻在线，接收已绑定设备的同步请求
  useEffect(function () {
    setIncomingSyncHandler(function (request, decide) {
      incomingDecideRef.current = decide
      setIncomingSync(request)
    })
    const offProgress = onSyncProgress(function (p) {
      if (p.phase === 'done' || p.phase === 'error') toast(p.message)
    })
    void bootSyncRuntime().catch(function (err) {
      toast(err instanceof Error ? err.message : '同步服务启动失败')
    })
    return function () {
      offProgress()
      setIncomingSyncHandler(null)
    }
  }, [])

  function answerIncoming(accepted: boolean): void {
    if (incomingDecideRef.current) incomingDecideRef.current(accepted)
    incomingDecideRef.current = null
    setIncomingSync(null)
  }

  // 保存失败提示
  useEffect(function () {
    store.onSaveError = function (message) {
      toast(message)
    }
    return function () {
      store.onSaveError = null
    }
  }, [])

  // 主题
  useEffect(function () {
    applyTheme(state.settings.theme)
  }, [state.settings.theme])

  // 便签改动后重新排闹钟
  useEffect(function () {
    resyncAll()
  }, [state.stickies])

  // 未读数同步给原生角标；都读完了就顺手清掉通知栏里的到期汇总通知
  useEffect(function () {
    const unread = visibleUnread()
    bridge.setBadge(unread)
    if (unread === 0) bridge.clearExpiryNotifications()
  }, [state.notifications])

  // 每 20 秒检查到点提醒与到期提醒
  useEffect(function () {
    function tick(): void {
      const due = collectDue(new Date())
      if (due.length) {
        if (store.state.settings.reminderSound) playBeep()
        setQueue(function (prev) { return prev.concat(due) })
        setState({ ...store.state })
      }
      syncExpiry(new Date())
      setState({ ...store.state })
    }
    tick()
    const timer = window.setInterval(tick, 20000)
    return function () {
      window.clearInterval(timer)
    }
  }, [])

  // 回到前台：原生通知里的按钮可能改过数据，重新读盘
  useEffect(function () {
    function onVisible(): void {
      if (document.visibilityState !== 'visible') return
      store.reload()
      setState({ ...store.state })
      resyncAll()
      const due = collectDue(new Date())
      if (due.length) setQueue(function (prev) { return prev.concat(due) })
    }
    document.addEventListener('visibilitychange', onVisible)
    return function () {
      document.removeEventListener('visibilitychange', onVisible)
    }
  }, [])

  // Android 返回键
  useEffect(function () {
    window.__handleBack = function (): string {
      if (confirmState) {
        setConfirmState(null)
        return '1'
      }
      if (sheet) {
        setSheet(null)
        return '1'
      }
      if (categoryId) {
        setCategoryId(null)
        return '1'
      }
      if (fabOpen) {
        setFabOpen(false)
        return '1'
      }
      if (tab !== 'home') {
        setTab('home')
        return '1'
      }
      return '0'
    }
    return function () {
      window.__handleBack = undefined
    }
  }, [confirmState, sheet, categoryId, fabOpen, tab])

  function visibleUnread(): number {
    return store.state.notifications.filter(function (n) { return !n.read && !n.deleted }).length
  }

  const unread = state.notifications.filter(function (n) { return !n.read && !n.deleted }).length

  function openItem(id: string): void {
    setSheet({ kind: 'item-detail', itemId: id })
  }

  function openSticky(id: string): void {
    setSheet({ kind: 'sticky-detail', stickyId: id })
  }

  function actionFromQueue(action: 'ok' | 'snooze' | 'done'): void {
    const current = queue[0]
    if (!current) return
    handleReminderAction(current.id, action)
    setQueue(function (prev) { return prev.slice(1) })
    setState({ ...store.state })
    if (action === 'done') toast('已标记完成')
    else if (action === 'snooze') toast('10 分钟后再提醒你')
  }

  async function onExport(): Promise<void> {
    const message = await bridge.exportData(store.exportJson(), 'guina-data-' + todayStamp() + '.json')
    toast(message || '已导出 data.json')
  }

  async function onImport(): Promise<void> {
    confirm({
      title: '导入数据？',
      body: '导入会用 data.json 里的内容覆盖当前全部数据，建议先做一份手动备份。',
      okText: '选择文件',
      onOk: async function () {
        setConfirmState(null)
        const json = await bridge.importData()
        if (json === null) {
          toast('没有选择文件')
          return
        }
        const result = store.replaceStateFromJson(json)
        if (!result.ok) {
          toast(result.error || '导入失败')
          return
        }
        setState({ ...store.state })
        resyncAll()
        toast('数据已导入')
      }
    })
  }

  function openAddItem(): void {
    setFabOpen(false)
    if (state.categories.length === 0) {
      toast('先新建一个分类吧')
      setSheet({ kind: 'category-form' })
      return
    }
    if (categoryId) {
      setSheet({ kind: 'item-form', categoryId: categoryId })
      return
    }
    setSheet({ kind: 'pick-category' })
  }

  function renderHeader() {
    if (categoryId) {
      const category = state.categories.find(function (c) { return c.id === categoryId })
      return (
        <header className={'topbar' + (scrolled ? ' scrolled' : '')}>
          <button
            className="icon-btn plain"
            aria-label="返回"
            onClick={function () {
              setCategoryId(null)
            }}
          >
            ‹
          </button>
          <div className="topbar-main">
            <div className="screen-title">{category ? category.icon + ' ' + category.name : '分类'}</div>
          </div>
          <button className="icon-btn" aria-label="通知" onClick={function () { setSheet({ kind: 'notifications' }) }}>
            🔔
            {unread ? <span className="badge">{unread > 99 ? '99+' : unread}</span> : null}
          </button>
          <button
            className="icon-btn"
            aria-label="分类操作"
            onClick={function () {
              if (categoryId) setSheet({ kind: 'category-actions', categoryId: categoryId })
            }}
          >
            ⋯
          </button>
        </header>
      )
    }
    return (
      <header className={'topbar' + (scrolled ? ' scrolled' : '')}>
        <div className="topbar-main">
          <div className="brand-mark">🌀</div>
          <div className="brand-text">
            <div className="brand-title">{tab === 'home' ? 'GuiN' : tab === 'search' ? '搜索' : '设置'}</div>
            <div className="brand-sub">
              {tab === 'home' ? '个人生活记忆库 · 东西放哪儿一搜就知道' : tab === 'search' ? '搜物品、地点、容器和备注' : '提醒、备份与关于'}
            </div>
          </div>
        </div>
        {tab === 'home' || tab === 'search' ? (
          <button className="icon-btn" aria-label="通知" onClick={function () { setSheet({ kind: 'notifications' }) }}>
            🔔
            {unread ? <span className="badge">{unread > 99 ? '99+' : unread}</span> : null}
          </button>
        ) : null}
      </header>
    )
  }

  function renderSheet() {
    if (!sheet) return null
    if (sheet.kind === 'item-form') {
      const category = state.categories.find(function (c) { return c.id === sheet.categoryId })
      if (!category) return null
      return (
        <ItemFormSheet
          state={state}
          category={category}
          itemId={sheet.itemId}
          onClose={function () { setSheet(null) }}
          toast={toast}
        />
      )
    }
    if (sheet.kind === 'item-detail') {
      const item = state.items.find(function (i) { return i.id === sheet.itemId })
      if (!item) return null
      return (
        <ItemDetailSheet
          state={state}
          item={item}
          onClose={function () { setSheet(null) }}
          onEdit={function () {
            setSheet({ kind: 'item-form', categoryId: item.categoryId, itemId: item.id })
          }}
          toast={toast}
          confirm={confirm}
        />
      )
    }
    if (sheet.kind === 'sticky-form') {
      return (
        <StickyFormSheet
          state={state}
          stickyId={sheet.stickyId}
          initialKind={sheet.initialKind}
          onClose={function () { setSheet(null) }}
          toast={toast}
        />
      )
    }
    if (sheet.kind === 'sticky-detail') {
      const sticky = state.stickies.find(function (s) { return s.id === sheet.stickyId })
      if (!sticky) return null
      return (
        <StickyDetailSheet
          state={state}
          sticky={sticky}
          onClose={function () { setSheet(null) }}
          onEdit={function () {
            setSheet({ kind: 'sticky-form', stickyId: sticky.id, initialKind: sticky.kind })
          }}
          toast={toast}
          confirm={confirm}
        />
      )
    }
    if (sheet.kind === 'category-form') {
      return (
        <CategoryFormSheet
          state={state}
          categoryId={sheet.categoryId}
          onClose={function () { setSheet(null) }}
          toast={toast}
        />
      )
    }
    if (sheet.kind === 'category-actions') {
      const category = state.categories.find(function (c) { return c.id === sheet.categoryId })
      if (!category) return null
      return (
        <Sheet title={category.name} onClose={function () { setSheet(null) }}>
          <button
            className="btn block ghost"
            data-testid="category-pin"
            style={{ marginBottom: 8 }}
            onClick={function () {
              const nextPinned = !category.pinned
              const op = store.updateCategory(category.id, { pinned: nextPinned })
              if (!op.ok) {
                toast(op.error)
                return
              }
              setState({ ...store.state })
              setSheet(null)
              toast(nextPinned ? '分类已置顶' : '已取消置顶')
            }}
          >
            {category.pinned ? '取消置顶' : '置顶这个分类'}
          </button>
          <button
            className="btn block"
            style={{ marginBottom: 8 }}
            onClick={function () { setSheet({ kind: 'category-form', categoryId: category.id }) }}
          >
            编辑名称和图标
          </button>
          <button
            className="btn block ghost"
            style={{ marginBottom: 8 }}
            onClick={function () {
              setSheet(null)
              setCategoryId(null)
              setSheet({ kind: 'item-form', categoryId: category.id })
            }}
          >
            往这个分类添加条目
          </button>
          {!category.builtin ? (
            <button
              className="btn block danger"
              onClick={function () {
                const count = state.items.filter(function (i) { return i.categoryId === category.id }).length
                confirm({
                  title: '删除分类「' + category.name + '」？',
                  body: count
                    ? '这个分类里的 ' + count + ' 个条目、备注和到期提醒记录会一起删除，无法恢复。'
                    : '分类下没有条目，可以放心删除，内置分类不能删。',
                  okText: '删除',
                  danger: true,
                  onOk: function () {
                    const op = store.deleteCategory(category.id)
                    if (!op.ok) {
                      toast(op.error)
                      return
                    }
                    setConfirmState(null)
                    setSheet(null)
                    setCategoryId(null)
                    setState({ ...store.state })
                    toast('分类已删除')
                  }
                })
              }}
            >
              删除这个分类
            </button>
          ) : (
            <div className="field-hint" style={{ marginTop: 8 }}>
              内置分类不能删除，但可以改名字和图标。
            </div>
          )}
        </Sheet>
      )
    }
    if (sheet.kind === 'pick-category') {
      return (
        <Sheet title="添加到哪个分类" onClose={function () { setSheet(null) }}>
          {sortCategoriesForDisplay(state.categories).map(function (category) {
            return (
              <button
                key={category.id}
                className="row"
                style={{ width: '100%', background: 'none', textAlign: 'left' }}
                onClick={function () {
                  setSheet({ kind: 'item-form', categoryId: category.id })
                }}
              >
                <div className="cat-icon" style={{ width: 34, height: 34, fontSize: 18 }}>
                  {category.icon}
                </div>
                <div className="row-main">
                  <div className="row-title">{category.name}</div>
                  <div className="row-sub">
                    {state.items.filter(function (i) { return i.categoryId === category.id }).length} 件
                  </div>
                </div>
                <span style={{ color: 'var(--text-faint)' }}>›</span>
              </button>
            )
          })}
          <div style={{ height: 8 }} />
        </Sheet>
      )
    }
    if (sheet.kind === 'notifications') {
      return (
        <NotificationsSheet
          state={state}
          onClose={function () { setSheet(null) }}
          onLocate={function (itemId) {
            setSheet({ kind: 'item-detail', itemId: itemId })
          }}
          toast={toast}
        />
      )
    }
    if (sheet.kind === 'sync') {
      return (
        <SyncSheet
          onClose={function () { setSheet(null) }}
          toast={toast}
          confirm={confirm}
        />
      )
    }
    if (sheet.kind === 'backups') {
      return (
        <BackupsSheet
          onClose={function () { setSheet(null) }}
          toast={toast}
          confirm={confirm}
          onChanged={function () {
            setState({ ...store.state })
          }}
        />
      )
    }
    return null
  }

  if (!state.onboardingDone) {
    return (
      <OnboardingScreen
        onDone={function () {
          store.finishOnboarding()
          setState({ ...store.state })
          toast('欢迎使用 GuiN')
        }}
      />
    )
  }

  const category = state.categories.find(function (c) { return c.id === categoryId })

  return (
    <div className="app-shell">
      {renderHeader()}
      <main
        className="screen"
        onScroll={function (e) {
          setScrolled(e.currentTarget.scrollTop > 6)
        }}
      >
        {categoryId && category ? (
          <CategoryScreen
            state={state}
            categoryId={categoryId}
            onBack={function () { setCategoryId(null) }}
            onOpenItem={openItem}
            onAddItem={function () { setSheet({ kind: 'item-form', categoryId: categoryId }) }}
          />
        ) : tab === 'search' ? (
          <SearchScreen state={state} onOpenItem={openItem} />
        ) : tab === 'settings' ? (
          <SettingsScreen
            state={state}
            version={bridge.getInfo().versionName}
            onUpdateSettings={function (patch) {
              store.updateSettings(patch)
              setState({ ...store.state })
            }}
            onOpenBackups={function () { setSheet({ kind: 'backups' }) }}
            onOpenSync={function () { setSheet({ kind: 'sync' }) }}
            onShowOnboarding={function () {
              store.showOnboarding()
              setState({ ...store.state })
            }}
            onTestReminder={function () {
              bridge.notifyTest('GuiN 测试提醒', '如果你看到这条通知，说明系统通知正常，提醒功能可用。')
              toast('已发送测试通知并播放提示音')
            }}
            onExport={onExport}
            onImport={onImport}
            onRequestPermission={function () {
              bridge.requestNotificationPermission()
              toast('请在系统弹窗里允许 GuiN 发送通知')
            }}
            toast={toast}
          />
        ) : (
          <HomeScreen
            state={state}
            unread={unread}
            onOpenCategory={function (id) {
              setCategoryId(id)
            }}
            onOpenSticky={openSticky}
            onNewSticky={function (kind) {
              setSheet({ kind: 'sticky-form', initialKind: kind })
            }}
            onNewCategory={function () { setSheet({ kind: 'category-form' }) }}
            onOpenNotifications={function () { setSheet({ kind: 'notifications' }) }}
            toast={toast}
            confirm={confirm}
          />
        )}
      </main>

      <nav className="tabbar">
        <button
          className={'tab' + (tab === 'home' && !categoryId ? ' active' : '')}
          onClick={function () {
            setCategoryId(null)
            setTab('home')
          }}
        >
          <span className="tab-icon">🏠</span>
          <span>首页</span>
        </button>
        <button
          className={'tab' + (tab === 'search' && !categoryId ? ' active' : '')}
          onClick={function () {
            setCategoryId(null)
            setTab('search')
          }}
        >
          <span className="tab-icon">🔍</span>
          <span>搜索</span>
        </button>
        <button
          className={'tab' + (tab === 'settings' && !categoryId ? ' active' : '')}
          onClick={function () {
            setCategoryId(null)
            setTab('settings')
          }}
        >
          <span className="tab-icon">⚙️</span>
          <span>设置</span>
        </button>
      </nav>

      <div className="fab-wrap">
        {!categoryId && fabOpen ? (
          <div className="fab-menu">
            <button
              className="fab-action"
              onClick={function () {
                setFabOpen(false)
                setSheet({ kind: 'sticky-form', initialKind: 'note' })
              }}
            >
              ✏️ 写便签
            </button>
            <button
              className="fab-action"
              onClick={function () {
                setFabOpen(false)
                setSheet({ kind: 'sticky-form', initialKind: 'reminder' })
              }}
            >
              🔔 新建提醒
            </button>
            <button className="fab-action" onClick={openAddItem}>
              📦 新增条目
            </button>
          </div>
        ) : null}
        <button
          className={'fab' + (fabOpen && !categoryId ? ' open' : '')}
          aria-label={categoryId ? '新增条目' : '新建'}
          onClick={function () {
            // 分类详情里加号只负责给当前分类新增条目；首页仍是写便签 / 新建提醒 / 新增条目三选一
            if (categoryId) {
              openAddItem()
              return
            }
            setFabOpen(!fabOpen)
          }}
        >
          +
        </button>
      </div>

      {renderSheet()}

      {queue.length ? (
        <ReminderPopup sticky={queue[0]} repeat={queue[0].repeat} onAction={actionFromQueue} />
      ) : null}

      {confirmState ? (
        <ConfirmDialog
          title={confirmState.title}
          body={confirmState.body}
          okText={confirmState.okText}
          danger={confirmState.danger}
          onCancel={function () { setConfirmState(null) }}
          onOk={function () {
            const callback = confirmState.onOk
            setConfirmState(null)
            if (callback) callback()
          }}
        />
      ) : null}

      {incomingSync ? (
        <ConfirmDialog
          title="有设备请求同步"
          body={
            '「' + incomingSync.deviceName + '」请求' +
            (incomingSync.mode === 'push' ? '把它的数据同步到本机' : incomingSync.mode === 'pull' ? '读取本机数据' : '合并双方数据') +
            '。机器码 ' + incomingSync.machineCode + '，请核对是不是你绑定的设备。接受后会先自动备份本机数据。' +
            (incomingSync.scope === 'no-stickies' ? '手机 ↔ 电脑同步不会同步便签与提醒。' : '')
          }
          okText="接受同步"
          onCancel={function () { answerIncoming(false) }}
          onOk={function () { answerIncoming(true) }}
        />
      ) : null}

      {toastText ? <Toast message={toastText} /> : null}
    </div>
  )
}
