import type { AppState } from '../../src/shared/types'
import { SyncRuntime } from '../../src/shared/sync/runtime'
import type { IncomingSyncRequest, SyncConfig, SyncProgress } from '../../src/shared/sync/types'
import * as bridge from './bridge'
import { store } from './store'

let runtime: SyncRuntime | null = null
let incomingHandler:
  | ((request: IncomingSyncRequest, decide: (accepted: boolean) => void) => void)
  | null = null
const configListeners = new Set<(config: SyncConfig) => void>()
const progressListeners = new Set<(progress: SyncProgress) => void>()

export function getSyncRuntime(): SyncRuntime | null {
  return runtime
}

export function onSyncConfig(cb: (config: SyncConfig) => void): () => void {
  configListeners.add(cb)
  const current = runtime ? runtime.getConfig() : null
  if (current) cb(current)
  return function () {
    configListeners.delete(cb)
  }
}

export function onSyncProgress(cb: (progress: SyncProgress) => void): () => void {
  progressListeners.add(cb)
  return function () {
    progressListeners.delete(cb)
  }
}

export function setIncomingSyncHandler(handler: typeof incomingHandler): void {
  incomingHandler = handler
}

/** 应用一份新的完整状态：先自动备份，失败可回滚 */
async function applyState(next: AppState): Promise<() => Promise<void>> {
  const before = store.exportJson()
  let created = store.createBackup('同步前自动备份')
  if (!created.ok) {
    const backups = store.listBackups()
    const oldest = backups.length ? backups[backups.length - 1] : null
    if (oldest) {
      store.deleteBackup(oldest.id)
      created = store.createBackup('同步前自动备份')
    }
  }
  if (!created.ok) throw new Error(created.error || '同步前的自动备份失败')
  const applied = store.replaceStateFromJson(JSON.stringify(next))
  if (!applied.ok) throw new Error(applied.error || '应用同步数据失败')
  return async function () {
    const rolled = store.replaceStateFromJson(before)
    if (!rolled.ok) throw new Error('回滚失败：' + (rolled.error || '未知错误'))
  }
}

/** 启动同步服务（幂等），返回本机同步配置 */
export async function bootSyncRuntime(): Promise<SyncConfig | null> {
  if (runtime) return runtime.getConfig()
  const info = bridge.getInfo()
  const manufacturer = info.manufacturer || ''
  const model = info.model || ''
  const platform = (manufacturer ? manufacturer + ' ' : '') + (model || 'Android') + ' · Android API ' + info.sdk
  const defaultName = (model || '安卓设备').slice(0, 24)
  runtime = new SyncRuntime({
    storage: {
      loadConfig: async function () {
        const text = bridge.loadSyncConfig()
        if (!text) return null
        try {
          return JSON.parse(text) as SyncConfig
        } catch {
          return null
        }
      },
      saveConfig: async function (config) {
        bridge.saveSyncConfig(JSON.stringify(config))
      }
    },
    effects: {
      getState: function () {
        return store.state
      },
      applyState: applyState
    },
    device: {
      kind: 'android',
      platform: platform,
      appVersion: info.versionName,
      defaultName: defaultName,
      machineSeed: platform + '|' + info.dataDir
    },
    onConfig: function (config) {
      configListeners.forEach(function (fn) {
        fn(config)
      })
    },
    onIncoming: function (request, decide) {
      if (incomingHandler) incomingHandler(request, decide)
      else decide(false)
    },
    onProgress: function (progress) {
      progressListeners.forEach(function (fn) {
        fn(progress)
      })
    }
  })
  const config = await runtime.init()
  void runtime.start().catch(function () {
    return
  })
  return config
}

export function shutdownSyncRuntime(): void {
  if (!runtime) return
  void runtime.stop().catch(function () {
    return
  })
  runtime = null
}
