import { useState } from 'react'
import type { AppState } from '../../../src/shared/types'
import type { ExpiryTier } from '../../../src/shared/types'
import { TIER_LABELS } from './tierLabels'
import { Seg, SwitchRow } from '../ui'
import * as bridge from '../bridge'

export function SettingsScreen(props: {
  state: AppState
  version: string
  onUpdateSettings: (patch: Partial<AppState['settings']>) => void
  onOpenBackups: () => void
  onOpenSync: () => void
  onShowOnboarding: () => void
  onTestReminder: () => void
  onExport: () => void
  onImport: () => void
  onRequestPermission: () => void
  toast: (message: string) => void
}) {
  const settings = props.state.settings
  const info = bridge.getInfo()
  // 系统闹钟：识别到的时钟应用 + 用户选择的导入方式（auto / silent / guided）
  const [alarmInfo] = useState(function () { return bridge.getAlarmInfo() })
  const [alarmMode, setAlarmMode] = useState<bridge.AlarmImportMode>(function () {
    const detected = bridge.getAlarmInfo()
    return detected ? detected.mode : 'auto'
  })
  return (
    <div>
      <section className="section">
        <div className="section-head">
          <div className="section-title">外观</div>
        </div>
        <div className="card">
          <div className="field-label" style={{ marginBottom: 8 }}>
            主题
          </div>
          <Seg
            value={settings.theme}
            options={[
              { value: 'light', label: '浅色' },
              { value: 'dark', label: '深色' },
              { value: 'system', label: '跟随系统' }
            ]}
            onChange={function (theme) { props.onUpdateSettings({ theme: theme }) }}
          />
        </div>
      </section>

      <section className="section">
        <div className="section-head">
          <div className="section-title">提醒</div>
        </div>
        <div className="card" style={{ paddingTop: 0, paddingBottom: 0 }}>
          <SwitchRow
            title="便签提醒弹窗"
            sub="关掉后到点只发系统通知，不弹应用内窗口"
            on={settings.reminderPopup}
            onChange={function (next) { props.onUpdateSettings({ reminderPopup: next }) }}
          />
          <SwitchRow
            title="提醒声音"
            sub="到点播放一声提示音"
            on={settings.reminderSound}
            onChange={function (next) { props.onUpdateSettings({ reminderSound: next }) }}
          />
          <div className="row">
            <div className="row-main">
              <div className="row-title">通知权限</div>
              <div className="row-sub">{info.notificationPermission ? '已允许发送通知' : '未允许，提醒可能收不到'}</div>
            </div>
            <button className="btn small ghost" onClick={props.onRequestPermission}>
              去开启
            </button>
          </div>
          <div className="row">
            <div className="row-main">
              <div className="row-title">测试提醒</div>
              <div className="row-sub">立即发一条，确认通知和声音正常</div>
            </div>
            <button className="btn small ghost" onClick={props.onTestReminder}>
              发一条
            </button>
          </div>
          <div className="row">
            <div className="row-main">
              <div className="row-title">精确闹钟</div>
              <div className="row-sub">
                {info.canScheduleExactAlarms
                  ? '已允许，提醒可以准点响'
                  : '未允许，提醒可能晚几分钟；建议去系统设置里打开'}
              </div>
            </div>
            <button className="btn small ghost" onClick={function () { bridge.openExactAlarmSettings() }}>
              去设置
            </button>
          </div>
          <div className="row">
            <div className="row-main">
              <div className="row-title">电池优化</div>
              <div className="row-sub">
                {info.ignoringBatteryOptimizations
                  ? '已关闭对 GuiN 的电池优化，通知更可靠'
                  : '建议关闭对 GuiN 的电池优化，否则锁屏久了可能收不到通知'}
              </div>
            </div>
            <button
              className="btn small ghost"
              onClick={function () {
                bridge.requestIgnoreBatteryOptimization()
                props.toast('请在系统弹窗里允许 GuiN 后台运行')
              }}
            >
              去设置
            </button>
          </div>
          <div className="row">
            <div className="row-main">
              <div className="row-title">自启动</div>
              <div className="row-sub">
                小米 / 华为 / OPPO / vivo 等需要在「自启动管理」里允许 GuiN，重启手机后才能继续发提醒。
              </div>
            </div>
            <button
              className="btn small ghost"
              onClick={function () {
                bridge.openAutoStartSettings()
                props.toast('如果没有打开，请到「设置 → 应用 → 自启动」里手动允许 GuiN')
              }}
            >
              去设置
            </button>
          </div>
          <div className="row">
            <div className="row-main">
              <div className="row-title">系统闹钟导入方式</div>
              <div className="row-sub">
                {alarmInfo
                  ? alarmInfo.resolved
                    ? '检测到时钟应用：' + alarmInfo.clockLabel + '（' + alarmInfo.clockPackage + '）'
                    : alarmInfo.manufacturer
                      ? '没有找到可查询的时钟应用（' + alarmInfo.manufacturer + '），导入时会打开时钟让你确认重复'
                      : '没有检测到系统时钟应用，导入闹钟会失败'
                  : '浏览器里不可用；装成 App 后会自动识别系统时钟'}
              </div>
            </div>
            <button
              className="btn small ghost"
              onClick={function () {
                bridge.runAlarmSelfCheck()
                props.toast('已打开时钟应用：看到「工作日」就说明循环导入正常')
              }}
            >
              测试
            </button>
          </div>
          <div className="alarm-mode-row">
            <Seg
              testId="alarm-mode"
              value={alarmMode}
              options={[
                { value: 'auto', label: '自动识别' },
                { value: 'silent', label: '不打开时钟' },
                { value: 'guided', label: '打开确认' }
              ]}
              onChange={function (next) {
                bridge.setAlarmMode(next)
                setAlarmMode(next)
                props.toast(
                  next === 'guided'
                    ? '以后导入循环闹钟会打开时钟，确认「重复」后点保存'
                    : next === 'silent'
                      ? '以后导入闹钟不再打开时钟应用'
                      : '已恢复自动识别时钟应用'
                )
              }}
            />
          </div>
          <div className="row">
            <div className="row-main">
              <div className="row-sub">
                小米 / OPPO / vivo / 华为等品牌的时钟在后台静默导入时可能忽略重复规则，自动模式会改成打开时钟让你确认；GuiN 自己的循环提醒同时在跑，不依赖系统时钟。
              </div>
            </div>
          </div>
          <div className="row">
            <div className="row-main">
              <div className="row-title">让通知弹出来</div>
              <div className="row-sub">
                GuiN 的提醒和到期通知使用「重要」通知渠道，会以横幅弹出；如果只在通知栏里出现，请把通知渠道的「重要程度」调高、并关闭「静默」。
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="section">
        <div className="section-head">
          <div className="section-title">到期提醒</div>
          <span className="section-sub">食品 / 药品到期前提醒</span>
        </div>
        <div className="card" style={{ paddingTop: 0, paddingBottom: 0 }}>
          {([30, 15, 7, 1] as ExpiryTier[]).map(function (tier) {
            return (
              <SwitchRow
                key={tier}
                title={TIER_LABELS[tier]}
                on={Boolean(settings.expiryTiers[tier])}
                onChange={function (next) {
                  props.onUpdateSettings({
                    expiryTiers: { ...settings.expiryTiers, [tier]: next }
                  })
                }}
              />
            )
          })}
          <div className="row">
            <div className="row-main">
              <div className="row-title">说明</div>
              <div className="row-sub">到期前这些天各提醒一次；已过期的物品也会单独提示。</div>
            </div>
          </div>
        </div>
      </section>

      <section className="section">
        <div className="section-head">
          <div className="section-title">搜索历史</div>
          <span className="section-sub">最多保留 50 条，显示最近 5 条</span>
        </div>
        <div className="card" style={{ paddingTop: 0, paddingBottom: 0 }}>
          <SwitchRow
            title="记录「搜索物品或存放位置」的历史"
            sub="默认开启；点击搜索框时列出最近搜过的词"
            on={settings.itemSearchHistory}
            onChange={function (next) { props.onUpdateSettings({ itemSearchHistory: next }) }}
          />
          <SwitchRow
            title="记录「便签与提醒」的搜索历史"
            sub="默认开启；关掉后不再记录新的关键词"
            on={settings.stickySearchHistory}
            onChange={function (next) { props.onUpdateSettings({ stickySearchHistory: next }) }}
          />
        </div>
      </section>

      <section className="section">
        <div className="section-head">
          <div className="section-title">数据</div>
        </div>
        <div className="card" style={{ paddingTop: 0, paddingBottom: 0 }}>
          <div className="row">
            <div className="row-main">
              <div className="row-title">数据目录</div>
              <div className="row-sub" style={{ wordBreak: 'break-all' }}>{info.dataDir}</div>
            </div>
          </div>
          <div className="row">
            <div className="row-main">
              <div className="row-title">手动备份</div>
              <div className="row-sub">重要改动前存一份，最多 5 份</div>
            </div>
            <button className="btn small ghost" onClick={props.onOpenBackups}>
              管理
            </button>
          </div>
          <div className="row">
            <div className="row-main">
              <div className="row-title">数据同步</div>
              <div className="row-sub">手机 / 电脑互传与合并，端到端加密</div>
            </div>
            <button className="btn small ghost" onClick={props.onOpenSync}>
              管理
            </button>
          </div>
          <div className="row">
            <div className="row-main">
              <div className="row-title">导出数据</div>
              <div className="row-sub">导出 data.json，可换手机或备份到网盘</div>
            </div>
            <button className="btn small ghost" onClick={props.onExport}>
              导出
            </button>
          </div>
          <div className="row">
            <div className="row-main">
              <div className="row-title">导入数据</div>
              <div className="row-sub">从 data.json 恢复，会覆盖当前全部数据</div>
            </div>
            <button className="btn small ghost" onClick={props.onImport}>
              导入
            </button>
          </div>
        </div>
      </section>

      <section className="section">
        <div className="section-head">
          <div className="section-title">其他</div>
        </div>
        <div className="card" style={{ paddingTop: 0, paddingBottom: 0 }}>
          <div className="row">
            <div className="row-main">
              <div className="row-title">新手引导</div>
              <div className="row-sub">再看一遍怎么用</div>
            </div>
            <button className="btn small ghost" onClick={props.onShowOnboarding}>
              查看
            </button>
          </div>
          <div className="about-block">
            <div className="about-title">关于 GuiN</div>
            <div className="about-line">GuiN（使用 DSH 制作的个人生活记忆库软件 · 开源）</div>
            <button
              className="about-link"
              data-testid="about-github"
              onClick={function () { bridge.openExternal('https://github.com/KiNineE9') }}
            >
              GitHub @KiNineE9 ↗
            </button>
            <button
              className="about-link"
              data-testid="about-bilibili"
              onClick={function () { bridge.openExternal('https://space.bilibili.com/28867358') }}
            >
              Bilibili @梦境薇凉i ↗
            </button>
            <div className="about-line">仅限个人使用</div>
            <button
              className="about-link"
              data-testid="about-email"
              onClick={function () { bridge.openExternal('mailto:1332004191@qq.com') }}
            >
              1332004191@qq.com ↗
            </button>
            <div className="about-line about-version">版本 {props.version}</div>
          </div>
          <div className="row">
            <div className="row-main">
              <div className="row-title">开源致谢</div>
              <div className="row-sub">
                数据同步基于 PeerJS（MIT，© Michelle Bu、Eric Zhang）；二维码 qrcode，扫码 jsQR。
              </div>
              <button
                className="about-link"
                data-testid="about-peerjs"
                onClick={function () { bridge.openExternal('https://github.com/peers/peerjs') }}
              >
                PeerJS 项目主页 ↗
              </button>
            </div>
          </div>
          <div className="row">
            <div className="row-main">
              <div className="row-title">设备信息</div>
              <div className="row-sub">
                {info.manufacturer} {info.model} · Android API {info.sdk}
              </div>
            </div>
          </div>
        </div>
      </section>

      <div className="launch-note" style={{ margin: '22px 0 8px' }}>
        所有数据都保存在本机，不上传任何服务器。
      </div>
      <div style={{ height: 8 }} />
    </div>
  )
}
