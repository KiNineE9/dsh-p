import type { ExpiryTier } from '../../../src/shared/types'

export const TIER_LABELS: Record<ExpiryTier, string> = {
  30: '到期前 30 天提醒',
  15: '到期前 15 天提醒',
  7: '到期前 7 天提醒',
  1: '到期前 1 天提醒'
}
