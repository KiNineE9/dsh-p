import { useMemo, useState } from 'react'
import type { AppState, Item, SortState } from '../../../src/shared/types'
import { formatDateTime, searchItems, sortItems } from '../../../src/shared/search'
import { sortDirectionArrow, sortOptionsFor, toggleSortState } from '../../../src/shared/schema'
import { cn, expiryInfoFor, formatDate, levelClass, locationOf } from '../helpers'
import { EmptyState } from '../ui'

export function ItemCard(props: { item: Item; highlighted?: boolean; onClick: () => void }) {
  const expiry = expiryInfoFor(props.item)
  return (
    <button
      className={cn('item-card', props.highlighted && 'hl')}
      onClick={props.onClick}
      data-testid="item-card"
    >
      <div className="item-name">{props.item.name}</div>
      <div className="item-loc">
        <span className="loc-tag">{props.item.locationType === 'container' ? '容器' : '地点'}</span>
        <span className="loc-name">{locationOf(props.item)}</span>
      </div>
      <div className="item-foot">
        {expiry ? (
          <span className={cn('expiry-pill', levelClass(expiry.level))}>
            {expiry.text}
          </span>
        ) : null}
        {props.item.fields.storedAt ? <span>存于 {formatDate(props.item.fields.storedAt)}</span> : null}
        {!expiry && !props.item.fields.storedAt ? <span>更新 {formatDateTime(props.item.updatedAt)}</span> : null}
      </div>
    </button>
  )
}

export function CategoryScreen(props: {
  state: AppState
  categoryId: string
  onBack: () => void
  onOpenItem: (id: string) => void
  onAddItem: () => void
}) {
  const [query, setQuery] = useState('')
  const [sort, setSort] = useState<SortState>({ mode: 'name', direction: 'asc' })
  const category = props.state.categories.find(function (c) { return c.id === props.categoryId })
  const options = category ? sortOptionsFor(category.baseTemplate) : []
  const list = useMemo(function () {
    const all = props.state.items.filter(function (i) { return i.categoryId === props.categoryId })
    const trimmed = query.trim()
    if (trimmed) {
      const hits = searchItems(props.state.items, props.state.categories, props.state.notes, trimmed, {
        categoryId: props.categoryId
      }).map(function (hit) { return hit.item })
      return sortItems(hits, sort.mode, sort.direction)
    }
    return sortItems(all, sort.mode, sort.direction)
  }, [props.state, props.categoryId, query, sort])

  if (!category) {
    return <EmptyState text="这个分类不见了" action={<button className="btn" onClick={props.onBack}>返回</button>} />
  }

  return (
    <div>
      <div className="toolbar">
        {/* 搜索单独一行；排序按钮始终显示在第二行，输入文字时 DOM 结构不变，输入法不会把光标挤到开头 */}
        <div className="toolbar-search">
          <div className="search-wrap">
            <input
              className="search-input"
              value={query}
              placeholder="在这个分类里搜索物品…"
              onChange={function (e) { setQuery(e.target.value) }}
            />
            <button
              className={cn('search-clear', !query && 'hidden')}
              onClick={function () { setQuery('') }}
              aria-label="清空"
              tabIndex={-1}
            >
              ✕
            </button>
          </div>
          <button className="btn primary small" onClick={props.onAddItem}>
            + 条目
          </button>
        </div>
        <div className="sort-chips" data-testid="sort-group">
          {options.map(function (option) {
            const active = sort.mode === option.mode
            return (
              <button
                key={option.mode}
                className={cn('chip', active && 'selected')}
                data-testid={'sort-' + option.mode}
                data-direction={active ? sort.direction : ''}
                onClick={function () {
                  setSort(function (current) { return toggleSortState(current, option.mode) })
                }}
              >
                {option.label}
                {active ? ' ' + sortDirectionArrow(sort.direction) : ''}
              </button>
            )
          })}
        </div>
      </div>

      {list.length ? (
        <div className="item-grid">
          {list.map(function (item) {
            return <ItemCard key={item.id} item={item} onClick={function () { props.onOpenItem(item.id) }} />
          })}
        </div>
      ) : (
        <EmptyState
          icon={category.icon}
          text={query ? '没有找到匹配的物品，换个词试试。' : '这个分类还没有条目，点右上角「+ 条目」添加。'}
        />
      )}
    </div>
  )
}
