import { useMemo, useState } from 'react'
import type { AppState } from '../../../src/shared/types'
import { searchItems } from '../../../src/shared/search'
import { locationOf } from '../helpers'
import { EmptyState, SearchHistoryList } from '../ui'
import { recordSearchHistory } from '../store'

const MATCH_LABELS = { name: '名称', location: '位置', note: '备注' } as const

/** 全局搜索：只搜条目（名称 / 位置 / 备注），便签留给首页的便签搜索 */
export function SearchScreen(props: { state: AppState; onOpenItem: (id: string) => void }) {
  const [query, setQuery] = useState('')
  const trimmed = query.trim()
  const hits = useMemo(function () {
    if (!trimmed) return []
    return searchItems(props.state.items, props.state.categories, props.state.notes, trimmed, { limit: 200 })
  }, [trimmed, props.state.items, props.state.categories, props.state.notes])

  return (
    <div>
      <div className="search-hero">
        <input
          className="search-input"
          data-testid="search-input"
          value={query}
          autoFocus
          placeholder="搜索物品、存放位置、备注…"
          onChange={function (e) { setQuery(e.target.value) }}
          onKeyDown={function (e) {
            if (e.key === 'Enter') recordSearchHistory('item', query)
          }}
        />
        {query ? (
          <button className="icon-btn plain" onClick={function () { setQuery('') }} aria-label="清空">
            ✕
          </button>
        ) : null}
      </div>

      {!trimmed ? (
        <div>
          <SearchHistoryList
            state={props.state}
            kind="item"
            testId="search-history"
            onPick={function (text) {
              recordSearchHistory('item', text)
              setQuery(text)
            }}
          />
          <EmptyState icon="🔍" text="输入名称、地点、容器或备注里的任意词，就能找到东西在哪儿。" />
        </div>
      ) : hits.length ? (
        <div>
          <div className="section-sub" style={{ margin: '2px 0 8px' }}>
            找到 {hits.length} 件
          </div>
          {hits.map(function (hit) {
            const cat = props.state.categories.find(function (c) { return c.id === hit.item.categoryId })
            return (
              <button
                key={hit.item.id}
                className="search-hit"
                onClick={function () {
                  recordSearchHistory('item', query)
                  props.onOpenItem(hit.item.id)
                }}
              >
                <div className="hit-icon">{hit.categoryIcon}</div>
                <div className="hit-main">
                  <div className="hit-name">{hit.item.name}</div>
                  <div className="hit-sub">
                    {cat ? cat.name + ' · ' : ''}
                    {locationOf(hit.item)}
                  </div>
                </div>
                <span className="hit-tag">命中{MATCH_LABELS[hit.matchField]}</span>
              </button>
            )
          })}
        </div>
      ) : (
        <EmptyState icon="🫥" text={'没有找到「' + trimmed + '」，换个词试试。'} />
      )}
    </div>
  )
}
