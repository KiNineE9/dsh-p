import { useEffect, useMemo, useRef, useState } from 'react'
import type { AppState, StickyKind, StickyNote } from '../../../src/shared/types'
import type { Category } from '../../../src/shared/types'
import { searchStickies } from '../../../src/shared/search'
import { isSpecialCategory, sortCategoriesForDisplay } from '../../../src/shared/schema'
import { describeRepeat } from '../../../src/shared/repeat'
import { cn, shortDateTime } from '../helpers'
import { recordSearchHistory, store } from '../store'
import { EmptyState, SearchHistoryList } from '../ui'

const LONG_PRESS_MS = 450

/** 便签排序：置顶在前（按置顶时间新→旧）→ 未完成在前 → 创建早的在前 */
function sortStickies(list: StickyNote[]): StickyNote[] {
  return list.slice().sort(function (a, b) {
    const pinDiff = (b.pinned ? 1 : 0) - (a.pinned ? 1 : 0)
    if (pinDiff !== 0) return pinDiff
    if (a.pinned && b.pinned) {
      const at = a.pinnedAt ? Date.parse(a.pinnedAt) : 0
      const bt = b.pinnedAt ? Date.parse(b.pinnedAt) : 0
      if (at !== bt) return bt - at
    }
    const doneDiff = (a.status === 'done' ? 1 : 0) - (b.status === 'done' ? 1 : 0)
    if (doneDiff !== 0) return doneDiff
    return Date.parse(a.createdAt) - Date.parse(b.createdAt)
  })
}

function useLongPress(onLongPress: () => void): {
  onPointerDown: (event: React.PointerEvent) => void
  onPointerMove: (event: React.PointerEvent) => void
  onPointerUp: () => void
  onPointerLeave: () => void
  consumePress: () => boolean
} {
  const timer = useRef<number | null>(null)
  const start = useRef({ x: 0, y: 0 })
  const fired = useRef(false)

  function cancel(): void {
    if (timer.current !== null) {
      window.clearTimeout(timer.current)
      timer.current = null
    }
  }

  return {
    onPointerDown: function (event) {
      fired.current = false
      start.current = { x: event.clientX, y: event.clientY }
      cancel()
      timer.current = window.setTimeout(function () {
        timer.current = null
        fired.current = true
        onLongPress()
      }, LONG_PRESS_MS)
    },
    onPointerMove: function (event) {
      if (timer.current === null) return
      const dx = Math.abs(event.clientX - start.current.x)
      const dy = Math.abs(event.clientY - start.current.y)
      if (dx > 8 || dy > 8) cancel()
    },
    onPointerUp: cancel,
    onPointerLeave: cancel,
    consumePress: function () {
      if (!fired.current) return false
      fired.current = false
      return true
    }
  }
}

export function StickiesSection(props: {
  state: AppState
  onOpenSticky: (id: string) => void
  onNewSticky: (kind: StickyKind) => void
  toast: (message: string) => void
  confirm: (opts: { title: string; body?: string; okText?: string; danger?: boolean; onOk: () => void }) => void
}) {
  const [query, setQuery] = useState('')
  const [manageKind, setManageKind] = useState<StickyKind | null>(null)
  const [selected, setSelected] = useState<string[]>([])
  const [pressedId, setPressedId] = useState<string | null>(null)

  const trimmed = query.trim()
  const visible = useMemo(function () {
    return trimmed ? searchStickies(props.state.stickies, trimmed) : props.state.stickies
  }, [trimmed, props.state.stickies])
  const notes = sortStickies(visible.filter(function (s) { return s.kind === 'note' }))
  const reminders = sortStickies(visible.filter(function (s) { return s.kind === 'reminder' }))

  // 点空白处收起「长按删除」按钮
  useEffect(function () {
    if (!pressedId) return
    function onDocPointerDown(event: PointerEvent): void {
      const target = event.target as HTMLElement | null
      if (target && target.closest('.sticky-card-wrap')) {
        const id = target.closest('.sticky-card-wrap')?.getAttribute('data-sticky-id')
        if (id === pressedId) return
      }
      setPressedId(null)
    }
    document.addEventListener('pointerdown', onDocPointerDown)
    return function () {
      document.removeEventListener('pointerdown', onDocPointerDown)
    }
  }, [pressedId])

  function toggleSelected(id: string): void {
    setSelected(function (prev) {
      return prev.indexOf(id) >= 0
        ? prev.filter(function (x) { return x !== id })
        : prev.concat([id])
    })
  }

  function enterManage(kind: StickyKind): void {
    setManageKind(kind)
    setSelected([])
    setPressedId(null)
  }

  function exitManage(): void {
    setManageKind(null)
    setSelected([])
  }

  function deleteSelected(kind: StickyKind): void {
    const ids = selected.filter(function (id) {
      const sticky = props.state.stickies.find(function (s) { return s.id === id })
      return sticky ? sticky.kind === kind : false
    })
    if (!ids.length) {
      props.toast('先选择要删除的' + (kind === 'note' ? '便签' : '提醒便签'))
      return
    }
    props.confirm({
      title: '删除选中的 ' + ids.length + ' 个' + (kind === 'note' ? '便签' : '提醒便签') + '？',
      body: '删除后无法恢复；已经生成的提醒也会一起取消。',
      okText: '删除',
      danger: true,
      onOk: function () {
        let removed = 0
        ids.forEach(function (id) {
          const op = store.deleteSticky(id)
          if (op.ok) removed += 1
        })
        exitManage()
        props.toast('已删除 ' + removed + ' 个' + (kind === 'note' ? '便签' : '提醒便签'))
      }
    })
  }

  function deleteOne(sticky: StickyNote): void {
    setPressedId(null)
    props.confirm({
      title: '删除这条' + (sticky.kind === 'note' ? '便签' : '提醒便签') + '？',
      body: (sticky.title ? '「' + sticky.title + '」' : sticky.content.slice(0, 20)) + (sticky.kind === 'reminder' ? '\n删除后对应的提醒也会一起取消。' : ''),
      okText: '删除',
      danger: true,
      onOk: function () {
        const op = store.deleteSticky(sticky.id)
        props.toast(op.ok ? '已删除' : op.error)
      }
    })
  }

  function renderCard(sticky: StickyNote) {
    const late =
      sticky.kind === 'reminder' &&
      sticky.status === 'pending' &&
      sticky.remindAt !== null &&
      Date.parse(sticky.remindAt) < Date.now()
    return (
      <StickyCard
        key={sticky.id}
        sticky={sticky}
        late={late}
        managing={manageKind === sticky.kind}
        selected={selected.indexOf(sticky.id) >= 0}
        pressed={pressedId === sticky.id}
        onPress={function () {
          if (manageKind === sticky.kind) {
            toggleSelected(sticky.id)
            return
          }
          setPressedId(sticky.id)
        }}
        canLongPress={manageKind === null}
        onOpen={function () {
          if (trimmed) recordSearchHistory('sticky', query)
          props.onOpenSticky(sticky.id)
        }}
        onDelete={function () { deleteOne(sticky) }}
        onSelect={function () { toggleSelected(sticky.id) }}
      />
    )
  }

  function renderColumn(kind: StickyKind, list: StickyNote[]) {
    const isNote = kind === 'note'
    const label = isNote ? '便签' : '提醒便签'
    const managing = manageKind === kind
    const count = selected.filter(function (id) {
      const sticky = props.state.stickies.find(function (s) { return s.id === id })
      return sticky ? sticky.kind === kind : false
    }).length
    return (
      <div className="sticky-col" data-kind={kind}>
        <div className="sticky-col-head">
          <div className="sticky-col-title">{label}</div>
          <span className="sticky-col-count">{list.length}</span>
          {managing ? (
            <button className="sticky-col-add" aria-label={'完成管理' + label} onClick={exitManage}>
              ✓
            </button>
          ) : (
            <AddButton
              label={'新建' + label}
              onAdd={function () { props.onNewSticky(kind) }}
              onLongPress={function () { enterManage(kind) }}
            />
          )}
        </div>
        {managing ? (
          <div className="sticky-manage-bar">
            <span>已选 {count} 条</span>
            <span className="grow" />
            <button
              className="link-btn"
              onClick={function () { setSelected(list.map(function (s) { return s.id })) }}
            >
              全选
            </button>
            <button className="link-btn" style={{ color: 'var(--danger)' }} onClick={function () { deleteSelected(kind) }}>
              删除所选
            </button>
            <button className="link-btn" onClick={exitManage}>
              完成
            </button>
          </div>
        ) : null}
        {list.length ? (
          <div className="sticky-board">{list.map(renderCard)}</div>
        ) : (
          <div className="empty" style={{ padding: '14px 8px', fontSize: 12 }}>
            {trimmed ? '没有匹配的' + label : isNote ? '还没有便签，点上面的 + 写一条。' : '还没有提醒便签，点上面的 + 建一条。'}
          </div>
        )}
      </div>
    )
  }

  return (
    <section className="sticky-section">
      <div className="sticky-head">
        <div className="section-title">便签与提醒</div>
        <div className="sticky-search-wrap">
          <input
            className="sticky-search"
            value={query}
            placeholder="搜便签标题或内容…"
            onChange={function (e) { setQuery(e.target.value) }}
            onKeyDown={function (e) {
              if (e.key === 'Escape') setQuery('')
              if (e.key === 'Enter') recordSearchHistory('sticky', query)
            }}
          />
          {query ? (
            <button className="search-clear" onClick={function () { setQuery('') }} aria-label="清空">
              ✕
            </button>
          ) : null}
        </div>
      </div>
      {!trimmed ? (
        <SearchHistoryList
          state={props.state}
          kind="sticky"
          testId="sticky-search-history"
          onPick={function (text) {
            recordSearchHistory('sticky', text)
            setQuery(text)
          }}
        />
      ) : null}
      <div className="sticky-columns">
        {renderColumn('note', notes)}
        {renderColumn('reminder', reminders)}
      </div>
    </section>
  )
}

function AddButton(props: { label: string; onAdd: () => void; onLongPress: () => void }) {
  const press = useLongPress(props.onLongPress)
  return (
    <button
      className="sticky-col-add"
      aria-label={props.label}
      onPointerDown={press.onPointerDown}
      onPointerMove={press.onPointerMove}
      onPointerUp={press.onPointerUp}
      onPointerLeave={press.onPointerLeave}
      onClick={function () {
        if (press.consumePress()) return
        props.onAdd()
      }}
    >
      +
    </button>
  )
}

function StickyCard(props: {
  sticky: StickyNote
  late: boolean
  managing: boolean
  selected: boolean
  pressed: boolean
  canLongPress: boolean
  onPress: () => void
  onOpen: () => void
  onDelete: () => void
  onSelect: () => void
}) {
  const sticky = props.sticky
  const press = useLongPress(props.canLongPress ? props.onPress : function () {})
  return (
    <div className="sticky-card-wrap" data-sticky-id={sticky.id}>
      <button
        className={cn(
          'sticky-card',
          sticky.status === 'done' && 'done',
          props.managing && 'selected',
          props.selected && 'selected',
          props.pressed && !props.managing && 'long-pressed'
        )}
        data-kind={sticky.kind}
        onPointerDown={press.onPointerDown}
        onPointerMove={press.onPointerMove}
        onPointerUp={press.onPointerUp}
        onPointerLeave={press.onPointerLeave}
        onClick={function () {
          if (props.managing) {
            props.onSelect()
            return
          }
          if (press.consumePress()) return
          if (props.pressed) return
          props.onOpen()
        }}
      >
        {props.managing ? <span className="sticky-check">{props.selected ? '✓' : ''}</span> : null}
        {sticky.title ? <div className="sticky-card-title">{sticky.title}</div> : null}
        <div className="sticky-card-content">{sticky.content}</div>
        <div className="sticky-card-meta">
          {sticky.pinned ? <span className="sticky-flag pin">置顶</span> : null}
          {sticky.kind === 'reminder' && (sticky.repeat || sticky.remindAt) ? (
            <span className={cn('sticky-flag', props.late && !sticky.repeat && 'late')}>
              {sticky.repeat
                ? describeRepeat(sticky.repeat)
                : props.late
                  ? '已到时间'
                  : shortDateTime(sticky.remindAt)}
            </span>
          ) : null}
          {sticky.status === 'done' ? <span className="sticky-flag">已完成</span> : null}
        </div>
      </button>
      {props.pressed && !props.managing ? (
        <div className="sticky-card-actions">
          <button className="sticky-card-delete" onClick={props.onDelete}>
            删除
          </button>
        </div>
      ) : null}
    </div>
  )
}

export function HomeScreen(props: {
  state: AppState
  unread: number
  onOpenCategory: (id: string) => void
  onOpenSticky: (id: string) => void
  onNewSticky: (kind: StickyKind) => void
  onNewCategory: () => void
  onOpenNotifications: () => void
  toast: (message: string) => void
  confirm: (opts: { title: string; body?: string; okText?: string; danger?: boolean; onOk: () => void }) => void
}) {
  const [catManage, setCatManage] = useState(false)
  const [catSelected, setCatSelected] = useState<string[]>([])
  const [dragId, setDragId] = useState<string | null>(null)
  const [dropId, setDropId] = useState<string | null>(null)
  const dragPoint = useRef({ x: 0, y: 0 })
  const catPress = useRef<{ timer: number | null; id: string; x: number; y: number } | null>(null)
  const suppressClick = useRef(false)

  const categories = sortCategoriesForDisplay(props.state.categories)

  useEffect(function () {
    if (!dragId) return
    const sourceId: string = dragId
    function move(event: PointerEvent): void {
      dragPoint.current = { x: event.clientX, y: event.clientY }
      const el = document.elementFromPoint(event.clientX, event.clientY) as HTMLElement | null
      const card = el ? (el.closest('.cat-card') as HTMLElement | null) : null
      const targetId = card ? card.getAttribute('data-cat-id') : null
      if (!targetId || targetId === dragId) {
        setDropId(null)
        return
      }
      const source = props.state.categories.find(function (c) { return c.id === dragId })
      const target = props.state.categories.find(function (c) { return c.id === targetId })
      setDropId(
        source && target && isSpecialCategory(source) === isSpecialCategory(target) ? targetId : null
      )
    }
    function up(): void {
      const el = document.elementFromPoint(dragPoint.current.x, dragPoint.current.y) as HTMLElement | null
      const card = el ? (el.closest('.cat-card') as HTMLElement | null) : null
      const targetId = card ? card.getAttribute('data-cat-id') : null
      finishDrag(sourceId, targetId)
    }
    function cancelDrag(): void {
      // 触摸被系统手势打断时不调整顺序，只收起拖拽状态
      setDragId(null)
      setDropId(null)
      suppressClick.current = true
      window.setTimeout(function () { suppressClick.current = false }, 300)
    }
    window.addEventListener('pointermove', move)
    window.addEventListener('pointerup', up)
    window.addEventListener('pointercancel', cancelDrag)
    return function () {
      window.removeEventListener('pointermove', move)
      window.removeEventListener('pointerup', up)
      window.removeEventListener('pointercancel', cancelDrag)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [dragId, props.state.categories])

  function cancelCatPress(): void {
    if (catPress.current && catPress.current.timer !== null) {
      window.clearTimeout(catPress.current.timer)
    }
    catPress.current = null
  }

  function catPointerDown(category: Category, event: React.PointerEvent): void {
    if (catManage) return
    cancelCatPress()
    // 捕获指针：手指拖出卡片范围后仍能收到 move/up，触摸拖动更稳
    try {
      ;(event.currentTarget as HTMLElement).setPointerCapture(event.pointerId)
    } catch {
      // 不支持指针捕获的 WebView 直接跳过
    }
    const x = event.clientX
    const y = event.clientY
    const timer = window.setTimeout(function () {
      catPress.current = null
      dragPoint.current = { x, y }
      setDragId(category.id)
    }, LONG_PRESS_MS)
    catPress.current = { timer, id: category.id, x, y }
  }

  function catPointerMove(event: React.PointerEvent): void {
    const press = catPress.current
    if (!press || press.timer === null) return
    if (Math.abs(event.clientX - press.x) > 14 || Math.abs(event.clientY - press.y) > 14) cancelCatPress()
  }

  function finishDrag(sourceId: string, targetId: string | null): void {
    setDragId(null)
    setDropId(null)
    suppressClick.current = true
    window.setTimeout(function () { suppressClick.current = false }, 300)
    if (!targetId || targetId === sourceId) return
    const display = sortCategoriesForDisplay(store.state.categories)
    const source = display.find(function (c) { return c.id === sourceId })
    const target = display.find(function (c) { return c.id === targetId })
    if (!source || !target) return
    if (isSpecialCategory(source) !== isSpecialCategory(target)) {
      props.toast('普通分类只能和普通分类换位置；内置/置顶分类只在它们之间调整')
      return
    }
    const special = display.filter(isSpecialCategory).map(function (c) { return c.id })
    const normal = display.filter(function (c) { return !isSpecialCategory(c) }).map(function (c) { return c.id })
    const group = isSpecialCategory(source) ? special : normal
    const from = group.indexOf(sourceId)
    const to = group.indexOf(targetId)
    if (from < 0 || to < 0) return
    group.splice(from, 1)
    group.splice(to, 0, sourceId)
    const ordered = special.concat(normal)
    const op = store.reorderCategories(ordered)
    if (!op.ok) {
      props.toast(op.error)
      return
    }
    props.toast('分类顺序已调整')
  }

  function toggleCatSelected(id: string): void {
    setCatSelected(function (prev) {
      return prev.indexOf(id) >= 0 ? prev.filter(function (x) { return x !== id }) : prev.concat([id])
    })
  }

  function deleteSelectedCategories(): void {
    if (!catSelected.length) {
      props.toast('先选择要删除的分类')
      return
    }
    const chosen = props.state.categories.filter(function (c) { return catSelected.indexOf(c.id) >= 0 })
    const deletable = chosen.filter(function (c) { return !c.builtin })
    const items = props.state.items.filter(function (i) {
      return deletable.some(function (c) { return c.id === i.categoryId })
    }).length
    if (!deletable.length) {
      props.toast('内置分类不能删除，可以改名或换图标')
      return
    }
    props.confirm({
      title: '删除选中的 ' + deletable.length + ' 个分类？',
      body:
        (items ? '分类里的 ' + items + ' 个条目、备注和到期提醒记录会一起删除，无法恢复。' : '这些分类下没有条目，可以放心删除。') +
        (chosen.length !== deletable.length ? '\n内置分类会自动跳过。' : ''),
      okText: '删除',
      danger: true,
      onOk: function () {
        let removed = 0
        deletable.forEach(function (c) {
          const op = store.deleteCategory(c.id)
          if (op.ok) removed += 1
        })
        setCatSelected([])
        setCatManage(false)
        props.toast('已删除 ' + removed + ' 个分类')
      }
    })
  }

  return (
    <div>
      <StickiesSection
        state={props.state}
        onOpenSticky={props.onOpenSticky}
        onNewSticky={props.onNewSticky}
        toast={props.toast}
        confirm={props.confirm}
      />

      {props.unread > 0 ? (
        <button className="notice unread" style={{ width: '100%', marginTop: 12, textAlign: 'left' }} onClick={props.onOpenNotifications}>
          <div className="notice-main">
            <div className="notice-title">有 {props.unread} 条到期提醒</div>
            <div className="notice-sub">有食品 / 药品临近过期或已过期，点这里看看</div>
          </div>
          <span className="hit-tag">查看</span>
        </button>
      ) : null}

      <section className="section">
        <div className="section-head">
          <div className="section-title">我的分类</div>
          {catManage ? (
            <button className="link-btn" onClick={function () { setCatManage(false); setCatSelected([]) }}>
              完成
            </button>
          ) : (
            <div style={{ display: 'flex', gap: 14 }}>
              <button className="link-btn" data-testid="category-manage" onClick={function () { setCatManage(true); setCatSelected([]) }}>
                管理
              </button>
              <button className="link-btn" onClick={props.onNewCategory}>
                + 新建分类
              </button>
            </div>
          )}
        </div>
        {catManage ? (
          <div className="cat-manage-bar">
            <span>已选 {catSelected.length} 个</span>
            <span className="grow" />
            <button
              className="link-btn"
              onClick={function () {
                setCatSelected(props.state.categories.filter(function (c) { return !c.builtin }).map(function (c) { return c.id }))
              }}
            >
              全选
            </button>
            <button className="link-btn" style={{ color: 'var(--danger)' }} onClick={deleteSelectedCategories}>
              删除所选
            </button>
          </div>
        ) : null}
        <div className="cat-grid">
          {categories.map(function (cat) {
            const count = props.state.items.filter(function (i) { return i.categoryId === cat.id }).length
            const selected = catSelected.indexOf(cat.id) >= 0
            return (
              <button
                key={cat.id}
                className={cn(
                  'cat-card',
                  selected && 'selected',
                  dragId === cat.id && 'dragging',
                  dropId === cat.id && 'drop-target'
                )}
                data-cat-id={cat.id}
                onPointerDown={function (e) { catPointerDown(cat, e) }}
                onPointerMove={catPointerMove}
                onPointerUp={cancelCatPress}
                onPointerLeave={cancelCatPress}
                onClick={function () {
                  if (suppressClick.current) return
                  if (catManage) {
                    toggleCatSelected(cat.id)
                    return
                  }
                  props.onOpenCategory(cat.id)
                }}
              >
                {catManage ? <span className="cat-check">{selected ? '✓' : ''}</span> : null}
                <div className="cat-icon">{cat.icon}</div>
                <div className="cat-text">
                  <div className="cat-name">
                    {cat.name}
                    {cat.pinned ? <span className="cat-pin" title="已置顶">📌</span> : null}
                  </div>
                  <div className="cat-count">{count} 件</div>
                </div>
              </button>
            )
          })}
        </div>
      </section>

      {props.state.categories.length === 0 ? <EmptyState text="还没有分类" /> : null}
    </div>
  )
}
