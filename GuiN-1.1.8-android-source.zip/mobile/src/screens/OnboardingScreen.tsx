import { useState } from 'react'

const PAGES = [
  {
    icon: '🧠',
    title: '东西放哪儿，一问就知道',
    text: 'GuiN 是你的个人生活记忆库：把「东西在哪里」「什么时候到期」「别忘了什么事」都记下来，想不起来的时候搜一下就有答案。'
  },
  {
    icon: '📦',
    title: '分类记录，地点容器分得清',
    text: '按图书、物品、食品、药品等分类记录。每个条目都写清放在哪个地点、哪个容器，还能补充详细位置。食品和药品填上过期时间，快过期会自动提醒。'
  },
  {
    icon: '🔔',
    title: '便签、提醒、随时备份',
    text: '便签可以置顶记事，提醒便签支持一次性或每天 / 工作日 / 周六日循环；首页能单独搜便签。数据全部存在手机本地，支持手动备份和导出 data.json。'
  }
]

export function OnboardingScreen(props: { onDone: () => void }) {
  const [index, setIndex] = useState(0)
  const page = PAGES[index]
  const last = index === PAGES.length - 1
  return (
    <div className="onboard">
      <div className="onboard-icon">{page.icon}</div>
      <div className="onboard-title">{page.title}</div>
      <div className="onboard-text">{page.text}</div>
      <div className="onboard-dots">
        {PAGES.map(function (_, i) {
          return <span key={i} className={'onboard-dot' + (i === index ? ' active' : '')} />
        })}
      </div>
      <div className="onboard-foot">
        <button
          className="btn primary block"
          onClick={function () {
            if (last) props.onDone()
            else setIndex(index + 1)
          }}
        >
          {last ? '开始使用' : '下一步'}
        </button>
        {!last ? (
          <button className="btn ghost block" onClick={props.onDone}>
            跳过
          </button>
        ) : null}
      </div>
    </div>
  )
}
