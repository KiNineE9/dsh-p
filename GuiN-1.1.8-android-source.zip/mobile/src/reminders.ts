import { nextRepeatOccurrence } from '../../src/shared/repeat'
import type { RepeatRule, StickyNote } from '../../src/shared/types'
import * as db from '../../src/main/data'
import * as bridge from './bridge'
import { store } from './store'

export type ReminderAction = 'ok' | 'snooze' | 'done'

function nextIso(rule: RepeatRule, now: Date): string | null {
  const next = nextRepeatOccurrence(rule, now)
  return next ? next.toISOString() : null
}

/** 已经交给系统闹钟的便签 id，用来取消那些被删除/改时间的 */
const scheduled = new Set<string>()

/**
 * 把便签提醒交给 Android 的 AlarmManager。
 * 每次状态变化后调用一次：该排的排上、该取消的取消，重复规则交给原生侧顺延。
 */
export function syncReminders(stickies: StickyNote[]): void {
  const wanted = stickies.filter(function (s) {
    return s.kind === 'reminder' && s.status === 'pending' && s.remindAt && s.notified !== true
  })
  const wantedIds = new Set(wanted.map(function (s) { return s.id }))
  scheduled.forEach(function (id) {
    if (!wantedIds.has(id)) {
      bridge.cancelReminder(id)
      scheduled.delete(id)
    }
  })
  const now = Date.now()
  wanted.forEach(function (s) {
    const at = s.remindAt ? Date.parse(s.remindAt) : NaN
    if (!Number.isFinite(at)) return
    // 已经过去超过 1 分钟的提醒交给 collectDue 在应用内处理，
    // 否则每次打开应用都会重新补发一次系统通知（1.1.8）
    if (at < now - 60 * 1000) return
    const triggerAt = Math.max(at, now + 1500)
    bridge.scheduleReminder(
      s.id,
      s.title || '',
      s.content || '',
      triggerAt,
      s.repeat ? s.repeat.kind : '',
      s.repeat ? s.repeat.time : '',
      store.state.settings.reminderSound
    )
    scheduled.add(s.id)
  })
}

/** 一次性把当前所有便签同步一遍 */
export function resyncAll(): void {
  syncReminders(store.state.stickies)
}

/** 应用在前台时检查有没有到点的提醒，返回需要弹窗的列表（与桌面版 checkStickies 语义一致） */
export function collectDue(now: Date): StickyNote[] {
  const due = db.dueStickies(store.state, now)
  if (!due.length) return []
  const popup = store.state.settings.reminderPopup
  const ready: StickyNote[] = []
  due.forEach(function (s) {
    if (popup) {
      db.markStickyNotified(store.state, s.id, now)
      ready.push(s)
    } else if (s.repeat) {
      const rule = s.repeat
      db.updateSticky(store.state, s.id, { remindAt: nextIso(rule, now) })
    } else {
      // 关掉提醒弹窗时，一次性提醒也要记为已提醒，
      // 否则它会一直留在待提醒状态、每次打开都被重新排进系统通知（1.1.8）
      db.markStickyNotified(store.state, s.id, now)
    }
  })
  store.commit()
  return ready
}

/** 处理提醒弹窗 / 通知按钮的三种动作 */
export function handleReminderAction(id: string, action: ReminderAction): void {
  const sticky = store.state.stickies.find(function (s) { return s.id === id })
  if (!sticky) return
  const now = new Date()
  if (action === 'done') {
    db.updateSticky(store.state, id, { status: 'done' })
  } else if (action === 'snooze') {
    const at = new Date(now.getTime() + 10 * 60 * 1000)
    db.updateSticky(store.state, id, { remindAt: at.toISOString(), status: 'pending' })
  } else if (sticky.repeat) {
    const rule = sticky.repeat
    db.updateSticky(store.state, id, {
      remindAt: nextIso(rule, now),
      status: 'pending'
    })
  } else {
    db.updateSticky(store.state, id, { status: 'pending' })
    const target = store.state.stickies.find(function (s) { return s.id === id })
    if (target) target.notified = true
  }
  store.commit()
  resyncAll()
}

/** 到期提醒：清掉过时的通知记录，再按档位生成新的；返回新生成的条数 */
export function syncExpiry(now: Date): number {
  db.pruneNotifications(store.state, now)
  const created = db.syncExpiryNotifications(store.state, now)
  if (created.length) store.commit()
  return created.length
}
