import { createRoot } from 'react-dom/client'
import App from './App'
import './styles.css'
import { store } from './store'
import { applyTheme } from './helpers'
import { getInfo } from './bridge'
import * as reminders from './reminders'

const info = getInfo()

/** 原生侧读到系统栏 / 刘海高度后会实时回调这里，旋转、折叠展开时也会更新。 */
function applyInsets(top: number, right: number, bottom: number, left: number): void {
  const root = document.documentElement
  root.style.setProperty('--safe-top', Math.max(0, top) + 'px')
  root.style.setProperty('--safe-right', Math.max(0, right) + 'px')
  root.style.setProperty('--safe-bottom', Math.max(0, bottom) + 'px')
  root.style.setProperty('--safe-left', Math.max(0, left) + 'px')
}

applyInsets(info.insets.top, info.insets.right, info.insets.bottom, info.insets.left)
;(window as unknown as { __setInsets?: typeof applyInsets }).__setInsets = applyInsets

store.init()
applyTheme(store.state.settings.theme)

const darkQuery = window.matchMedia('(prefers-color-scheme: dark)')
darkQuery.addEventListener('change', function () {
  if (store.state.settings.theme === 'system') applyTheme('system')
})

// 启动时先补一遍到期提醒记录，再把便签闹钟排给系统
reminders.syncExpiry(new Date())
reminders.resyncAll()

const container = document.getElementById('root')
if (container) {
  createRoot(container).render(<App />)
}
