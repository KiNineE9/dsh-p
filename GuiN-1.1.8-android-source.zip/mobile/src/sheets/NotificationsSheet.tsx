import { useState } from 'react'
import type { AppState, NotificationKind } from '../../../src/shared/types'
import { visibleNotifications } from '../../../src/main/data'
import { daysUntil } from '../../../src/shared/search'
import { locationOf } from '../helpers'
import { store } from '../store'
import { EmptyState, Sheet } from '../ui'

function tierText(days: number | null): string {
  if (days === null) return '没有填写过期时间'
  if (days < 0) return '已过期 ' + Math.abs(days) + ' 天'
  if (days === 0) return '今天到期'
  return '还剩 ' + days + ' 天过期'
}

export function NotificationsSheet(props: {
  state: AppState
  onClose: () => void
  onLocate: (itemId: string) => void
  toast: (message: string) => void
}) {
  const [kind, setKind] = useState<NotificationKind>('food')
  // 已读只由用户手动点「标为已读 / 标为未读」决定（1.1.8）
  const visible = visibleNotifications(props.state)
  const list = visible.filter(function (n) { return n.kind === kind })

  return (
    <Sheet
      title="到期提醒"
      onClose={props.onClose}
      footer={
        <>
          <button
            className="btn ghost"
            onClick={function () {
              const op = store.markAllNotificationsRead()
              if (!op.ok) props.toast(op.error)
              else props.toast('已全部标为已读')
            }}
          >
            全部标为已读
          </button>
          <button
            className="btn ghost"
            onClick={function () {
              const op = store.deleteReadNotifications()
              if (!op.ok) props.toast(op.error)
              else props.toast(op.value ? '已删除 ' + op.value + ' 条已读' : '没有已读记录可删')
            }}
          >
            删除已读
          </button>
        </>
      }
    >
      <div className="tabs">
        {(['food', 'medicine'] as NotificationKind[]).map(function (k) {
          const count = visible.filter(function (n) { return n.kind === k }).length
          return (
            <button
              key={k}
              className={'tab-pill' + (kind === k ? ' active' : '')}
              onClick={function () { setKind(k) }}
            >
              {k === 'food' ? '食品' : '药品'} {count}
            </button>
          )
        })}
      </div>

      {list.length ? (
        list.map(function (n) {
          const item = props.state.items.find(function (i) { return i.id === n.itemId })
          const days = item && item.fields.expiresAt ? daysUntil(item.fields.expiresAt) : null
          return (
            <div key={n.id} className={'notice' + (n.read ? '' : ' unread')}>
              <div className="notice-main">
                <div className="notice-title">{item ? item.name : '（物品已删除）'}</div>
                <div className="notice-sub">{tierText(days)}</div>
                {item ? <div className="notice-sub">{locationOf(item)}</div> : null}
              </div>
              <div className="notice-actions">
                {item ? (
                  <button
                    className="mini-btn"
                    onClick={function () {
                      props.onLocate(item.id)
                    }}
                  >
                    定位
                  </button>
                ) : null}
                <button
                  className="mini-btn"
                  onClick={function () {
                    const op = store.markNotificationRead(n.id, !n.read)
                    if (!op.ok) props.toast(op.error)
                  }}
                >
                  {n.read ? '标为未读' : '标为已读'}
                </button>
                <button
                  className="mini-btn danger"
                  onClick={function () {
                    const op = store.deleteNotification(n.id)
                    if (!op.ok) props.toast(op.error)
                    else props.toast('已删除这条提醒记录')
                  }}
                >
                  删除
                </button>
              </div>
            </div>
          )
        })
      ) : (
        <EmptyState
          icon={kind === 'food' ? '🍎' : '💊'}
          text={
            kind === 'food'
              ? '食品都还新鲜，没有临期或过期的。'
              : '药品都在有效期内，没有临期或过期的。'
          }
        />
      )}
      <div className="field-hint" style={{ marginTop: 12 }}>
        提醒在到期前 30 / 15 / 7 / 1 天生成，可在设置里关掉对应档位。
      </div>
    </Sheet>
  )
}
