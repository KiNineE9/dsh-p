import { useState } from 'react'
import type { NativeBackup } from '../bridge'
import { store, MAX_MANUAL_BACKUPS } from '../store'
import { shortDateTime } from '../helpers'
import { EmptyState, Sheet } from '../ui'

export function BackupsSheet(props: {
  onClose: () => void
  toast: (message: string) => void
  confirm: (opts: { title: string; body?: string; okText?: string; danger?: boolean; onOk: () => void }) => void
  onChanged: () => void
}) {
  const [list, setList] = useState<NativeBackup[]>(function () { return store.listBackups() })
  const [name, setName] = useState('')

  function refresh(): void {
    setList(store.listBackups())
    props.onChanged()
  }

  function create(): void {
    const result = store.createBackup(name)
    if (!result.ok) {
      props.toast(result.error || '备份失败')
      return
    }
    setName('')
    refresh()
    props.toast('已备份')
  }

  return (
    <Sheet
      title="手动备份"
      onClose={props.onClose}
      footer={
        <>
          <input
            className="input"
            style={{ flex: 1 }}
            value={name}
            maxLength={40}
            placeholder="备份名（选填）"
            onChange={function (e) { setName(e.target.value) }}
          />
          <button className="btn primary" disabled={list.length >= MAX_MANUAL_BACKUPS} onClick={create}>
            备份
          </button>
        </>
      }
    >
      <div className="field-hint" style={{ marginBottom: 10 }}>
        最多保留 {MAX_MANUAL_BACKUPS} 份手动备份；另外每次保存都会自动滚动备份 7 份，放在数据目录里。还原会覆盖当前全部数据。
      </div>
      {list.length ? (
        list.map(function (backup) {
          return (
            <div className="row" key={backup.id}>
              <div className="row-main">
                <div className="row-title">{backup.name || '未命名备份'}</div>
                <div className="row-sub">
                  {shortDateTime(backup.time)} · {(backup.size / 1024).toFixed(1)} KB
                </div>
              </div>
              <button
                className="mini-btn"
                onClick={function () {
                  props.confirm({
                    title: '还原这份备份？',
                    body: '当前的数据会被这份备份完全覆盖。',
                    okText: '还原',
                    onOk: function () {
                      const result = store.restoreBackup(backup.id)
                      if (!result.ok) {
                        props.toast(result.error || '还原失败')
                        return
                      }
                      refresh()
                      props.toast('已还原')
                      props.onClose()
                    }
                  })
                }}
              >
                还原
              </button>
              <button
                className="mini-btn danger"
                onClick={function () {
                  props.confirm({
                    title: '删除这份备份？',
                    body: backup.name || '未命名备份',
                    okText: '删除',
                    danger: true,
                    onOk: function () {
                      store.deleteBackup(backup.id)
                      refresh()
                      props.toast('已删除')
                    }
                  })
                }}
              >
                删除
              </button>
            </div>
          )
        })
      ) : (
        <EmptyState icon="🗂️" text="还没有手动备份。点下面输入名字再点「备份」。 " />
      )}
      <div style={{ height: 8 }} />
    </Sheet>
  )
}
