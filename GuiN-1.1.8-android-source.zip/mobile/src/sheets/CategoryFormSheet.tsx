import { useState } from 'react'
import type { AppState, BaseTemplate, Category, CustomFieldDef, CustomFieldType } from '../../../src/shared/types'
import { makeId, TEMPLATE_ICONS, validateCategoryDraft } from '../../../src/shared/schema'
import { store } from '../store'
import { Field, Sheet } from '../ui'

const TEMPLATES: Array<{ value: BaseTemplate; label: string; sub: string }> = [
  { value: 'book', label: '图书', sub: '记录存放时间' },
  { value: 'item', label: '物品', sub: '只有名称和位置' },
  { value: 'food', label: '食品', sub: '类型、拆封、过期时间' },
  { value: 'medicine', label: '药品', sub: '类型、拆封、过期时间、作用' }
]
/** 图标列表：普通图标在前，四个模板对应的图标排在最后（模板本身也默认对应其中一个） */
const BASE_ICONS = ['🏷️', '🧸', '🧰', '🎁', '👕', '🧴', '🪑', '🎒', '🧪', '🔧', '🎮', '🧹']
const TEMPLATE_ICON_LIST = TEMPLATES.map(function (t) { return TEMPLATE_ICONS[t.value] })
const ICONS = BASE_ICONS.concat(TEMPLATE_ICON_LIST)
const CUSTOM_TYPES: Array<{ value: CustomFieldType; label: string }> = [
  { value: 'text', label: '文本' },
  { value: 'number', label: '数字' },
  { value: 'date', label: '日期' },
  { value: 'select', label: '选项' },
  { value: 'textarea', label: '多行文本' },
  { value: 'boolean', label: '是 / 否' }
]

interface FieldRow {
  key: string
  label: string
  type: CustomFieldType
  optionsText: string
}

export function CategoryFormSheet(props: {
  state: AppState
  categoryId?: string
  onClose: () => void
  toast: (message: string) => void
}) {
  const editing: Category | undefined = props.state.categories.find(function (c) { return c.id === props.categoryId })
  const [name, setName] = useState(editing ? editing.name : '')
  const [icon, setIcon] = useState(editing ? editing.icon : TEMPLATE_ICONS.item)
  const [template, setTemplate] = useState<BaseTemplate>(editing ? editing.baseTemplate : 'item')
  const [rows, setRows] = useState<FieldRow[]>(function () {
    if (!editing) return []
    return editing.customFields.map(function (f) {
      return { key: f.key, label: f.label, type: f.type, optionsText: (f.options || []).join(',') }
    })
  })
  const [errors, setErrors] = useState<Record<string, string>>({})

  function save(): void {
    const customFields: CustomFieldDef[] = []
    for (const row of rows) {
      const label = row.label.trim()
      if (!label) continue
      const def: CustomFieldDef = { key: row.key, label: label, type: row.type, required: false }
      if (row.type === 'select') {
        const options = row.optionsText
          .split(/[,，]/)
          .map(function (s) { return s.trim() })
          .filter(function (s) { return Boolean(s) })
        if (!options.length) {
          props.toast('自定义选项「' + label + '」至少要填一个选项')
          return
        }
        def.options = options
      }
      customFields.push(def)
    }

    if (editing) {
      const op = store.updateCategory(editing.id, { name: name, icon: icon })
      if (!op.ok) {
        props.toast(op.error)
        return
      }
      props.onClose()
      props.toast('分类已更新')
      return
    }

    const check = validateCategoryDraft(
      { name: name, baseTemplate: template, icon: icon, customFields: customFields },
      props.state.categories
    )
    if (!check.ok) {
      setErrors(check.errors)
      props.toast(Object.values(check.errors)[0] || '分类信息不完整')
      return
    }
    const op = store.createCategory({ name: name, icon: icon, baseTemplate: template, customFields: customFields })
    if (!op.ok) {
      props.toast(op.error)
      return
    }
    props.onClose()
    props.toast('已新建分类「' + name.trim() + '」')
  }

  return (
    <Sheet
      title={editing ? '编辑分类' : '新建分类'}
      onClose={props.onClose}
      footer={
        <>
          <button className="btn ghost" onClick={props.onClose}>
            取消
          </button>
          <button className="btn primary" onClick={save}>
            保存
          </button>
        </>
      }
    >
      <Field label="分类名称" required error={errors['name']}>
        <input
          className="input"
          value={name}
          maxLength={16}
          placeholder="例如：证件 / 玩具 / 宠物用品"
          onChange={function (e) { setName(e.target.value) }}
        />
      </Field>

      <Field label="图标">
        <div className="chips">
          {ICONS.map(function (item) {
            return (
              <button
                key={item}
                className={'chip' + (item === icon ? ' selected' : '')}
                style={{ fontSize: 19, padding: '5px 10px' }}
                onClick={function () { setIcon(item) }}
              >
                {item}
              </button>
            )
          })}
        </div>
      </Field>

      {editing ? (
        <div className="field-hint" style={{ marginTop: 4 }}>
          分类的字段模板创建后不能改，避免已经填好的条目丢失内容；名称和图标随时能改。
        </div>
      ) : (
        <div>
          <Field label="字段模板" hint="决定这个分类里条目要填哪些信息">
            <div className="chips">
              {TEMPLATES.map(function (t) {
                return (
                  <button
                    key={t.value}
                    className={'chip' + (template === t.value ? ' selected' : '')}
                    onClick={function () {
                      setTemplate(t.value)
                      setIcon(TEMPLATE_ICONS[t.value])
                    }}
                    style={{ flexDirection: 'column', alignItems: 'flex-start', padding: '7px 12px' }}
                  >
                    <span style={{ fontWeight: 600 }}>{t.label}</span>
                    <span style={{ fontSize: 11, opacity: 0.75 }}>{t.sub}</span>
                  </button>
                )
              })}
            </div>
          </Field>

          <div className="field-label" style={{ marginBottom: 8 }}>
            自定义字段（选填）
          </div>
          {rows.map(function (row, index) {
            return (
              <div key={row.key} className="card" style={{ padding: 12, marginBottom: 10 }}>
                <div style={{ display: 'flex', gap: 8 }}>
                  <input
                    className="input"
                    style={{ flex: 1 }}
                    value={row.label}
                    placeholder="字段名，例如：颜色"
                    onChange={function (e) {
                      const next = rows.slice()
                      next[index] = { ...row, label: e.target.value }
                      setRows(next)
                    }}
                  />
                  <select
                    className="sort-select"
                    value={row.type}
                    onChange={function (e) {
                      const next = rows.slice()
                      next[index] = { ...row, type: e.target.value as CustomFieldType }
                      setRows(next)
                    }}
                  >
                    {CUSTOM_TYPES.map(function (t) {
                      return (
                        <option key={t.value} value={t.value}>
                          {t.label}
                        </option>
                      )
                    })}
                  </select>
                </div>
                {row.type === 'select' ? (
                  <input
                    className="input"
                    style={{ marginTop: 8 }}
                    value={row.optionsText}
                    placeholder="选项，用逗号分开：红,蓝,黑"
                    onChange={function (e) {
                      const next = rows.slice()
                      next[index] = { ...row, optionsText: e.target.value }
                      setRows(next)
                    }}
                  />
                ) : null}
                <button
                  className="link-btn"
                  style={{ marginTop: 6, color: 'var(--danger)' }}
                  onClick={function () {
                    setRows(rows.filter(function (_, i) { return i !== index }))
                  }}
                >
                  删除这个字段
                </button>
              </div>
            )
          })}
          <button
            className="btn ghost block"
            onClick={function () {
              setRows(rows.concat([{ key: makeId('f'), label: '', type: 'text', optionsText: '' }]))
            }}
          >
            + 添加自定义字段
          </button>
        </div>
      )}
      <div style={{ height: 8 }} />
    </Sheet>
  )
}
