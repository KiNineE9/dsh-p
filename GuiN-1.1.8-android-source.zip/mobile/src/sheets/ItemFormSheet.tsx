import { useState } from 'react'
import type { AppState, Category, Item, ItemDraft } from '../../../src/shared/types'
import { emptyDraftFor, getFormSchema, validateItemDraft } from '../../../src/shared/schema'
import { store } from '../store'
import { Field, Seg, Sheet } from '../ui'

function draftFromItem(item: Item): ItemDraft {
  const fields = { ...item.fields }
  if (item.fields.custom) fields.custom = { ...item.fields.custom }
  return {
    name: item.name,
    locationType: item.locationType,
    locationLabel: item.locationLabel,
    locationName: item.locationName,
    fields: fields
  }
}

export function ItemFormSheet(props: {
  state: AppState
  category: Category
  itemId?: string
  onClose: () => void
  toast: (message: string) => void
}) {
  const editing = props.state.items.find(function (i) { return i.id === props.itemId })
  const schema = getFormSchema(props.category.baseTemplate, props.category.customFields)
  const [draft, setDraft] = useState<ItemDraft>(function () {
    return editing ? draftFromItem(editing) : emptyDraftFor(props.category.baseTemplate, props.category.customFields)
  })
  const [errors, setErrors] = useState<Record<string, string>>({})
  const saved = props.state.savedNames[draft.locationType]

  function getValue(key: string): string {
    if (key.indexOf('custom.') === 0) {
      const custom = draft.fields.custom || {}
      return custom[key.slice(7)] || ''
    }
    const value = (draft.fields as unknown as Record<string, unknown>)[key]
    if (value === undefined || value === null) return ''
    return String(value)
  }

  function setValue(key: string, value: string | boolean | undefined): void {
    const next: ItemDraft = {
      ...draft,
      fields: { ...draft.fields, custom: { ...(draft.fields.custom || {}) } }
    }
    if (key.indexOf('custom.') === 0) {
      next.fields.custom = { ...(next.fields.custom || {}) }
      next.fields.custom[key.slice(7)] = String(value || '')
    } else if (key === 'opened') {
      next.fields.opened = Boolean(value)
    } else if (key === 'foodType' || key === 'medicineType') {
      const foodValue = String(value || '') as 'liquid' | 'solid'
      if (key === 'foodType') next.fields.foodType = foodValue
      else next.fields.medicineType = foodValue
    } else {
      ;(next.fields as unknown as Record<string, unknown>)[key] = value
    }
    setDraft(next)
  }

  function save(): void {
    const check = validateItemDraft(draft, props.category.baseTemplate, props.category.customFields)
    if (!check.ok) {
      setErrors(check.errors)
      props.toast('还有必填项没填')
      return
    }
    setErrors({})
    const op = editing
      ? store.updateItem(editing.id, draft)
      : store.createItem(props.category.id, draft)
    if (!op.ok) {
      props.toast(op.error)
      return
    }
    props.onClose()
    props.toast(editing ? '已保存修改' : '已添加「' + draft.name.trim() + '」')
  }

  function renderField(f: { key: string; label: string; type: string; options?: string[]; required?: boolean; placeholder?: string; hint?: string }) {
    const value = getValue(f.key)
    if (f.type === 'boolean') {
      const current = f.key === 'opened' ? Boolean(draft.fields.opened) : value === 'true'
      return (
        <Field key={f.key} label={f.label} required={f.required} error={errors[f.key]} hint={f.hint}>
          <Seg
            value={current ? 'yes' : 'no'}
            options={[
              { value: 'yes', label: '是' },
              { value: 'no', label: '否' }
            ]}
            onChange={function (next) { setValue(f.key, next === 'yes') }}
          />
        </Field>
      )
    }
    if (f.type === 'select') {
      const options = f.options || []
      return (
        <Field key={f.key} label={f.label} required={f.required} error={errors[f.key]} hint={f.hint}>
          <div className="chips">
            {options.map(function (opt) {
              return (
                <button
                  key={opt}
                  className={'chip' + (value === opt ? ' selected' : '')}
                  onClick={function () { setValue(f.key, opt === value ? '' : opt) }}
                >
                  {opt}
                </button>
              )
            })}
          </div>
        </Field>
      )
    }
    if (f.type === 'textarea') {
      return (
        <Field key={f.key} label={f.label} required={f.required} error={errors[f.key]} hint={f.hint}>
          <textarea
            className="textarea"
            value={value}
            placeholder={f.placeholder}
            onChange={function (e) { setValue(f.key, e.target.value) }}
          />
        </Field>
      )
    }
    return (
      <Field key={f.key} label={f.label} required={f.required} error={errors[f.key]} hint={f.hint}>
        <input
          className="input"
          type={f.type === 'date' ? 'date' : f.type === 'number' ? 'number' : 'text'}
          value={value}
          placeholder={f.placeholder}
          onChange={function (e) { setValue(f.key, e.target.value) }}
        />
      </Field>
    )
  }

  return (
    <Sheet
      title={(editing ? '编辑' : '新增') + ' · ' + props.category.name}
      onClose={props.onClose}
      footer={
        <>
          <button className="btn ghost" onClick={props.onClose}>
            取消
          </button>
          <button className="btn primary" onClick={save}>
            保存
          </button>
        </>
      }
    >
      <Field label={schema.nameLabel} required error={errors['name']}>
        <input
          className="input"
          value={draft.name}
          placeholder={schema.namePlaceholder}
          onChange={function (e) { setDraft({ ...draft, name: e.target.value }) }}
        />
      </Field>

      <Field label="放在哪里">
        <Seg
          value={draft.locationType}
          options={[
            { value: 'place', label: '地点' },
            { value: 'container', label: '容器' }
          ]}
          onChange={function (next) { setDraft({ ...draft, locationType: next }) }}
        />
      </Field>

      <Field
        label={draft.locationType === 'container' ? '容器名称' : '地点名称'}
        required
        error={errors['locationLabel']}
      >
        <input
          className="input"
          value={draft.locationLabel}
          placeholder={draft.locationType === 'container' ? '例如：抽屉柜 / 收纳箱' : schema.labelPlaceholder}
          onChange={function (e) { setDraft({ ...draft, locationLabel: e.target.value }) }}
        />
      </Field>

      {saved.length ? (
        <div className="chips" style={{ margin: '-4px 0 14px' }}>
          {saved.map(function (s) {
            return (
              <span key={s.name} className="chip">
                <button onClick={function () { setDraft({ ...draft, locationLabel: s.name }) }}>{s.name}</button>
                <button
                  className="chip-del"
                  aria-label={'删除已保存名称 ' + s.name}
                  onClick={function () {
                    const op = store.removeSavedName(draft.locationType, s.name)
                    if (!op.ok) props.toast(op.error)
                  }}
                >
                  ✕
                </button>
              </span>
            )
          })}
        </div>
      ) : null}

      <Field label={schema.locationLabel}>
        <input
          className="input"
          value={draft.locationName}
          placeholder={schema.locationPlaceholder}
          onChange={function (e) { setDraft({ ...draft, locationName: e.target.value }) }}
        />
      </Field>

      {schema.fields.map(renderField)}

    </Sheet>
  )
}
