import type { RepeatRule, StickyNote } from '../../../src/shared/types'
import { describeRepeat } from '../../../src/shared/repeat'
import { shortDateTime } from '../helpers'
import type { ReminderAction } from '../reminders'

export function ReminderPopup(props: {
  sticky: StickyNote
  repeat?: RepeatRule | null
  onAction: (action: ReminderAction) => void
}) {
  const sticky = props.sticky
  return (
    <div className="reminder-mask">
      <div className="reminder-card">
        <div className="reminder-kicker">提醒时间到</div>
        {sticky.title ? <div className="reminder-title">{sticky.title}</div> : null}
        <div className="reminder-content">{sticky.content}</div>
        <div className="reminder-time">
          {sticky.remindAt ? shortDateTime(sticky.remindAt) : ''}
          {sticky.repeat ? ' · 循环：' + describeRepeat(sticky.repeat) : ''}
        </div>
        <div className="reminder-actions">
          <button className="btn ghost" onClick={function () { props.onAction('snooze') }}>
            稍后提醒
          </button>
          <button className="btn" onClick={function () { props.onAction('done') }}>
            标记完成
          </button>
          <button className="btn primary" onClick={function () { props.onAction('ok') }}>
            知道了
          </button>
        </div>
      </div>
    </div>
  )
}
