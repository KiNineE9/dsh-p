import type { AppState, StickyNote } from '../../../src/shared/types'
import { describeRepeat } from '../../../src/shared/repeat'
import { shortDateTime } from '../helpers'
import { store } from '../store'
import { Sheet } from '../ui'
import { resyncAll } from '../reminders'

export function StickyDetailSheet(props: {
  state: AppState
  sticky: StickyNote
  onClose: () => void
  onEdit: () => void
  toast: (message: string) => void
  confirm: (opts: { title: string; body?: string; okText?: string; danger?: boolean; onOk: () => void }) => void
}) {
  const sticky = props.sticky
  const late =
    sticky.kind === 'reminder' && sticky.status === 'pending' && sticky.remindAt !== null && Date.parse(sticky.remindAt) < Date.now()

  return (
    <Sheet
      title={sticky.kind === 'note' ? '便签' : '提醒便签'}
      onClose={props.onClose}
      footer={
        <>
          <button className="btn ghost" onClick={props.onEdit}>
            编辑
          </button>
          <button
            className="btn danger"
            onClick={function () {
              props.confirm({
                title: '删除这张便签？',
                body: '删除后无法恢复。',
                okText: '删除',
                danger: true,
                onOk: function () {
                  const op = store.deleteSticky(sticky.id)
                  if (!op.ok) props.toast(op.error)
                  else {
                    resyncAll()
                    props.toast('已删除')
                    props.onClose()
                  }
                }
              })
            }}
          >
            删除
          </button>
        </>
      }
    >
      {sticky.title ? <div className="detail-title">{sticky.title}</div> : null}
      <div className="detail-meta">
        {sticky.pinned ? <span className="sticky-flag pin">置顶</span> : null}
        {sticky.status === 'done' ? <span className="sticky-flag">已完成</span> : null}
        {sticky.repeat ? <span className="sticky-flag">循环：{describeRepeat(sticky.repeat)}</span> : null}
        {sticky.remindAt ? (
          <span className={'sticky-flag' + (late ? ' late' : '')}>
            {late ? '已到时间' : '提醒 ' + shortDateTime(sticky.remindAt)}
          </span>
        ) : null}
        <span>{shortDateTime(sticky.updatedAt)}</span>
      </div>

      <div className="card" style={{ whiteSpace: 'pre-wrap', wordBreak: 'break-word', fontSize: 15 }}>
        {sticky.content}
      </div>

      <div className="chips" style={{ marginTop: 14 }}>
        {sticky.kind === 'note' ? (
          <button
            className="btn"
            onClick={function () {
              const nextPinned = !sticky.pinned
              const op = store.updateSticky(sticky.id, { pinned: nextPinned })
              if (!op.ok) props.toast(op.error)
              else props.toast(nextPinned ? '已置顶' : '已取消置顶')
            }}
          >
            {sticky.pinned ? '取消置顶' : '置顶'}
          </button>
        ) : null}
        <button
          className="btn"
          onClick={function () {
            const next = sticky.status === 'done' ? 'pending' : 'done'
            const op = store.updateSticky(sticky.id, { status: next })
            if (!op.ok) props.toast(op.error)
            else {
              resyncAll()
              props.toast(next === 'done' ? '标记为已完成' : '恢复为待办')
            }
          }}
        >
          {sticky.status === 'done' ? '标为未完成' : '标记完成'}
        </button>
      </div>
      <div style={{ height: 8 }} />
    </Sheet>
  )
}
