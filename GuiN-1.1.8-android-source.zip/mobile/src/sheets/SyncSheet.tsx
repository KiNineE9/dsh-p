import { useEffect, useRef, useState } from 'react'
import { createPortal } from 'react-dom'
import QRCode from 'qrcode'
import type { SyncBinding, SyncConfig, SyncMode } from '../../../src/shared/sync/types'
import { getSyncRuntime, onSyncConfig, onSyncProgress } from '../syncClient'
import { bindingLabel } from '../../../src/shared/sync/runtime'
import { isFrontCameraLabel, pickMainBackCamera } from '../../../src/shared/camera'
import { cn, shortDateTime } from '../helpers'
import { Sheet } from '../ui'

const MODE_LABEL: Record<SyncMode, string> = {
  push: '把本机数据发给对方',
  pull: '从对方获取数据',
  merge: '合并双方数据'
}

function sleep(ms: number): Promise<void> {
  return new Promise(function (resolve) {
    window.setTimeout(resolve, ms)
  })
}

function kindText(kind: SyncBinding['kind']): string {
  return kind === 'android' ? '手机 / 平板' : '电脑'
}

export function SyncSheet(props: {
  onClose: () => void
  toast: (message: string) => void
  confirm: (opts: { title: string; body?: string; okText?: string; danger?: boolean; onOk: () => void }) => void
}) {
  const [config, setConfig] = useState<SyncConfig | null>(function () {
    const rt = getSyncRuntime()
    return rt ? rt.getConfig() : null
  })
  const [name, setName] = useState(config ? config.identity.name : '')
  const [busy, setBusy] = useState(false)
  const [progress, setProgress] = useState('')
  const [pairing, setPairing] = useState<{ text: string; code: string } | null>(null)
  const [qr, setQr] = useState('')
  const [joinOpen, setJoinOpen] = useState(false)
  const [joinText, setJoinText] = useState('')
  const [joinCode, setJoinCode] = useState('')
  const [scanning, setScanning] = useState(false)
  const [scanError, setScanError] = useState('')
  const [torchOn, setTorchOn] = useState(false)
  const [torchSupported, setTorchSupported] = useState(false)
  const [checking, setChecking] = useState('')
  const [online, setOnline] = useState<Record<string, { online: boolean; checkedAt: string }>>({})
  const [aliasEditing, setAliasEditing] = useState<string | null>(null)
  const [aliasDraft, setAliasDraft] = useState('')
  const videoRef = useRef<HTMLVideoElement | null>(null)
  const streamRef = useRef<MediaStream | null>(null)
  const scanningRef = useRef(false)

  useEffect(function () {
    const offConfig = onSyncConfig(function (next) {
      setConfig(next)
      setName(next.identity.name)
    })
    const offProgress = onSyncProgress(function (p) {
      setProgress(p.message)
    })
    return function () {
      offConfig()
      offProgress()
      stopScan()
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  // 扫码浮层出现后再把视频流接到 video 上，避免 setTimeout 抢不到节点
  useEffect(function () {
    if (!scanning) return
    const video = videoRef.current
    const stream = streamRef.current
    if (video && stream) {
      video.srcObject = stream
      void video.play().catch(function () {})
    }
  }, [scanning])

  function stopScan(): void {
    scanningRef.current = false
    setTorchOn(false)
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(function (track) {
        track.stop()
      })
      streamRef.current = null
    }
    setScanning(false)
  }

  async function saveName(): Promise<void> {
    const rt = getSyncRuntime()
    if (!rt) return
    try {
      const next = await rt.setDeviceName(name)
      setConfig(next)
      setName(next.identity.name)
      props.toast('设备名称已保存')
    } catch (err) {
      props.toast(err instanceof Error ? err.message : '保存失败')
    }
  }

  async function beginPairing(): Promise<void> {
    const rt = getSyncRuntime()
    if (!rt) return
    setBusy(true)
    setJoinOpen(false)
    try {
      const session = await rt.startPairing()
      const dataUrl = await QRCode.toDataURL(session.text, { margin: 1, width: 320 })
      setQr(dataUrl)
      setPairing({ text: session.text, code: session.code })
      const binding = await rt.waitPairing()
      props.toast('已与「' + bindingLabel(binding) + '」绑定成功')
    } catch (err) {
      props.toast(err instanceof Error ? err.message : '绑定失败')
    } finally {
      setPairing(null)
      setQr('')
      setBusy(false)
    }
  }

  function cancelPairing(): void {
    const rt = getSyncRuntime()
    if (rt) rt.cancelPairing()
  }

  async function joinPairing(): Promise<void> {
    const rt = getSyncRuntime()
    if (!rt) return
    stopScan()
    setBusy(true)
    try {
      const binding = await rt.joinPairing(joinText, joinCode)
      props.toast('已与「' + bindingLabel(binding) + '」绑定成功')
      setJoinOpen(false)
      setJoinText('')
      setJoinCode('')
    } catch (err) {
      props.toast(err instanceof Error ? err.message : '绑定失败')
    } finally {
      setBusy(false)
    }
  }

  async function openStream(constraints: MediaStreamConstraints): Promise<MediaStream | null> {
    try {
      return await navigator.mediaDevices.getUserMedia(constraints)
    } catch {
      return null
    }
  }

  function stopStream(stream: MediaStream | null): void {
    if (!stream) return
    stream.getTracks().forEach(function (track) { track.stop() })
  }

  /**
   * 打开后置主摄。
   * 第一次先按 facingMode 打开（顺便拿到相机权限与设备名），再用共享的
   * pickMainBackCamera 把「长焦 / 微距 / 景深」排除掉换到主摄；最后把变焦拉回 1x，
   * 避免逻辑相机默认停在 0.5x 超广或长焦档。
   */
  async function openBackCamera(): Promise<MediaStream> {
    const size = { width: { ideal: 1920 }, height: { ideal: 1080 } }
    let stream = await openStream({ video: { facingMode: { exact: 'environment' }, ...size } })
    if (!stream) stream = await openStream({ video: { facingMode: { ideal: 'environment' }, ...size } })
    if (!stream) stream = await openStream({ video: true })
    if (!stream) throw new Error('没有可用的摄像头')
    const track = stream.getVideoTracks()[0]
    try {
      const devices = await navigator.mediaDevices.enumerateDevices()
      const settings = track && typeof track.getSettings === 'function' ? track.getSettings() : ({} as MediaTrackSettings)
      const pick = pickMainBackCamera(
        devices.map(function (device) {
          return { deviceId: device.deviceId, label: device.label, kind: device.kind }
        }),
        settings.deviceId
      )
      if (pick && pick.deviceId && pick.deviceId !== settings.deviceId && !isFrontCameraLabel(pick.label)) {
        stopStream(stream)
        const switched = await openStream({ video: { deviceId: { exact: pick.deviceId }, ...size } })
        if (switched) stream = switched
      }
    } catch {
      // 枚举失败就沿用按后置打开的那一路
    }
    const active = stream.getVideoTracks()[0]
    const caps = active && typeof active.getCapabilities === 'function'
      ? (active.getCapabilities() as MediaTrackCapabilities & { zoom?: { min?: number; max?: number } })
      : null
    const zoom = caps ? caps.zoom : undefined
    if (zoom && typeof zoom.min === 'number' && typeof zoom.max === 'number' && zoom.min < 1 && zoom.max >= 1) {
      try {
        await active.applyConstraints({ advanced: [{ zoom: 1 } as unknown as MediaTrackConstraintSet] })
      } catch {
        // 这台设备的相机不支持设置变焦，忽略
      }
    }
    return stream
  }

  function setupTorch(stream: MediaStream): void {
    const track = stream.getVideoTracks()[0]
    const caps = track && typeof track.getCapabilities === 'function'
      ? (track.getCapabilities() as MediaTrackCapabilities & { torch?: boolean })
      : null
    setTorchSupported(Boolean(caps && caps.torch))
  }

  async function toggleTorch(): Promise<void> {
    const track = streamRef.current ? streamRef.current.getVideoTracks()[0] : null
    if (!track) return
    const next = !torchOn
    try {
      await track.applyConstraints({ advanced: [{ torch: next } as unknown as MediaTrackConstraintSet] })
      setTorchOn(next)
    } catch {
      props.toast('这个摄像头不支持手电筒')
    }
  }

  async function startScan(): Promise<void> {
    setScanError('')
    try {
      const stream = await openBackCamera()
      streamRef.current = stream
      setTorchOn(false)
      setupTorch(stream)
      setScanning(true)
      setJoinOpen(true)
      void scanLoop()
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err)
      setScanError(message)
      props.toast('无法打开相机：' + message)
    }
  }

  async function scanLoop(): Promise<void> {
    scanningRef.current = true
    const mod = await import('jsqr')
    const jsQR = mod.default
    const canvas = document.createElement('canvas')
    while (scanningRef.current) {
      const video = videoRef.current
      if (!video || video.readyState < 2 || !video.videoWidth) {
        await sleep(160)
        continue
      }
      // 缩小到 720 宽再识别：够清晰，又比全分辨率省电省内存
      const width = Math.min(720, video.videoWidth)
      const height = Math.max(1, Math.round((width * video.videoHeight) / video.videoWidth))
      if (canvas.width !== width || canvas.height !== height) {
        canvas.width = width
        canvas.height = height
      }
      const ctx = canvas.getContext('2d')
      if (!ctx) break
      ctx.drawImage(video, 0, 0, width, height)
      const frame = ctx.getImageData(0, 0, width, height)
      const found = jsQR(frame.data, frame.width, frame.height)
      if (found && found.data) {
        setJoinText(found.data)
        stopScan()
        props.toast('已识别二维码，输入六位数字确认即可')
        return
      }
      await sleep(180)
    }
  }

  function askSync(binding: SyncBinding, mode: SyncMode): void {
    const scope = binding.kind === 'android' ? 'full' : 'no-stickies'
    props.confirm({
      title: MODE_LABEL[mode],
      body:
        '确定要和「' + bindingLabel(binding) + '」' + MODE_LABEL[mode] + '？' +
        '同步前会自动备份本机数据，失败会自动回滚。' +
        (scope === 'no-stickies' ? '手机 ↔ 电脑同步只同步分类、条目和备注，不同步便签与提醒。' : ''),
      okText: '开始同步',
      onOk: function () {
        void runSync(binding, mode)
      }
    })
  }

  async function runSync(binding: SyncBinding, mode: SyncMode): Promise<void> {
    const rt = getSyncRuntime()
    if (!rt) return
    setBusy(true)
    setProgress('')
    try {
      const result = await rt.sync(binding, mode)
      props.toast(
        mode === 'merge'
          ? '合并完成：新增 ' + result.stats.added + ' 条、更新 ' + result.stats.updated + ' 条、跳过重复 ' + result.stats.duplicates + ' 条'
          : mode === 'push'
            ? '已把本机数据发送给「' + bindingLabel(binding) + '」'
            : '已从「' + bindingLabel(binding) + '」获取数据'
      )
    } catch (err) {
      props.toast(err instanceof Error ? err.message : '同步失败')
    } finally {
      setBusy(false)
      setProgress('')
    }
  }

  function askUnbind(binding: SyncBinding): void {
    props.confirm({
      title: '解除绑定',
      body: '解除后需要重新用六位数字绑定才能同步，本机数据不受影响。',
      okText: '解除绑定',
      danger: true,
      onOk: function () {
        const rt = getSyncRuntime()
        if (!rt) return
        void rt
          .removeBinding(binding.deviceId)
          .then(function () {
            props.toast('已解除绑定')
          })
          .catch(function (err) {
            props.toast(err instanceof Error ? err.message : '解除失败')
          })
      }
    })
  }

  async function checkOnline(deviceId: string): Promise<void> {
    const rt = getSyncRuntime()
    if (!rt) return
    setChecking(deviceId)
    try {
      const result = await rt.checkBinding(deviceId)
      setOnline(function (prev) {
        const next = Object.assign({}, prev)
        next[deviceId] = { online: result.online, checkedAt: result.checkedAt }
        return next
      })
      props.toast(result.online ? '设备在线，可以同步' : '设备不在线：' + (result.message || '请确认对方已打开 GuiN 并联网'))
    } catch (err) {
      props.toast(err instanceof Error ? err.message : '检测失败')
    } finally {
      setChecking('')
    }
  }

  function beginAlias(binding: SyncBinding): void {
    setAliasEditing(binding.deviceId)
    setAliasDraft(binding.alias || '')
  }

  async function saveAlias(binding: SyncBinding): Promise<void> {
    const rt = getSyncRuntime()
    if (!rt) return
    try {
      const next = await rt.setBindingAlias(binding.deviceId, aliasDraft)
      setConfig(next)
      setAliasEditing(null)
      const saved = next.bindings.find(function (b) { return b.deviceId === binding.deviceId })
      props.toast(saved && saved.alias ? '备注已保存为「' + saved.alias + '」' : '已清除备注，恢复显示对方设备名')
    } catch (err) {
      props.toast(err instanceof Error ? err.message : '保存备注失败')
    }
  }

  const identity = config ? config.identity : null
  const bindings = config ? config.bindings : []

  return (
    <Sheet title="数据同步" onClose={props.onClose}>
      <div className="field-hint" style={{ marginBottom: 12 }}>
        同一网络下优先局域网直连，跨网络自动走 P2P；数据经端到端加密，同步前自动备份，失败自动回滚。
      </div>

      {identity ? (
        <>
          <div className="field">
            <div className="field-label">本机设备名</div>
            <div style={{ display: 'flex', gap: 8 }}>
              <input
                className="input"
                value={name}
                maxLength={24}
                onChange={function (e) { setName(e.target.value) }}
              />
              <button className="btn small" disabled={busy} onClick={function () { void saveName() }}>
                保存
              </button>
            </div>
          </div>
          <div className="row">
            <div className="row-main">
              <div className="row-title">机器码</div>
              <div className="row-sub">绑定后两台设备核对这串字符，确认没连错设备</div>
            </div>
            <div className="row-value" style={{ fontFamily: 'monospace' }}>{identity.machineCode}</div>
          </div>

          <div className="section-head" style={{ marginTop: 18 }}>
            <div className="section-title">已绑定设备（{bindings.length}）</div>
          </div>
          {bindings.length ? (
            bindings.map(function (binding) {
              const presence = online[binding.deviceId]
              return (
                <div className="card sync-device-card" key={binding.deviceId} style={{ marginBottom: 10 }} data-testid="sync-binding">
                  <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 6, flexWrap: 'wrap' }}>
                    <div style={{ fontWeight: 600 }} data-testid="sync-binding-name">{bindingLabel(binding)}</div>
                    {binding.alias ? <span className="chip sync-alias-chip">备注</span> : null}
                    <span className="chip">{kindText(binding.kind)}</span>
                    <span className={'sync-online' + (presence ? (presence.online ? ' on' : ' off') : '')} data-testid="sync-online-badge">
                      {checking === binding.deviceId ? '检测中…' : presence ? (presence.online ? '在线' : '离线') : '未检测'}
                    </span>
                  </div>
                  <div className="row-sub" style={{ marginBottom: 8 }} data-testid="sync-binding-meta">
                    {binding.machineCode} · {binding.lastSyncAt ? '上次同步 ' + shortDateTime(binding.lastSyncAt) : '还没有同步过'}
                    {binding.lastSeenAt ? ' · 上次在线 ' + shortDateTime(binding.lastSeenAt) : ''}
                  </div>
                  {aliasEditing === binding.deviceId ? (
                    <div style={{ display: 'flex', gap: 6, marginBottom: 8 }}>
                      <input
                        className="input"
                        data-testid="sync-alias-input"
                        value={aliasDraft}
                        maxLength={24}
                        placeholder="备注名；留空恢复对方设备名"
                        onChange={function (e) { setAliasDraft(e.target.value) }}
                      />
                      <button className="btn small primary" data-testid="sync-alias-save" onClick={function () { void saveAlias(binding) }}>保存</button>
                      <button className="btn small ghost" onClick={function () { setAliasEditing(null) }}>取消</button>
                    </div>
                  ) : null}
                  <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                    <button className="btn small" data-testid="sync-check-online" disabled={busy || checking === binding.deviceId} onClick={function () { void checkOnline(binding.deviceId) }}>
                      {checking === binding.deviceId ? '检测中…' : '检测在线'}
                    </button>
                    <button className="btn small" data-testid="sync-alias-edit" disabled={busy} onClick={function () { beginAlias(binding) }}>添加备注</button>
                    <button className="btn small" disabled={busy} onClick={function () { askSync(binding, 'push') }}>发送数据</button>
                    <button className="btn small" disabled={busy} onClick={function () { askSync(binding, 'pull') }}>获取数据</button>
                    <button className="btn small primary" disabled={busy} onClick={function () { askSync(binding, 'merge') }}>合并数据</button>
                    <button className="btn small danger" disabled={busy} onClick={function () { askUnbind(binding) }}>解绑</button>
                  </div>
                  {binding.kind === 'desktop' ? (
                    <div className="field-hint" style={{ marginTop: 8 }}>
                      手机 ↔ 电脑同步只同步分类、条目和备注，不同步便签与提醒。
                    </div>
                  ) : null}
                </div>
              )
            })
          ) : (
            <div className="empty" style={{ padding: '18px 10px' }}>
              还没有绑定设备。让另一台设备生成二维码或邀请码，再在这里输入六位数字绑定。
            </div>
          )}

          {pairing ? (
            <div className="card" style={{ marginTop: 12, textAlign: 'center' }}>
              <div className="field-label">把这六位数字告诉对方，让对方输入后绑定</div>
              <div style={{ fontSize: 34, fontWeight: 700, letterSpacing: 8, margin: '10px 0', color: 'var(--primary-strong)' }}>
                {pairing.code}
              </div>
              {qr ? <img src={qr} alt="绑定二维码" style={{ width: 220, height: 220, borderRadius: 12, background: '#fff', padding: 6 }} /> : null}
              <textarea className="textarea" readOnly value={pairing.text} style={{ marginTop: 10, minHeight: 64, fontSize: 11 }} />
              <div style={{ display: 'flex', gap: 8, marginTop: 10 }}>
                <button
                  className="btn small"
                  onClick={function () {
                    void navigator.clipboard.writeText(pairing.text).then(function () {
                      props.toast('邀请码已复制')
                    })
                  }}
                >
                  复制邀请码
                </button>
                <button className="btn small danger" onClick={cancelPairing}>取消配对</button>
              </div>
            </div>
          ) : joinOpen ? (
            <div className="card" style={{ marginTop: 12 }}>
              <div className="field">
                <div className="field-label">对方生成的邀请码</div>
                <textarea
                  className="textarea"
                  value={joinText}
                  placeholder="把对方显示的邀请码粘贴到这里，或点「扫码」"
                  onChange={function (e) { setJoinText(e.target.value) }}
                />
              </div>
              <div className="field">
                <div className="field-label">六位数字</div>
                <input
                  className="input"
                  inputMode="numeric"
                  maxLength={6}
                  value={joinCode}
                  placeholder="例如 123456"
                  onChange={function (e) { setJoinCode(e.target.value.replace(/[^0-9]/g, '').slice(0, 6)) }}
                  style={{ letterSpacing: 4, maxWidth: 180 }}
                />
              </div>
              <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                <button className="btn primary small" disabled={busy} onClick={function () { void joinPairing() }}>确认绑定</button>
                <button className="btn small" onClick={function () { void startScan() }}>扫码</button>
                <button className="btn small ghost" onClick={function () { stopScan(); setJoinOpen(false) }}>返回</button>
              </div>
              {scanError ? <div className="field-hint" style={{ marginTop: 8 }}>相机打不开：{scanError}</div> : null}
            </div>
          ) : (
            <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginTop: 12 }}>
              <button className="btn small primary" disabled={busy} onClick={function () { void beginPairing() }}>绑定新设备</button>
              <button className="btn small" disabled={busy} onClick={function () { setJoinOpen(true) }}>输入邀请码绑定</button>
              <button className="btn small" disabled={busy} onClick={function () { void startScan() }}>扫码绑定</button>
            </div>
          )}

          {progress ? <div className="field-hint" style={{ marginTop: 10 }}>{progress}</div> : null}
          {busy ? <div className="field-hint" style={{ marginTop: 10 }}>正在处理，请两台设备都保持 GuiN 打开…</div> : null}
        </>
      ) : (
        <div className="empty" style={{ padding: '24px 10px' }}>同步服务正在启动…</div>
      )}

      {scanning
        ? createPortal(
            <div className="scan-overlay">
              <div className="scan-panel">
                <div className="scan-head">
                  <div>
                    <div className="scan-title">扫码绑定</div>
                    <div className="scan-sub">对准对方「生成二维码」的页面</div>
                  </div>
                  <button className="scan-close" aria-label="关闭扫码" onClick={function () { stopScan() }}>
                    ×
                  </button>
                </div>
                <div className="scan-stage">
                  <video ref={videoRef} className="scan-video" playsInline muted />
                  <div className="scan-mask">
                    <div className="scan-frame">
                      <span className="scan-line" />
                    </div>
                  </div>
                  {scanError ? <div className="scan-error">{scanError}</div> : null}
                </div>
                <div className="scan-tip">把二维码放进框里，识别后会自动填入邀请码</div>
                <div className="scan-foot">
                  <button
                    className={cn('btn', torchOn && 'primary')}
                    disabled={!torchSupported}
                    onClick={function () { void toggleTorch() }}
                  >
                    {torchSupported ? (torchOn ? '关闭手电筒' : '打开手电筒') : '手电筒不可用'}
                  </button>
                  <button className="btn primary" onClick={function () { stopScan() }}>
                    取消扫码
                  </button>
                </div>
              </div>
            </div>,
            document.body
          )
        : null}
    </Sheet>
  )
}
