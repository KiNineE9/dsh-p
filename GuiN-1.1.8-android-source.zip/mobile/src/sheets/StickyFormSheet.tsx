import { useState } from 'react'
import type { AppState, RepeatKind, StickyKind, StickyNote } from '../../../src/shared/types'
import { REPEAT_LABELS } from '../../../src/shared/repeat'
import { formatLocalInput, isoFromLocalInput, localInputFromIso, minutesLater, tomorrowMorning } from '../helpers'
import { addSystemAlarm } from '../bridge'
import { store } from '../store'
import { Field, Seg, Sheet, Switch } from '../ui'

type RepeatChoice = 'none' | RepeatKind

export function StickyFormSheet(props: {
  state: AppState
  stickyId?: string
  initialKind: StickyKind
  onClose: () => void
  toast: (message: string) => void
}) {
  const editing = props.state.stickies.find(function (s) { return s.id === props.stickyId })
  const [kind, setKind] = useState<StickyKind>(editing ? editing.kind : props.initialKind)
  const [title, setTitle] = useState(editing ? editing.title || '' : '')
  const [content, setContent] = useState(editing ? editing.content : '')
  const [pinned, setPinned] = useState(editing ? editing.pinned : false)
  const [repeat, setRepeat] = useState<RepeatChoice>(editing && editing.repeat ? editing.repeat.kind : 'none')
  const [repeatTime, setRepeatTime] = useState(editing && editing.repeat ? editing.repeat.time : '09:00')
  const [remindLocal, setRemindLocal] = useState(function () {
    if (editing && editing.remindAt) return localInputFromIso(editing.remindAt)
    return minutesLater(60)
  })
  const [status, setStatus] = useState<'pending' | 'done'>(editing ? editing.status : 'pending')
  const [contentError, setContentError] = useState('')
  const [titleError, setTitleError] = useState('')

  function save(importAlarm?: boolean): void {
    if (!content.trim()) {
      setContentError('写点什么吧，内容不能为空')
      return
    }
    setContentError('')
    if (kind === 'reminder' && !title.trim()) {
      setTitleError('提醒便签需要填标题，方便在通知里一眼看到')
      return
    }
    setTitleError('')
    if (kind === 'note') {
      const op = editing
        ? store.updateSticky(editing.id, {
            title: title.trim() || undefined,
            content: content.trim(),
            kind: 'note',
            pinned: pinned,
            remindAt: null,
            repeat: null,
            status: status
          })
        : store.createSticky({ content: content.trim(), title: title.trim() || undefined, kind: 'note', pinned: pinned })
      finish(op.ok ? '' : op.error)
      return
    }
    let remindAt: string | null = null
    if (repeat !== 'none') {
      const [hourText, minuteText] = repeatTime.split(':')
      const next = new Date()
      next.setHours(Number(hourText) || 9, Number(minuteText) || 0, 0, 0)
      if (next.getTime() <= Date.now()) next.setDate(next.getDate() + 1)
      remindAt = next.toISOString()
    } else {
      remindAt = isoFromLocalInput(remindLocal)
      if (!remindAt) {
        props.toast('请选择提醒时间')
        return
      }
    }
    const patch = {
      title: title.trim() || undefined,
      content: content.trim(),
      kind: 'reminder' as const,
      pinned: false,
      remindAt: remindAt,
      repeat: repeat === 'none' ? null : { kind: repeat, time: repeatTime },
      status: status
    }
    const op = editing ? store.updateSticky(editing.id, patch) : store.createSticky(patch)
    if (!op.ok) {
      props.toast(op.error)
      return
    }
    if (importAlarm) {
      const at = Date.parse(remindAt)
      if (Number.isFinite(at)) {
        // guided 表示这台手机的时钟在静默导入时会丢重复规则，改成打开时钟让用户确认
        const alarmMode = addSystemAlarm(title.trim(), at, repeat === 'none' ? '' : repeat)
        props.onClose()
        props.toast(repeat !== 'none' && alarmMode === 'guided'
          ? '已保存；请在时钟应用确认「重复」后点保存'
          : '已保存，并导入到系统闹钟')
        return
      }
    }
    finish('')
  }

  function finish(error: string): void {
    if (error) {
      props.toast(error)
      return
    }
    props.onClose()
    props.toast(editing ? '已保存修改' : kind === 'note' ? '便签已创建' : '提醒已创建')
  }

  const isReminder = kind === 'reminder'

  return (
    <Sheet
      title={editing ? '编辑便签' : isReminder ? '新建提醒便签' : '新建便签'}
      onClose={props.onClose}
      footer={
        <>
          <button className="btn ghost" onClick={props.onClose}>
            取消
          </button>
          {isReminder ? (
            <button className="btn" onClick={function () { save(true) }}>
              保存并导入闹钟
            </button>
          ) : null}
          <button className="btn primary" onClick={function () { save(false) }}>
            保存
          </button>
        </>
      }
    >
      <Field label="类型">
        <Seg
          value={kind}
          options={[
            { value: 'note', label: '便签' },
            { value: 'reminder', label: '提醒便签' }
          ]}
          onChange={function (next) {
            setKind(next)
            if (next === 'note') setPinned(pinned)
          }}
        />
      </Field>

      <Field
        label="标题"
        required={isReminder}
        error={titleError}
        hint={isReminder ? '提醒便签必填，最多 60 个字' : '选填，最多 60 个字'}
      >
        <input
          className="input"
          value={title}
          maxLength={60}
          placeholder={isReminder ? '例如：吃药' : '例如：明天吃饭记得订位'}
          onChange={function (e) { setTitle(e.target.value) }}
        />
      </Field>

      <Field label="内容" required error={contentError}>
        <textarea
          className="textarea"
          value={content}
          placeholder="写清楚一点，比如「周五前把体检报告拍照发给妈妈」"
          onChange={function (e) { setContent(e.target.value) }}
        />
      </Field>

      {!isReminder ? (
        <div className="row" style={{ borderBottom: 'none' }}>
          <div className="row-main">
            <div className="row-title">置顶这张便签</div>
            <div className="row-sub">置顶后会排在便签最前面</div>
          </div>
          <Switch on={pinned} onChange={setPinned} />
        </div>
      ) : (
        <div>
          <Field label="提醒方式">
            <Seg
              value={repeat === 'none' ? 'once' : 'repeat'}
              options={[
                { value: 'once', label: '一次性' },
                { value: 'repeat', label: '循环提醒' }
              ]}
              onChange={function (next) {
                if (next === 'repeat') setRepeat('daily')
                else setRepeat('none')
              }}
            />
          </Field>

          {repeat === 'none' ? (
            <div>
              <Field label="提醒时间">
                <input
                  className="input"
                  type="datetime-local"
                  value={remindLocal}
                  onChange={function (e) { setRemindLocal(e.target.value) }}
                />
              </Field>
              <div className="chips" style={{ marginTop: -6, marginBottom: 14 }}>
                <button className="chip" onClick={function () { setRemindLocal(minutesLater(10)) }}>
                  10 分钟后
                </button>
                <button className="chip" onClick={function () { setRemindLocal(minutesLater(60)) }}>
                  1 小时后
                </button>
                <button className="chip" onClick={function () { setRemindLocal(tomorrowMorning()) }}>
                  明天上午 9 点
                </button>
              </div>
            </div>
          ) : (
            <div>
              <Field label="循环规则">
                <Seg
                  value={repeat as RepeatKind}
                  options={(['daily', 'weekdays', 'weekends'] as RepeatKind[]).map(function (k) {
                    return { value: k, label: REPEAT_LABELS[k] }
                  })}
                  onChange={function (next) { setRepeat(next) }}
                />
              </Field>
              <Field label="提醒时间" hint="按手机本地时间，到点发通知">
                <input
                  className="input"
                  type="time"
                  value={repeatTime}
                  onChange={function (e) { setRepeatTime(e.target.value) }}
                />
              </Field>
            </div>
          )}
        </div>
      )}

      {editing ? (
        <Field label="状态">
          <Seg
            value={status}
            options={[
              { value: 'pending', label: '待办' },
              { value: 'done', label: '已完成' }
            ]}
            onChange={function (next) { setStatus(next) }}
          />
        </Field>
      ) : null}
      <div className="field-hint" style={{ marginTop: 4 }}>
        {isReminder ? '到点会发系统通知；点「稍后提醒」会延后 10 分钟。' : '便签不会提醒，只用来记事和置顶。'}
      </div>
      <div style={{ height: 6 }} />
    </Sheet>
  )
}
