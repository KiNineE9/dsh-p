import { useState } from 'react'
import type { AppState, Item } from '../../../src/shared/types'
import { getFormSchema } from '../../../src/shared/schema'
import { formatLocation } from '../../../src/shared/schema'
import { daysUntil, expiryLevel } from '../../../src/shared/search'
import { formatDate, locationOf, shortDateTime } from '../helpers'
import { store } from '../store'
import { EmptyState, Field, Sheet } from '../ui'

function fieldText(item: Item, key: string): string {
  if (key.indexOf('custom.') === 0) {
    const custom = item.fields.custom || {}
    return custom[key.slice(7)] || ''
  }
  const value = (item.fields as unknown as Record<string, unknown>)[key]
  if (value === undefined || value === null || value === '') return ''
  if (typeof value === 'boolean') return value ? '是' : '否'
  return String(value)
}

export function ItemDetailSheet(props: {
  state: AppState
  item: Item
  onClose: () => void
  onEdit: () => void
  toast: (message: string) => void
  confirm: (opts: { title: string; body?: string; okText?: string; danger?: boolean; onOk: () => void }) => void
}) {
  const category = props.state.categories.find(function (c) { return c.id === props.item.categoryId })
  const schema = category ? getFormSchema(category.baseTemplate, category.customFields) : null
  const notes = props.state.notes
    .filter(function (n) { return n.itemId === props.item.id })
    .slice()
    .sort(function (a, b) { return Date.parse(b.createdAt) - Date.parse(a.createdAt) })
  const [noteText, setNoteText] = useState('')
  const [editingNote, setEditingNote] = useState<string | null>(null)
  const days = props.item.fields.expiresAt ? daysUntil(props.item.fields.expiresAt) : null
  const level = days === null ? null : expiryLevel(days)

  function addNote(): void {
    const op = store.addNote(props.item.id, noteText)
    if (!op.ok) {
      props.toast(op.error)
      return
    }
    setNoteText('')
    props.toast('备注已添加')
  }

  function saveNoteEdit(id: string): void {
    const op = store.updateNote(id, noteText)
    if (!op.ok) {
      props.toast(op.error)
      return
    }
    setEditingNote(null)
    setNoteText('')
    props.toast('备注已更新')
  }

  return (
    <Sheet
      title={category ? category.name : '条目'}
      onClose={props.onClose}
      footer={
        <>
          <button className="btn ghost" onClick={props.onEdit}>
            编辑
          </button>
          <button
            className="btn danger"
            onClick={function () {
              props.confirm({
                title: '删除「' + props.item.name + '」？',
                body: '条目和它的备注、到期提醒记录都会一起删除。',
                okText: '删除',
                danger: true,
                onOk: function () {
                  const op = store.deleteItem(props.item.id)
                  if (!op.ok) props.toast(op.error)
                  else {
                    props.toast('已删除')
                    props.onClose()
                  }
                }
              })
            }}
          >
            删除
          </button>
        </>
      }
    >
      <div className="detail-title">{props.item.name}</div>
      <div className="detail-meta">
        <span className="loc-tag">{props.item.locationType === 'container' ? '容器' : '地点'}</span>
        <span>{locationOf(props.item)}</span>
        {days !== null && level ? (
          <span className={'expiry-pill level-' + level}>
            {days < 0 ? '已过期 ' + Math.abs(days) + ' 天' : days === 0 ? '今天到期' : '还剩 ' + days + ' 天'}
          </span>
        ) : null}
      </div>

      <div className="card" style={{ paddingTop: 4, paddingBottom: 4 }}>
        <div className="kv">
          <div className="kv-key">存放位置</div>
          <div className="kv-val">{formatLocation(props.item.locationLabel, props.item.locationName)}</div>
        </div>
        {schema
          ? schema.fields.map(function (f) {
              const text = fieldText(props.item, f.key)
              return (
                <div className="kv" key={f.key}>
                  <div className="kv-key">{f.label}</div>
                  <div className="kv-val">{f.type === 'date' && text ? formatDate(text) : text || '—'}</div>
                </div>
              )
            })
          : null}
        <div className="kv">
          <div className="kv-key">更新时间</div>
          <div className="kv-val">{shortDateTime(props.item.updatedAt)}</div>
        </div>
      </div>

      <section className="section">
        <div className="section-head">
          <div className="section-title">备注</div>
          <span className="section-sub">{notes.length} 条</span>
        </div>
        {notes.length ? (
          notes.map(function (note) {
            return (
              <div className="note-item" key={note.id}>
                {editingNote === note.id ? (
                  <div>
                    <textarea
                      className="textarea"
                      value={noteText}
                      onChange={function (e) { setNoteText(e.target.value) }}
                    />
                    <div className="chips" style={{ marginTop: 8, justifyContent: 'flex-end' }}>
                      <button className="btn small ghost" onClick={function () { setEditingNote(null); setNoteText('') }}>
                        取消
                      </button>
                      <button className="btn small primary" onClick={function () { saveNoteEdit(note.id) }}>
                        保存
                      </button>
                    </div>
                  </div>
                ) : (
                  <div>
                    <div>{note.content}</div>
                    <div className="note-time">{shortDateTime(note.updatedAt)}</div>
                    <div className="chips" style={{ marginTop: 6, justifyContent: 'flex-end' }}>
                      <button
                        className="mini-btn"
                        onClick={function () {
                          setEditingNote(note.id)
                          setNoteText(note.content)
                        }}
                      >
                        编辑
                      </button>
                      <button
                        className="mini-btn danger"
                        onClick={function () {
                          const op = store.deleteNote(note.id)
                          if (!op.ok) props.toast(op.error)
                          else props.toast('备注已删除')
                        }}
                      >
                        删除
                      </button>
                    </div>
                  </div>
                )}
              </div>
            )
          })
        ) : (
          <EmptyState text="还没有备注，记一句「充电器在抽屉最里面」也不怕忘。" />
        )}
        <Field label="添加备注">
          <textarea
            className="textarea"
            style={{ minHeight: 72 }}
            value={noteText}
            placeholder="例如：说明书放在同一层，充电线在袋子里"
            onChange={function (e) { setNoteText(e.target.value) }}
          />
        </Field>
        <button className="btn block primary" disabled={!noteText.trim()} onClick={addNote}>
          添加备注
        </button>
      </section>
    </Sheet>
  )
}
