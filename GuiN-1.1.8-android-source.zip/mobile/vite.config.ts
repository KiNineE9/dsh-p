import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// 手机端 Web 层：构建产物直接放进 Android 壳的 assets/web，由 WebView 以 https://app.local/ 加载。
export default defineConfig({
  root: 'mobile',
  base: './',
  plugins: [react()],
  build: {
    outDir: '../android/app/src/main/assets/web',
    emptyOutDir: true,
    target: 'chrome100',
    assetsDir: 'assets',
    chunkSizeWarningLimit: 2000
  },
  server: { port: 5180, host: '127.0.0.1' }
})
